module.exports = config => { require('ui-salad/karma')(config); }; // eslint-disable-line global-require
