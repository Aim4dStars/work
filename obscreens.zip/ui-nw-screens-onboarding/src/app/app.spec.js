import AppModule from './app';

describe('app module test', () => {
  it('should export nw.onboarding', () => {
    expect(AppModule.name).to.eq('nw.onboarding');
  });
});
