import template from './offlinePrint.html';
import controller from './offlinePrint.controller';
import './offlinePrint.scss';

const offlinePrintComponent = {
  bindings: {
    applicationDetails: '<',
    schemaEnums: '<',
    staticData: '<',
    tncsLongContent: '<',
    tncsConfirmationContent: '<',
    logoDetails: '<',
  },
  template,
  controller,
};

export default offlinePrintComponent;
