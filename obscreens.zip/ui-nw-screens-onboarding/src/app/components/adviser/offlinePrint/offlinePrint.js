import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import offlinePrintComponent from './offlinePrint.component';
import offlinePrintService from './offlinePrint.service';

const offlinePrintModule = angular.module('nw.onboarding.adviser.offlinePrint', [
  uiRouter,
  'nw.onboarding.common.viewApplication',
  'nw.onboarding.common.api',
  'nw.onboarding.common.cms',
  'nw.onboarding.common.filters',
  'nw.core.common.permissions',
])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.adviser.offlinePrint', {
        url: '/offline-print?id&accountNumber&accountType&parentProdName',
        component: 'nw.onboarding.adviser.offlinePrint.offlinePrintComponent',
        resolve: {
          applicationDetails: ['nw.onboarding.adviser.offlinePrint.offlinePrintService', '$stateParams', (service, $stateParams) =>
            service.getApplicationDetails($stateParams.id, $stateParams.accountNumber),
          ],
          tncsLongContent: ['nw.onboarding.adviser.offlinePrint.offlinePrintService', '$stateParams', (service, $stateParams) =>
            service.getLongTncsFromCms($stateParams.accountType, $stateParams.parentProdName),
          ],
          tncsConfirmationContent: ['nw.onboarding.adviser.offlinePrint.offlinePrintService', '$stateParams', (service, $stateParams) =>
            service.getConfirmationTncsFromCms($stateParams.accountType, $stateParams.parentProdName),
          ],
          schemaEnums: ['nw.onboarding.common.api.schemaEnums', schemaService => schemaService.getSchemaEnums()],
          staticData: ['nw.onboarding.common.api.static', staticDataService => staticDataService.getStaticData('states'),
          ],
          logoDetails: ['nw.core.common.api.user', userService => userService.getLogoDetails()],
        },
      });
  })

  .component('nw.onboarding.adviser.offlinePrint.offlinePrintComponent', offlinePrintComponent)

  .service('nw.onboarding.adviser.offlinePrint.offlinePrintService', offlinePrintService);

export default offlinePrintModule;
