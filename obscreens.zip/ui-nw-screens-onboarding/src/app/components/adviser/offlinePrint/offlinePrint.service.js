import get from 'lodash/get';

class OfflinePrintService {
  constructor($http, cmsService) {
    this.$http = $http;
    this.cmsService = cmsService;
  }

  getApplicationDetails(id, accountNumber) {
    let url;
    if (accountNumber) {
      url = `../api/v1_0/draft_accounts/${accountNumber}/approvals`;
    } else {
      url = `../api/v1_0/draft_accounts/client_application?id=${id}`;
    }

    return this.$http.get(url)
      .then(res => get(res, 'data.data'));
  }

  getLongTncsFromCms(accountType, parentProductName) {
    const url = '/termsandconditions/onboarding/advised-investor';
    let htmlSource;
    if (parentProductName === 'Cash Management Account') {
      switch (accountType) {
        case 'newIndividualSMSF':
          htmlSource = 'terms-and-conditions-cash-management-account-individual-smsf-fe';
          break;
        case 'newCorporateSMSF':
          htmlSource = 'terms-and-conditions-cash-management-account-corporate-smsf-fe';
          break;
        default:
          htmlSource = 'terms-and-conditions-cash-management-account';
          break;
      }
    } else {
      switch (accountType) {
        case 'superAccumulation':
          htmlSource = 'terms-and-conditions-super-and-pension';
          break;
        case 'superPension':
          htmlSource = 'terms-and-conditions-super-and-pension';
          break;
        case 'newIndividualSMSF':
          htmlSource = 'terms-and-conditions-individual-smsf-fund-establishment';
          break;
        case 'newCorporateSMSF':
          htmlSource = 'terms-and-conditions-corporate-smsf-fund-establishment';
          break;
        default:
          htmlSource = 'terms-and-conditions-all-account-types';
          break;
      }
    }

    return this.cmsService.fetchCmsContent(url, htmlSource);
  }

  getConfirmationTncsFromCms(accountType, parentProductName) {
    const url = '/termsandconditions/onboarding/advised-investor';
    let htmlSource;
    if (parentProductName === 'Cash Management Account') {
      switch (accountType) {
        case 'newIndividualSMSF':
          htmlSource = 'offline-ts-and-cs-cma-individual-smsf-fe-confirmation';
          break;
        case 'newCorporateSMSF':
          htmlSource = 'offline-ts-and-cs-cma-corporate-smsf-fe-confirmation';
          break;
        default:
          htmlSource = 'offline-ts-and-cs-cma-confirmation';
          break;
      }
    } else {
      switch (accountType) {
        case 'superAccumulation':
          htmlSource = 'offline-ts-and-cs-super-pension-confirmation';
          break;
        case 'superPension':
          htmlSource = 'offline-ts-and-cs-super-pension-confirmation';
          break;
        case 'newIndividualSMSF':
          htmlSource = 'offline-ts-and-cs-individual-smsf-fe-confirmation';
          break;
        case 'newCorporateSMSF':
          htmlSource = 'offline-ts-and-cs-corporate-smsf-fe-confirmation';
          break;
        default:
          htmlSource = 'offline-ts-and-cs-all-account-types-confirmation';
          break;
      }
    }

    return this.cmsService.fetchCmsContent(url, htmlSource);
  }
}

OfflinePrintService.$inject = ['$http', 'nw.onboarding.common.cms.cmsService'];

export default OfflinePrintService;
