import angular from 'angular';
import OfflinePrintModule from './offlinePrint';
import OfflinePrintController from './offlinePrint.controller';
import OfflinePrintComponent from './offlinePrint.component';
import OfflinePrintTemplate from './offlinePrint.html';
import { accountTypeToAccountNameMap } from '../../../helper/utilities';

describe('OfflinePrint', () => {
  let $rootScope;
  let $componentController;
  let controller;
  let service;
  let $httpBackend;
  let schemaService;
  let staticDataService;
  let userService;
  let $state;

  // load the module

  beforeEach(() => {
    window.module('ui.router');
    window.module($stateProvider => {
      $stateProvider.state('app', { url: '/app' });
      $stateProvider.state('app.adviser', { url: '/adviser' });
    });
    window.module(OfflinePrintModule.name);
  });

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $httpBackend = $injector.get('$httpBackend');
    service = $injector.get('nw.onboarding.adviser.offlinePrint.offlinePrintService');
    schemaService = $injector.get('nw.onboarding.common.api.schemaEnums');
    staticDataService = $injector.get('nw.onboarding.common.api.static');
    userService = $injector.get('nw.core.common.api.user');
    $state = $injector.get('$state');
  }));

  describe('Module', () => {
    const component = OfflinePrintComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(OfflinePrintTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(OfflinePrintController);
    });

    it('should call getSchemaEnums, getStaticData, getApplicationDetails, getConfirmationTncsFromCms, getLongTncsFromCms on transition to state', () => {
      schemaService.getSchemaEnums = sinon.spy();
      staticDataService.getStaticData = sinon.spy();
      userService.getLogoDetails = sinon.spy();
      service.getApplicationDetails = sinon.spy();
      service.getLongTncsFromCms = sinon.spy();
      service.getConfirmationTncsFromCms = sinon.spy();
      $state.go('app.adviser.offlinePrint', { id: '123456', accountNumber: 'ABCDEF' });
      $rootScope.$digest();
      expect(schemaService.getSchemaEnums).to.have.been.called;
      expect(staticDataService.getStaticData).to.have.been.called;
      expect(service.getApplicationDetails).to.have.been.called;
      expect(service.getLongTncsFromCms).to.have.been.called;
      expect(service.getConfirmationTncsFromCms).to.have.been.called;
      expect(userService.getLogoDetails).to.have.been.called;
    });

    it('should call getSchemaEnums, getStaticData, getApplicationDetails, getConfirmationTncsFromCms with parentProdName as cma, getLongTncsFromCms with parentProdName as cma on transition to state', () => {
      schemaService.getSchemaEnums = sinon.spy();
      staticDataService.getStaticData = sinon.spy();
      service.getApplicationDetails = sinon.spy();
      service.getLongTncsFromCms = sinon.spy();
      service.getConfirmationTncsFromCms = sinon.spy();
      userService.getLogoDetails = sinon.spy();
      $state.go('app.adviser.offlinePrint', {
        id: '123456', accountNumber: 'ABCDEF', accountType: 'anyaccounttype', parentProdName: 'Cash Management Account',
      });
      $rootScope.$digest();
      expect(schemaService.getSchemaEnums).to.have.been.called;
      expect(staticDataService.getStaticData).to.have.been.called;
      expect(service.getApplicationDetails).to.have.been.called;
      expect(service.getLongTncsFromCms).to.have.been.calledWith('anyaccounttype', 'Cash Management Account');
      expect(service.getConfirmationTncsFromCms).to.have.been.calledWith('anyaccounttype', 'Cash Management Account');
      expect(userService.getLogoDetails).to.have.been.called;
    });
  });

  describe('Service', () => {
    let res;
    const baseTcUrl = '/content/public/panorama/termsandconditions/onboarding/advised-investor';
    const data = { data: { property: 'testData' }, source: { property: 'testData' } };

    it('getApplicationDetails should call /draft_accounts/<client_application?id=id', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/draft_accounts/client_application?id=123456').respond(data);
      service.getApplicationDetails('123456').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getApplicationDetails should call /draft_accounts/<acctNumber>/approvals if account number is defined', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/draft_accounts/ABCDEFG/approvals').respond(data);
      service.getApplicationDetails('23', 'ABCDEFG').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-all-account-types.htmlsource.json if accounttype is IDPS', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-all-account-types.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('individual').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-individual-smsf-fund-establishment.htmlsource.json if accounttype is newIndividualSMSF', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-individual-smsf-fund-establishment.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('newIndividualSMSF').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-corporate-smsf-fund-establishment.htmlsource.json if accounttype is newCorporateSMSF', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-corporate-smsf-fund-establishment.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('newCorporateSMSF').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-super-and-pension.htmlsource.json if accounttype is any super account', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-super-and-pension.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('superPension').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-super-and-pension.htmlsource.json if accounttype is any super', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-super-and-pension.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('superAccumulation').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cash-management-account.htmlsource.json if parentProductName is Cash Management Account (any accounttype except Ind or Corp SMSF)', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-cash-management-account.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('nonIndCorpAccounttype', 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cash-management-account-corporate-smsf-fe.htmlsource.json if parentProductName is Cash Management Account (and accounttype Corp SMSF)', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-cash-management-account-corporate-smsf-fe.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('newCorporateSMSF', 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getLongTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cash-management-account-individual-smsf-fe.htmlsource.json if parentProductName is Cash Management Account (and accounttype Ind SMSF)', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/terms-and-conditions-cash-management-account-individual-smsf-fe.htmlsource.json`).respond(data);
      service.getLongTncsFromCms('newIndividualSMSF', 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-all-account-types-confirmation.htmlsource.json if accounttype is IDPS', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-all-account-types-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('individual').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-individual-smsf-fe-confirmation.htmlsource.json if accounttype is newIndividualSMSF', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-individual-smsf-fe-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('newIndividualSMSF').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-corporate-smsf-fe-confirmation.htmlsource.json if accounttype is newCorporateSMSF', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-corporate-smsf-fe-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('newCorporateSMSF').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-super-pension-confirmation.htmlsource.json if accounttype is any super account', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-super-pension-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('superPension').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-super-pension-confirmation.htmlsource.json if accounttype is any super', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-super-pension-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('superAccumulation').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-cma-confirmation.htmlsource.json if parentProductName is Cash Management Account (any accounttype except Ind or Corp SMSF)', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-cma-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('nonIndCorpAccounttype', 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-cma-corporate-smsf-fe-confirmation.htmlsource.json if parentProductName is Cash Management Account (and accounttype Corp SMSF)', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-cma-corporate-smsf-fe-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('newCorporateSMSF', 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getConfirmationTncsFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/offline-ts-and-cs-cma-individual-smsf-fe-confirmation.htmlsource.json if parentProductName is Cash Management Account (and accounttype Individual SMSF)', () => {
      $httpBackend.whenGET(u => u === `${baseTcUrl}/offline-ts-and-cs-cma-individual-smsf-fe-confirmation.htmlsource.json`).respond(data);
      service.getConfirmationTncsFromCms('newIndividualSMSF', 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });
  });

  describe('Controller', () => {
    let $resolve;

    beforeEach(() => {
      $resolve = { // mock resolved data
        applicationDetails: {
          accountName: 'Angela Smith', adviser: { fullName: 'Rob Bailey', email: [{ email: 'Dummy@BTFinancialGroup.com' }], phone: [{ number: '123456789' }] }, investorAccountType: 'joint', productName: 'White Label', referenceNumber: 'R00012',
        },
        schemaEnums:
          {
            AccountTypeEnum:
            {
              INDIVIDUAL: 'individual',
              JOINT: 'joint',
              COMPANY: 'company',
              INDIVIDUAL_TRUST: 'individualTrust',
              CORPORATE_TRUST: 'corporateTrust',
              NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
              NEW_CORPORATE_SMSF: 'newCorporateSMSF',
              INDIVIDUAL_SMSF: 'individualSMSF',
              CORPORATE_SMSF: 'corporateSMSF',
              SUPER_ACCUMULATION: 'superAccumulation',
              SUPER_PENSION: 'superPension',
            },
          },
        staticData:
          {
            states: [
              {
                value: 'NSW',
                label: 'New South Wales',
              },
              {
                value: 'QLD',
                label: 'Queensland',
              },
            ],
          },
      };
      controller = $componentController('nw.onboarding.adviser.offlinePrint.offlinePrintComponent', { $scope: $rootScope.$new() }, $resolve);
    });

    describe('$onInit', () => {
      it('should be initilised with proper data', () => {
        controller.setAccountSummaryName = sinon.spy();
        controller.setAdviserContactDetails = sinon.spy();
        controller.setPrimaryContactDetails = sinon.spy();
        controller.setApplicationIssueDate = sinon.spy();
        controller.handleDynamicDataForConfirmation = sinon.spy();
        controller.$onInit();
        expect(controller.model.applicationDetails).to.equal($resolve.applicationDetails);
        expect(controller.accountType).to.equal(controller.schemaEnums.AccountTypeEnum.JOINT);
        expect(controller.model.accountFullName).to.equal(accountTypeToAccountNameMap[controller.schemaEnums.AccountTypeEnum.JOINT]);
        expect(controller.setAccountSummaryName).to.have.been.called;
        expect(controller.setAdviserContactDetails).to.have.been.called;
        expect(controller.setPrimaryContactDetails).to.have.been.called;
        expect(controller.setApplicationIssueDate).to.have.been.called;
        expect(controller.handleDynamicDataForConfirmation).to.have.been.called;
      });
    });

    describe('setAccountSummaryName', () => {
      it('should set preper account summary name for display', () => {
        controller.setAccountSummaryName();
        expect(controller.model.accountSummaryName).to.equal('Joint account • White Label • R00012');
      });
    });

    describe('setApplicationIssueDate', () => {
      it('should set ApplicationIssueDate  for display from response', () => {
        controller.applicationDetails.applicationOpenDate = '2016-12-06T13:00:00.000Z';
        controller.setApplicationIssueDate();
        expect(controller.model.applicationIssueDate).to.equal('2016-12-06T13:00:00.000Z');
      });

      it('should set ApplicationIssueDate  for display as today date if not present in response', () => {
        controller.applicationDetails.applicationOpenDate = null;
        controller.setApplicationIssueDate();
        expect(controller.model.applicationIssueDate).not.to.be.undefined;
      });
    });

    describe('setAdviserContactDetails', () => {
      const primaryPhone = {
        preferred: true,
        number: '0415657899',
        phoneType: 'Primary',
        type: 'Phone',
      };

      const workPhone = {
        preferred: false,
        number: '0298657899',
        phoneType: 'Work',
        type: 'Phone',
      };

      const adviser = {
        email: [
          {
            email: 'adviser7@mail.com',
            preferred: false,
            emailType: 'Primary',
            type: 'Email',
          },
        ],
        phone: [
          primaryPhone,
        ],
        corporateName: 'OR AdviserSeven FN AdviserSeven LN',
        dealerGroupName: 'My dealer group',
      };

      it('shoulld set the advise related info for pint document display', () => {
        controller.applicationDetails.adviser = adviser;
        controller.setAdviserContactDetails();
        expect(controller.model.adviserPrimaryEmail).to.equal('adviser7@mail.com');
        expect(controller.model.adviserWorkPhone).to.equal(null);
        expect(controller.model.adviserPrimaryPhone).to.equal('0415657899');
        expect(controller.model.adviserCorporateName).to.equal('OR AdviserSeven FN AdviserSeven LN');
        expect(controller.model.adviserDealerGroup).to.equal('My dealer group');
      });

      it('shoulld set the advise related info when work phone is present', () => {
        adviser.phone.push(workPhone);
        controller.applicationDetails.adviser = adviser;
        controller.setAdviserContactDetails();
        expect(controller.model.adviserWorkPhone).to.equal('0298657899');
      });
    });

    describe('setPrimaryContactDetails', () => {
      const accountSettingWithClientkey =
                            {
                              clientKey: {
                                clientId: '456DEF',
                              },
                              name: 'AA CC',
                              approver: true,
                              adviser: false,
                              primaryContactPerson: true,
                            };

      const accountSettingWithNameMatch =
                            {
                              clientKey: null,
                              name: 'AA CC',
                              approver: false,
                              adviser: false,
                              primaryContactPerson: true,
                            };

      const investorDetailstWithClientkey =
                            {
                              key: {
                                clientId: '456DEF',
                              },
                              fullName: 'AA BB CC',
                              firstName: 'AA',
                              middleName: 'BB',
                              lastName: 'CC',
                              addresses: [
                                {
                                  streetName: 'StreetName',
                                  building: 'Building',
                                  city: 'City',
                                  postcode: '1012',
                                  country: 'Aland Island',
                                  domicile: true,
                                  mailingAddress: false,
                                },
                                {
                                  streetName: 'StreetName',
                                  building: 'Building',
                                  city: 'City',
                                  postcode: '1012',
                                  country: 'Aland Island',
                                  domicile: false,
                                  mailingAddress: true,
                                },
                              ],
                              emails: [
                                {
                                  email: 'deepaky@gmail.com',
                                  preferred: false,
                                  emailType: 'Primary',
                                },
                              ],
                              phones: [
                                {
                                  number: '0414111222',
                                  phoneType: 'Primary',
                                },
                              ],
                            };

      const investorDetailstWithoutClientkey =
                           {
                             key: null,
                             fullName: 'AA BB CC',
                             firstName: 'AA',
                             lastName: 'CC',
                             addressesV2: [
                               {
                                 addressDisplayText: '33 Pitt Road, SOUTH NANANGO  QLD  4615',
                                 addressType: 'RESIDENTIAL',
                               },
                               {
                                 addressDisplayText: '33 Pitt Road, SOUTH NANANGO  QLD  4615',
                                 addressType: 'PLACEOFBUSINESS',
                               },
                             ],
                             emails: [
                               {
                                 email: 'deepaky@gmail.com',
                                 preferred: false,
                                 emailType: 'Primary',
                               },
                             ],
                             phones: [
                               {
                                 number: '0414111222',
                                 phoneType: 'Primary',
                               },
                             ],
                           };

      it('should set primary contact details to be displayed in fat footer based off client key match from investor', () => {
        controller.applicationDetails.accountSettings = { personRelations: [accountSettingWithNameMatch] };
        controller.applicationDetails.investors = [investorDetailstWithClientkey];
        controller.setPrimaryContactDetails();
        expect(controller.model.primaryContactNumber).to.equal('0414111222');
        expect(controller.model.domicileAddress).to.equal('StreetName Building City 1012 Aland Island');
        expect(controller.model.primaryContactName).to.equal('AA CC');
      });

      it('should set primary contact details to be displayed in fat footer based off client key match from directors', () => {
        controller.applicationDetails.accountSettings = { personRelations: [accountSettingWithNameMatch] };
        controller.applicationDetails.directors = [investorDetailstWithClientkey];
        controller.setPrimaryContactDetails();
        expect(controller.model.primaryContactNumber).to.equal('0414111222');
        expect(controller.model.domicileAddress).to.equal('StreetName Building City 1012 Aland Island');
        expect(controller.model.primaryContactName).to.equal('AA CC');
      });

      it('should set primary contact details to be displayed in fat footer based off name match from investors and addressesV2 present', () => {
        controller.applicationDetails.accountSettings = { personRelations: [accountSettingWithClientkey] };
        controller.applicationDetails.investors = [investorDetailstWithoutClientkey];
        controller.setPrimaryContactDetails();
        expect(controller.model.primaryContactNumber).to.equal('0414111222');
        expect(controller.model.domicileAddress).to.equal('33 Pitt Road, SOUTH NANANGO  QLD  4615');
        expect(controller.model.primaryContactName).to.equal('AA CC');
      });

      it('should set primary contact details to be displayed in fat footer based off name match from trustees and addressesV2 present', () => {
        controller.applicationDetails.accountSettings = { personRelations: [accountSettingWithClientkey] };
        controller.applicationDetails.trustees = [investorDetailstWithoutClientkey];
        controller.setPrimaryContactDetails();
        expect(controller.model.primaryContactNumber).to.equal('0414111222');
        expect(controller.model.domicileAddress).to.equal('33 Pitt Road, SOUTH NANANGO  QLD  4615');
        expect(controller.model.primaryContactName).to.equal('AA CC');
      });
    });

    describe('printPage', () => {
      it('should call window print method', () => {
        controller.$window = { print() {} };

        controller.$window.print = sinon.spy();
        controller.printPage();
        expect(controller.$window.print).to.have.been.called;
      });
    });

    describe('handleCtrlPOfflinePrint', () => {
      beforeEach(() => {
        controller.setAccountSummaryName = sinon.spy();
        controller.setAdviserContactDetails = sinon.spy();
        controller.setPrimaryContactDetails = sinon.spy();
        controller.setApplicationIssueDate = sinon.spy();
        controller.handleDynamicDataForConfirmation = sinon.spy();
        sinon.spy(controller, 'handleCtrlPOfflinePrint');
        sinon.spy(controller, 'printPage');
        controller.$onInit();
      });

      it('should call window print method when ctrl p triggered', () => {
        angular.element(controller.$document).triggerHandler({ type: 'keydown', keyCode: 80, ctrlKey: true });
        expect(controller.handleCtrlPOfflinePrint).to.have.been.called;
        expect(controller.printPage).to.have.been.called;
        angular.element(controller.$document).triggerHandler({ type: 'keydown', keyCode: 80, metaKey: true });
        expect(controller.handleCtrlPOfflinePrint).to.have.been.called;
        expect(controller.printPage).to.have.been.called;
      });

      it('should not call window print method when other than ctrl p kewdown gets trigeered', () => {
        angular.element(controller.$document).triggerHandler({ type: 'keydown', keyCode: 89, metaKey: true });
        expect(controller.handleCtrlPOfflinePrint).to.have.been.called;
        expect(controller.printPage).not.to.have.been.called;
      });
    });

    describe('handleDynamicDataForConfirmation', () => {
      let cmsDataResponse;
      let expNotAssetAdminCmsTc;
      let expAssetAdminCmsTc;

      beforeEach(() => {
        controller.model = { applicationDetails: { productName: 'Asset Administrator' } };
        cmsDataResponse = '<p>I have received and read the latest <a href="/Panorama_Investor_Guide.pdf" class="btpdf">Investor Guide</a> <a href="/IOOF_Panorama_Investors_Guide_0215px.pdf" class="assetadminpdf">Investor Guide</a> </p>';
        expAssetAdminCmsTc = '<p>I have received and read the latest  <a href="/IOOF_Panorama_Investors_Guide_0215px.pdf" class="assetadminpdf">Investor Guide</a> </p>';
        expNotAssetAdminCmsTc = '<p>I have received and read the latest <a href="/Panorama_Investor_Guide.pdf" class="btpdf">Investor Guide</a>  </p>';
      });

      it('when productName is Asset Administrator then asset admin investor guide link to be shown', () => {
        controller.handleDynamicDataForConfirmation(cmsDataResponse);
        expect(controller.tncsFooter).to.equal(expAssetAdminCmsTc);
      });

      it('when productName is Asset Administrator Compaq then also asset admin investor guide link to be shown', () => {
        controller.model.applicationDetails.productName = 'Asset Administrator Compaq';
        controller.handleDynamicDataForConfirmation(cmsDataResponse);
        expect(controller.tncsFooter).to.equal(expAssetAdminCmsTc);
      });

      it('when productName is White Label BT Product then asset admin investor guide link to be shown', () => {
        controller.model.applicationDetails.productName = 'White Label BT Product';
        controller.handleDynamicDataForConfirmation(cmsDataResponse);
        expect(controller.tncsFooter).to.equal(expNotAssetAdminCmsTc);
      });
    });
  });
});
