import compact from 'lodash/compact';
import find from 'lodash/find';
import { accountTypeToAccountNameMap, formatAddressForAvaloqData } from '../../../helper/utilities';

class OfflinePrintController {
  constructor($window, $filter, $document) {
    this.name = 'Offline print';
    this.$window = $window;
    this.$filter = $filter;
    this.$document = $document;
    this.model = {};
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.model.applicationDetails = this.applicationDetails;
    this.accountType = this.model.applicationDetails.investorAccountType;
    this.model.accountFullName = accountTypeToAccountNameMap[this.applicationDetails.investorAccountType];
    this.setAccountSummaryName();
    this.setAdviserContactDetails();
    this.setPrimaryContactDetails();
    this.setApplicationIssueDate();
    this.handleDynamicDataForConfirmation(this.tncsConfirmationContent);
    this.$document.on('keydown', e => this.handleCtrlPOfflinePrint(e));
  }

  setAccountSummaryName() {
    const accountType = accountTypeToAccountNameMap[this.applicationDetails.investorAccountType];
    this.model.accountSummaryName = compact([[accountType, 'account'].join(' '), this.applicationDetails.productName, this.applicationDetails.referenceNumber]).join(' • ');
  }

  setAdviserContactDetails() {
    const primaryEmail = find(this.applicationDetails.adviser.email, ['emailType', 'Primary']);
    const workPhone = find(this.applicationDetails.adviser.phone, ['phoneType', 'Work']);
    this.model.adviserPrimaryEmail = primaryEmail.email;
    this.model.adviserWorkPhone = workPhone ? workPhone.number : null;
    this.model.adviserPrimaryPhone = this.applicationDetails.adviser.phone[0].number;
    this.model.adviserCorporateName = this.applicationDetails.adviser.corporateName;
    this.model.adviserDealerGroup = this.applicationDetails.adviser.dealerGroupName;
  }

  setPrimaryContactDetails() {
    const investorsdetails = this.applicationDetails.investors || this.applicationDetails.trustees || this.applicationDetails.directors;
    const primaryContact = find(this.applicationDetails.accountSettings.personRelations, { primaryContactPerson: true });
    this.model.primaryContactName = primaryContact.name;
    const clientKey = primaryContact.clientKey;
    const primaryInvestorDetails = this.getInvestorContactDetails(investorsdetails, clientKey);
    this.setContactDetails(primaryInvestorDetails);
  }

  setApplicationIssueDate() {
    this.model.applicationIssueDate = this.applicationDetails.applicationOpenDate ? this.applicationDetails.applicationOpenDate : new Date();
  }

  getInvestorContactDetails(investorsdetails, clientKey) {
    // Match by client key, if account isn't in Avaloq, match by name instead
    return find(investorsdetails, elem => this.isClientKeyMatch(elem, clientKey) || this.isNameMatch(elem));
  }

  isClientKeyMatch(elem, clientKey) {
    return elem.key && clientKey && elem.key.clientId === clientKey.clientId;
  }

  isNameMatch(elem) {
    return this.model.primaryContactName.toUpperCase() === this.getFullName(elem).toUpperCase();
  }

  getFullName(elem) {
    return [elem.firstName, elem.lastName].filter(fullName => fullName).join(' ');
  }

  setContactDetails(primaryInvestorDetails) {
    const primaryPhone = find(primaryInvestorDetails.phones, ['phoneType', 'Primary']);
    if (primaryInvestorDetails.addressesV2) {
      this.model.domicileAddress = this.$filter('addressV2Display')(primaryInvestorDetails.addressesV2, 'RESIDENTIAL');
    } else {
      const domicileAddress = find(primaryInvestorDetails.addresses, 'domicile');
      if (domicileAddress) {
        this.model.domicileAddress = formatAddressForAvaloqData(domicileAddress);
      }
    }

    this.model.primaryContactNumber = primaryPhone.number;
  }

  handleDynamicDataForConfirmation(data) {
    const linkRegex = this.model.applicationDetails.productName.indexOf('Asset Administrator') > -1
      ? /<a[^>]+class="btpdf"+[^<]+<\/a>/g
      : /<a[^>]+class="assetadminpdf"+[^<]+<\/a>/g;
    let cleanData = data;

    if (cleanData && cleanData.match(linkRegex)) {
      cleanData = cleanData.replace(linkRegex, '');
    }

    this.tncsFooter = cleanData;
  }

  printPage() {
    this.$window.print();
  }

  isIEorEDGE() {
    /* first condtion to detect IE upto 11 and second condition to detect IE edge */
    return Boolean(((false) || (this.$document.documentMode)) || (!(this.$document.documentMode) && this.$window.StyleMedia));
  }

  /**
   * @method handleCtrlPOfflinePrint
   * when ctr + p pressed then browser prints the page from parent window (out side the iframe) and for chrome, safari
   * browser does not detect the end of the page inside the iframe and minor content gets stripped off at the bootom
   * like sentence gets cut in middle. Mozilla only prints first page.  below method detects the ctrl p event and prints page
   * inside the current window, inside the iframe. So now while printing there wont be any iframe into the picture
   * Below method does checks for IE, because IE does not support prevent default and that causes two print dialog.
   */
  handleCtrlPOfflinePrint(event) {
    if (!this.isIEorEDGE() && event.keyCode === 80 && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      this.printPage();
    }
  }

  // need to hide chrome adviser as it should not be shown to on offline print screen.
  $postLink() {
    const adviserChrome = angular.element(this.$window.top.document.querySelector('#chrome-adviser'));
    adviserChrome.remove();
  }
}

OfflinePrintController.$inject = ['$window', '$filter', '$document'];

export default OfflinePrintController;
