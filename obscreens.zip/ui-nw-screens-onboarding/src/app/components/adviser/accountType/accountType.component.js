import template from './accountType.html';
import controller from './accountType.controller';

const accountTypeComponent = {
  bindings: {
    singleAdviserRes: '<',
    schemaEnums: '<',
  },
  template,
  controller,
};

export default accountTypeComponent;
