import get from 'lodash/get';

class AccountTypeService {
  constructor($http, $q, permission) {
    this.$http = $http;
    this.$q = $q;
    this.isProductSetsEnabled = permission.hasPermission('feature.global.productSets', '');
  }

  getAdviserSearch() {
    const url = '../api/v1_0/single_adviser_for_user';
    return this.$http.get(url)
      .then(res => get(res, 'data.data'));
  }

  getProductsList(adviserId) {
    let url;
    if (this.isProductSetsEnabled) {
      url = `../api/products/v1_0/adviser/${adviserId}`;
    } else {
      url = `../api/v1_0/advisers/${adviserId}/products`;
    }

    return this.$http.get(url)
      .then(res => get(res, 'data.data'));
  }

  adviserAutoSearch(query) {
    this.autoSearchRequest = this.$q.defer();

    return this.$http.get('../api/v1_0/adviser', {
      timeout: this.autoSearchRequest.promise,
      params: {
        query,
      },
    })
      .then(res => get(res, 'data.data.resultList'));
  }
}

AccountTypeService.$inject = ['$http', '$q', 'nw.core.common.permissions.permissionsService'];

export default AccountTypeService;
