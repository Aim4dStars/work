class AnnuityModalController {
  constructor($uibModalInstance, $window, nexturl) {
    this.nexturl = nexturl;
    this.$window = $window;

    this.continue = () => {
      $uibModalInstance.dismiss();
      this.$window.top.location.href = this.$window.top.location.href.replace(this.$window.top.location.hash, this.nexturl);
    };

    this.close = () => {
      $uibModalInstance.dismiss();
    };

    this.cancel = () => {
      $uibModalInstance.dismiss();
    };
  } // constructor
}

AnnuityModalController.$inject = [
  '$uibModalInstance',
  '$window',
  'nexturl',
];

export default AnnuityModalController;
