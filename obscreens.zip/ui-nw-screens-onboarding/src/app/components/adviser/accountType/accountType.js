import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import accountTypeComponent from './accountType.component';
import accountTypeService from './accountType.service';
import adviserSearchTypehead from './adviserSearchTypehead.html';

const accountTypeModule = angular.module('nw.onboarding.adviser.accountType', [
  uiRouter,
  'nw.core.common.api',
  'nw.onboarding.common.api',
  'nw.core.common.permissions',

])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.adviser.accountType', {
        url: '/account-type',
        component: 'nw.onboarding.adviser.accountType',
        data: {
          chromeConfig: {
            headerPanel: 'Open an account',
            headerMenu: true,
          },
        },
        resolve: {
          singleAdviserRes: ['$q', 'nw.onboarding.adviser.accountType.accountTypeService', ($q, service) => {
            const deferred = $q.defer();
            service.getAdviserSearch().then(singleAdviserRes => {
              if (singleAdviserRes.singleAdviser) {
                service.getProductsList(singleAdviserRes.adviserPositionId).then(productListRes => {
                  deferred.resolve({ productList: productListRes.resultList, adviserDetails: singleAdviserRes });
                }).catch(() => deferred.reject());
              } else {
                deferred.resolve({ adviserDetails: singleAdviserRes });
              }
            }).catch(() => deferred.reject());
            return deferred.promise;
          },
          ],
          schemaEnums: ['nw.onboarding.common.api.schemaEnums', schemaService => schemaService.getSchemaEnums()],
        },
      });
  })

  .run($templateCache => {
    'ngInject';

    $templateCache.put('nw-adviser-search-typehead.html', adviserSearchTypehead);
  })

  .component('nw.onboarding.adviser.accountType', accountTypeComponent)

  .service('nw.onboarding.adviser.accountType.accountTypeService', accountTypeService);

export default accountTypeModule;
