import find from 'lodash/find';
import cloneDeep from 'lodash/cloneDeep';
import keys from 'lodash/keys';
import without from 'lodash/without';
import each from 'lodash/each';
import groupBy from 'lodash/groupBy';
import sortBy from 'lodash/sortBy';
import filter from 'lodash/filter';
import accountTypesConfig from './accountType.config';
import annuityModal from './annuity/annuityModal.html';
import annuityModalController from './annuity/annuityModal.controller';

class AccountTypeController {
  constructor(accountTypeService, profileService, permission, $uibModal) {
    this.name = 'Account type';
    this.service = accountTypeService;
    this.profileService = profileService;
    this.model = {};
    this.form = {};
    this.isAnnutiesEnabled = permission.hasPermission('feature.global.onboardingAnnuities', '');
    this.isSuperPermitted = permission.hasPermission('account.application.super.create', '');
    this.isNewIndiSmsfPermitted = permission.hasPermission('account.application.newsmsf.individual.create', '');
    this.isNewCorpSmsfPermitted = permission.hasPermission('account.application.newsmsf.corporate.create', '');
    this.isProductSetsEnabled = permission.hasPermission('feature.global.productSets', '');
    this.model.isSearchRequired = true;
    this.$window = this.profileService.$window;
    this.$uibModal = $uibModal;
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.model.isAsim = this.profileService.isAsim();
    this.model.hasAsimRole = this.profileService.hasAsimRole();
    this.model.hasNonAsimRole = this.profileService.hasNonAsimRole();
    this.model.adviserDetails = this.singleAdviserRes.adviserDetails;
    this.model.isAdviser = this.isAdviser();
    if (this.model.adviserDetails.singleAdviser) {
      this.adviserId = this.model.adviserDetails.adviserPositionId;
      this.model.isSearchRequired = false;
      this.model.productRetrieved = true;
      this.model.productList = this.singleAdviserRes.productList;
      this.processProductList();
    }
  }

  onAdviserSelect(item) {
    this.loading = true;
    this.error = false;
    this.model.productRetrieved = false;
    this.adviserId = item.adviserPositionId; // adviserId would be sent to then next screen
    this.service.getProductsList(item.adviserPositionId)
      .then(res => {
        this.loading = false;
        this.error = false;
        this.model.productRetrieved = true;
        this.model.productList = res.resultList;
        this.processProductList();
      })
      .catch(() => {
        this.model.productRetrieved = false;
        this.loading = false;
        this.error = true;
      });
  }

  processProductList() {
    this.form.accounts = null;
    this.form.productType = null;
    this.sortProductNames();

    if (this.isProductSetsEnabled) {
      this.model.productTypeObjs = groupBy(this.model.productList, 'productGroup');
    } else {
      this.model.productTypeObjs = groupBy(this.model.productList, 'parentProductName');
    }

    this.model.productTypeKeys = keys(this.model.productTypeObjs);
    if (!this.isSuperPermitted) {
      this.model.productTypeKeys = without(this.model.productTypeKeys, 'Superannuation');
    }

    if (!this.isAnnutiesEnabled) {
      this.model.productTypeKeys = without(this.model.productTypeKeys, 'Annuity');
    }

    if (this.model.productTypeKeys.length === 1) {
      this.model.singleProductTypeOnly = true;
      this.form.productType = this.model.productTypeKeys[0];
      this.productTypeChanged();
    }
  }

  sortProductNames() {
    each(this.model.productList, product => {
      product.productName = product.productName.replace(/\s+Investments/gi, '');
      product.productName = product.productName.replace(/\s+Super/gi, '');
    });
    this.model.productList = sortBy(this.model.productList, product => product.productName);
  }

  productTypeChanged() {
    this.form.product = null;
    this.form.accounts = null;
    this.resetAccountOptions();
    const selectedProductType = this.form.productType;
    this.model.currentProducts = this.model.productTypeObjs[selectedProductType];
    if (this.isProductSetsEnabled) {
      this.form.parentProductName = this.model.currentProducts[0].productGroup;
    } else {
      this.form.parentProductName = this.model.currentProducts[0].parentProductName;
    }

    if (this.model.currentProducts.length === 1) {
      this.form.product = this.model.currentProducts[0].key.productId;
      this.model.singleProductOnly = true;
      this.processAccountTypes();
    } else {
      this.model.singleProductOnly = false;
    }
  }

  resetAccountOptions() {
    accountTypesConfig.idpsAccountTypeConfig.map(account => {
      delete account.trustType;
      return account;
    });
    accountTypesConfig.idpsAccountTypeConfig.map(account => {
      if (account.smsfAccountTypes && account.accountType) {
        delete account.accountType;
      }
      return account;
    });
  }

  processAccountTypes() {
    const productType = this.form.productType.toLowerCase();
    switch (productType) {
      case 'cash management account':
      case 'investments':
        this.form.accounts = this.manageFundEstablishment();
        break;
      case 'superannuation':
        this.form.accounts = accountTypesConfig.superAccountTypeConfig;
        break;
      case 'annuity':
        this.form.accounts = this.manageAnnuitiesAccountConfig();
        break;
      default:
        this.form.accounts = null;
        break;
    }
  }

  manageFundEstablishment() {
    let idpsAccountTypeConfig = cloneDeep(accountTypesConfig.idpsAccountTypeConfig);
    const newSmsf = find(idpsAccountTypeConfig, ['accountSectionTitle', 'Establish a brand new SMSF']);
    const dropDowns = cloneDeep(newSmsf.smsfAccountTypes);
    newSmsf.smsfAccountTypes = [];
    if (this.isNewCorpSmsfPermitted) {
      newSmsf.smsfAccountTypes.push(dropDowns[0]);
    }

    if (this.isNewIndiSmsfPermitted) {
      newSmsf.smsfAccountTypes.push(dropDowns[1]);
    }

    if (!this.isNewCorpSmsfPermitted && !this.isNewIndiSmsfPermitted) {
      idpsAccountTypeConfig = filter(accountTypesConfig.idpsAccountTypeConfig, idpsAcc => idpsAcc.accountSectionTitle !== 'Establish a brand new SMSF');
    }

    return idpsAccountTypeConfig;
  }

  manageAnnuitiesAccountConfig() {
    let idpsAccountTypeConfig = cloneDeep(accountTypesConfig.idpsAccountTypeConfig);

    idpsAccountTypeConfig = filter(accountTypesConfig.idpsAccountTypeConfig, idpsAcc => idpsAcc.accountSectionTitle !== 'Establish a brand new SMSF');

    return idpsAccountTypeConfig;
  }

  productChanged() {
    this.form.accounts = null;
    this.processAccountTypes();
  }

  smsfAccountChanged(account) {
    account.helpAndSupportUrl = find(account.smsfAccountTypes, smsf => smsf.accountType === account.accountType).helpAndSupportUrl;
  }

  openAccount(account) {
    const parentProductName = this.form.parentProductName.toLowerCase();
    let url;
    if (this.isAnnutiesEnabled) {
      url = `#/app/adviser/what-to-expect?accountType=${account.accountType}&productId=${this.form.product}&parentProductName=${this.form.parentProductName}&adviserId=${this.adviserId}`;
      if (this.isTrust(account)) {
        url += `&trustType=${account.trustType}`;
      }
    } else {
      url = `#ng/newaccount/accounttypechecklist?accounttype=${account.accountType}&productid=${this.form.product}&parentProductName=${this.form.parentProductName}&adviserid=${this.adviserId}`;
      if (this.isTrust(account)) {
        url += `&trusttype=${account.trustType}`;
      }
    }
    let modal;
    if (parentProductName === 'annuity') {
      modal = this.$uibModal.open({
        template: annuityModal,
        resolve: {
          nexturl: () => url,
        },
        ariaLabelledBy: 'modal-title',
        windowClass: 'modal-generic',
        controller: annuityModalController,
        controllerAs: '$ctrl',
      });
    } else {
      this.$window.top.location.href = this.$window.top.location.href.replace(this.$window.top.location.hash, url);
    }

    return modal;
  }

  shouldDisableOpenButton(account) {
    let result;

    if (this.isSmsf(account)) {
      result = !account.accountType;
    } else if (this.isTrust(account)) {
      result = !account.trustType;
    }

    return result;
  }

  isAdviser() {
    return filter(this.profileService.model.roles, { role: 'Adviser', active: true }).length >= 1;
  }

  isSmsf(account) {
    return !!account.smsfAccountTypes;
  }

  isTrust(account) {
    const accountTypeEnum = this.schemaEnums.AccountTypeEnum;
    return account.accountType === accountTypeEnum.INDIVIDUAL_TRUST || account.accountType === accountTypeEnum.CORPORATE_TRUST;
  }
}

AccountTypeController.$inject = [
  'nw.onboarding.adviser.accountType.accountTypeService',
  'nw.core.common.api.user',
  'nw.core.common.permissions.permissionsService',
  '$uibModal',
];

export default AccountTypeController;
