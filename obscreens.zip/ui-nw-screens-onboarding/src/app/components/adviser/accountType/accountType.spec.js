import find from 'lodash/find';
import AccountTypeModule from './accountType';
import AccountTypeController from './accountType.controller';
import AccountTypeComponent from './accountType.component';
import AccountTypeTemplate from './accountType.html';
import AccountTypeConfig from './accountType.config';
import annuityModal from './annuity/annuityModal.html';
import AnnuityModalController from './annuity/annuityModal.controller';

const permissionMap = {
  'feature.global.onboardingAnnuities': true,
  'account.application.super.create': true,
  'account.application.newsmsf.individual.create': true,
  'account.application.newsmsf.corporate.create': true,
  'feature.global.productSets': false,
};

describe('AccountType', () => {
  let $rootScope;
  let $controller;
  let $componentController;
  let $httpBackend;
  let $state;
  let sandbox;
  let controller;
  let service;
  let schemaService;
  let $q;
  let permission;

  // load the module
  beforeEach(() => {
    window.module('ui.router');
    window.module($stateProvider => {
      $stateProvider.state('app', { url: '/app' });
      $stateProvider.state('app.adviser', { url: '/adviser' });
    });
    window.module(AccountTypeModule.name);
  });

  beforeEach(inject(($injector, _$controller_) => {
    $rootScope = $injector.get('$rootScope');
    $controller = _$controller_;
    $componentController = $injector.get('$componentController');
    $state = $injector.get('$state');
    $q = $injector.get('$q');
    $httpBackend = $injector.get('$httpBackend');
    schemaService = $injector.get('nw.onboarding.common.api.schemaEnums');
    permission = $injector.get('nw.core.common.permissions.permissionsService');

    sandbox = sinon.sandbox.create();
    sandbox.stub(permission, 'getPermission').returns($q.resolve());
    sandbox.stub(permission, 'hasPermission', rule => permissionMap[rule]);
    service = $injector.get('nw.onboarding.adviser.accountType.accountTypeService');
  }));

  afterEach(() => {
    sandbox.restore();
  });

  describe('Module', () => {
    const component = AccountTypeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(AccountTypeTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(AccountTypeController);
    });

    it('when single_adviser_for_user api returns true, then it should call product list as well', () => {
      schemaService.getSchemaEnums = sinon.spy();
      const deferred = $q.defer();
      const productListDeferred = $q.defer();
      sandbox.stub(service, 'getAdviserSearch').returns(deferred.promise);
      sinon.stub(service, 'getProductsList').returns(productListDeferred.promise);
      $state.go('app.adviser.accountType');
      deferred.resolve({ singleAdviser: true, adviserPositionId: 'ABCD1234XYZ' });
      productListDeferred.resolve({});
      $rootScope.$digest();
      expect(service.getAdviserSearch).to.have.been.called;
      expect(service.getProductsList).to.have.been.called;
      expect($state.current.name).to.eq('app.adviser.accountType');
    });

    it('when single_adviser_for_user api returns false, then it should not call product list api ', () => {
      schemaService.getSchemaEnums = sinon.spy();
      const deferred = $q.defer();
      sandbox.stub(service, 'getAdviserSearch').returns(deferred.promise);
      sinon.stub(service, 'getProductsList');
      $state.go('app.adviser.accountType');
      deferred.resolve({ singleAdviser: false, adviserPositionId: 'ABCD1234XYZ' });
      $rootScope.$digest();
      expect(service.getAdviserSearch).to.have.been.called;
      expect(service.getProductsList).not.to.have.been.called;
      expect($state.current.name).to.eq('app.adviser.accountType');
    });

    it('when single_adviser_for_user api failes then shoud not go to the accountType component', () => {
      schemaService.getSchemaEnums = sinon.spy();
      const deferred = $q.defer();
      sandbox.stub(service, 'getAdviserSearch').returns(deferred.promise);
      sinon.stub(service, 'getProductsList');
      $state.go('app.adviser.accountType');
      deferred.reject();
      $rootScope.$digest();
      expect(service.getAdviserSearch).to.have.been.called;
      expect(service.getProductsList).not.to.have.been.called;
      expect($state.current.name).to.eq('');
    });

    it('when product list api fails then also shoud not go to the accountType component', () => {
      schemaService.getSchemaEnums = sinon.spy();
      const deferred = $q.defer();
      const productListDeferred = $q.defer();
      sandbox.stub(service, 'getAdviserSearch').returns(deferred.promise);
      sinon.stub(service, 'getProductsList').returns(productListDeferred.promise);
      $state.go('app.adviser.accountType');
      deferred.resolve({ singleAdviser: true, adviserPositionId: 'ABCD1234XYZ' });
      productListDeferred.reject();
      $rootScope.$digest();
      expect(service.getAdviserSearch).to.have.been.called;
      expect(service.getProductsList).to.have.been.called;
      expect($state.current.name).to.eq('');
    });
  });

  describe('Service', () => {
    it('getAdviserSearch should make an HTTP GET request', () => {
      let res;
      const data = { data: { property: 'testData' } };
      $httpBackend.whenGET(u => u === '../api/v1_0/single_adviser_for_user').respond(data);
      service.getAdviserSearch().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getProductsList should make an HTTP GET request', () => {
      let res;
      const data = { data: { property: 'testData' } };
      $httpBackend.whenGET(u => u === '../api/v1_0/advisers/A1B2C3/products').respond(data);
      service.getProductsList('A1B2C3').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('adviserAutoSearch should make an HTTP GET request', () => {
      let res;
      const data = { data: { resultList: [{ product: 'ABC' }] } };
      $httpBackend.whenGET(u => u === '../api/v1_0/adviser?query=vip').respond(data);
      service.adviserAutoSearch('vip').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal([{ product: 'ABC' }]);
    });
  });

  describe('Controller', () => {
    let resolve;
    beforeEach(() => {
      const productList = [
        {
          productName: 'BT Panorama Investments', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'ABC' },
        },
        {
          productName: 'BT Panorama Super', parentProduct: 'BT Panorama SUPER Product', parentProductName: 'Superannuation', parentProductKey: { productId: 'DEF' },
        },
        {
          productName: 'Asset Administrator Investments', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'GHI' },
        },
        {
          productName: 'Asset Administrator Super', parentProduct: 'BT Panorama SUPER Product', parentProductName: 'Superannuation', parentProductKey: { productId: 'JKL' },
        },
        {
          productName: 'BT Panorama Investments Compact', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'MNO' },
        },
        {
          productName: 'Challenger Annuity', parentProduct: 'Challenger Annuities', parentProductName: 'Annuity', parentProductKey: { productId: 'PQR' },
        },
      ];
      const accountTypeEnum = {
        COMPANY: 'company',
        CORPORATE_SMSF: 'corporateSMSF',
        CORPORATE_TRUST: 'corporateTrust',
        INDIVIDUAL: 'individual',
        INDIVIDUAL_SMSF: 'individualSMSF',
        INDIVIDUAL_TRUST: 'individualTrust',
        JOINT: 'joint',
        NEW_CORPORATE_SMSF: 'newCorporateSMSF',
        NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
        SUPER_ACCUMULATION: 'superAccumulation',
        SUPER_PENSION: 'superPension',
      };

      resolve = { singleAdviserRes: { productList, adviserDetails: { singleAdviser: true, adviserPositionId: 'ABCD1234XYZ' } }, schemaEnums: { AccountTypeEnum: accountTypeEnum } };
      controller = $componentController('nw.onboarding.adviser.accountType', {
        $scope: $rootScope.$new(),
        'nw.onboarding.adviser.accountType.accountTypeService': service,
      }, resolve);
    });

    describe('$onInit', () => {
      it('should initilized values when adviser is single', () => {
        controller.processProductList = sinon.spy();
        controller.$onInit();
        expect(controller.model).to.have.property('isAsim');
        expect(controller.model).to.have.property('hasAsimRole');
        expect(controller.model).to.have.property('hasNonAsimRole');
        expect(controller.adviserId).to.equal('ABCD1234XYZ');
        expect(controller.model.productList).to.equal(resolve.singleAdviserRes.productList);
        expect(controller.model.isSearchRequired).to.be.false;
        expect(controller.model.productRetrieved).to.be.true;
        expect(controller.processProductList).to.have.been.called;
      });
      it('should initilized values when adviser is not single adviser', () => {
        controller.singleAdviserRes.adviserDetails.singleAdviser = false;
        controller.processProductList = sinon.spy();
        controller.$onInit();
        expect(controller.model).to.have.property('isAsim');
        expect(controller.model).to.have.property('hasAsimRole');
        expect(controller.model).to.have.property('hasNonAsimRole');
        expect(controller.adviserId).to.be.undefined;
        expect(controller.model.productList).to.be.undefined;
        expect(controller.model.isSearchRequired).to.be.true;
        expect(controller.model.productRetrieved).to.be.undefined;
        expect(controller.processProductList).not.to.have.been.called;
      });
    });

    describe('onAdviserSelect', () => {
      let deferred;
      beforeEach(() => {
        deferred = $q.defer();
        sinon.stub(service, 'getProductsList').returns(deferred.promise);
        sinon.spy(controller, 'processProductList');
      });

      it('should call productList for specific adviserId on success of service', () => {
        controller.processProductList = sinon.spy();
        controller.onAdviserSelect({ adviserPositionId: '123ABC' });
        expect(controller.loading).to.be.true;
        expect(controller.error).to.be.false;
        expect(controller.model.productRetrieved).to.be.false;
        expect(controller.adviserId).to.equal('123ABC');
        deferred.resolve({ resultList: [] });
        $rootScope.$digest();
        expect(controller.loading).to.be.false;
        expect(controller.error).to.be.false;
        expect(controller.model.productRetrieved).to.be.true;
        expect(controller.model.productList).to.deep.equal([]);
        expect(controller.processProductList).to.have.been.called;
      });

      it('should not process productList for specific adviserId on failure of service', () => {
        controller.processProductList = sinon.spy();
        controller.onAdviserSelect({ adviserPositionId: '123ABC' });
        expect(controller.loading).to.be.true;
        expect(controller.error).to.be.false;
        expect(controller.model.productRetrieved).to.be.false;
        expect(controller.adviserId).to.equal('123ABC');
        deferred.reject();
        $rootScope.$digest();
        expect(controller.loading).to.be.false;
        expect(controller.error).to.be.true;
        expect(controller.model.productRetrieved).to.be.false;
        expect(controller.model.productList).to.be.undefined;
        expect(controller.processProductList).not.to.have.been.called;
      });
    });

    describe('processProductList', () => {
      let expectedRes;
      beforeEach(() => {
        expectedRes = {
          Investments: [
            {
              productName: 'Asset Administrator', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'GHI' },
            },
            {
              productName: 'BT Panorama', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'ABC' },
            },
            {
              productName: 'BT Panorama Compact', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'MNO' },
            },
          ],
          Superannuation: [
            {
              productName: 'Asset Administrator', parentProduct: 'BT Panorama SUPER Product', parentProductName: 'Superannuation', parentProductKey: { productId: 'JKL' },
            },
            {
              productName: 'BT Panorama', parentProduct: 'BT Panorama SUPER Product', parentProductName: 'Superannuation', parentProductKey: { productId: 'DEF' },
            },
          ],

        };
      });
      it('should group by "parentProductName"  and results are more than one and sort by "productName" ', () => {
        controller.productTypeChanged = sinon.spy();
        controller.model.productList = resolve.singleAdviserRes.productList;
        controller.processProductList();
        expect(controller.model.productTypeObjs.Investments).to.deep.equal(expectedRes.Investments);
        expect(controller.model.productTypeObjs.Superannuation).to.deep.equal(expectedRes.Superannuation);
        expect(controller.model.productTypeKeys).to.deep.equal(['Investments', 'Superannuation', 'Annuity']);
        expect(controller.form.productType).to.be.null;
        expect(controller.form.accounts).to.be.null;
        expect(controller.model.singleProductTypeOnly).to.be.undefined;
        expect(controller.productTypeChanged).not.to.have.been.called;
      });

      it('whens group by "parentProductName"  and results are more than one but super permission is false ', () => {
        controller.isSuperPermitted = false;
        controller.productTypeChanged = sinon.spy();
        controller.model.productList = resolve.singleAdviserRes.productList;
        controller.processProductList();
        expect(controller.model.productTypeKeys).to.deep.equal(['Investments', 'Annuity']);
        expect(controller.form.productType).to.be.null;
        expect(controller.form.accounts).to.be.null;
        expect(controller.productTypeChanged).not.to.have.been.called;
      });

      it('whens group by "parentProductName"  and results are more than one but Annuity toggle permission is false ', () => {
        controller.isAnnutiesEnabled = false;
        controller.productTypeChanged = sinon.spy();
        controller.model.productList = resolve.singleAdviserRes.productList;
        controller.processProductList();
        expect(controller.model.productTypeKeys).to.deep.equal(['Investments', 'Superannuation']);
        expect(controller.form.productType).to.be.null;
        expect(controller.form.accounts).to.be.null;
        expect(controller.productTypeChanged).not.to.have.been.called;
      });
      it('should group by "parentProductName" and grouping result is only one productType then productType should be auto selected ', () => {
        controller.productTypeChanged = sinon.spy();
        controller.model.productList = [{
          productName: 'BT Panorama Investments', parentProduct: 'BT Panorama IDPS Product', parentProductName: 'Investments', parentProductKey: { productId: 'ABC' },
        }];
        controller.processProductList();
        expect(controller.model.productTypeKeys.length).to.eql(1);
        expect(controller.model.singleProductTypeOnly).to.eql(true);
        expect(controller.model.productTypeKeys).to.deep.equal(['Investments']);
        expect(controller.form.productType).to.eql('Investments');
        expect(controller.form.accounts).to.be.null;
        expect(controller.productTypeChanged).to.have.been.called;
      });
    });

    describe('productTypeChanged with more than one product', () => {
      let productTypeObjs;

      beforeEach(() => {
        productTypeObjs = {
          IDPSProduct: [
            {
              productName: 'BT Panorama', parentProduct: 'Investments', parentProductName: 'BT Panorama Investments', parentProductKey: { productId: 'ABC' },
            },
            {
              productName: 'Asset Administrator', parentProduct: 'Investments', parentProductName: 'BT Panorama Investments', parentProductKey: { productId: 'GHI' },
            },
            {
              productName: 'BT Panorama Compact', parentProduct: 'Investments', parentProductName: 'BT Panorama Investments', parentProductKey: { productId: 'MNO' },
            },
          ],
          SuperProduct: [
            {
              productName: 'BT Panorama', parentProduct: 'Superannuation', parentProductName: 'BT Super Investments', parentProductKey: { productId: 'DEF' },
            },
            {
              productName: 'Asset Administrator', parentProduct: 'Superannuation', parentProductName: 'BT Super Investments', parentProductKey: { productId: 'JKL' },
            },
          ],
        };
        controller.model.productTypeObjs = productTypeObjs;
        sinon.stub(controller, 'processAccountTypes');
        sinon.stub(controller, 'resetAccountOptions');
      });

      describe('IDPS Product Type is selected', () => {
        it('should populate products of IDPS only and NOT populate the accounts when products >1', () => {
          controller.form.productType = 'IDPSProduct';
          controller.productTypeChanged();

          expect(controller.form.product).to.be.null;
          expect(controller.form.accounts).to.be.null;
          expect(controller.model.currentProducts.length).to.equal(3);
          expect(controller.resetAccountOptions).to.have.been.called;
          expect(controller.processAccountTypes).to.not.have.been.called;
          expect(controller.model.singleProductOnly).to.be.false;
          expect(controller.form.parentProductName).to.equal('BT Panorama Investments');
          expect(controller.model.currentProducts).to.deep.equal(productTypeObjs.IDPSProduct);
        });
      });

      describe('SUPER Product Type is selected', () => {
        it('should populate products of SUPER only and NOT populate the accounts when products >1', () => {
          controller.form.productType = 'SuperProduct';
          controller.productTypeChanged();

          expect(controller.form.product).to.be.null;
          expect(controller.form.accounts).to.be.null;
          expect(controller.model.currentProducts.length).to.equal(2);
          expect(controller.resetAccountOptions).to.have.been.called;
          expect(controller.processAccountTypes).to.not.have.been.called;
          expect(controller.model.singleProductOnly).to.be.false;
          expect(controller.model.currentProducts).to.deep.equal(productTypeObjs.SuperProduct);
        });
      });
    });

    describe('productTypeChanged with one product', () => {
      let productTypeObjs;

      beforeEach(() => {
        productTypeObjs = {
          IDPSProduct: [
            {
              key: { productId: 'ABC' }, productName: 'BT Panorama', parentProduct: 'Investments', parentProductKey: { productId: 'ABC' },
            },
          ],
          SuperProduct: [
            {
              key: { productId: 'DEF' }, productName: 'BT Panorama', parentProduct: 'Superannuation', parentProductKey: { productId: 'DEF' },
            },
          ],
        };
        controller.model.productTypeObjs = productTypeObjs;
        sinon.stub(controller, 'processAccountTypes');
        sinon.stub(controller, 'resetAccountOptions');
      });

      describe('IDPS Product Type is selected', () => {
        it('should populate products of IDPS only and populate the accounts when there is one product', () => {
          controller.form.productType = 'IDPSProduct';
          controller.productTypeChanged();

          expect(controller.form.product).to.equal('ABC');
          expect(controller.model.currentProducts.length).to.equal(1);
          expect(controller.resetAccountOptions).to.have.been.called;
          expect(controller.processAccountTypes).to.have.been.called;
          expect(controller.model.singleProductOnly).to.be.true;
          expect(controller.model.currentProducts).to.deep.equal(productTypeObjs.IDPSProduct);
        });
      });

      describe('SUPER Product Type is selected', () => {
        it('should populate products of SUPER only and populate the accounts when there is one product', () => {
          controller.form.productType = 'SuperProduct';
          controller.productTypeChanged();

          expect(controller.form.product).to.equal('DEF');
          expect(controller.model.currentProducts.length).to.equal(1);
          expect(controller.resetAccountOptions).to.have.been.called;
          expect(controller.processAccountTypes).to.have.been.called;
          expect(controller.model.singleProductOnly).to.be.true;
          expect(controller.model.currentProducts).to.deep.equal(productTypeObjs.SuperProduct);
        });
      });
    });

    describe('shouldDisableOpenButton', () => {
      it('should return TRUE when the account is SMSF and accountType is NOT selected from options ', () => {
        const smsfAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountSectionTitle === 'SMSF');
        expect(controller.shouldDisableOpenButton(smsfAccount)).to.be.true;
      });
      it('should return FALSE when the account is SMSF and accountType is selected from options', () => {
        const smsfAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountSectionTitle === 'SMSF');
        smsfAccount.accountType = 'corporateSMSF';
        expect(controller.shouldDisableOpenButton(smsfAccount)).to.be.false;
      });
      it('should return TRUE when the account is TRUST and TrustType is NOT selected from options', () => {
        const trustAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individualTrust');
        expect(controller.shouldDisableOpenButton(trustAccount)).to.be.true;
      });

      it('should return FALSE when the account is TRUST and TrustType is selected from options', () => {
        const trustAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individualTrust');
        trustAccount.trustType = 'govsuper';
        expect(controller.shouldDisableOpenButton(trustAccount)).to.be.false;
      });
    });

    describe('smsfAccountChanged', () => {
      it('should return appropriate helpAndSupportUrl when the account is SMSF and accountType is corporateSMSF ', () => {
        const smsfAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountSectionTitle === 'SMSF');
        smsfAccount.accountType = 'corporateSMSF';
        controller.smsfAccountChanged(smsfAccount);
        expect(smsfAccount.helpAndSupportUrl).to.equal('/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/smsf-corporate-trustee.html');
      });

      it('should return appropriate helpAndSupportUrl when the account is SMSF and accountType is individualSMSF ', () => {
        const smsfAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountSectionTitle === 'SMSF');
        smsfAccount.accountType = 'individualSMSF';
        controller.smsfAccountChanged(smsfAccount);
        expect(smsfAccount.helpAndSupportUrl).to.equal('/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/smsf-individual-trustees.html');
      });
    });

    describe('openAccount when annuities toggle is off', () => {
      beforeEach(() => {
        controller.isAnnutiesEnabled = false;
        controller.$window = { top: { location: { href: 'ng/secure/#/adviser/account-type', hash: '#/adviser/account-type' } } };
        controller.form.productType = 'Investments';
        sinon.spy(controller.$uibModal, 'open');
      });
      it('should return appropriate url link when the account is SMSF and accountType is corporateSMSF ', () => {
        const accountMock = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountSectionTitle === 'SMSF');
        accountMock.accountType = 'corporateSMSF';
        controller.form.product = '1234';
        controller.form.parentProductName = 'Cash Management Account';
        controller.adviserId = '2016015578';
        controller.openAccount(accountMock);
        expect(controller.$window.top.location.href).to.contain('ng/secure/#ng/newaccount/accounttypechecklist?accounttype=corporateSMSF&productid=1234&parentProductName=Cash Management Account&adviserid=2016015578');
        expect(controller.$uibModal.open).to.not.have.been.called;
      });

      it('should return appropriate url link when the account is TRUST and trustType is govsuper ', () => {
        const accountMock = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individualTrust');
        accountMock.accountType = 'individualTrust';
        accountMock.trustType = 'govsuper';
        controller.form.product = '1234';
        controller.form.parentProductName = 'Cash Management Account';
        controller.adviserId = '2016015578';
        controller.openAccount(accountMock);
        expect(controller.$window.top.location.href).to.eql('ng/secure/#ng/newaccount/accounttypechecklist?accounttype=individualTrust&productid=1234&parentProductName=Cash Management Account&adviserid=2016015578&trusttype=govsuper');
        expect(controller.$uibModal.open).to.not.have.been.called;
      });
    });

    describe('openAccount when annuities toggle is on', () => {
      beforeEach(() => {
        controller.isAnnutiesEnabled = true;
        controller.$window = { top: { location: { href: 'ng/secure/#/app/adviser/what-to-expect', hash: '#/app/adviser/what-to-expect' } } };
        sinon.spy(controller.$uibModal, 'open');
      });
      it('should return appropriate url link when the account is SMSF and accountType is corporateSMSF ', () => {
        const accountMock = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountSectionTitle === 'SMSF');
        accountMock.accountType = 'corporateSMSF';
        controller.form.product = '1234';
        controller.form.parentProductName = 'Cash Management Account';
        controller.adviserId = '2016015578';
        controller.openAccount(accountMock);
        expect(controller.$window.top.location.href).to.contain('ng/secure/#/app/adviser/what-to-expect?accountType=corporateSMSF&productId=1234&parentProductName=Cash Management Account&adviserId=2016015578');
        expect(controller.$uibModal.open).to.not.have.been.called;
      });

      it('should return appropriate url link when the account is TRUST and trustType is govsuper ', () => {
        const accountMock = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individualTrust');
        accountMock.accountType = 'individualTrust';
        accountMock.trustType = 'govsuper';
        controller.form.product = '1234';
        controller.form.parentProductName = 'Cash Management Account';
        controller.adviserId = '2016015578';
        controller.openAccount(accountMock);
        expect(controller.$window.top.location.href).to.eql('ng/secure/#/app/adviser/what-to-expect?accountType=individualTrust&productId=1234&parentProductName=Cash Management Account&adviserId=2016015578&trustType=govsuper');
        expect(controller.$uibModal.open).to.not.have.been.called;
      });

      it('should open the dialogue box for annuity product when Annuity is enabled', () => {
        const accountMock = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individual');
        accountMock.accountType = 'individual';
        controller.form.product = '1234';
        controller.form.parentProductName = 'Annuity';
        controller.form.productType = 'annuity';
        controller.adviserId = '2016015578';
        controller.openAccount(accountMock);
        expect(controller.$uibModal.open).to.have.been.called;
      });
    });

    describe('when annuity dialog is opened', () => {
      let annuityModalController;
      let modalInstance;
      const $window = { top: { location: { href: 'ng/secure/app/#/adviser/account-type', hash: '#/adviser/account-type' } } };
      beforeEach(() => {
        controller.accountType = 'individual';
        controller.form.product = '1234';
        controller.form.parentProductName = 'Annuity';
        controller.form.productType = 'annuity';
        controller.adviserId = '2016015578';
        sinon.spy(controller.$uibModal, 'open');
        const url = '#/app/adviser/what-to-expect?accounttype=individual&productid=1234&parentProductName=Annuity&adviserid=2016015578';
        modalInstance = controller.$uibModal.open({
          template: annuityModal,
          ariaLabelledBy: 'modal-title',
          windowClass: 'modal-generic',
          controller: annuityModalController,
          controllerAs: '$ctrl',
        });
        annuityModalController = $controller(AnnuityModalController, {
          $uibModalInstance: modalInstance,
          $state: controller.$state,
          $window,
          nexturl: url,
        });
        sinon.spy(modalInstance, 'dismiss');
      }); // beforeEach

      it('should open modal dialog with the corresponding modal flags set', () => {
        const accountMock = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individual');
        accountMock.accountType = 'individual';
        controller.openAccount(accountMock);
        expect(controller.$uibModal.open).to.have.been.called;
      });

      it('should navigate to investor accounts overview page when user clicks NO', () => {
        annuityModalController.cancel(); // NO
        expect(modalInstance.dismiss).to.have.been.called;
        expect($window.top.location.href).to.eq('ng/secure/app/#/adviser/account-type');
      });

      it('should navigate to superForm when user clicks YES', () => {
        annuityModalController.continue(); // YES
        expect(modalInstance.dismiss).to.have.been.called;
        expect(annuityModalController.$window.top.location.href).to.eq('ng/secure/app/#/app/adviser/what-to-expect?accounttype=individual&productid=1234&parentProductName=Annuity&adviserid=2016015578');
      });
    });


    describe('productChanged', () => {
      it('should return appropriate account options when the product type is changed ', () => {
        const idpsAccounts = find(AccountTypeConfig.idpsAccountTypeConfig);
        controller.form.accounts = idpsAccounts;
        controller.form.productType = 'Superannuation';
        controller.productChanged();
        expect(controller.form.accounts).to.equal(AccountTypeConfig.superAccountTypeConfig);
      });
    });

    describe('processAccountTypes', () => {
      it('should return appropriate account options when the Cash management account is selected ', () => {
        controller.form.productType = 'Cash management account';
        controller.processAccountTypes();
        expect(controller.form.accounts.length).to.equal(7);
      });
      it('should return appropriate account options when the IDPS product is selected ', () => {
        controller.form.productType = 'Investments';
        controller.processAccountTypes();
        expect(controller.form.accounts.length).to.equal(7);
      });
      it('newCorporateSMSF option should not be there, when corporate fund establishment permisson is false for Investments or CMA', () => {
        controller.form.productType = 'Investments';
        sinon.spy(controller, 'manageFundEstablishment');
        controller.isNewCorpSmsfPermitted = false;
        controller.processAccountTypes();
        expect(controller.manageFundEstablishment).to.have.been.called;
        const newSmsf = find(controller.form.accounts, ['accountSectionTitle', 'Establish a brand new SMSF']);
        expect(newSmsf.smsfAccountTypes.length).to.equal(1);
        expect(newSmsf.smsfAccountTypes[0].accountType).not.to.equal('newCorporateSMSF');
      });
      it('newIndividualSMSF option should not be there, when individual fund establishment permisson is false for Investments or CMA', () => {
        controller.form.productType = 'Cash management account';
        sinon.spy(controller, 'manageFundEstablishment');
        controller.isNewIndiSmsfPermitted = false;
        controller.processAccountTypes();
        expect(controller.manageFundEstablishment).to.have.been.called;
        const newSmsf = find(controller.form.accounts, ['accountSectionTitle', 'Establish a brand new SMSF']);
        expect(newSmsf.smsfAccountTypes.length).to.equal(1);
        expect(newSmsf.smsfAccountTypes[0].accountType).not.to.equal('newIndividualSMSF');
      });

      it('Establish a brand new SMSF row itself should not be there, when individual and corporate fund establishment permisson is false for Investments or CMA', () => {
        controller.form.productType = 'Investments';
        sinon.spy(controller, 'manageFundEstablishment');
        controller.isNewIndiSmsfPermitted = false;
        controller.isNewCorpSmsfPermitted = false;
        controller.processAccountTypes();
        expect(controller.manageFundEstablishment).to.have.been.called;
        const newSmsf = find(controller.form.accounts, ['accountSectionTitle', 'Establish a brand new SMSF']);
        expect(newSmsf).to.equal(undefined);
      });

      it('NEW SMSF account opening should not be there, when the product is annuities and any product type under annuities is selected', () => {
        controller.form.productType = 'Annuity';
        sinon.spy(controller, 'manageAnnuitiesAccountConfig');
        controller.isAnnutiesEnabled = true;
        controller.processAccountTypes();
        expect(controller.manageAnnuitiesAccountConfig).to.have.been.called;
        const newSmsf = find(controller.form.accounts, ['accountSectionTitle', 'Establish a brand new SMSF']);
        expect(newSmsf).to.equal(undefined);
        const existingSmsf = find(controller.form.accounts, ['accountSectionTitle', 'SMSF']);
        expect(existingSmsf).not.to.equal(undefined);
      });

      it('should return appropriate account options when the Annuities product is selected ', () => {
        controller.form.productType = 'Annuity';
        controller.processAccountTypes();
        expect(controller.form.accounts.length).to.equal(6);
      });

      it('should return appropriate account options when the SUPER product is selected ', () => {
        controller.form.productType = 'Superannuation';
        controller.processAccountTypes();
        expect(controller.form.accounts).to.equal(AccountTypeConfig.superAccountTypeConfig);
      });
      it('should return appropriate account options when some product is selected ', () => {
        controller.form.productType = 'SOME OTHER PRODUCT';
        controller.processAccountTypes();
        expect(controller.form.accounts).to.be.null;
      });
    });

    describe('resetAccountOptions', () => {
      it('should reset the account options choosen for trust', () => {
        AccountTypeConfig.idpsAccountTypeConfig.map(account => {
          account.trustType = 'govsuper';
          return account;
        });
        expect(AccountTypeConfig.idpsAccountTypeConfig[0].trustType).to.equal('govsuper');
        controller.resetAccountOptions();
        expect(AccountTypeConfig.idpsAccountTypeConfig[0].trustType).to.be.undefined;
      });

      it('should reset the account options choosen for smsf', () => {
        AccountTypeConfig.idpsAccountTypeConfig.map(account => {
          if (account.smsfAccountTypes) {
            account.accountType = 'individualSMSF';
          }

          return account;
        });
        let smsfAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individualSMSF');
        expect(smsfAccount).not.to.be.undefined;
        controller.resetAccountOptions();
        smsfAccount = find(AccountTypeConfig.idpsAccountTypeConfig, account => account.accountType === 'individualSMSF');
        expect(smsfAccount).to.be.undefined;
      });
    });
  });
});

