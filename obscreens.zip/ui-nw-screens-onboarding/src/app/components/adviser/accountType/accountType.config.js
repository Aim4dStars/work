const trustOptionsList = [
  {
    trustType: 'family',
    displayName: 'Family trust',
  },
  {
    trustType: 'govsuper',
    displayName: 'Government super fund',
  },
  {
    trustType: 'invscheme',
    displayName: 'Registered managed investment scheme',
  },
  {
    trustType: 'regulated',
    displayName: 'Regulated Trust',
  },
  {
    trustType: 'other',
    displayName: 'Other(e.g. unit, charitable or estate)',
  },
];

const idpsAccountTypeConfig = [
  {
    accountSectionTitle: 'Individual',
    accountType: 'individual',
    accountDetailsMore: 'An account with one investor',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/individual-and-joint-accounts.html',
  },
  {
    accountSectionTitle: 'Joint',
    accountType: 'joint',
    accountDetailsMore: 'An account with 2 to 5 investors',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/individual-and-joint-accounts.html',
  },
  {
    accountSectionTitle: 'Trust with individual trustees',
    accountType: 'individualTrust',
    accountDetailsMore: 'A trust with up to 10 individual trustees',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/individual-trust-accounts.html',
    trustOptions: trustOptionsList,

  },
  {
    accountSectionTitle: 'Trust with a corporate trustee',
    accountType: 'corporateTrust',
    accountDetailsMore: 'A trust where a company acts as the trustee',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/trust-corporate-trustee.html',
    trustOptions: trustOptionsList,
  },
  {
    accountSectionTitle: 'Company',
    accountType: 'company',
    accountDetailsMore: 'An Australian registered proprietary company',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/company-accounts.html',
  },
  {
    accountSectionTitle: 'SMSF',
    accountDetailsMore: 'Open an account for an existing SMSF',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/smsf/smsf-accounts/existing-smsf-accounts.html',
    smsfAccountTypes: [
      {
        accountType: 'corporateSMSF',
        displayName: 'Corporate Trustee',
        helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/smsf-corporate-trustee.html',

      },
      {
        accountType: 'individualSMSF',
        displayName: 'Individual Trustee',
        helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/clients/new-accounts/smsf-individual-trustees.html',
      },
    ],
  },
  {
    accountSectionTitle: 'Establish a brand new SMSF',
    accountDetailsMore: 'Using the Panorama SMSF Establishment Service',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/smsf/smsf-accounts/new-smsf-accounts.html',
    smsfAccountTypes: [
      {
        accountType: 'newCorporateSMSF',
        displayName: 'Corporate Trustee',
        helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/smsf/smsf-accounts/newsmsf-corporate-trustee.html',

      },
      {
        accountType: 'newIndividualSMSF',
        displayName: 'Individual Trustee',
        helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/smsf/smsf-accounts/newsmsf-individual-trustee.html',
      },
    ],
  },

];

const superAccountTypeConfig = [
  {
    accountSectionTitle: 'Super',
    accountType: 'superAccumulation',
    accountDetailsMore: 'An account for your client`s superannuation funds',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/managing-your-clients/opening-new-accounts/super-accounts.html',
  },
  {
    accountSectionTitle: 'Pension',
    accountType: 'superPension',
    accountDetailsMore: 'An account for receiving a superannuation pension including transition to retirement',
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/managing-your-clients/opening-new-accounts/pension-accounts.html',
  },
];

const accountTypesConfig = { idpsAccountTypeConfig, superAccountTypeConfig };

export default accountTypesConfig;

