import get from 'lodash/get';

class ViewApplicationService {
  constructor($http) {
    this.$http = $http;
  }

  getApplicationDetails(id) {
    const url = `../api/v1_0/draft_accounts/client_application?id=${id}`;
    return this.$http.get(url)
      .then(res => get(res, 'data.data'));
  }
}

ViewApplicationService.$inject = ['$http'];

export default ViewApplicationService;
