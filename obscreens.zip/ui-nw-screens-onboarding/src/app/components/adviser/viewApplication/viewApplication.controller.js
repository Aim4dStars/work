import compact from 'lodash/compact';
import { accountTypeToAccountNameMap } from '../../../helper/utilities';

class ViewApplicationController {
  constructor($stateParams, schemaService, staticDataService) {
    this.$stateParams = $stateParams;
    this.name = 'adviser view application';
    this.model = {};
    this.schemaService = schemaService;
    this.staticDataService = staticDataService;
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.model.applicationDetails = this.applicationDetails;
    this.accountType = this.model.applicationDetails.investorAccountType;
    this.setPageSubtitle();
    this.setContentOfSummaryBar(this.applicationDetails.productName, this.applicationDetails.trust, this.applicationDetails.referenceNumber);
  }

  setPageSubtitle() {
    const accountType = accountTypeToAccountNameMap[this.model.applicationDetails.investorAccountType];
    const subtitle = [[accountType, 'account'].join(' '), this.model.applicationDetails.accountName].join(' • ');
    this.model.subtitle = subtitle;
  }

  setContentOfSummaryBar(productName, trust, referenceNumber) {
    let trustTypeLabel;
    if (trust && trust.trustType) {
      trustTypeLabel = `Trust type: ${trust.trustType}`;
    }

    this.model.summaryBar = compact([productName, trustTypeLabel, referenceNumber]).join(' • ');
  }
}

ViewApplicationController.$inject = ['$stateParams', 'nw.onboarding.common.api.schemaEnums'];

export default ViewApplicationController;
