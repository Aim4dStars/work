import viewApplicationModule from './viewApplication';
import viewApplicationController from './viewApplication.controller';
import viewApplicationComponent from './viewApplication.component';
import viewApplicationTemplate from './viewApplication.html';

describe('viewApplication', () => {
  let $rootScope;
  let $componentController;
  let controller;
  let service;
  let $httpBackend;
  let $q;
  let schemaService;
  let staticDataService;
  let $state;

  // load the module
  beforeEach(() => {
    window.module('ui.router');
    window.module($stateProvider => {
      $stateProvider.state('app', { url: '/app' });
      $stateProvider.state('app.adviser', { url: '/adviser' });
      $stateProvider.state('app.adviser.applicationNotFound', { url: '/applicationNotFound' });
    });
    window.module(viewApplicationModule.name);
  });

  beforeEach(inject($injector => {
    $httpBackend = $injector.get('$httpBackend');
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $q = $injector.get('$q');
    service = $injector.get('nw.onboarding.adviser.viewApplication.viewApplicationService');
    schemaService = $injector.get('nw.onboarding.common.api.schemaEnums');
    staticDataService = $injector.get('nw.onboarding.common.api.static');
    $state = $injector.get('$state');
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = viewApplicationComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(viewApplicationTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(viewApplicationController);
    });

    it('should call getSchemaEnums, getStaticData and getApplicationDetails on transition to state', () => {
      schemaService.getSchemaEnums = sinon.spy();
      staticDataService.getStaticData = sinon.spy();
      service.getApplicationDetails = sinon.stub().returns($q.resolve());
      $state.go('app.adviser.viewApplication', { id: '123456' });
      $rootScope.$digest();
      expect(schemaService.getSchemaEnums).to.have.been.called;
      expect(staticDataService.getStaticData).to.have.been.called;
      expect(service.getApplicationDetails).to.have.been.called;
    });

    it('should call applicationNotFound on reject of getApplicationDetails', () => {
      const deferred = $q.defer();
      schemaService.getSchemaEnums = sinon.spy();
      staticDataService.getStaticData = sinon.spy();
      sinon.stub(service, 'getApplicationDetails').returns(deferred.promise);
      $state.go('app.adviser.viewApplication', { id: '123456' });
      deferred.reject();
      $rootScope.$digest();
      expect($state.current.name).to.eq('app.adviser.applicationNotFound');
    });
  });

  describe('Controller', () => {
    let $resolve;

    // controller specs
    beforeEach(() => {
      $resolve = { // mock resolved data
        applicationDetails: {
          accountName: 'Angela Smith', investorAccountType: 'joint', adviser: { fullName: 'Rob Bailey', email: [{ email: 'Dummy@BTFinancialGroup.com' }], phone: [{ number: '123456789' }] }, productName: 'White Label', referenceNumber: 'R00012',
        },
        schemaEnums:
          {
            AccountTypeEnum:
            {
              INDIVIDUAL: 'individual',
              JOINT: 'joint',
              COMPANY: 'company',
              INDIVIDUAL_TRUST: 'individualTrust',
              CORPORATE_TRUST: 'corporateTrust',
              NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
              NEW_CORPORATE_SMSF: 'newCorporateSMSF',
              INDIVIDUAL_SMSF: 'individualSMSF',
              CORPORATE_SMSF: 'corporateSMSF',
              SUPER_ACCUMULATION: 'superAccumulation',
              SUPER_PENSION: 'superPension',
            },
          },
        staticData:
          {
            states: [
              {
                value: 'NSW',
                label: 'New South Wales',
              },
              {
                value: 'QLD',
                label: 'Queensland',
              },
            ],
          },
      };
      const stateParams = { overview: true };
      controller = $componentController('nw.onboarding.adviser.viewApplication.viewApplicationComponent', {
        $scope: $rootScope.$new(), $stateParams: stateParams,
      }, $resolve);
    });

    describe('onInit', () => {
      it('should set applicationDetails to model', () => {
        controller.$onInit();
        expect(controller.model.applicationDetails).to.equal($resolve.applicationDetails);
      });

      it('should be able to access schemaEnums in conroller', () => {
        controller.$onInit();
        expect(controller.schemaEnums.AccountTypeEnum.SUPER_ACCUMULATION).to.equal('superAccumulation');
      });

      it('should be able to access staticData in controller', () => {
        controller.$onInit();
        expect(controller.staticData.states.length).to.equal(2);
      });

      it('should set page sub titile', () => {
        controller.$onInit();
        expect(controller.model.subtitle).to.equal('Joint account • Angela Smith');
      });

      it('should set summary bar when trust type is not present', () => {
        controller.$onInit();
        expect(controller.model.summaryBar).to.equal('White Label • R00012');
      });

      it('should set summary bar when trust type is  present', () => {
        controller.applicationDetails.trust = { trustType: 'other' };
        controller.$onInit();
        expect(controller.model.summaryBar).to.equal('White Label • Trust type: other • R00012');
      });
    });
  });

  describe('Service', () => {
    let res;
    const data = { data: { property: 'testData' } };

    it('getApplicationDetails should call /draft_accounts/<client_application?id=id', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/draft_accounts/client_application?id=123456').respond(data);
      service.getApplicationDetails('123456').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });
  });
});
