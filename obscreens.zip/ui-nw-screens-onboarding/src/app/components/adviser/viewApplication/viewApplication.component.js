import template from './viewApplication.html';
import controller from './viewApplication.controller';

const viewApplicationComponent = {
  bindings: {
    applicationDetails: '<',
    schemaEnums: '<',
    staticData: '<',
  },
  template,
  controller,
};

export default viewApplicationComponent;
