import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import viewApplicationComponent from './viewApplication.component';
import viewApplicationService from './viewApplication.service';

const viewApplicationModule = angular.module('nw.onboarding.adviser.viewApplication', [
  uiRouter,
  'nw.onboarding.common.viewApplication',
  'nw.onboarding.common.api',
])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.adviser.viewApplication', {
        url: '/view-application/:id',
        component: 'nw.onboarding.adviser.viewApplication.viewApplicationComponent',
        data: {
          chromeConfig: {
            headerPanel: 'Application Summary',
            headerMenu: true,
          },
        },
        resolve: {
          applicationDetails: ['nw.onboarding.adviser.viewApplication.viewApplicationService', '$stateParams', '$state', (service, $stateParams, $state) =>
            service.getApplicationDetails($stateParams.id).catch(() => $state.go('app.adviser.applicationNotFound')),
          ],
          schemaEnums: ['nw.onboarding.common.api.schemaEnums', schemaService => schemaService.getSchemaEnums()],
          staticData: ['nw.onboarding.common.api.static', staticDataService => staticDataService.getStaticData('states'),
          ],
        },
      });
  })

  .component('nw.onboarding.adviser.viewApplication.viewApplicationComponent', viewApplicationComponent)

  .service('nw.onboarding.adviser.viewApplication.viewApplicationService', viewApplicationService);

export default viewApplicationModule;
