
const trustConfig = {
  family: {
    title: 'Add Trust Details',
    fields: [
      'Trust name',
      'Date of registration',
      'Registration state',
      'Industry category',
      'Registered for GST',
      'Source of wealth',
      'Personal investment entity',
      'Settlor of trust',
      'Trust TFN/exemption',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Trust address',
      'Trust verification check',
    ],
  },
  govsuper: {
    title: 'Add Trust Details',
    fields: [
      'Trust name',
      'Date of registration',
      'Registration state',
      'Name of legislation establishing the fund',
      'Industry category',
      'Registered for GST',
      'Source of wealth',
      'Trust TFN/exemption',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Trust address',
      'Trust verification check',
    ],
  },

  other: {
    title: 'Add Trust Details',
    fields: [
      'Trust description',
      'Trust name',
      'Date of registration',
      'Registration state',
      'Industry category',
      'Registered for GST',
      'Source of wealth',
      'Personal investment entity',
      'Settlor of trust',
      'Trust TFN/exemption',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Trust address',
      'Trust verification check',
    ],
  },

  invscheme: {
    title: 'Add Trust Details',
    fields: [
      'Trust name',
      'Australian registered scheme number (ARSN)',
      'Date of registration',
      'Registration state',
      'Industry category',
      'Registered for GST',
      'Source of wealth',
      'Trust TFN/exemption',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Trust address',
      'Trust verification check',
    ],
  },

  regulated: {
    title: 'Add Trust Details',
    fields: [
      'Trust name',
      'Licensing number',
      'Date of registration',
      'Registration state',
      'Industry category',
      'Registered for GST',
      'Source of wealth',
      'Trust TFN/exemption',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Trust address',
      'Trust verification check',
    ],
  },


};

export default trustConfig;

