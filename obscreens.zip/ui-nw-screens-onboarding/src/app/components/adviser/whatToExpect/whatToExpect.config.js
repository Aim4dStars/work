
const AccountTypes = {
  individual: {
    sections: ['person', 'accountSettings', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for an existing Panorama client, their current details will be used.',
    timeToComplete: 5,
  },
  joint: {
    sections: ['person', 'accountSettings', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for existing Panorama clients, their current details will be used.',
    timeToComplete: 10,

  },
  individualSMSF: {
    sections: ['smsfDetails', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for existing client(s), their current details will be used.',
    timeToComplete: 10,
  },
  corporateSMSF: {
    sections: ['smsfDetails', 'companyTrustee', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for existing client(s), their current details will be used.',
    timeToComplete: 10,
  },
  newIndividualSMSF: {
    sections: ['smsfDetails', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/smsf/smsf-accounts/new-smsf-accounts.html',
    feeAmount: '$695',
    timeToComplete: 10,
  },
  newCorporateSMSF: {
    sections: ['smsfDetails', 'companyTrustee', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    helpAndSupportUrl: '/content/secure/help-and-support/bt/en/adviser/smsf/smsf-accounts/new-smsf-accounts.html',
    feeAmount: '$1,475',
    timeToComplete: 10,
  },
  individualTrust: {
    sections: ['trustDetails', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for an existing Panorama trust or client/s, their current details will be used.',
    timeToComplete: 10,
  },
  corporateTrust: {
    sections: ['trustDetails', 'companyTrustee', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for an existing Panorama trust or client/s, their current details will be used.',
    timeToComplete: 10,
  },
  company: {
    sections: ['companyDetails', 'person', 'accountSettings', 'shareholderAndMembers', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for an existing Panorama client/s, their current details will be used.',
    timeToComplete: 10,
  },
  superAccumulation: {
    sections: ['person', 'accountSettings', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for an existing Panorama client, their current details will be used.',
    timeToComplete: 5,
  },
  superPension: {
    sections: ['pensionEligibility', 'person', 'accountSettings', 'linkedAccounts', 'fees'],
    existingClientInfo: 'If this account is for an existing Panorama client, their current details will be used.',
    timeToComplete: 5,
  },
};

export default AccountTypes;
