
import angular from 'angular';
import uiRouter from 'angular-ui-router';// eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import whatToExpectComponent from './whatToExpect.component';
import personTemplate from './person/person.html';
import accountSettingsTemplate from './accountSettings/accountSettings.html';
import linkedAccountsTemplate from './linkedAccounts/linkedAccounts.html';
import feesTemplate from './fees/fees.html';
import shareholderAndMembersTemplate from './shareholderAndMembers/shareholderAndMembers.html';
import companyTemplate from './company/company.html';
import companyTrusteeTemplate from './companyTrustee/companyTrustee.html';
import smsfTemplate from './smsf/smsf.html';
import trustTemplate from './trust/trust.html';
import pensionEligibilityTemplate from './pensionEligibility/pensionEligibility.html';

const whatToExpectModule = angular.module('nw.onboarding.adviser.whatToExpect', [
  uiRouter,

])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.adviser.whatToExpect', {
        url: '/what-to-expect?accountType&productId&adviserId&trustType&parentProductName',
        component: 'nw.onboarding.adviser.whatToExpect',
        data: {
          chromeConfig: {
            headerPanel: 'Open an account',
            headerMenu: false,
            headerCancel: { url: '#/app/adviser/account-type' },
          },
        },
      });
  })

  .run($templateCache => {
    'ngInject';

    $templateCache.put('person-template.html', personTemplate);
    $templateCache.put('account-settings-template.html', accountSettingsTemplate);
    $templateCache.put('linked-accounts-template.html', linkedAccountsTemplate);
    $templateCache.put('fees-template.html', feesTemplate);
    $templateCache.put('shareholder-and-members-template.html', shareholderAndMembersTemplate);
    $templateCache.put('company-details-template.html', companyTemplate);
    $templateCache.put('company-trustee-template.html', companyTrusteeTemplate);
    $templateCache.put('smsf-details-template.html', smsfTemplate);
    $templateCache.put('trust-details-template.html', trustTemplate);
    $templateCache.put('pension-eligibility-template.html', pensionEligibilityTemplate);
  })

  .component('nw.onboarding.adviser.whatToExpect', whatToExpectComponent);

export default whatToExpectModule;
