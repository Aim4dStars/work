
const smsfConfig = {

  existingSmsf: {
    title: 'Add smsf details',
    fields: [
      'SMSF fund name',
      'ABN',
      'Date of registration',
      'Registration state',
      'Industry category',
      'Registered for GST',
      'Source of wealth',
      'Fund TFN/exemption',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'SMSF address',
      'SMSF verification check',
    ],
  },

  newSmsf: {
    title: 'Add smsf details',
    fields: [
      'SMSF fund name',
      'Source of wealth',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'SMSF address',
    ],
    subSection: {
      infoTitle: 'The following will be provided when we set up your fund',
      fields: [
        'ABN',
        'Date of registration',
        'Registration state',
        'Fund TFN',
      ],
    },
  },

};

export default smsfConfig;

