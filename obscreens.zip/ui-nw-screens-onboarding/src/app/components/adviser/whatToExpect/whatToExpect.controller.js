import without from 'lodash/without';
import map from 'lodash/map';
import AccountTypes from './whatToExpect.config';
import personConfig from './person/person.config';
import accountSettingsConfig from './accountSettings/accountSettings.config';
import shareholderAndMembersConfig from './shareholderAndMembers/shareholderAndMembers.config';
import companyTrusteeConfig from './companyTrustee/companyTrustee.config';
import smsfConfig from './smsf/smsf.config';
import trustConfig from './trust/trust.config';

class WhatToExpectController {
  constructor($stateParams, $window) {
    this.name = 'What to expect';
    this.$stateParams = $stateParams;
    this.$window = $window;
    this.accountType = this.$stateParams.accountType;
    this.adviserId = this.$stateParams.adviserId;
    this.productId = this.$stateParams.productId;
    this.trustType = this.$stateParams.trustType;
    this.productType = this.$stateParams.parentProductName;
    this.model = {};
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.isFamilyorOther = this.trustType === 'family' || this.trustType === 'other';
    this.isAnnuity = this.productType === 'Annuity';
    this.isLinkedAccountOptional = this.checkForLinkedAccountOptional();
    this.account = AccountTypes[this.accountType];
    this.account.sections = this.isAnnuity ? without(this.account.sections, 'fees') : this.account.sections;
    this.personConfig = personConfig[this.accountType];
    this.accountSettingsConfig = this.isAnnuity ? accountSettingsConfig.annuity[this.accountType] : accountSettingsConfig[this.accountType];
    this.companyTrusteeConfig = companyTrusteeConfig[this.accountType];
    this.shareholderAndMembersConfig = shareholderAndMembersConfig[this.accountType];
    this.shareholderAndMembersConfig = this.isFamilyorOther && this.shareholderAndMembersConfig.familyOrOther ? this.shareholderAndMembersConfig.familyOrOther : this.shareholderAndMembersConfig;
    this.smsfConfig = (this.accountType === 'newIndividualSMSF' || this.accountType === 'newCorporateSMSF') ? smsfConfig.newSmsf : smsfConfig.existingSmsf;
    this.trustConfig = trustConfig[this.trustType];
    this.makeDynamicTemplate();
  }

  checkForLinkedAccountOptional() {
    const linkedAccountsOptionalAcctTypes = ['individualSMSF', 'corporateSMSF', 'newCorporateSMSF', 'newIndividualSMSF'];
    return !this.isAnnuity && (this.productType === 'Cash Management Account' || linkedAccountsOptionalAcctTypes.indexOf(this.accountType) > -1);
  }

  startApp() {
    const firstSection = this.account.sections[0].toLowerCase() === 'person' ? 'investors' : this.account.sections[0].toLowerCase();
    let url = `#ng/newaccount/newaccountform?accounttype=${this.accountType}&productid=${this.productId}&adviserid=${this.adviserId}&section=${firstSection}`;
    if (this.trustType) {
      url += `&trusttype=${this.trustType}`;
    }
    this.$window.top.location.href = this.$window.top.location.href.replace(this.$window.top.location.hash, url);
  }

  makeDynamicTemplate() {
    this.sectionTemplates = map(this.account.sections, sectionName => sectionName.replace(/([A-Z])/g, firstChar => `-${firstChar.toLowerCase()}`).concat('-template.html'));
  }
}

WhatToExpectController.$inject = [
  '$stateParams',
  '$window',
];

export default WhatToExpectController;
