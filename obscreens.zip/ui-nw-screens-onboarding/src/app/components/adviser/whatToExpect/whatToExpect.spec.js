import AccountTypes from './whatToExpect.config';
import personConfig from './person/person.config';
import accountSettingsConfig from './accountSettings/accountSettings.config';
import shareholderAndMembersConfig from './shareholderAndMembers/shareholderAndMembers.config';
import companyTrusteeConfig from './companyTrustee/companyTrustee.config';
import smsfConfig from './smsf/smsf.config';
import trustConfig from './trust/trust.config';
import WhatToExpectModule from './whatToExpect';
import WhatToExpectController from './whatToExpect.controller';
import WhatToExpectComponent from './whatToExpect.component';
import WhatToExpectTemplate from './whatToExpect.html';

describe('WhatToExpect', () => {
  let $rootScope;
  let $compile;
  let $componentController;
  let scope;
  let $stateParams;
  let controller;

  // load the module
  beforeEach(window.module(WhatToExpectModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $compile = $injector.get('$compile');
    $stateParams = $injector.get('$stateParams');
    scope = $rootScope.$new();
  }));

  describe('Module', () => {
    const component = WhatToExpectComponent;
    it('includes the intended template', () => {
      expect(component.template).to.equal(WhatToExpectTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(WhatToExpectController);
    });
  });


  describe('Controller', () => {
    // controller specs
    const stateParams = {
      accountType: 'individual',
      productId: 'abc',
      adviserId: '123',
      parentProductName: 'Investment',
    };

    beforeEach(() => {
      controller = $componentController('nw.onboarding.adviser.whatToExpect', {
        $scope: $rootScope.$new(),
        $stateParams: stateParams,
      });
    });

    describe('$onInit', () => {
      describe('when accountype is individual', () => {
        it('when Investment product', () => {
          controller.accountType = 'individual';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.account).to.eql(AccountTypes.individual);
          expect(controller.personConfig).to.eql(personConfig.individual);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.individual);
          expect(controller.sectionTemplates).to.eql(['person-template.html', 'account-settings-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'individual';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
        it('when Annuity product', () => {
          controller.accountType = 'individual';
          controller.productType = 'Annuity';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.true;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.individual);
          expect(controller.sectionTemplates).to.eql(['person-template.html', 'account-settings-template.html', 'linked-accounts-template.html']);
        });
      });

      describe('when accountype is joint', () => {
        it('when Investment product', () => {
          controller.accountType = 'joint';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.account).to.eql(AccountTypes.joint);
          expect(controller.personConfig).to.eql(personConfig.joint);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.joint);
          expect(controller.sectionTemplates).to.eql(['person-template.html', 'account-settings-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'joint';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
        it('when Annuity product', () => {
          controller.accountType = 'joint';
          controller.productType = 'Annuity';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.true;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.joint);
          expect(controller.sectionTemplates).to.eql(['person-template.html', 'account-settings-template.html', 'linked-accounts-template.html']);
        });
      });
      describe('when accountype individualTrust', () => {
        describe('when family type', () => {
          it('when Investment product', () => {
            controller.accountType = 'individualTrust';
            controller.trustType = 'family';
            controller.$onInit();
            expect(controller.isAnnuity).to.be.false;
            expect(controller.isLinkedAccountOptional).to.be.false;
            expect(controller.account).to.eql(AccountTypes.individualTrust);
            expect(controller.trustConfig).to.eql(trustConfig.family);
            expect(controller.personConfig).to.eql(personConfig.individualTrust);
            expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.individualTrust);
            expect(controller.shareholderAndMembersConfig).to.eql(shareholderAndMembersConfig.individualTrust.familyOrOther);
            expect(controller.sectionTemplates).to.eql(['trust-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
          });
          it('when Cash management product, has only one change', () => {
            controller.accountType = 'individualTrust';
            controller.productType = 'Cash Management Account';
            controller.$onInit();
            expect(controller.isAnnuity).to.be.false;
            expect(controller.isLinkedAccountOptional).to.be.true;
          });
          it('when Annuity product', () => {
            controller.accountType = 'individualTrust';
            controller.productType = 'Annuity';
            controller.$onInit();
            expect(controller.isAnnuity).to.be.true;
            expect(controller.isLinkedAccountOptional).to.be.false;
            expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.individualTrust);
            expect(controller.sectionTemplates).to.eql(['trust-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html']);
          });
        });
        describe('when other trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'individualTrust';
            controller.trustType = 'other';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.other);
          });
        });
        describe('when govsuper trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'individualTrust';
            controller.trustType = 'govsuper';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.govsuper);
          });
        });
        describe('when invscheme trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'individualTrust';
            controller.trustType = 'invscheme';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.invscheme);
          });
        });
        describe('when regulated trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'individualTrust';
            controller.trustType = 'regulated';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.regulated);
          });
        });
      });

      describe('when accountype corporateTrust', () => {
        describe('when family type', () => {
          it('when Investment product', () => {
            controller.accountType = 'corporateTrust';
            controller.trustType = 'family';
            controller.$onInit();
            expect(controller.isAnnuity).to.be.false;
            expect(controller.isLinkedAccountOptional).to.be.false;
            expect(controller.account).to.eql(AccountTypes.corporateTrust);
            expect(controller.trustConfig).to.eql(trustConfig.family);
            expect(controller.personConfig).to.eql(personConfig.corporateTrust);
            expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.corporateTrust);
            expect(controller.shareholderAndMembersConfig).to.eql(shareholderAndMembersConfig.corporateTrust);
            expect(controller.sectionTemplates).to.eql(['trust-details-template.html', 'company-trustee-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
          });
          it('when Cash management product, has only one change', () => {
            controller.accountType = 'corporateTrust';
            controller.productType = 'Cash Management Account';
            controller.$onInit();
            expect(controller.isAnnuity).to.be.false;
            expect(controller.isLinkedAccountOptional).to.be.true;
          });
          it('when Annuity product', () => {
            controller.accountType = 'corporateTrust';
            controller.productType = 'Annuity';
            controller.$onInit();
            expect(controller.isAnnuity).to.be.true;
            expect(controller.isLinkedAccountOptional).to.be.false;
            expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.corporateTrust);
            expect(controller.sectionTemplates).to.eql(['trust-details-template.html', 'company-trustee-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html']);
          });
        });
        describe('when other trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'corporateTrust';
            controller.trustType = 'other';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.other);
          });
        });
        describe('when govsuper trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'corporateTrust';
            controller.trustType = 'govsuper';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.govsuper);
          });
        });
        describe('when invscheme trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'corporateTrust';
            controller.trustType = 'invscheme';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.invscheme);
          });
        });
        describe('when regulated trust ( only one change or else same as family test caes', () => {
          it('when Investment product', () => {
            controller.accountType = 'corporateTrust';
            controller.trustType = 'regulated';
            controller.$onInit();
            expect(controller.trustConfig).to.eql(trustConfig.regulated);
          });
        });
      });


      describe('when accountype is superAccumulation', () => {
        it('when Supperannuation product', () => {
          controller.accountType = 'superAccumulation';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.account).to.eql(AccountTypes.superAccumulation);
          expect(controller.personConfig).to.eql(personConfig.superAccumulation);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.superAccumulation);
          expect(controller.sectionTemplates).to.eql(['person-template.html', 'account-settings-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
      });

      describe('when accountype is superPension', () => {
        it('when Supperannuation product', () => {
          controller.accountType = 'superPension';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.account).to.eql(AccountTypes.superPension);
          expect(controller.personConfig).to.eql(personConfig.superPension);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.superPension);
          expect(controller.sectionTemplates).to.eql(['pension-eligibility-template.html', 'person-template.html', 'account-settings-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
      });

      describe('when accountype is individualSMSF', () => {
        it('when Investment product', () => {
          controller.accountType = 'individualSMSF';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
          expect(controller.account).to.eql(AccountTypes.individualSMSF);
          expect(controller.smsfConfig).to.eql(smsfConfig.existingSmsf);
          expect(controller.personConfig).to.eql(personConfig.individualSMSF);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.individualSMSF);
          expect(controller.shareholderAndMembersConfig).to.eql(shareholderAndMembersConfig.individualSMSF);
          expect(controller.sectionTemplates).to.eql(['smsf-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'individualSMSF';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
        it('when Annuity product', () => {
          controller.accountType = 'individualSMSF';
          controller.productType = 'Annuity';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.true;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.individualSMSF);
          expect(controller.sectionTemplates).to.eql(['smsf-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html']);
        });
      });

      describe('when accountype is corporateSMSF', () => {
        it('when Investment product', () => {
          controller.accountType = 'corporateSMSF';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
          expect(controller.account).to.eql(AccountTypes.corporateSMSF);
          expect(controller.smsfConfig).to.eql(smsfConfig.existingSmsf);
          expect(controller.personConfig).to.eql(personConfig.corporateSMSF);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.corporateSMSF);
          expect(controller.shareholderAndMembersConfig).to.eql(shareholderAndMembersConfig.corporateSMSF);
          expect(controller.companyTrusteeConfig).to.eql(companyTrusteeConfig.corporateSMSF);
          expect(controller.sectionTemplates).to.eql(['smsf-details-template.html', 'company-trustee-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'corporateSMSF';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
        it('when Annuity product', () => {
          controller.accountType = 'corporateSMSF';
          controller.productType = 'Annuity';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.true;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.corporateSMSF);
          expect(controller.sectionTemplates).to.eql(['smsf-details-template.html', 'company-trustee-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html']);
        });
      });

      describe('when accountype is newIndividualSMSF', () => {
        it('when Investment product', () => {
          controller.accountType = 'newIndividualSMSF';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
          expect(controller.account).to.eql(AccountTypes.newIndividualSMSF);
          expect(controller.smsfConfig).to.eql(smsfConfig.newSmsf);
          expect(controller.personConfig).to.eql(personConfig.newIndividualSMSF);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.newIndividualSMSF);
          expect(controller.shareholderAndMembersConfig).to.eql(shareholderAndMembersConfig.newIndividualSMSF);
          expect(controller.sectionTemplates).to.eql(['smsf-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'newIndividualSMSF';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
      });

      describe('when accountype is newCorporateSMSF', () => {
        it('when Investment product', () => {
          controller.accountType = 'newCorporateSMSF';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
          expect(controller.account).to.eql(AccountTypes.newCorporateSMSF);
          expect(controller.smsfConfig).to.eql(smsfConfig.newSmsf);
          expect(controller.personConfig).to.eql(personConfig.newCorporateSMSF);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.newCorporateSMSF);
          expect(controller.companyTrusteeConfig).to.eql(companyTrusteeConfig.newCorporateSMSF);
          expect(controller.shareholderAndMembersConfig).to.eql(shareholderAndMembersConfig.newCorporateSMSF);
          expect(controller.sectionTemplates).to.eql(['smsf-details-template.html', 'company-trustee-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'newCorporateSMSF';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
      });

      describe('when accountype is company', () => {
        it('when Investment product', () => {
          controller.accountType = 'company';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.account).to.eql(AccountTypes.company);
          expect(controller.personConfig).to.eql(personConfig.company);
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.company);
          expect(controller.sectionTemplates).to.eql(['company-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html', 'fees-template.html']);
        });
        it('when Cash management product, has only one change', () => {
          controller.accountType = 'company';
          controller.productType = 'Cash Management Account';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.false;
          expect(controller.isLinkedAccountOptional).to.be.true;
        });
        it('when Annuity product', () => {
          controller.accountType = 'company';
          controller.productType = 'Annuity';
          controller.$onInit();
          expect(controller.isAnnuity).to.be.true;
          expect(controller.isLinkedAccountOptional).to.be.false;
          expect(controller.accountSettingsConfig).to.eql(accountSettingsConfig.annuity.company);
          expect(controller.sectionTemplates).to.eql(['company-details-template.html', 'person-template.html', 'account-settings-template.html', 'shareholder-and-members-template.html', 'linked-accounts-template.html']);
        });
      });
    });

    describe('startApp', () => {
      beforeEach(() => {
        controller.$window = { top: { location: { href: 'ng/secure/#/adviser/what-to-expect', hash: '#/adviser/what-to-expect' } } };
      });
      it('should naviagte to old form capture based on accounttype', () => {
        controller.accountType = 'individual';
        controller.$onInit(); // to intilise the data
        controller.startApp();
        expect(controller.$window.top.location.href).to.equals('ng/secure/#ng/newaccount/newaccountform?accounttype=individual&productid=abc&adviserid=123&section=investors');
      });
      it('should naviagte to old form capture when trust type is there', () => {
        controller.accountType = 'individualTrust';
        controller.trustType = 'family';
        controller.$onInit(); // to intilise the data
        controller.startApp();
        expect(controller.$window.top.location.href).to.equals('ng/secure/#ng/newaccount/newaccountform?accounttype=individualTrust&productid=abc&adviserid=123&section=trustdetails&trusttype=family');
      });
    });
  });

  describe('View', () => {
    // view layer specs.
    let template;
    let ctrl;

    beforeEach(() => {
      $stateParams.accountType = 'individual';
      $stateParams.parentProductName = 'Investment';
      template = $compile('<nw.onboarding.adviser.what-to-expect></nw.onboarding.adviser.what-to-expect>')(scope);
      ctrl = template.controller('nw.onboarding.adviser.whatToExpect');
      scope.$apply();
    });

    describe('when new newCorporateSMSF under Investment product', () => {
      it('header related info', () => {
        ctrl.accountType = 'newCorporateSMSF';
        ctrl.$onInit();
        scope.$apply();
        expect(template.html()).to.match(/he corporate trustee setup will take place on submission of this form. You will need to confirm you have the relevant consents in place for this setup./g);
        expect(template.html()).to.match(/The full SMSF establishment process can take up to 30 days. <a href="\/content\/secure\/help-and-support\/bt\/en\/adviser\/smsf\/smsf-accounts\/new-smsf-accounts.html" target="_blank" class="text-link">Learn more<\/a>/g);
        expect(template.html()).to.match(/The fee for establishment of an SMSF on Panorama is <span class="type-important ng-binding">\$1,475<\/span>. You can add your own establishment fee and ongoing advice fees. These fees will be charged when sufficient funds are available in the account./g);
        expect(template.html()).to.match(/If this account is for existing client\/s, their current details will be used./g);
      });
    });

    describe('when new newIndividualSMSF under Investment product', () => {
      it('header related info', () => {
        ctrl.accountType = 'newIndividualSMSF';
        ctrl.$onInit();
        scope.$apply();
        expect(template.html()).not.to.match(/he corporate trustee setup will take place on submission of this form. You will need to confirm you have the relevant consents in place for this setup./g);
        expect(template.html()).to.match(/The full SMSF establishment process can take up to 30 days. <a href="\/content\/secure\/help-and-support\/bt\/en\/adviser\/smsf\/smsf-accounts\/new-smsf-accounts.html" target="_blank" class="text-link">Learn more<\/a>/g);
        expect(template.html()).to.match(/The fee for establishment of an SMSF on Panorama is <span class="type-important ng-binding">\$695<\/span>. You can add your own establishment fee and ongoing advice fees. These fees will be charged when sufficient funds are available in the account./g);
        expect(template.html()).to.match(/If this account is for existing client\/s, their current details will be used./g);
      });
    });

    describe('when new super and pension account', () => {
      it('header related info', () => {
        ctrl.accountType = 'superAccumulation';
        ctrl.$onInit();
        scope.$apply();
        expect(template.html()).to.match(/Complete this application to open an account. After opening this account you can:/g);
        expect(template.html()).to.match(/Rollover super funds/g);
        expect(template.html()).to.match(/Make contributions/g);
        expect(template.html()).to.match(/Add beneficiaries/g);
      });
    });

    describe('general info', () => {
      it('when Investment or cma products', () => {
        expect(template.html()).to.match(/Steps and information you will need/g);
        expect(template.html()).not.to.match(/Steps for opening a Challenger annuity on Panorama/g);
        expect(template.html()).not.to.match(/Information you will need to open a Panorama annuity account/g);
      });

      it('when Annuity product', () => {
        ctrl.productType = 'Annuity';
        ctrl.$onInit();
        scope.$apply();
        expect(template.html()).to.match(/Steps for opening a Challenger annuity on Panorama/g);
        expect(template.html()).to.match(/Information you will need to open a Panorama annuity account/g);
        expect(template.html()).to.match(/Panorama annuity account created/g);
        expect(template.html()).to.match(/Access to apply for Challenger annuity/g);
      });
    });
  });
});
