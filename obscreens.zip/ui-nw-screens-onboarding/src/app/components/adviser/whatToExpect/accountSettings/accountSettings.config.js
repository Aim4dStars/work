
const accountSettingsConfig = {
  individual: {
    title: 'Set up account settings',
    fields: [
      'Payment settings for investor',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  joint: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Payment settings for investors',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  individualSMSF: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Payment settings for trustees',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  corporateSMSF: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Directors approving the opening of this account (only if more than two directors)',
      'Payment settings for directors',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  newIndividualSMSF: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Payment settings for trustees',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  newCorporateSMSF: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Directors approving the opening of this account (only if more than two directors)',
      'Payment settings for directors',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  individualTrust: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Payment settings for trustees',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  corporateTrust: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Directors approving the opening of this account (only if more than two directors)',
      'Payment settings for directors',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  company: {
    title: 'Set up account settings',
    fields: [
      'Primary contact',
      'Roles i.e. directors, signatories and secretaries',
      'Directors, signatories and secretaries approving the opening of this account (only if more than two directors, signatories and secretaries)',
      'Payment settings for directors, secretaries and signatories',
      'Payment settings for professionals',
      'Source of funds',
      'Specify if a person linked to this account holds a power of attorney over the account',
    ],
  },
  superAccumulation: {
    title: 'Set up account settings',
    fields: [
      'Payment settings for investor',
      'Payment settings for professionals',
      'Source of funds',
    ],
  },
  superPension: {
    title: 'Set up account settings',
    fields: [
      'Payment settings for investor',
      'Payment settings for professionals',
      'Source of funds',
    ],
  },

  annuity: {
    individual: {
      title: 'Set up account settings',
      fields: [
        'Source of funds',
      ],
    },
    joint: {
      title: 'Set up account settings',
      fields: [
        'Source of funds',
      ],
    },
    company: {
      title: 'Set up account settings',
      fields: [
        'Primary contact',
        'Roles i.e. directors, signatories and secretaries',
        'Source of funds',
      ],
    },
    individualTrust: {
      title: 'Set up account settings',
      fields: [
        'Primary contact',
        'Source of funds',
      ],
    },
    corporateTrust: {
      title: 'Set up account settings',
      fields: [
        'Primary contact',
        'Source of funds',
      ],
    },
    individualSMSF: {
      title: 'Set up account settings',
      fields: [
        'Primary contact',
        'Source of funds',
      ],
    },
    corporateSMSF: {
      title: 'Set up account settings',
      fields: [
        'Primary contact',
        'Source of funds',
      ],
    },
  },
};


export default accountSettingsConfig;
