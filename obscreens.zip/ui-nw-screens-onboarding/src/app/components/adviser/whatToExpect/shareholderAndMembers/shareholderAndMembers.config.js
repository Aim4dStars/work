
const shareholderAndMembersConfig = {

  individualSMSF: {
    title: 'Add Members including under 18/legally disabled',
    fields: ['Name', 'Date of birth', 'Residential address'],
  },

  corporateSMSF: {
    title: 'Add members, Shareholders and Controllers',
    sections: [
      {
        title: 'For shareholders and controllers',
        fields: ['Name', 'Alternate name', 'Gender', 'Date of birth', 'Country of residence for tax purposes', 'Tax identification number(s) (for overseas residents)', 'Residential address', 'Proof of identity'],
      },
      {
        title: 'For members under 18/legally disabled',
        fields: ['Name', 'Date of birth', 'Residential address'],
      },
    ],
  },

  newIndividualSMSF: {
    title: 'Nominate Members',
    fields: ['Fund members'],
  },

  newCorporateSMSF: {
    title: 'Nominate Shareholders and Members',
    fields: ['Company secretary', 'Shareholders', 'Fund members'],
  },

  individualTrust: {
    title: 'Add Beneficiaries',
    sections: [
      {
        title: 'Class of beneficiary of the trust if applicable',
        fields: ['Details of the class or classes of beneficiary'],
      },
      {
        title: 'For beneficiaries',
        fields: ['Name'],
      },
    ],
    familyOrOther: {
      title: 'Add Beneficiaries and Controllers',
      sections: [
        {
          title: 'Class of beneficiary of the trust if applicable',
          fields: ['Details of the class or classes of beneficiary'],
        },
        {
          title: 'For beneficiaries',
          fields: ['Name'],
        },
        {
          title: 'For controllers',
          fields: ['Name', 'Alternate name', 'Gender', 'Date of birth', 'Country of residence for tax purposes', 'Tax identification number(s) (for overseas residents)', 'Residential address', 'Proof of identity'],
        },
      ],
    },
  },


  corporateTrust: {
    title: 'Add Beneficiaries, Shareholders and Controllers',
    sections: [
      {
        title: 'Class of beneficiary of the trust if applicable',
        fields: ['Details of the class or classes of beneficiary'],
      },
      {
        title: 'For beneficiaries',
        fields: ['Name'],
      },
      {
        title: 'For shareholders and controllers',
        fields: ['Name', 'Alternate name', 'Gender', 'Date of birth', 'Country of residence for tax purposes', 'Tax identification number(s) (for overseas residents)', 'Residential address', 'Proof of identity'],
      },
    ],
  },

  company: {
    title: 'Add Shareholders and controllers',
    fields: ['Name', 'Alternate name', 'Gender', 'Date of birth', 'Country of residence for tax purposes', 'Tax identification number(s) (for overseas residents)', 'Residential address', 'Proof of identity'],
  },
};

export default shareholderAndMembersConfig;

