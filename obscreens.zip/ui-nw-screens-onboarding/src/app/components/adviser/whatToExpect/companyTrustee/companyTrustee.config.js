
const companyTrusteeConfig = {
  corporateTrust: {
    title: 'Add company acting as trustee',
    fields: [
      'Company name',
      'ASIC registered name',
      'ACN',
      'Industry category',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Registered company office address',
      'Principal place of business address',
      'Company verification check',
    ],
  },

  corporateSMSF: {
    title: 'Add company acting as trustee',
    fields: [
      'Company name',
      'ASIC registered name',
      'ACN',
      'Industry category',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Registered company office address',
      'Principal place of business address',
      'Company verification check',
    ],
  },

  newCorporateSMSF: {
    title: 'Add corporate trustee',
    subParagraph: 'We\'ll register a new company with ASIC to act as the trustee for your SMSF',
    fields: [
      'Company name',
      'Overseas countries of residence for tax purposes',
      'Tax identification number(s) (for overseas residents)',
      'Registered company office including occupier name if applicable',
      'Registered place of business',
    ],
    subSection: {
      infoTitle: 'The following will be provided when we set up your corporate trustee',
      fields: [
        'ASIC registered name',
        'ACN',
      ],
    },
  },

};

export default companyTrusteeConfig;

