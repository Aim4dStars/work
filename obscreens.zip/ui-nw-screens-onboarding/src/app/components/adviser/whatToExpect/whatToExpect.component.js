
import template from './whatToExpect.html';
import controller from './whatToExpect.controller';

const whatToExpectComponent = {
  bindings: {},
  template,
  controller,
};

export default whatToExpectComponent;
