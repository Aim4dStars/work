import angular from 'angular';
import viewApplication from './viewApplication/viewApplication';
import offlinePrint from './offlinePrint/offlinePrint';
import applicationNotFound from './applicationNotFound/applicationNotFound';
import accountType from './accountType/accountType';
import whatToExpect from './whatToExpect/whatToExpect';

const adviserModule = angular.module('nw.onboarding.adviser', [
  viewApplication.name,
  offlinePrint.name,
  applicationNotFound.name,
  accountType.name,
  whatToExpect.name,
]);

export default adviserModule;
