import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import applicationNotFoundComponent from './applicationNotFound.component';

const applicationNotFoundModule = angular.module('nw.onboarding.adviser.applicationNotFound', [
  uiRouter,
])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.adviser.applicationNotFound', {
        url: '/application-not-found',
        component: 'nw.onboarding.adviser.applicationNotFound',
      });
  })

  .component('nw.onboarding.adviser.applicationNotFound', applicationNotFoundComponent);

export default applicationNotFoundModule;
