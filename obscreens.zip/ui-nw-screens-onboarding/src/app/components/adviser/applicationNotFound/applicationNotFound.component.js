import template from './applicationNotFound.html';

const applicationNotFoundComponent = {
  bindings: {},
  template,
};

export default applicationNotFoundComponent;
