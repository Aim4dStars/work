import ApplicationNotFoundModule from './applicationNotFound';
import ApplicationNotFoundComponent from './applicationNotFound.component';
import ApplicationNotFoundTemplate from './applicationNotFound.html';

describe('ApplicationNotFound', () => {
  let $rootScope;
  let $compile;
  let scope;

  // load the module
  beforeEach(window.module(ApplicationNotFoundModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = ApplicationNotFoundComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(ApplicationNotFoundTemplate);
    });
  });


  describe('View', () => {
    beforeEach(() => {
      $compile('<nw.onboarding.adviser.withdrawn-application></nw.onboarding.adviser.withdrawn-application>')(scope);
      scope.$apply();
    });
  });
});
