export default {
  notRegistered: {
    label: 'Not registered',
    icon: 'danger',
  },
  registered: {
    label: 'Registered',
    icon: 'success',
  },
  awaitingApproval: {
    label: 'Awaiting approval',
    icon: 'progress',
  },
  approved: {
    label: 'Approved',
    icon: 'success',
  },
};
