import template from './holdingPage.html';
import controller from './holdingPage.controller';

const holdingPageComponent = {
  bindings: {
    applicationDetails: '<',
    schema: '<',
  },
  template,
  controller,
};

export default holdingPageComponent;
