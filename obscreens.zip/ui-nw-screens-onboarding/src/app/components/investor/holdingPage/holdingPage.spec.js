import holdingPageModule from './holdingPage';
import holdingPageController from './holdingPage.controller';
import holdingPageComponent from './holdingPage.component';
import holdingPageTemplate from './holdingPage.html';

describe(' Holding Page', () => {
  let $rootScope;
  let $componentController;
  let controller;
  let $resolve;
  let $httpBackend;
  let holdingPageService;
  let schemaService;
  let $state;

  // load the module
  beforeEach(() => {
    window.module('ui.router');
    window.module($stateProvider => {
      $stateProvider.state('app', { url: '/app' });
      $stateProvider.state('app.investor', { url: '/investor' });
    });
    window.module(holdingPageModule.name);
  });

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $httpBackend = $injector.get('$httpBackend');
    holdingPageService = $injector.get('nw.onboarding.investor.holdingPage.holdingPageService');
    schemaService = $injector.get('nw.onboarding.common.api.schemaEnums');
    $state = $injector.get('$state');
  }));

  describe('Module', () => {
    it('has the expected name', () => {
      expect(holdingPageModule.name).to.equal('nw.onboarding.investor.holdingPage');
    });

    it('has the expected depenedencies', () => {
      expect(holdingPageModule.requires).to.eql(['ui.router', 'nw.core.common.filter', 'nw.core.common.permissions', 'nw.onboarding.common.api']);
    });

    it('should call getScheamaEnums and getApplicationData on transition to state', () => {
      schemaService.getSchemaEnums = sinon.spy();
      holdingPageService.getApplicationData = sinon.spy();
      $state.go('app.investor.holdingPage', { accountId: '123456' });
      $rootScope.$digest();
      expect(schemaService.getSchemaEnums).to.have.been.called;
      expect(holdingPageService.getApplicationData).to.have.been.called;
    });

    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    describe('Component', () => {
      const component = holdingPageComponent;
      it('includes the intended template', () => {
        expect(component.template).to.equal(holdingPageTemplate);
      });
      it('invokes the right controller', () => {
        expect(component.controller).to.equal(holdingPageController);
      });
    }); // Component

    describe('Controller', () => {
      describe('when inputs provided', () => {
        // controller specs
        beforeEach(() => {
          // https://docs.angularjs.org/api/ngMock/service/$componentController
          $resolve = { // mock resolved data
            applicationDetails: {
              orderType: 'newIndividualSMSF',
              clients: [],
              adviser: {
                fullName: 'Homer Simpson',
                businessPhone: '0411222444',
                email: 'homer@simpson.com',
              },
              approvalType: 'OFFLINE',
              type: 'HoldingApplication',
            },
            schema: {
              ApprovalTypeEnum: {
                ONLINE: 'online',
                OFFLINE: 'offline',
              },
              AccountTypeEnum: {
                INDIVIDUAL: 'individual',
                JOINT: 'joint',
                COMPANY: 'company',
                INDIVIDUAL_TRUST: 'individualTrust',
                CORPORATE_TRUST: 'corporateTrust',
                NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
                NEW_CORPORATE_SMSF: 'newCorporateSMSF',
                INDIVIDUAL_SMSF: 'individualSMSF',
                CORPORATE_SMSF: 'corporateSMSF',
                SUPER_ACCUMULATION: 'superAccumulation',
                SUPER_PENSION: 'superPension',
              },
            },
          };
          controller = $componentController('nw.onboarding.investor.holdingPage', {
            $scope: $rootScope.$new(),
          }, $resolve);
        });
        describe('$onInit', () => {
          describe('when applicationDetails.orderType is newIndividualSMSF', () => {
            beforeEach(() => {
              controller.applicationDetails.orderType = 'newIndividualSMSF';
            });
            describe('when applicationDetails.approvalType is ONLINE', () => {
              beforeEach(() => {
                controller.applicationDetails.approvalType = 'ONLINE';
                controller.$onInit();
              });
              it('isNewSMSF & isOnlineApproval have expected values', () => {
                expect(controller.isNewSMSF).to.eq(true);
                expect(controller.isOnlineApproval).to.eq(true);
              });
            });
            describe('when applicationDetails.approvalType is OFFLINE', () => {
              beforeEach(() => {
                controller.applicationDetails.approvalType = 'OFFLINE';
                controller.$onInit();
              });
              it('isNewSMSF & isOnlineApproval have expected values', () => {
                expect(controller.isNewSMSF).to.eq(true);
                expect(controller.isOnlineApproval).to.eq(false);
              });
            });
          }); // newIndividualSMSF

          describe('when applicationDetails.orderType is newCorporateSMSF', () => {
            beforeEach(() => {
              controller.applicationDetails.orderType = 'newCorporateSMSF';
            });
            describe('when applicationDetails.approvalType is ONLINE', () => {
              beforeEach(() => {
                controller.applicationDetails.approvalType = 'ONLINE';
                controller.$onInit();
              });
              it('isNewSMSF & isOnlineApproval have expected values', () => {
                expect(controller.isNewSMSF).to.eq(true);
                expect(controller.isOnlineApproval).to.eq(true);
              });
            });
            describe('when applicationDetails.approvalType is OFFLINE', () => {
              beforeEach(() => {
                controller.applicationDetails.approvalType = 'OFFLINE';
                controller.$onInit();
              });
              it('isNewSMSF & isOnlineApproval have expected values', () => {
                expect(controller.isNewSMSF).to.eq(true);
                expect(controller.isOnlineApproval).to.eq(false);
              });
            });
          }); // newCorporateSMSF

          describe('when applicationDetails.orderType is individualSMSF', () => {
            beforeEach(() => {
              controller.applicationDetails.orderType = 'individualSMSF';
            });
            describe('when applicationDetails.approvalType is ONLINE', () => {
              beforeEach(() => {
                controller.applicationDetails.approvalType = 'ONLINE';
                controller.$onInit();
              });
              it('isNewSMSF & isOnlineApproval have expected values', () => {
                expect(controller.isNewSMSF).to.eq(false);
                expect(controller.isOnlineApproval).to.eq(true);
              });
            });
            describe('when applicationDetails.approvalType is OFFLINE', () => {
              beforeEach(() => {
                controller.applicationDetails.approvalType = 'OFFLINE';
                controller.$onInit();
              });
              it('isNewSMSF & isOnlineApproval have expected values', () => {
                expect(controller.isNewSMSF).to.eq(false);
                expect(controller.isOnlineApproval).to.eq(false);
              });
            });
          }); // individualSMSF

          describe('when adviser has Australian phone number', () => {
            beforeEach(() => {
              controller.applicationDetails.adviser.businessPhone = '61422408282';
              sinon.spy(controller, 'adaptPhoneNumbers');
              controller.$onInit();
            });
            it('should replace AUS country prefix with 0', () => {
              expect(controller.adaptPhoneNumbers).to.have.been.called;
              expect(controller.applicationDetails.adviser.businessPhone).to.eq('0422408282');
            });
          });

          describe('when adviser has no phone number', () => {
            beforeEach(() => {
              controller.applicationDetails.adviser.businessPhone = null;
              sinon.spy(controller, 'adaptPhoneNumbers');
              controller.$onInit();
            });
            it('should not replace any numbers', () => {
              expect(controller.adaptPhoneNumbers).to.have.been.called;
              expect(controller.applicationDetails.adviser.businessPhone).to.eq(null);
            });
          });

          describe('when clients have Australian phone numbers', () => {
            beforeEach(() => {
              controller.applicationDetails.clients = [{ phoneNumber: '61422408282' }, { phoneNumber: '61422408299' }, { phoneNumber: '0422408211' }];
              sinon.spy(controller, 'adaptPhoneNumbers');
              controller.$onInit();
            });
            it('should replace AUS country prefix with 0', () => {
              expect(controller.adaptPhoneNumbers).to.have.been.called;
              expect(controller.applicationDetails.clients[0].phoneNumber).to.eq('0422408282');
              expect(controller.applicationDetails.clients[1].phoneNumber).to.eq('0422408299');
              expect(controller.applicationDetails.clients[2].phoneNumber).to.eq('0422408211');
            });
          });
        }); // $onInit
      }); // inputs
    }); // Controller

    describe('Service', () => {
      it('getApplicationData($accountId) should make an HTTP GET request', () => {
        let res;
        const data = { data: { property: 'testData' } };
        $httpBackend.whenGET(u => u === '../api/v1_0/draft_accounts/holding_app/7777').respond(data);
        holdingPageService.getApplicationData('7777').then(r => {
          res = r;
        });
        $httpBackend.flush();
        expect(res).to.deep.equal({ property: 'testData' });
      });
    });
  }); // Module
});
