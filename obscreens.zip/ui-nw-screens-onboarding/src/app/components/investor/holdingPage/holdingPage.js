import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import holdingPageComponent from './holdingPage.component';
import holdingPageService from './holdingPage.service';

const holdingPageModule = angular.module('nw.onboarding.investor.holdingPage', [
  uiRouter,
  'nw.core.common.filter',
  'nw.core.common.permissions',
  'nw.onboarding.common.api',
])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.investor.holdingPage', {
        url: '/holding-page/:accountId?overview',
        params: {
          accountId: { dynamic: true },
        },
        component: 'nw.onboarding.investor.holdingPage',
        resolve: {
          applicationDetails: ['nw.onboarding.investor.holdingPage.holdingPageService', '$stateParams',
            (service, $stateParams) => service.getApplicationData($stateParams.accountId),
          ],
          schema: ['nw.onboarding.common.api.schemaEnums', schemaEnumsService => schemaEnumsService.getSchemaEnums()],
        },
      });
  })

  .component('nw.onboarding.investor.holdingPage', holdingPageComponent)

  .service('nw.onboarding.investor.holdingPage.holdingPageService', holdingPageService);

export default holdingPageModule;
