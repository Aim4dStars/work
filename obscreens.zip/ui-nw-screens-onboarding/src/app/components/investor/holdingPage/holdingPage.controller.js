import each from 'lodash/each';
import ApplicationStatus from './holdingPage.config';
import { countryAus } from '../../../helper/utilities';

class HoldingPageController {
  constructor($stateParams) {
    this.name = 'HoldingPage';
    this.$stateParams = $stateParams;
    this.ApplicationStatus = ApplicationStatus;
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.isNewSMSF = this.applicationDetails.orderType === this.schema.AccountTypeEnum.NEW_CORPORATE_SMSF || this.applicationDetails.orderType === this.schema.AccountTypeEnum.NEW_INDIVIDUAL_SMSF;
    this.isOnlineApproval = this.applicationDetails.approvalType ? this.applicationDetails.approvalType.toLowerCase() === this.schema.ApprovalTypeEnum.ONLINE : true;
    this.adaptPhoneNumbers();
    if (this.$stateParams.overview) {
      this.showBacktoAccounts = true;
    }
  }

  adaptPhoneNumbers() {
    if (this.applicationDetails.adviser.businessPhone && this.applicationDetails.adviser.businessPhone.substr(0, 2) === countryAus) {
      this.applicationDetails.adviser.businessPhone = this.applicationDetails.adviser.businessPhone.replace(countryAus, '0');
    }

    each(this.applicationDetails.clients, client => {
      if (client.phoneNumber.substr(0, 2) === countryAus) {
        client.phoneNumber = client.phoneNumber.replace(countryAus, '0');
      }
    });
  }
}

HoldingPageController.$inject = ['$stateParams'];

export default HoldingPageController;
