import get from 'lodash/get';

class HoldingPageService {
  constructor($http) {
    this.$http = $http;
  }

  getApplicationData(accountId) {
    const url = `../api/v1_0/draft_accounts/holding_app/${accountId}`;
    return this.$http.get(url).then(res => get(res, 'data.data'));
  }
}

HoldingPageService.$inject = ['$http'];

export default HoldingPageService;
