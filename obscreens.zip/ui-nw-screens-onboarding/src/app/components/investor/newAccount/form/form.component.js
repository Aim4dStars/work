import template from './form.html';
import controller from './form.controller';

const newAccountFormComponent = {
  bindings: {
    staticData: '<',
    pensionInfoContent: '<',
    underPreserveInfo: '<',
    preservationAgeOptions: '<',
    bankAccounts: '<',
  },
  template,
  controller,
};

export default newAccountFormComponent;
