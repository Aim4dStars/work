import find from 'lodash/find';
import { InvestmentOptions, FormSections } from '../form.config';

class InvestmentOptionsController {
  constructor($scope) {
    this.name = FormSections.INVESTMENT_OPTIONS;
    this.$scope = $scope;
    this.form = {};
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.investmentOptions = InvestmentOptions;
    this.isInitialDepositShown = true;
    this.DECIDE_LATER = '0';
    this.populateFormData();
    this.updateInitialDepositSection();
    this.isNominatedAccountSelected = false;

    this.onCollapse = this.$scope.$on('nw.onboarding.investor.newAccount.form.collapse', (ev, data) => {
      if (data.currentSection === FormSections.INVESTMENT_OPTIONS) {
        this.$scope.investmentoptionsForm.$setSubmitted();
        this.onSavedata({ data: this.prepareFormDataObject(), section: this.prepareFormActionData('collapse') });
      }
    });

    this.$scope.$on('nw.onboarding.investor.newAccount.form.linkedAccounts.isNominated', (ev, data) => {
      this.isNominatedAccountSelected = !!data.isNominated;
    });
  }

  reviewAndSave() {
    if (this.$scope.investmentoptionsForm.$valid) {
      this.onSavedata({ data: this.prepareFormDataObject(), section: this.prepareFormActionData('review') });
    }
  }

  prepareFormDataObject() {
    return { portfolioType: this.form.portfolioType, initialDeposit: this.form.amount, portfolioName: this.getPortfolioName() };
  }

  prepareFormActionData(action) {
    return { name: FormSections.INVESTMENT_OPTIONS, valid: this.$scope.investmentoptionsForm.$valid, action };
  }

  getPortfolioName() {
    return find(InvestmentOptions, ['value', this.form.portfolioType]).label;
  }

  updateInitialDepositSection() {
    if (this.form.portfolioType === this.DECIDE_LATER) {
      this.isInitialDepositShown = false;
      this.form.amount = null;
    } else {
      this.isInitialDepositShown = true;
    }

    if (this.$scope.investmentoptionsForm) {
      this.$scope.investmentoptionsForm.$setPristine();
      this.$scope.investmentoptionsForm.$setUntouched();
    }
  }

  /**
   * @method populateFormData
   * When user comes from summary screen to this screen by either back button ot edit button, populate the form
   */
  populateFormData() {
    const portfolioType = find(this.investmentOptions, ['value', this.investmentFormData.portfolioType ? this.investmentFormData.portfolioType : this.portfolio]);
    this.form.portfolioType = portfolioType ? portfolioType.value : this.investmentOptions[0].value;
    this.form.amount = this.investmentFormData.initialDeposit || null;
  }
}

InvestmentOptionsController.$inject = ['$scope'];

export default InvestmentOptionsController;
