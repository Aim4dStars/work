import angular from 'angular';

import newAccountFormComponent from './form.component';
import formService from './form.service';

import investorDetails from './investorDetails/investorDetails';
import linkedAccounts from './linkedAccounts/linkedAccounts';
import investmentOptions from './investmentOptions/investmentOptions';
import pensionEligibility from './pensionEligibility/pensionEligibility';

const newAccountFormModule = angular.module('nw.onboarding.investor.newAccount.form', [
  'nw.onboarding.investor.newAccount',
  'nw.core.common.permissions',
  'nw.onboarding.common.api',
  investorDetails.name,
  linkedAccounts.name,
  investmentOptions.name,
  pensionEligibility.name,
])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.investor.newAccount.form', {
        url: '/form/:section',
        params: {
          section: { dynamic: true },
        },
        component: 'nw.onboarding.investor.newAccount.form',
        resolve: {
          staticData: ['nw.onboarding.common.api.static', 'nw.onboarding.investor.newAccount.newAccountService', (staticDataService, newAccountService) => {
            if (newAccountService.getUserData().accountType === 'pension') {
              return staticDataService.getStaticData('countries', 'pensionTaxOptions', 'pensionEligibilityOptions', 'conditionReleaseOptions');
            }

            return staticDataService.getStaticData('countries', 'taxExemptions', 'taxOptionsDirect');
          },
          ],
          pensionInfoContent: ['nw.onboarding.investor.newAccount.form.formService', '$q', 'nw.onboarding.investor.newAccount.newAccountService', (service, $q, newAccountService) => {
            if (newAccountService.getUserData().accountType === 'pension') {
              return service.getPensionEligibilityInfo();
            }

            return $q.resolve();
          },
          ],
          underPreserveInfo: ['nw.onboarding.investor.newAccount.form.formService', '$q', 'nw.onboarding.investor.newAccount.newAccountService', (service, $q, newAccountService) => {
            if (newAccountService.getUserData().accountType === 'pension') {
              return service.getUnderPreserveInfo();
            }

            return $q.resolve();
          },

          ],
          preservationAgeOptions: ['nw.onboarding.common.api.static', 'nw.onboarding.investor.newAccount.newAccountService', '$q', (staticDataService, newAccountService, $q) => {
            if (newAccountService.getUserData().accountType === 'pension') {
              return staticDataService.fetchPreservationAge();
            }

            return $q.resolve();
          },
          ],
        },
        data: {
          skipOmnitureTracking: true,
        },
      });
  })

  .component('nw.onboarding.investor.newAccount.form', newAccountFormComponent)

  .service('nw.onboarding.investor.newAccount.form.formService', formService)

  .run(($transitions, $state, $stateParams) => {
    'ngInject';

    $transitions.onBefore(
      { to: 'app.investor.newAccount.form' },
      trans => {
        let result;
        const $injector = trans.injector();
        const userData = $injector.get('nw.onboarding.investor.newAccount.newAccountService').getUserData();
        if (!userData) {
          result = $state.target('app.investor.newAccount.whatToExpect', $stateParams);
        }
        return result;
      },
    );
  });

export default newAccountFormModule;
