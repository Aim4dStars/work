import FormModule from './form';
import FormController from './form.controller';
import FormComponent from './form.component';
import FormTemplate from './form.html';
import { FormSections } from './form.config';

describe('form', () => {
  let $rootScope;
  let $compile;
  let $componentController;
  let scope;
  let controller;
  let sandbox;
  let formService;
  let commonService;
  let newAccountService;
  let res;
  let $state;
  let $stateParams;
  let whatToExpectService;
  let permission;
  let $httpBackend;
  let currentDate;
  let dateFilter;

  // load the module
  beforeEach(() => {
    window.module('ui.router');
    window.module($stateProvider => {
      $stateProvider.state('app', { url: '/app' });
      $stateProvider.state('app.investor', { url: '/investor' });
    });
    window.module(FormModule.name);
  });

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
    $state = $injector.get('$state');
    $stateParams = $injector.get('$stateParams');
    $httpBackend = $injector.get('$httpBackend');
    commonService = $injector.get('nw.onboarding.common.api.static');
    formService = $injector.get('nw.onboarding.investor.newAccount.form.formService');
    newAccountService = $injector.get('nw.onboarding.investor.newAccount.newAccountService');
    whatToExpectService = $injector.get('nw.onboarding.investor.newAccount.whatToExpect.whatToExpectService');
    permission = $injector.get('nw.core.common.permissions.permissionsService');
    dateFilter = $injector.get('$filter')('date');
  }));

  beforeEach(() => {
    sandbox = sinon.sandbox.create();
    currentDate = new Date();
    sandbox.stub(permission, 'hasPermission').returns(true);
  });

  afterEach(() => {
    sandbox.restore();
  });

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = FormComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(FormTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(FormController);
    });

    it('form empty states to going newAccount.form state with empty userdata, redircts to whatToExpect states', () => {
      commonService.getStaticData = sinon.spy();
      whatToExpectService.getCmsHeaderContent = sinon.spy();
      whatToExpectService.getCmsFooterContent = sinon.spy();
      sandbox.stub(newAccountService, 'getUserData').returns(null);
      $state.go('app.investor.newAccount.form');
      $rootScope.$digest();
      expect($state.current.name).to.eq('app.investor.newAccount.whatToExpect');
    });

    it('from whatToExpect states to going newAccount.form with userdata, form component renders', () => {
      sandbox.stub(newAccountService, 'getUserData').returns({ data: {} });
      commonService.getStaticData = sinon.spy();
      $state.go('app.investor.newAccount.form', { section: 'testData', userData: {} });
      $rootScope.$digest();
      expect(commonService.getStaticData).to.have.been.called;
    });

    it('from whatToExpect states to going newAccount.form with account pension, form component renders', () => {
      sandbox.stub(newAccountService, 'getUserData').returns({ offerType: 'simple', accountType: 'pension' });
      commonService.getStaticData = sinon.spy();
      commonService.fetchPreservationAge = sinon.spy();
      formService.getPensionEligibilityInfo = sinon.spy();
      formService.getUnderPreserveInfo = sinon.spy();
      $state.go('app.investor.newAccount.form', { section: 'testData', userData: {} });
      $rootScope.$digest();
      expect(commonService.getStaticData).to.have.been.called;
    });
  });

  describe('Service', () => {
    it('getPensionEligibilityInfo should resolved with cms data', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/onboarding/directpension/information-on-pension-eligibility.htmlsource.json').respond({ source: 'getPensionEligibilityInfo data' });
      formService.getPensionEligibilityInfo().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal('getPensionEligibilityInfo data');
    });

    it('getUnderPreserveInfo should resolved with cms data', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/onboarding/directpension/underpreservationage-information-on-pension-eligibility.htmlsource.json').respond({ source: 'getUnderPreserveInfo data' });
      formService.getUnderPreserveInfo().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal('getUnderPreserveInfo data');
    });

    it('getSuperTfnInfo should resolved with cms data', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/onboarding/directsuper/tfndeclaration.htmlsource.json').respond({ source: 'getSuperTfnInfo data' });
      formService.getSuperTfnInfo().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal('getSuperTfnInfo data');
    });

    it('getPensionTfnInfo should resolved with cms data', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/onboarding/directpension/tfndeclaration.htmlsource.json').respond({ source: 'getPensionTfnInfo data' });
      formService.getPensionTfnInfo().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal('getPensionTfnInfo data');
    });
  });

  describe('Controller', () => {
    beforeEach(() => {
      const stateParams = { section: FormSections.INVESTOR_DETAILS };
      controller = $componentController('nw.onboarding.investor.newAccount.form', {
        $scope: $rootScope.$new(), $stateParams: stateParams, $state,
      });
      sinon.spy(controller, 'initializeData');
      sinon.spy(controller, 'setCollapsedState');
      sinon.spy(controller, 'clearSharedFormData');
      sinon.spy(controller, 'initilizeFormData');
    });

    describe('onInit', () => {
      describe('when accountType is invest', () => {
        const accountType = 'invest';
        beforeEach(() => {
          sandbox.stub(newAccountService, 'getUserData').returns({ offerType: 'simple', accountType });
        });
        it('$onInit should set the right data', () => {
          controller.$onInit();
          expect(controller.currentSection).to.equal(FormSections.INVESTOR_DETAILS);
          expect(controller.userData).to.eql({ offerType: 'simple', accountType });
          expect(controller.initializeData).to.have.been.called;
          expect(controller.initilizeFormData).to.have.been.called;
          expect(controller.setCollapsedState).to.have.been.called;
          expect(controller.uiOnParamsChanged).not.to.be.undefined;
        });

        it('$onInit should clear the any shared form data if present. This is to prevent browser forward button,once user comes back from summary screen to from screen', () => {
          controller.$onInit();
          expect(controller.clearSharedFormData).to.have.been.called;
        });

        it('$onInit should set a listener for $locationChangeSuccess', () => {
          controller.handleAnalyticsEvent = sinon.spy();

          controller.$onInit();
          controller.$scope.$emit('$locationChangeSuccess');

          expect(controller.handleAnalyticsEvent).to.have.been.calledWith('invest', controller.currentSection);
        });
      });
      describe('when accountType is pension', () => {
        const accountType = 'pension';
        beforeEach(() => {
          sandbox.stub(newAccountService, 'getUserData').returns({ accountType });
          const stateParams = { section: FormSections.PENSION_ELIGIBILITY };
          controller = $componentController('nw.onboarding.investor.newAccount.form', {
            $scope: $rootScope.$new(), $stateParams: stateParams, $state,
          });
          sinon.spy(controller, 'initializeData');
          sinon.spy(controller, 'setCollapsedState');
          sinon.spy(controller, 'clearSharedFormData');
          sinon.spy(controller, 'initilizeFormData');
        });
        it('$onInit should set the right data', () => {
          controller.$onInit();
          expect(controller.currentSection).to.equal(FormSections.PENSION_ELIGIBILITY);
          expect(controller.userData).to.eql({ accountType });
          expect(controller.initializeData).to.have.been.called;
          expect(controller.initilizeFormData).to.have.been.called;
          expect(controller.setCollapsedState).to.have.been.called;
          expect(controller.uiOnParamsChanged).not.to.be.undefined;
        });

        it('$onInit should clear the any shared form data if present. This is to prevent browser forward button,once user comes back from summary screen to from screen', () => {
          controller.$onInit();
          expect(controller.clearSharedFormData).to.have.been.called;
        });

        it('$onInit should set a listener for $locationChangeSuccess', () => {
          controller.handleAnalyticsEvent = sinon.spy();

          controller.$onInit();
          controller.$scope.$emit('$locationChangeSuccess');

          expect(controller.handleAnalyticsEvent).to.have.been.calledWith('pension', controller.currentSection);
        });
      });
    });

    describe('initializeData', () => {
      describe('when accountType is invest', () => {
        it('when offerType is simple', () => {
          controller.userData = { offerType: 'simple', accountType: 'invest' };
          controller.initializeData();
          expect(controller.childSections).to.eql(['investorDetails', 'linkedAccounts', 'investmentOptions']);
          expect(controller.sectionConfig.investorDetails.index).to.eql(1);
          expect(controller.sectionConfig.investorDetails.nextSection).to.eql(FormSections.LINKED_ACCOUNTS);
          expect(controller.sectionConfig.linkedAccounts.index).to.eql(2);
          expect(controller.sectionConfig.linkedAccounts.nextSection).to.eql(FormSections.INVESTMENT_OPTIONS);
          expect(controller.sectionConfig.investmentOptions.index).to.eql(3);
          expect(controller.sectionConfig.investmentOptions.nextSection).to.be.undefined;
        });
        it('when offerType is not  simple', () => {
          controller.userData = { offerType: 'someother', accountType: 'invest' };
          controller.initializeData();
          expect(controller.childSections).to.eql(['investorDetails', 'linkedAccounts']);
          expect(controller.sectionConfig.investorDetails.index).to.eql(1);
          expect(controller.sectionConfig.investorDetails.nextSection).to.eql(FormSections.LINKED_ACCOUNTS);
          expect(controller.sectionConfig.linkedAccounts.index).to.eql(2);
          expect(controller.sectionConfig.linkedAccounts.nextSection).to.be.undefined;
          expect(controller.sectionConfig.investmentOptions).to.be.undefined;
        });
      });

      describe('when accountType is pension', () => {
        it('populate section information', () => {
          controller.userData = { accountType: 'pension' };
          controller.initializeData();
          expect(controller.childSections).to.eql(['pensionEligibility', 'investorDetails', 'linkedAccounts']);
          expect(controller.sectionConfig.pensionEligibility.index).to.eql(1);
          expect(controller.sectionConfig.pensionEligibility.nextSection).to.eql(FormSections.INVESTOR_DETAILS);
          expect(controller.sectionConfig.investorDetails.index).to.eql(2);
          expect(controller.sectionConfig.investorDetails.nextSection).to.eql(FormSections.LINKED_ACCOUNTS);
          expect(controller.sectionConfig.linkedAccounts.index).to.eql(3);
          expect(controller.sectionConfig.linkedAccounts.nextSection).to.be.undefined;
        });
      });
    });

    describe('initilizeFormData', () => {
      beforeEach(() => {
        sandbox.stub(controller, 'populateSectionsInfo');
        controller.userData = {};
        controller.childSections = ['pensionEligibility', 'investorDetails', 'linkedAccounts', 'investmentOptions'];
      });

      it('when form data present means coming from summary page with either bowser back button or edit button, should populate form data', () => {
        sandbox.stub(controller.newAccountService, 'getFormData').returns({ data: 'somedata' });
        controller.initilizeFormData();
        expect(controller.formData).to.eql({ data: 'somedata' });
        expect(controller.populateSectionsInfo).to.have.been.called;
      });

      it('when form data not  present means first time visiting this form so initilise with dafualt data', () => {
        sandbox.stub(controller.newAccountService, 'getFormData').returns(null);
        controller.initilizeFormData();
        expect(controller.formData.investorDetails).to.eql({});
        expect(controller.formData.linkedAccounts).to.eql({});
        expect(controller.formData.pensionEligibility).to.eql({});
        expect(controller.formData.investmentOptions).to.eql({});
        expect(controller.populateSectionsInfo).not.to.have.been.called;
      });
    });

    describe('populateSectionsInfo', () => {
      beforeEach(() => {
        controller.currentSection = FormSections.INVESTOR_DETAILS;
        controller.userData = { offerType: 'simple', accountType: 'invest' };
        controller.initializeData(); // to get section data initlised with default values
      });

      it('should not show the icon for current section for EDIT and borwser back button flow', () => {
        controller.populateSectionsInfo();
        expect(controller.sectionConfig.investorDetails.showIcon).to.be.false;
      });

      it('should show valid sections', () => {
        controller.populateSectionsInfo();
        expect(controller.sectionConfig.investorDetails.valid).to.be.true;
        expect(controller.sectionConfig.linkedAccounts.valid).to.be.true;
        expect(controller.sectionConfig.investmentOptions.valid).to.be.true;
      });

      it('should show icons except cuttrent section', () => {
        controller.populateSectionsInfo();
        expect(controller.sectionConfig.investorDetails.showIcon).to.be.false;
        expect(controller.sectionConfig.linkedAccounts.showIcon).to.be.true;
        expect(controller.sectionConfig.investmentOptions.showIcon).to.be.true;
      });
    });

    describe('goToSummaryPage', () => {
      beforeEach(() => {
        controller.formData = { data: 'somedata' };
        sinon.stub(controller.$state, 'transitionTo');
        sinon.spy(controller.newAccountService, 'setFormData');
      });
      it('should go the summary page with saving data in newAccountService shared service', () => {
        controller.goToSummaryPage();
        expect(controller.newAccountService.setFormData).to.have.been.calledWith({ data: 'somedata' });
        expect(controller.$state.transitionTo).to.have.been.called;
      });
    });

    describe('expandSection', () => {
      beforeEach(() => {
        sandbox.stub(controller.$state, 'transitionTo');
      });

      it('expand the linkedAccounts from investorDetails,  transitionTo linkedAccounts', () => {
        controller.currentSection = FormSections.INVESTOR_DETAILS;
        controller.expandSection(FormSections.LINKED_ACCOUNTS);
        expect(controller.$state.transitionTo).to.have.been.calledWith('app.investor.newAccount.form', { section: FormSections.LINKED_ACCOUNTS });
      });

      it('expand the investmentOptions from linkedAccounts,  transitionTo investmentOptions', () => {
        controller.currentSection = FormSections.LINKED_ACCOUNTS;
        controller.expandSection(FormSections.INVESTMENT_OPTIONS);
        expect(controller.$state.transitionTo).to.have.been.calledWith('app.investor.newAccount.form', { section: FormSections.INVESTMENT_OPTIONS });
      });

      it('expand the investorDetails from linkedAccounts,transitionTo investorDetails', () => {
        controller.currentSection = FormSections.INVESTMENT_OPTIONS;
        controller.expandSection(FormSections.INVESTOR_DETAILS);
        expect(controller.$state.transitionTo).to.have.been.calledWith('app.investor.newAccount.form', { section: FormSections.INVESTOR_DETAILS });
      });

      it('try to expand the investorDetails from  same investorDetails, it should not fire collpase event ', () => {
        controller.currentSection = FormSections.INVESTOR_DETAILS;
        controller.expandSection(FormSections.INVESTOR_DETAILS);
        expect(controller.$state.transitionTo).not.to.have.been.called;
      });
    });

    describe('saveAndContinue', () => {
      beforeEach(() => {
        controller.userData = { offerType: 'simple', accountType: 'pension' };
        controller.initilizeFormData(); // initilise the section form data
        controller.initializeData(); // initilise the section data
        sandbox.stub(controller.$state, 'transitionTo');
        sinon.spy(controller, 'saveSectionData');
        sinon.spy(controller, 'goToSummaryPage');
      });

      it('by click on continue, it will transition to linkedAccounts section', () => {
        controller.saveAndContinue({ data: 'data' }, { name: FormSections.INVESTOR_DETAILS, valid: true, action: 'continue' });
        expect(controller.$state.transitionTo).to.have.been.calledWith('app.investor.newAccount.form', { section: FormSections.LINKED_ACCOUNTS });
      });

      it('by click on review, it will get collpased and any invalid section will get opened', () => {
        controller.sectionConfig.pensionEligibility.valid = true;
        controller.sectionConfig.investorDetails.valid = false;
        controller.saveAndContinue({ data: 'data' }, { name: FormSections.LINKED_ACCOUNTS, valid: true, action: 'review' });
        expect(controller.saveSectionData).to.have.been.calledWith({ data: 'data' }, { name: FormSections.LINKED_ACCOUNTS, valid: true, action: 'review' });
        expect(controller.$state.transitionTo).to.have.been.calledWith('app.investor.newAccount.form', { section: FormSections.INVESTOR_DETAILS });
      });

      it('by click on review on linkedAccounts secction, it will got to review page if other all section are valid', () => {
        controller.sectionConfig.pensionEligibility.valid = true; // other sections are valid
        controller.sectionConfig.investorDetails.valid = true; // other sections are valid
        controller.saveAndContinue({ data: 'data' }, { name: FormSections.LINKED_ACCOUNTS, valid: true, action: 'review' });
        expect(controller.saveSectionData).to.have.been.calledWith({ data: 'data' }, { name: FormSections.LINKED_ACCOUNTS, valid: true, action: 'review' });
        expect(controller.goToSummaryPage).to.have.been.called;
      });

      it('save the valid/invalid investorDetails by collpased action ', () => {
        controller.saveAndContinue({ data: 'data' }, { name: FormSections.INVESTOR_DETAILS, valid: false, action: 'collpased' });
        expect(controller.sectionConfig.investorDetails.valid).to.be.false;
        expect(controller.sectionConfig.investorDetails.showIcon).to.be.true;
        expect(controller.saveSectionData).to.have.been.calledWith({ data: 'data' }, { name: FormSections.INVESTOR_DETAILS, valid: false, action: 'collpased' });
        expect(controller.$state.transitionTo).not.to.have.been.called;
      });
    });

    describe('uiOnParamsChanged', () => {
      const accountType = 'invest';
      beforeEach(() => {
        sandbox.stub(newAccountService, 'getUserData').returns({ offerType: 'simple', accountType });
        controller.$onInit();
        controller.currentSection = FormSections.INVESTOR_DETAILS;
        sandbox.stub(controller.$scope, '$broadcast');
        sinon.spy(controller, 'resetAll');
        sinon.spy(controller, 'collapseSection');
      });

      it('go to the linkedAccounts section from investorDetails, form will not get reloaded and uiOnParamsChanged gets called with newParam', () => {
        controller.uiOnParamsChanged({ section: FormSections.LINKED_ACCOUNTS });
        expect(controller.collapseSection).to.have.been.calledWith(FormSections.INVESTOR_DETAILS);
        expect(controller.$scope.$broadcast).to.have.been.calledWith('nw.onboarding.investor.newAccount.form.collapse', { currentSection: FormSections.INVESTOR_DETAILS });
        expect(controller.$scope.$broadcast).not.to.have.been.calledWith('nw.onboarding.investor.newAccount.form.linkedAccounts.isNominated', { somedata: '' });
        expect(controller.currentSection).to.equal(FormSections.LINKED_ACCOUNTS);
        expect(controller.resetAll).to.have.been.called;
        expect(controller.setCollapsedState).to.have.been.called;
        expect(controller.sectionConfig.linkedAccounts.collapsed).to.be.false;
      });
    });

    describe('isNominated', () => {
      const accountType = 'invest';
      beforeEach(() => {
        sandbox.stub(newAccountService, 'getUserData').returns({ offerType: 'simple', accountType });
      });
      it('should go to the INVESTMENT CHOICE section from LINKED ACCOUNTS, broadcasts an isNominated event and  having isAccountManuallyEntered flag as true', () => {
        sandbox.stub(newAccountService, 'getFormData').returns({ linkedAccounts: { isAccountManuallyEntered: true } });
        const stateParams = { section: FormSections.LINKED_ACCOUNTS };
        controller = $componentController('nw.onboarding.investor.newAccount.form', {
          $scope: $rootScope.$new(), $stateParams: stateParams, $state,
        });
        controller.$onInit();
        controller.currentSection = FormSections.LINKED_ACCOUNTS;
        sandbox.stub(controller.$scope, '$broadcast');
        controller.uiOnParamsChanged({ section: FormSections.INVESTMENT_OPTIONS });
        expect(controller.$scope.$broadcast).to.have.been.calledWith('nw.onboarding.investor.newAccount.form.linkedAccounts.isNominated', { isNominated: true });
      });

      it('should go to the INVESTMENT CHOICE section from LINKED ACCOUNTS, broadcasts an isNominated event and  having isAccountManuallyEntered flag as false', () => {
        sandbox.stub(newAccountService, 'getFormData').returns({ linkedAccounts: { isAccountManuallyEntered: false } });
        const stateParams = { section: FormSections.LINKED_ACCOUNTS };
        controller = $componentController('nw.onboarding.investor.newAccount.form', {
          $scope: $rootScope.$new(), $stateParams: stateParams, $state,
        });
        controller.$onInit();
        controller.currentSection = FormSections.LINKED_ACCOUNTS;
        sandbox.stub(controller.$scope, '$broadcast');
        controller.uiOnParamsChanged({ section: FormSections.INVESTMENT_OPTIONS });
        expect(controller.$scope.$broadcast).to.have.been.calledWith('nw.onboarding.investor.newAccount.form.linkedAccounts.isNominated', { isNominated: false });
      });
    });

    describe('handleAnalyticsEvent', () => {
      describe('when accountType is invest', () => {
        const accountType = 'invest';
        beforeEach(() => {
          sandbox.stub(newAccountService, 'getUserData').returns({ offerType: 'simple', accountType });
        });
        it('should call triggerAnalyticsEvent when form section is linked account details', () => {
          sinon.stub(newAccountService, 'triggerAnalyticsEvent');
          controller.handleAnalyticsEvent('invest', FormSections.LINKED_ACCOUNTS);
          expect(newAccountService.triggerAnalyticsEvent).to.have.been.calledWith('invest');
        });

        it('should call triggerAnalyticsStartAndCompleteEvent when form section is investor details', () => {
          sinon.stub(newAccountService, 'triggerAnalyticsStartAndCompleteEvent');
          controller.handleAnalyticsEvent('invest', FormSections.INVESTOR_DETAILS);
          expect(newAccountService.triggerAnalyticsStartAndCompleteEvent).to.have.been.calledWith('start', 'invest');
        });
      });

      describe('when accountType is pension', () => {
        const accountType = 'pension';
        beforeEach(() => {
          sandbox.stub(newAccountService, 'getUserData').returns({ accountType });
        });

        it('should call triggerAnalyticsEvent when form section is investor details', () => {
          sinon.stub(newAccountService, 'triggerAnalyticsEvent');
          controller.handleAnalyticsEvent('pension', FormSections.INVESTOR_DETAILS);
          expect(newAccountService.triggerAnalyticsEvent).to.have.been.calledWith('pension');
        });

        it('should call triggerAnalyticsStartAndCompleteEvent when form section is pension eligibility', () => {
          sinon.stub(newAccountService, 'triggerAnalyticsStartAndCompleteEvent');
          controller.handleAnalyticsEvent('pension', FormSections.PENSION_ELIGIBILITY);
          expect(newAccountService.triggerAnalyticsStartAndCompleteEvent).to.have.been.calledWith('start', 'pension');
        });
      });
    });
  });

  describe('View', () => {
    let template;

    describe('Form BT Invest View', () => {
      beforeEach(() => {
        $stateParams.section = 'investorDetails';
        sinon.stub(newAccountService, 'getUserData').returns({ offerType: 'simple', accountType: 'invest' });
        template = $compile('<nw.onboarding.investor.new-account.form></nw.onboarding.investor.new-account.form>')(scope);

        scope.$apply();
      });
      it('has BT Invest Title', () => {
        expect(template.find('h1').html()).to.match(/Set up a new BT Invest account/);
      });
      it('doen not have Pension Eligibility', () => {
        expect(template.html()).not.to.match(/Pension Eligibility/);
      });
      it('only has your details, linked account and investment Options  section', () => {
        expect(template.html()).to.match(/Your details/);
        expect(template.html()).to.match(/Linked accounts/);
        expect(template.html()).to.match(/Investment choice/);
      });
    });

    describe('Form BT Direct Pension View', () => {
      beforeEach(() => {
        const preservationAgeTable = [
          {
            age: 55,
            birthDateFrom: null,
            birthDateTo: dateFilter(new Date(currentDate.getFullYear() - 55, 5, 30), 'dd-MMM-yyyy'),
            type: 'PreservationAge',
          },
          {
            age: 56,
            birthDateFrom: dateFilter(new Date(currentDate.getFullYear() - 55, 6, 1), 'dd-MMM-yyyy'),
            birthDateTo: dateFilter(new Date(currentDate.getFullYear() - 54, 5, 30), 'dd-MMM-yyyy'),
            type: 'PreservationAge',
          },
          {
            age: 57,
            birthDateFrom: dateFilter(new Date(currentDate.getFullYear() - 54, 6, 1), 'dd-MMM-yyyy'),
            birthDateTo: dateFilter(new Date(currentDate.getFullYear() - 53, 5, 30), 'dd-MMM-yyyy'),
            type: 'PreservationAge',
          },
          {
            age: 58,
            birthDateFrom: dateFilter(new Date(currentDate.getFullYear() - 53, 6, 1), 'dd-MMM-yyyy'),
            birthDateTo: dateFilter(new Date(currentDate.getFullYear() - 52, 5, 30), 'dd-MMM-yyyy'),
            type: 'PreservationAge',
          },
          {
            age: 59,
            birthDateFrom: dateFilter(new Date(currentDate.getFullYear() - 52, 6, 1), 'dd-MMM-yyyy'),
            birthDateTo: dateFilter(new Date(currentDate.getFullYear() - 51, 5, 30), 'dd-MMM-yyyy'),
            type: 'PreservationAge',
          },
          {
            age: 60,
            birthDateFrom: dateFilter(new Date(currentDate.getFullYear() - 51, 6, 1), 'dd-MMM-yyyy'),
            birthDateTo: null,
            type: 'PreservationAge',
          },
        ];

        sinon.stub(commonService, 'fetchPreservationAge').returns(preservationAgeTable);
        $stateParams.section = 'pensionEligibility';
        scope.staticData = { countries: [], pensionEligibilityOptions: commonService.cache.get('pensionEligibilityOptions'), conditionReleaseOptions: [] };
        sinon.stub(newAccountService, 'getUserData').returns({ accountType: 'pension' });
        template = $compile('<nw.onboarding.investor.new-account.form static-data ="staticData"></nw.onboarding.investor.new-account.form>')(scope);
        scope.$apply();
      });
      it('has BT Pension Title', () => {
        expect(template.find('h1').html()).to.match(/Set up a new BT Pension account/);
      });
      it('has Pension Eligibility', () => {
        expect(template.html()).to.match(/Pension eligibility/);
        expect(template.html()).to.match(/All the money I am adding to my pension will be transferred from other super providers and I have previously satisfied eligibility criteria to access this money./);
        expect(template.html()).to.match(/This means the money you are transferring to your pension is 100% unrestricted non-preserved. If you are unsure, you can check your last super account statement or contact your other super provider\/s./);
      });
      it('has your details and linked account section', () => {
        expect(template.html()).to.match(/Your details/);
        expect(template.html()).to.match(/Linked accounts/);
      });
    });
  });
});
