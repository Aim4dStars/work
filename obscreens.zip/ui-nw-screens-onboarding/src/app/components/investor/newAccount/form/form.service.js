class FormService {
  constructor(cmsService) {
    this.cmsService = cmsService;
  }

  getPensionEligibilityInfo() {
    return this.cmsService.fetchCmsContent('/onboarding/directpension', 'information-on-pension-eligibility');
  }

  getUnderPreserveInfo() {
    return this.cmsService.fetchCmsContent('/onboarding/directpension', 'underpreservationage-information-on-pension-eligibility');
  }

  getSuperTfnInfo() {
    return this.cmsService.fetchCmsContent('/onboarding/directsuper', 'tfndeclaration');
  }

  getPensionTfnInfo() {
    return this.cmsService.fetchCmsContent('/onboarding/directpension', 'tfndeclaration');
  }
}

FormService.$inject = ['nw.onboarding.common.cms.cmsService'];

export default FormService;
