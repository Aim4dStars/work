import find from 'lodash/find';
import toArray from 'lodash/toArray';
import clone from 'lodash/clone';
import without from 'lodash/without';
import forEach from 'lodash/forEach';
import { FormSections, AccountTypes } from './form.config';

class NewAccountFormController {
  constructor($stateParams, $state, $scope, newAccountService) {
    this.$stateParams = $stateParams;
    this.$state = $state;
    this.$scope = $scope;
    this.newAccountService = newAccountService;
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.currentSection = this.$stateParams.section; // the active (expanded) section on the form
    this.userData = this.newAccountService.getUserData(); // userData is store only here and accessed by child components
    this.initializeData();
    this.initilizeFormData();
    this.clearSharedFormData();
    this.setCollapsedState(this.currentSection);
    this.uiOnParamsChanged = newParam => {
      this.collapseSection(this.currentSection);
      this.currentSection = newParam.section;
      this.resetAll();
      this.setCollapsedState(this.currentSection);
    };

    this.$scope.$on('$locationChangeSuccess', () => {
      this.handleAnalyticsEvent(this.userData.accountType || 'invest', this.currentSection);
    });
  }

  handleAnalyticsEvent(accountType, currentSection) {
    if ((accountType === 'invest' && currentSection === FormSections.INVESTOR_DETAILS)
      || (accountType === 'pension' && currentSection === FormSections.PENSION_ELIGIBILITY)) {
      this.newAccountService.triggerAnalyticsStartAndCompleteEvent('start', accountType);
    } else {
      this.newAccountService.triggerAnalyticsEvent(accountType);
    }
  }

  saveAndContinue(sectionData, section) {
    if (section.action === 'continue') {
      // simply go to next section
      this.$state.transitionTo('app.investor.newAccount.form', { section: this.sectionConfig[section.name].nextSection });
    } else if (section.action === 'review') {
      // find if any invalid section present and if present then open that or go to summary screen
      this.saveSectionData(sectionData, section);
      const invalidSection = this.findInvalidSection();
      if (invalidSection) {
        this.$state.transitionTo('app.investor.newAccount.form', { section: invalidSection.name });
      } else {
        this.goToSummaryPage();
      }
    } else { // collapse action will handle even browser bac and forward between the sections
      this.saveSectionData(sectionData, section);
    }
  }

  saveSectionData(sectionData, section) {
    this.sectionConfig[section.name].valid = section.valid;
    this.sectionConfig[section.name].showIcon = true;
    this.formData[section.name] = sectionData;
  }

  findInvalidSection() {
    return find(toArray(this.sectionConfig), ['valid', false]);
  }

  goToSummaryPage() {
    this.newAccountService.setFormData(this.formData);
    this.$state.go('app.investor.newAccount.summary');
  }

  initializeData() {
    this.sectionConfig = {};
    let counter = 0;
    const accountType = this.userData.accountType || 'invest';
    this.childSections = AccountTypes[accountType].sections;
    if (this.userData.offerType !== 'simple') {
      this.childSections = without(this.childSections, FormSections.INVESTMENT_OPTIONS);
    }

    forEach(this.childSections, section => {
      this.sectionConfig[section] = {};
      this.sectionConfig[section].name = section;
      this.sectionConfig[section].collapsed = true;
      this.sectionConfig[section].valid = false;
      this.sectionConfig[section].showIcon = false;

      counter += 1;
      this.sectionConfig[section].index = counter;
      this.sectionConfig[section].nextSection = this.childSections[counter];
    });
  }

  expandSection(sectionName) {
    if (sectionName !== this.currentSection) {
      this.$state.transitionTo('app.investor.newAccount.form', { section: sectionName });
    }
  }

  collapseSection(sectionName) {
    this.$scope.$broadcast('nw.onboarding.investor.newAccount.form.collapse', {
      currentSection: sectionName,
    });

    if (sectionName === FormSections.LINKED_ACCOUNTS) {
      this.$scope.$broadcast('nw.onboarding.investor.newAccount.form.linkedAccounts.isNominated', {
        isNominated: this.formData[FormSections.LINKED_ACCOUNTS].isAccountManuallyEntered,
      });
    }
  }

  setCollapsedState(sectionName) {
    this.sectionConfig[sectionName].collapsed = false;
  }

  resetAll() {
    forEach(this.childSections, section => {
      this.sectionConfig[section].collapsed = true;
    });
  }
  /**
   * @method initilizeFormData
   * clone the form data if user comes from edit flow or press the back button from summary page
   */

  initilizeFormData() {
    this.formData = clone(this.newAccountService.getFormData());
    if (!this.formData) {
      this.formData = {};
      forEach(this.childSections, section => {
        this.formData[section] = {};
      });
    } else { // if form data present means edit flow or borwser back button flow
      this.populateSectionsInfo();
    }
  }

  /**
   * @method populateSectionsInfo
   * set the valid and show icon true once user comes back from summary screen by browser back button or edit button
   */

  populateSectionsInfo() {
    forEach(this.childSections, section => {
      this.sectionConfig[section].showIcon = true;
      this.sectionConfig[section].valid = true;
    });

    this.sectionConfig[this.currentSection].showIcon = false; // in edit flow do not show the icon for current first time visible section;
  }

  /**
   * @method clearSharedFormData
   * once formData is cloned , clear them from shared service to prevent browser forward button in this screen when user
   * come from summary screen to this from screen by browser back button
   */
  clearSharedFormData() {
    this.newAccountService.clearFormData();
  }
}

NewAccountFormController.$inject = ['$stateParams', '$state', '$scope', 'nw.onboarding.investor.newAccount.newAccountService'];

export default NewAccountFormController;
