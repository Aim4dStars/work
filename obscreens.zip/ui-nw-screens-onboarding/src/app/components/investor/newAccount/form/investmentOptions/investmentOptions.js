import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved

import investmentOptionsComponent from './investmentOptions.component';

const investmentOptionsModule = angular.module('nw.onboarding.investor.newAccount.form.investmentOptions', [
  uiRouter,
  'nw.core.common.permissions',
])

  .component('nw.onboarding.investor.newAccount.form.investmentOptions', investmentOptionsComponent);

export default investmentOptionsModule;
