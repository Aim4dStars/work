export const FormSections = {
  PENSION_ELIGIBILITY: 'pensionEligibility',
  INVESTOR_DETAILS: 'investorDetails',
  LINKED_ACCOUNTS: 'linkedAccounts',
  INVESTMENT_OPTIONS: 'investmentOptions',
};

export const AccountTypes = {
  invest: {
    sections: [FormSections.INVESTOR_DETAILS, FormSections.LINKED_ACCOUNTS, FormSections.INVESTMENT_OPTIONS],
  },
  pension: {
    sections: [FormSections.PENSION_ELIGIBILITY, FormSections.INVESTOR_DETAILS, FormSections.LINKED_ACCOUNTS],
  },
};

export const InvestmentOptions = [
  {
    value: 'WFS0583AU',
    label: 'BT Conservative Portfolio',
  }, {
    value: 'WFS0586AU',
    label: 'BT Moderate Portfolio',
  }, {
    value: 'WFS0587AU',
    label: 'BT Balanced Portfolio',
  }, {
    value: 'WFS0584AU',
    label: 'BT Growth Portfolio',
  }, {
    value: 'WFS0585AU',
    label: 'BT High Growth Portfolio',
  }, {
    value: '0',
    label: 'I\'d like to decide later',
  },
];
