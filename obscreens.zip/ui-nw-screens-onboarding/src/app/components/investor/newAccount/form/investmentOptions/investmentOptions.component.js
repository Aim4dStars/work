import template from './investmentOptions.html';
import controller from './investmentOptions.controller';

// import './investmentOptions.scss';

const investmentOptionsComponent = {
  bindings: {
    portfolio: '<',
    onSavedata: '&',
    investmentFormData: '<',
  },
  template,
  controller,
};

export default investmentOptionsComponent;
