import angular from 'angular';
import approvalSummary from './approvalSummary/approvalSummary';
import newAccount from './newAccount/newAccount';
import holdingPage from './holdingPage/holdingPage';
import registrationTncs from './registrationTncs/registrationTncs';
import withdrawnApplication from './withdrawnApplication/withdrawnApplication';

const investorModule = angular.module('nw.onboarding.investor', [
  approvalSummary.name,
  newAccount.name,
  holdingPage.name,
  registrationTncs.name,
  withdrawnApplication.name,
]);

export default investorModule;
