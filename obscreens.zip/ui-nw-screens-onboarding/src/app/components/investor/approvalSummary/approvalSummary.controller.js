import find from 'lodash/find';
import { accountTypeToAccountNameMap } from '../../../helper/utilities';

class ApprovalSummaryController {
  constructor($stateParams, schemaService, staticDataService, permission, approvalSummaryService, $window) {
    this.$stateParams = $stateParams;
    this.name = 'investor view application';
    this.model = {};
    this.form = {};
    this.schemaService = schemaService;
    this.staticDataService = staticDataService;
    this.approvalSummaryService = approvalSummaryService;
    this.hasCreate = permission.hasPermission('account.application.create', 'base');
    this.hasEmulating = permission.hasPermission('emulating', 'base');
    this.$window = $window;
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.model.applicationDetails = this.applicationDetails;
    this.accountType = this.model.applicationDetails.investorAccountType;
    this.setPageSubtitle();
    this.setHeaderDetails();
    this.setBackToAccountFlag();
    this.disableApproveButton();
    this.getCmsTncs();
  }

  setBackToAccountFlag() {
    if (this.$stateParams.overview) {
      this.model.showBacktoAccounts = true;
    }
  }

  setPageSubtitle() {
    const accountType = accountTypeToAccountNameMap[this.model.applicationDetails.investorAccountType];
    const subtitle = [[accountType, 'account'].join(' '), this.model.applicationDetails.accountName].join(' • ');
    this.model.subtitle = subtitle;
  }

  setHeaderDetails() {
    const primaryEmail = this.getPrimaryEmail();
    const workPhone = this.getWorkPhone();
    this.model.adviserCorporateName = this.applicationDetails.adviser.corporateName;
    this.model.adviserEmail = (primaryEmail) ? primaryEmail.email : '';
    this.model.adviserPhone = (workPhone) ? workPhone.number : '';
    this.model.investorAccountType = accountTypeToAccountNameMap[this.applicationDetails.investorAccountType];
    this.model.productName = this.applicationDetails.productName;
    this.model.parentProductName = (this.applicationDetails.parentProductName) ? this.applicationDetails.parentProductName : '';
    this.model.accountName = this.applicationDetails.accountName;
  }

  getPrimaryEmail() {
    return find(this.applicationDetails.adviser.email, { emailType: 'Primary' });
  }

  getWorkPhone() {
    return find(this.applicationDetails.adviser.phone, { phoneType: 'Work' });
  }

  approve() {
    this.loading = true;
    this.error = false;
    this.approvalSummaryService.approveApplication(this.model.applicationDetails.onboardingApplicationKey)
      .then(() => {
        this.loading = false;
        this.refreshApp();
      })
      .catch(() => {
        this.error = true;
        this.loading = false;
      });
  }

  disableApproveButton() { // should disable the button if either its create or emulating or cms text loading
    this.model.disableApprove = this.form.agree ? (this.hasCreate || this.hasEmulating || this.cmsLoading) : true;
  }

  refreshApp() {
    this.$window.top.location.href = this.$window.top.location.href.replace(this.$window.top.location.hash, '');
  }

  getCmsTncs() {
    this.cmsLoading = true;
    this.cmsError = false;
    this.approvalSummaryService.getTcFromCms(this.accountType, this.schemaEnums.AccountTypeEnum, this.model.parentProductName)
      .then(data => {
        if (data && data !== '') {
          this.cmsLoading = false;
          this.success = true;
          this.handleDynamicData(data);
        } else {
          this.cmsError = true;
          this.cmsLoading = false;
        }
      })
      .catch(() => {
        this.cmsError = true;
        this.cmsLoading = false;
      });
  }

  handleDynamicData(data) {
    const linkRegex = this.model.applicationDetails.productName.indexOf('Asset Administrator') > -1
      ? /<a[^>]+class="btpdf"+[^<]+<\/a>/g
      : /<a[^>]+class="assetadminpdf"+[^<]+<\/a>/g;

    let cleanData = data;

    if (cleanData && cleanData.match(linkRegex)) {
      cleanData = cleanData.replace(linkRegex, '');
    }

    if (cleanData && this.accountType === this.schemaEnums.AccountTypeEnum.NEW_CORPORATE_SMSF) {
      cleanData = cleanData.replace('###company_name###', this.model.applicationDetails.smsf.company.asicName);
    }

    this.cmsTc = cleanData;
  }
}

ApprovalSummaryController.$inject = ['$stateParams', 'nw.onboarding.common.api.schemaEnums', 'nw.onboarding.common.api.static', 'nw.core.common.permissions.permissionsService', 'nw.onboarding.investor.approvalSummary.approvalSummaryService', '$window'];

export default ApprovalSummaryController;
