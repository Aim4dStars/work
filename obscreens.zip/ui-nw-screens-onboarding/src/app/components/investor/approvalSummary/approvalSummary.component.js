import template from './approvalSummary.html';
import controller from './approvalSummary.controller';

const approvalSummaryComponent = {
  bindings: {
    applicationDetails: '<',
    schemaEnums: '<',
    staticData: '<',
  },
  template,
  controller,
};

export default approvalSummaryComponent;
