import get from 'lodash/get';

class ApprovalSummaryService {
  constructor($http, cmsService) {
    this.$http = $http;
    this.cmsService = cmsService;
  }

  getApplicationDetails(accountNumber) {
    let url;
    if (accountNumber) {
      url = `../api/v1_0/draft_accounts/${accountNumber}/approvals`;
    } else {
      url = '../api/v1_0/draft_accounts/approvals';
    }

    return this.$http.get(url)
      .then(res => get(res, 'data.data'));
  }

  approveApplication(applicationId) {
    return this.$http.post(`../api/v1_0/draft_accounts/${applicationId}/approvals`);
  }

  getTcFromCms(accountType, accountTypeEnum, parentProductName) {
    let htmlSource;
    if (parentProductName === 'Cash Management Account') {
      switch (accountType) {
        case accountTypeEnum.NEW_INDIVIDUAL_SMSF:
          htmlSource = 'terms-and-conditions-cma-individual-smsf-fe-confirmation';
          break;
        case accountTypeEnum.NEW_CORPORATE_SMSF:
          htmlSource = 'terms-and-conditions-cma-corporate-smsf-fe-confirmation';
          break;
        default:
          htmlSource = 'terms-and-conditions-cash-management-account-confirmation';
          break;
      }
    } else {
      switch (accountType) {
        case accountTypeEnum.SUPER_ACCUMULATION:
          htmlSource = 'terms-and-conditions-super-pension-confirmation';
          break;
        case accountTypeEnum.SUPER_PENSION:
          htmlSource = 'terms-and-conditions-super-pension-confirmation';
          break;
        case accountTypeEnum.NEW_INDIVIDUAL_SMSF:
          htmlSource = 'terms-and-conditions-individual-smsf-fe-confirmation';
          break;
        case accountTypeEnum.NEW_CORPORATE_SMSF:
          htmlSource = 'terms-and-conditions-corporate-smsf-fe-confirmation';
          break;
        default:
          htmlSource = 'terms-and-conditions-all-account-types-confirmation';
          break;
      }
    }

    return this.cmsService.fetchCmsContent('/termsandconditions/onboarding/advised-investor', htmlSource);
  }
}

ApprovalSummaryService.$inject = ['$http', 'nw.onboarding.common.cms.cmsService'];

export default ApprovalSummaryService;
