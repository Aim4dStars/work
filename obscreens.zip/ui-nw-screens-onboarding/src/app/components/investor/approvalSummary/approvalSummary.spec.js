import keys from 'lodash/keys';
import approvalSummaryModule from './approvalSummary';
import approvalSummaryController from './approvalSummary.controller';
import approvalSummaryComponent from './approvalSummary.component';
import approvalSummaryTemplate from './approvalSummary.html';

describe('ApprovalSummary', () => {
  let $rootScope;
  let $componentController;
  let controller;
  let service;
  let $httpBackend;
  let permission;
  let sandbox;
  let $q;
  let schemaService;
  let staticDataService;
  let $state;

  // load the module
  beforeEach(() => {
    window.module('ui.router');
    window.module($stateProvider => {
      $stateProvider.state('app', { url: '/app' });
      $stateProvider.state('app.investor', { url: '/investor' });
      $stateProvider.state('app.investor.withdrawnApplication', { url: '/withdrawnApplication' });
    });
    window.module(approvalSummaryModule.name);
  });

  beforeEach(inject($injector => {
    $httpBackend = $injector.get('$httpBackend');
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $q = $injector.get('$q');
    service = $injector.get('nw.onboarding.investor.approvalSummary.approvalSummaryService');
    schemaService = $injector.get('nw.onboarding.common.api.schemaEnums');
    staticDataService = $injector.get('nw.onboarding.common.api.static');
    $state = $injector.get('$state');
    permission = $injector.get('nw.core.common.permissions.permissionsService');
  }));

  // sinon setup
  beforeEach(() => {
    sandbox = sinon.sandbox.create();
    sandbox.stub(permission, 'hasPermission').returns(true);
  });

  // sinon cleanup
  afterEach(() => {
    sandbox.restore();
  });

  describe('Module', () => {
    it('should call getSchemaEnums, getStaticData and getApplicationDetails on transition to state with account number', () => {
      schemaService.getSchemaEnums = sinon.spy();
      service.getApplicationDetails = sinon.stub().returns($q.resolve());
      staticDataService.getStaticData = sinon.spy();
      $state.go('app.investor.approvalSummary', { accountNumber: '123456' });
      $rootScope.$digest();
      expect(schemaService.getSchemaEnums).to.have.been.called;
      expect(staticDataService.getStaticData).to.have.been.called;
      expect(service.getApplicationDetails).to.have.been.called;
    });

    it('should call getSchemaEnums, getStaticData and getApplicationDetails on transition to state without account number', () => {
      schemaService.getSchemaEnums = sinon.spy();
      service.getApplicationDetails = sinon.stub().returns($q.resolve());
      staticDataService.getStaticData = sinon.spy();
      $state.go('app.investor.approvalSummary');
      $rootScope.$digest();
      expect(schemaService.getSchemaEnums).to.have.been.called;
      expect(staticDataService.getStaticData).to.have.been.called;
      expect(service.getApplicationDetails).to.have.been.called;
    });

    it('should call withdrawnApplication on reject of getApplicationDetails', () => {
      const deferred = $q.defer();
      schemaService.getSchemaEnums = sinon.spy();
      staticDataService.getStaticData = sinon.spy();
      sinon.stub(service, 'getApplicationDetails').returns(deferred.promise);
      $state.go('app.investor.approvalSummary', { accountNumber: '123456' });
      deferred.reject();
      $rootScope.$digest();
      expect($state.current.name).to.eq('app.investor.withdrawnApplication');
    });

    describe('Component', () => {
      const component = approvalSummaryComponent;

      it('includes the intended template', () => {
        expect(component.template).to.equal(approvalSummaryTemplate);
      });

      it('invokes the right controller', () => {
        expect(component.controller).to.equal(approvalSummaryController);
      });

      it('declares the correct bindings', () => {
        expect(component.bindings).to.contain.all.keys(['applicationDetails', 'schemaEnums', 'staticData']);
        expect(keys(component.bindings)).to.have.length(3);
      });
    });
  });

  describe('Controller', () => {
    let $resolve;

    // controller specs
    beforeEach(() => {
      $resolve = { // mock resolved data
        applicationDetails: {
          accountName: 'Angela Smith', investorAccountType: 'joint', adviser: { corporateName: 'Rob Bailey', email: [{ email: 'Dummy@BTFinancialGroup.com', emailType: 'Primary' }], phone: [{ number: '123456789', phoneType: 'Work' }] }, productName: 'White Label', onboardingApplicationKey: '12345',
        },
        schemaEnums:
          {
            AccountTypeEnum:
            {
              INDIVIDUAL: 'individual',
              JOINT: 'joint',
              COMPANY: 'company',
              INDIVIDUAL_TRUST: 'individualTrust',
              CORPORATE_TRUST: 'corporateTrust',
              NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
              NEW_CORPORATE_SMSF: 'newCorporateSMSF',
              INDIVIDUAL_SMSF: 'individualSMSF',
              CORPORATE_SMSF: 'corporateSMSF',
              SUPER_ACCUMULATION: 'superAccumulation',
              SUPER_PENSION: 'superPension',
            },
          },
        staticData:
          {
            states: [
              {
                value: 'NSW',
                label: 'New South Wales',
              },
              {
                value: 'QLD',
                label: 'Queensland',
              },
            ],
          },
      };
      const stateParams = { overview: true };
      controller = $componentController('nw.onboarding.investor.approvalSummary.approvalSummaryComponent', {
        $scope: $rootScope.$new(), $stateParams: stateParams,
      }, $resolve);
    });

    describe('onInit', () => {
      it('should set applicationDetails to model', () => {
        controller.$onInit();
        expect(controller.model.applicationDetails).to.equal($resolve.applicationDetails);
      });

      it('should be able to access schemaEnums in controller', () => {
        controller.$onInit();
        expect(controller.schemaEnums.AccountTypeEnum.SUPER_ACCUMULATION).to.equal('superAccumulation');
      });

      it('should be able to access staticData in controller', () => {
        controller.$onInit();
        expect(controller.staticData.states.length).to.equal(2);
      });

      it('should set page sub titile', () => {
        controller.$onInit();
        expect(controller.model.subtitle).to.equal('Joint account • Angela Smith');
      });

      it('should set Header details', () => {
        controller.$onInit();
        expect(controller.model.adviserCorporateName).to.equal('Rob Bailey');
        expect(controller.model.adviserEmail).to.equal('Dummy@BTFinancialGroup.com');
        expect(controller.model.adviserPhone).to.equal('123456789');
        expect(controller.model.investorAccountType).to.equal('Joint');
        expect(controller.model.productName).to.equal('White Label');
        expect(controller.model.parentProductName).to.equal('');
        expect(controller.model.accountName).to.equal('Angela Smith');
      });

      it('should set Header details with parent product name in case of CMA', () => {
        $resolve.applicationDetails.parentProductName = 'Cash Management Account';
        controller.$onInit();
        expect(controller.model.adviserCorporateName).to.equal('Rob Bailey');
        expect(controller.model.adviserEmail).to.equal('Dummy@BTFinancialGroup.com');
        expect(controller.model.adviserPhone).to.equal('123456789');
        expect(controller.model.investorAccountType).to.equal('Joint');
        expect(controller.model.productName).to.equal('White Label');
        expect(controller.model.parentProductName).to.equal('Cash Management Account');
        expect(controller.model.accountName).to.equal('Angela Smith');
      });

      it('should not set phone if there is no work phone', () => {
        sinon.stub(controller, 'getWorkPhone').returns(undefined);
        controller.$onInit();
        expect(controller.model.adviserPhone).to.equal('');
      });

      it('should not set Email if there is no primay email', () => {
        sinon.stub(controller, 'getPrimaryEmail').returns(undefined);
        controller.$onInit();
        expect(controller.model.adviserEmail).to.equal('');
      });

      it('should set showBacktoAccounts to true when overview parameter is true', () => {
        controller.$onInit();
        expect(controller.model.showBacktoAccounts).to.be.true;
      });

      it('should set showBacktoAccounts to undefined when overview parameter is undefined', () => {
        controller.$stateParams = {};
        controller.$onInit();
        expect(controller.model.showBacktoAccounts).to.be.undefined;
      });

      it('should set model.disableApprove to true when form.agree is not defined', () => {
        controller.$stateParams = {};
        controller.$onInit();
        expect(controller.model.disableApprove).to.be.true;
      });

      it('should set model.disableApprove to false when form.agree is true, hasCreate is true and hasEmulating is false and cmsLoading is false', () => {
        controller.$stateParams = {};
        controller.form.agree = true;
        controller.hasCreate = false;
        controller.hasEmulating = false;
        controller.cmsLoading = false;
        controller.$onInit();
        expect(controller.model.disableApprove).to.be.false;
      });

      it('should set model.disableApprove to true when form.agree is true, hasCreate is true and hasEmulating is false and cmsLoading is true', () => {
        controller.$stateParams = {};
        controller.form.agree = true;
        controller.hasCreate = false;
        controller.hasEmulating = false;
        controller.cmsLoading = true;
        controller.$onInit();
        expect(controller.model.disableApprove).to.be.true;
      });
    });

    describe('approve', () => {
      let deferred;
      beforeEach(() => {
        deferred = $q.defer();
        sinon.stub(service, 'approveApplication').returns(deferred.promise);
        sinon.spy(controller, 'refreshApp');
        controller.$window = { top: { location: { href: 'http://dummy/#/hello' } } };
        controller.model = { applicationDetails: { onboardingApplicationKey: '111' } };
      });

      it('when controller.approve  is resolved then refreshApp need to be called', () => {
        controller.approve();
        expect(controller.loading).to.be.true;
        expect(controller.error).to.be.false;
        deferred.resolve({ data: { } });
        $rootScope.$digest();

        expect(controller.loading).to.be.false;
        expect(controller.error).to.be.false;
        expect(controller.refreshApp).to.have.been.called;
      });

      it('when controller.approve  is rejected then refreshApp not to be called', () => {
        controller.approve();
        expect(controller.loading).to.be.true;
        expect(controller.error).to.be.false;
        deferred.reject();
        $rootScope.$digest();

        expect(controller.loading).to.be.false;
        expect(controller.error).to.be.true;
        expect(controller.refreshApp).not.to.have.been.called;
      });
    });

    describe('getCmsTncs', () => {
      let deferred;
      beforeEach(() => {
        deferred = $q.defer();
        sinon.stub(service, 'getTcFromCms').returns(deferred.promise);
        sinon.stub(controller, 'handleDynamicData');
      });

      it('when getCmsTncs  is resolved then handleDynamicData need to be called', () => {
        controller.getCmsTncs();
        expect(controller.cmsLoading).to.be.true;
        expect(controller.cmsError).to.be.false;
        deferred.resolve({ data: { } });
        $rootScope.$digest();

        expect(controller.cmsLoading).to.be.false;
        expect(controller.cmsError).to.be.false;
        expect(controller.handleDynamicData).to.have.been.called;
      });

      it('when getCmsTncs  is rejected then handleDynamicData not to be called', () => {
        controller.getCmsTncs();
        expect(controller.cmsLoading).to.be.true;
        expect(controller.cmsError).to.be.false;
        deferred.reject();
        $rootScope.$digest();

        expect(controller.cmsLoading).to.be.false;
        expect(controller.cmsError).to.be.true;
        expect(controller.handleDynamicData).not.to.have.been.called;
      });
    });

    describe('handleDynamicData', () => {
      let cmsDataResponse;
      let expNotAssetAdminCmsTc;
      let expAssetAdminCmsTc;

      beforeEach(() => {
        controller.model = { applicationDetails: { productName: 'Asset Administrator' } };
        cmsDataResponse = '<p>I have received and read the latest <a href="/Panorama_Investor_Guide.pdf" class="btpdf">Investor Guide</a> <a href="/IOOF_Panorama_Investors_Guide_0215px.pdf" class="assetadminpdf">Investor Guide</a> </p>';
        expAssetAdminCmsTc = '<p>I have received and read the latest  <a href="/IOOF_Panorama_Investors_Guide_0215px.pdf" class="assetadminpdf">Investor Guide</a> </p>';
        expNotAssetAdminCmsTc = '<p>I have received and read the latest <a href="/Panorama_Investor_Guide.pdf" class="btpdf">Investor Guide</a>  </p>';
      });

      it('when productName is Asset Administrator then asset admin investor guide link to be shown', () => {
        controller.handleDynamicData(cmsDataResponse);
        expect(controller.cmsTc).to.equal(expAssetAdminCmsTc);
      });

      it('when productName is Asset Administrator Compaq then also asset admin investor guide link to be shown', () => {
        controller.model.applicationDetails.productName = 'Asset Administrator Compaq';
        controller.handleDynamicData(cmsDataResponse);
        expect(controller.cmsTc).to.equal(expAssetAdminCmsTc);
      });

      it('when productName is White Label BT Product then asset admin investor guide link to be shown', () => {
        controller.model.applicationDetails.productName = 'White Label BT Product';
        controller.handleDynamicData(cmsDataResponse);
        expect(controller.cmsTc).to.equal(expNotAssetAdminCmsTc);
      });

      it('when account type is newCorporateSMSF then ###company_name### should be replaced by real company name', () => {
        controller.model.applicationDetails.productName = 'White Label BT Product';
        controller.accountType = 'newCorporateSMSF';
        controller.model.applicationDetails.smsf = { company: { asicName: 'Test Company' } };
        controller.handleDynamicData('I am authorised by ###company_name### to complete this');
        expect(controller.cmsTc).to.equal('I am authorised by Test Company to complete this');
      });
    });
  });

  describe('Service', () => {
    let AccountTypeEnum;
    let res;
    let data;
    beforeEach(() => {
      AccountTypeEnum = {
        INDIVIDUAL: 'individual',
        JOINT: 'joint',
        COMPANY: 'company',
        INDIVIDUAL_TRUST: 'individualTrust',
        CORPORATE_TRUST: 'corporateTrust',
        NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
        NEW_CORPORATE_SMSF: 'newCorporateSMSF',
        INDIVIDUAL_SMSF: 'individualSMSF',
        CORPORATE_SMSF: 'corporateSMSF',
        SUPER_ACCUMULATION: 'superAccumulation',
        SUPER_PENSION: 'superPension',
      };

      data = { data: { property: 'testData' }, source: { property: 'testData' } };
    });

    it('getApplicationDetails should call /draft_accounts/<acctNumber>/approvals if account number is defined', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/draft_accounts/123456/approvals').respond(data);
      service.getApplicationDetails('123456').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getApplicationDetails should call /draft_accounts/approvals if account number is not defined', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/draft_accounts/approvals').respond(data);
      service.getApplicationDetails().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('approveApplication should call draft_accounts/{applicationId}/approvals and should resolve promise on success', () => {
      $httpBackend.whenPOST(u => u === '../api/v1_0/draft_accounts/258963/approvals').respond(() => [200]);
      service.approveApplication('258963').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res.status).to.equal(200);
    });

    it('approveApplication should call draft_accounts/{applicationId}/approvals and should not resolve promise on error', () => {
      $httpBackend.whenPOST(u => u === '../api/v1_0/draft_accounts/258963/approvals').respond(() => [500]);
      service.approveApplication('258963').catch(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res.status).to.equal(500);
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-all-account-types-confirmation.htmlsource.json if accounttype is IDPS', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-all-account-types-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('individual', AccountTypeEnum).then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-individual-smsf-fe-confirmation.htmlsource.json if accounttype is newIndividualSMSF', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-individual-smsf-fe-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('newIndividualSMSF', AccountTypeEnum).then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-corporate-smsf-fe-confirmation.htmlsource.json if accounttype is newCorporateSMSF', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-corporate-smsf-fe-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('newCorporateSMSF', AccountTypeEnum).then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-super-pension-confirmation.htmlsource.json if accounttype is any super account', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-super-pension-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('superPension', AccountTypeEnum).then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-super-pension-confirmation.htmlsource.json if accounttype is any super', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-super-pension-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('superAccumulation', AccountTypeEnum).then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cash-management-account-confirmation.htmlsource.json if parentProductName is any Cash Management Account (any accounttype except Ind and Corp SMSF)', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cash-management-account-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('nonIndCorpSMSFaccounttype', AccountTypeEnum, 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cma-individual-smsf-fe-confirmation.htmlsource.json if parentProductName is Cash Management Account (and account type Individual SMSF)', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cma-individual-smsf-fe-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('newIndividualSMSF', AccountTypeEnum, 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });

    it('getTcFromCms should call /content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cma-corporate-smsf-fe-confirmation.htmlsource.json if parentProductName is Cash Management Account (and account type Corporate SMSF)', () => {
      $httpBackend.whenGET(u => u === '/content/public/panorama/termsandconditions/onboarding/advised-investor/terms-and-conditions-cma-corporate-smsf-fe-confirmation.htmlsource.json').respond(data);
      service.getTcFromCms('newCorporateSMSF', AccountTypeEnum, 'Cash Management Account').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal({ property: 'testData' });
    });
  });
});
