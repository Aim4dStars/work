import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import approvalSummaryComponent from './approvalSummary.component';
import approvalSummaryService from './approvalSummary.service';

const approvalSummaryModule = angular.module('nw.onboarding.investor.approvalSummary', [
  uiRouter,
  'nw.onboarding.common.viewApplication',
  'nw.onboarding.common.api',
  'nw.onboarding.common.cms',
  'nw.core.common.permissions',
])

  .config($stateProvider => {
    'ngInject';

    $stateProvider
      .state('app.investor.approvalSummary', {
        url: '/approval-summary/:accountNumber?overview',
        params: {
          accountNumber: { squash: true, value: null },
        },
        component: 'nw.onboarding.investor.approvalSummary.approvalSummaryComponent',
        resolve: {
          applicationDetails: ['nw.onboarding.investor.approvalSummary.approvalSummaryService', '$stateParams', '$state', (service, $stateParams, $state) =>
            service.getApplicationDetails($stateParams.accountNumber).catch(() => $state.go('app.investor.withdrawnApplication')),
          ],
          schemaEnums: ['nw.onboarding.common.api.schemaEnums', schemaService => schemaService.getSchemaEnums()],
          staticData: ['nw.onboarding.common.api.static', staticDataService => staticDataService.getStaticData('states')],
        },
      });
  })

  .component('nw.onboarding.investor.approvalSummary.approvalSummaryComponent', approvalSummaryComponent)

  .service('nw.onboarding.investor.approvalSummary.approvalSummaryService', approvalSummaryService);

export default approvalSummaryModule;
