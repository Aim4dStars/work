import template from './home.html';
import controller from './home.controller';

const homeComponent = {
  bindings: {},
  template,
  controller,
};

export default homeComponent;
