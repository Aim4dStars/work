import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import lodash from 'lodash';
import homeComponent from './home.component';

const env = ENV;
const homeModule = angular.module('nw.onboarding.home', [
  uiRouter,
])
  .config(($stateProvider, $urlRouterProvider) => {
    'ngInject';

    if (lodash.get(env, 'name') === 'production') {
    // enable home screen only on dev builds
      return;
    }

    $stateProvider
      .state('app.home', {
        url: '/home',
        component: 'nw.onboarding.home',
      });

    $urlRouterProvider.when('', '/app/home');
  })
  .component('nw.onboarding.home', homeComponent);

export default homeModule;
