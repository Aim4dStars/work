export default [
  {
    id: '77777',
    label: 'New Individual SMSF - ALL Approved',
    holdingPage: true,
  }, {
    id: '67890',
    label: 'New Individual SMSF - Pending Others Approval',
    holdingPage: true,
  }, {
    id: '12345',
    label: 'Existing SMSF - Pending Others Approval ',
    holdingPage: true,
  }, {
    id: '1010',
    label: 'Individual Trust (Other) - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1002',
    label: 'Corporate Trust - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1003',
    label: 'Corporate SMSF - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1004',
    label: 'Individual SMSF - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1020',
    label: 'Company - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1040',
    label: 'New Corporate SMSF - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1041',
    label: 'New Individual SMSF - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1063',
    label: 'Super - Pension - Pending Approval',
    approvalSummary: true,
  }, {
    id: '1064',
    label: 'Super - Pension - with condition of release - Pending Approval',
    approvalSummary: true,
  }, {
    id: 'ABABABABAB',
    label: 'Joint',
    approvalSummary: true,
  }, {
    id: '75E3DB3581CF34131B7DE2DE3E0921BC53438DAFE6E96F79',
    label: 'Corporate SMSF',
    approvalSummary: true,
  },
];
