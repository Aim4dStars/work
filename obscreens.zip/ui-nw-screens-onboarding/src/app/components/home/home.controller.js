import HomePageAccounts from './home.config';

class HomeController {
  constructor() {
    this.name = 'Home';
    this.accounts = HomePageAccounts;
  }
}

export default HomeController;
