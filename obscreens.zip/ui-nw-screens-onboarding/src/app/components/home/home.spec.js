import lodash from 'lodash';
import HomeModule from './home';
import HomeController from './home.controller';
import HomeComponent from './home.component';
import HomeTemplate from './home.html';

describe('Home', () => {
  let $rootScope;
  let $componentController;
  let controller;
  let $state;

  describe('when env is other than production', () => {
    // load the module
    beforeEach(() => {
      window.module('ui.router');
      window.module($stateProvider => {
        $stateProvider.state('app', { url: '/app' });
      });
      window.module(HomeModule.name);
    });

    beforeEach(inject($injector => {
      $state = $injector.get('$state');
    }));

    describe('', () => {
      it('/home path should be set', () => {
        const states = $state.get('app.home');
        expect(states).not.to.be.null;
      });
    });
  });

  describe('when env is  production', () => {
    beforeEach(() => {
      sinon.stub(lodash, 'get', () => 'production');
    });

    // load the module
    beforeEach(() => {
      window.module('ui.router');
      window.module($stateProvider => {
        $stateProvider.state('app', { url: '/app' });
      });
      window.module(HomeModule.name);
    });

    beforeEach(inject($injector => {
      $state = $injector.get('$state');
    }));

    it('/home path should be not be set', () => {
      const states = $state.get('app.home');
      expect(states).to.be.null;
    });
  });

  describe('Module', () => {
    const component = HomeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(HomeTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(HomeController);
    });
  });

  describe('Controller', () => {
    beforeEach(() => {
      window.module(HomeModule.name);
    });
    beforeEach(inject($injector => {
      $rootScope = $injector.get('$rootScope');
      $componentController = $injector.get('$componentController');
    }));

    // controller specs
    beforeEach(() => {
      controller = $componentController('nw.onboarding.home', {
        $scope: $rootScope.$new(),
      });
    });

    it('has a name property', () => { // erase if removing this.name from the controller
      expect(controller).to.have.property('name');
    });
  });
});
