import angular from 'angular';
import Home from './home/home';
import Adviser from './adviser/adviser';
import Investor from './investor/investor';

const componentModule = angular.module('nw.onboarding.components', [
  Home.name,
  Adviser.name,
  Investor.name,

]);

export default componentModule;
