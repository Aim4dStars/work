import 'normalize.css';

import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import ngSanitize from 'angular-sanitize';
import ngMaterial from 'angular-material';
import AppCore from 'ui-nw-shared-core/src/app/app';
import NwComponents from 'ui-nw-shared-components/src/app/app';
import log from 'loglevel';
import Common from './common/common';
import Components from './components/components';

// set log level
log.setLevel('info');

// Bootstrap
const app = angular
  .module('nw.onboarding', [
    uiRouter,
    ngMaterial,
    ngSanitize,
    AppCore.name,
    NwComponents.name,
    Common.name,
    Components.name,
  ]);

export default app;
