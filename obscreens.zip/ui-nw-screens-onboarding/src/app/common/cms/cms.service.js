import angular from 'angular';
import get from 'lodash/get';

class CmsService {
  constructor($http, $window, envService) {
    this.$http = $http;
    this.$window = $window;
    this.envService = envService;
  }

  /**
   * Build the CMS URL based on running env
   * @param  {String} url - cms url
   * @param  {String} htmlSource - cms file name
   * @param  {String} extension  - defaults to '.htmlsource.json'
   * @return {String} - the CMS url for onboarding
   */
  buildCmsUrl(url, htmlSource, extension = '.htmlsource.json') {
    let env = '';
    const baseUrl = '/content/public/panorama';
    const envCache = this.$window.sessionStorage.getItem('env');
    if (envCache) {
      env = angular.fromJson(envCache);
    } else {
      env = get(this.envService.getEnv(), 'environment');
    }

    return `${get(env, 'cmsHostForAem') || ''}${baseUrl}${url}/${htmlSource}${extension}`;
  }

  /**
 * Return content from CMS
 * @param  {String} url - cms url
 * @param  {[type]} htmlSource - cms template
 * @return {String} - cms content
 */
  fetchCmsContent(url, htmlSource) {
    return this.$http.get(this.buildCmsUrl(url, htmlSource)).then(res => get(res, 'data.source'));
  }
}

CmsService.$inject = ['$http', '$window', 'nw.core.common.api.env'];

export default CmsService;
