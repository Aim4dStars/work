import angular from 'angular';
import cmsService from './cms.service';

const cmsModule = angular.module('nw.onboarding.common.cms', [
  'nw.core.common.api',
])
  .service('nw.onboarding.common.cms.cmsService', cmsService);

export default cmsModule;
