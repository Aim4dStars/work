import cms from './cms';

describe('cms', () => {
  let $httpBackend;
  let service;
  let sandbox;

  beforeEach(() => {
    sandbox = sinon.sandbox.create();
  });

  afterEach(() => {
    sandbox.restore();
  });

  // load the module
  beforeEach(window.module(cms.name));

  beforeEach(inject($injector => {
    $httpBackend = $injector.get('$httpBackend');
    service = $injector.get('nw.onboarding.common.cms.cmsService');
  }));

  describe('CmsService', () => {
    it('should retrieve data from the server when missing environment settings', () => {
      let res;
      const data = { source: { property: 'testData' } };
      $httpBackend.whenGET(u => u === '/content/public/panorama/cms-test-url/template.htmlsource.json').respond(data);
      service.fetchCmsContent('/cms-test-url', 'template').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res).to.deep.equal(data.source);
    });

    it('should use environment settings from sessionStorage to retrieve data from server', () => {
      service.$window = {
        sessionStorage: {
          getItem: () => {},
        },
      };
      sandbox.stub(service.$window.sessionStorage, 'getItem').returns({ cmsHostForAem: 'cms-host-stored' });

      let res;
      $httpBackend.whenGET(u => u === 'cms-host-stored/content/public/panorama/cms-test-url/template.htmlsource.json').respond({ source: { property: 'testDataCmsHostStored' } });
      service.fetchCmsContent('/cms-test-url', 'template').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(service.$window.sessionStorage.getItem).to.have.been.called;
      expect(res).to.deep.equal({ property: 'testDataCmsHostStored' });
    });

    it('should use environment service for settings to retrieve data from server when missing sessionStorage', () => {
      sandbox.stub(service.envService, 'getEnv').returns({ environment: { cmsHostForAem: 'cms-host-env' } });
      let res;
      $httpBackend.whenGET(u => u === 'cms-host-env/content/public/panorama/cms-test-url/template.htmlsource.json').respond({ source: { property: 'testDataCmsHostEnv' } });
      service.fetchCmsContent('/cms-test-url', 'template').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(service.envService.getEnv).to.have.been.called;
      expect(res).to.deep.equal({ property: 'testDataCmsHostEnv' });
    });
  });
});
