import noTfnAndNoSuperSearchModule from './noTfnAndNoSuperSearch';
import noTfnAndNoSuperSearchComponent from './noTfnAndNoSuperSearch.component';
import noTfnAndNoSuperSearchTemplate from './noTfnAndNoSuperSearch.html';

describe('noTfnAndNoSuperSearch', () => {
  let $rootScope;
  let $compile;
  let scope;

  // load the module
  beforeEach(window.module(noTfnAndNoSuperSearchModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = noTfnAndNoSuperSearchComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(noTfnAndNoSuperSearchTemplate);
    });
  });

  describe('View', () => {
    // view layer specs.
    let template;

    it('if account type is super', () => {
      scope.accountType = 'super';
      template = $compile('<nw.onboarding.common.no-tfn-and-no-super-search account-type = "accountType"></nw.onboarding.common.no-tfn-and-no-super-search>')(scope);
      scope.$apply();
      expect(template.html()).to.match(/BT Super Invest is powered by the BT Panorama operating system. We have detected that you are an existing Panorama client./g);
    });

    it('if account type is pension', () => {
      scope.accountType = 'pension';
      template = $compile('<nw.onboarding.common.no-tfn-and-no-super-search account-type = "accountType"></nw.onboarding.common.no-tfn-and-no-super-search>')(scope);
      scope.$apply();
      expect(template.html()).to.match(/BT Pension is powered by the BT Panorama operating system. We have detected that you are an existing Panorama client./g);
    });
  });
});
