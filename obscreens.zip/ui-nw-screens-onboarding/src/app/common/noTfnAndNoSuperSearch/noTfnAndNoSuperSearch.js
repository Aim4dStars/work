import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import noTfnAndNoSuperSearchComponent from './noTfnAndNoSuperSearch.component';

const noTfnAndNoSuperSearchModule = angular.module('nw.onboarding.common.noTfnAndNoSuperSearch', [
  uiRouter,
])

  .component('nw.onboarding.common.noTfnAndNoSuperSearch', noTfnAndNoSuperSearchComponent);

export default noTfnAndNoSuperSearchModule;
