import template from './noTfnAndNoSuperSearch.html';

const noTfnAndNoSuperSearchComponent = {
  bindings: {
    accountType: '<',
  },
  template,
};

export default noTfnAndNoSuperSearchComponent;
