import angular from 'angular';
import viewApplication from './viewApplication/viewApplication';
import api from './api/api';
import directives from './directives/directives';
import filters from './filters/filters';
import queue from './queue/queue';
import noTfnAndSuperSearch from './noTfnAndSuperSearch/noTfnAndSuperSearch';
import noTfnAndNoSuperSearch from './noTfnAndNoSuperSearch/noTfnAndNoSuperSearch';
import defaultExistingOption from './defaultExistingOption/defaultExistingOption';
import cms from './cms/cms';

const commonModule = angular.module('nw.onboarding.common', [
  viewApplication.name,
  api.name,
  directives.name,
  filters.name,
  queue.name,
  noTfnAndSuperSearch.name,
  noTfnAndNoSuperSearch.name,
  defaultExistingOption.name,
  cms.name,
]);

export default commonModule;
