import angular from 'angular';
import tfnFilter from './tfn/tfn';
import exemptionFilter from './exemption/exemption';
import staticLabelFilter from './staticLabel/staticLabel';
import yesNoLabelFilter from './yesNoLabel/yesNoLabel';
import industryFilter from './industry/industry';
import verifiedNotVerifiedLabelFilter from './verifiedNotVerifiedLabel/verifiedNotVerifiedLabel';
import addressV2DisplayFilter from './addressV2Display/addressV2Display';
import persontypeFilter from './persontype/persontype';
import tinExemptionFilter from './tinexemptiontype/tinexemptiontype';
import setupAccountLabelFilter from './setupAccountLabel/setupAccountLabel';

const filterModule = angular.module('nw.onboarding.common.filters', ['nw.core.common.permissions'])

  .filter('tfn', tfnFilter)
  .filter('exemption', exemptionFilter)
  .filter('industry', industryFilter)
  .filter('staticLabel', staticLabelFilter)
  .filter('yesNoLabel', yesNoLabelFilter)
  .filter('verifiedNotVerifiedLabel', verifiedNotVerifiedLabelFilter)
  .filter('addressV2Display', addressV2DisplayFilter)
  .filter('persontype', persontypeFilter)
  .filter('tinexemptiontype', tinExemptionFilter)
  .filter('setupAccountLabel', setupAccountLabelFilter);

export default filterModule;
