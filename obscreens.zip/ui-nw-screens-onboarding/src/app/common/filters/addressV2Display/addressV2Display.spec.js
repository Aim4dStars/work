import filtersModule from '../filters';

describe('staticLabelFilter', () => {
  let filter;
  const addressesV2 = [
    {
      addressDisplayText: '33 Pitt Road, SOUTH NANANGO  QLD  4615',
      addressType: 'REGISTERED',
    },
    {
      addressDisplayText: '33 Pitt Road, SOUTH NANANGO  QLD  4615',
      addressType: 'PLACEOFBUSINESS',
    },
  ];

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('addressV2Display');
  }));

  it('should return the address display text where addressType is REGISTERED', () => {
    expect(filter(addressesV2, 'REGISTERED')).to.eql('33 Pitt Road, SOUTH NANANGO  QLD  4615');
  });

  it('should return the address display text where addressType is PLACEOFBUSINESS', () => {
    expect(filter(addressesV2, 'PLACEOFBUSINESS')).to.eql('33 Pitt Road, SOUTH NANANGO  QLD  4615');
  });

  it('should return empty address display text where addressType is not provided', () => {
    expect(filter(addressesV2)).to.eql('');
  });

  it('should return empty address display text where given addressType is not present', () => {
    expect(filter(addressesV2, 'dummy')).to.eql('');
  });

  it('should return empty address display text on null address object', () => {
    expect(filter(null)).to.eql('');
  });
});
