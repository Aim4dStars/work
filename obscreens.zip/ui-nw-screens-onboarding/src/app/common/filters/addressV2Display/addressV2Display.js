import find from 'lodash/find';

const addressV2DisplayFilter = () =>
  (addressesV2, addressType) => {
    if (addressesV2 != null && addressType != null) {
      const address = find(addressesV2, ['addressType', addressType]);
      return address ? address.addressDisplayText : '';
    }

    return '';
  };

export default addressV2DisplayFilter;
