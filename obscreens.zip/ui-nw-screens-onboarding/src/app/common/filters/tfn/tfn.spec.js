import filtersModule from '../filters';

describe('TfnFilter', () => {
  let filter;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('tfn');
  }));

  it('should not format an empty string', () => {
    expect(filter('')).to.eq('');
  });

  it('should not format an undefined string', () => {
    expect(filter(undefined)).to.eq('');
  });

  it('should not format if already been formatted', () => {
    expect(filter('567 890 898')).to.eq('567 890 898');
  });

  it('should format 9 digit tfn numbers', () => {
    expect(filter('678908987')).to.eq('678 908 987');
  });

  it('should format 8 digit bsb numbers', () => {
    expect(filter('46789087')).to.eq('467 890 87');
  });
});
