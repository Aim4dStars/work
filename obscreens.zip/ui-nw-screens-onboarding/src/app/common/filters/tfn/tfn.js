const tfnFilter = () =>
  input => {
    if (!input) {
      return '';
    }

    const stringInput = input.toString();

    // check if input is already formatted
    if (/(\d{3}) (\d{3}) (\d{2})/.test(stringInput)) {
      return stringInput;
    }

    return stringInput.replace(/(\d{3})(\d{3})(\d{2})/, '$1 $2 $3');
  };

export default tfnFilter;
