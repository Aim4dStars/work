import filtersModule from '../filters';

describe('tinExemptionFilter', () => {
  let filter;
  let tinExemptionReason;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('tinexemptiontype');
  }));

  it('should set proper value when reason is tin not issued', () => {
    tinExemptionReason = 'TIN not issued';
    expect(filter(tinExemptionReason)).to.equal('TIN not issued');
  });

  it('should set proper value when reason is tin pending', () => {
    tinExemptionReason = 'TIN pending';
    expect(filter(tinExemptionReason)).to.equal('TIN pending');
  });

  it('should set proper value when reason is tax file number', () => {
    tinExemptionReason = 'Tax identification number';
    expect(filter(tinExemptionReason)).to.equal('TIN');
  });

  it('should set proper value when reason is under age', () => {
    tinExemptionReason = 'Under age';
    expect(filter(tinExemptionReason)).to.equal('TIN exempt - under age');
  });

  it('should set proper value when reason is improper', () => {
    tinExemptionReason = 'Under aged';
    expect(filter(tinExemptionReason)).to.equal('');
  });
});
