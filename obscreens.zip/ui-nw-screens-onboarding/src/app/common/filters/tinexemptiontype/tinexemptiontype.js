import find from 'lodash/find';

const tinExemptionReasons = [
  {
    value: 'TIN not issued',
    label: 'TIN not issued',
  },
  {
    value: 'TIN pending',
    label: 'TIN pending',
  },
  {
    value: 'Tax identification number',
    label: 'TIN',
  },
  {
    value: 'Under age',
    label: 'TIN exempt - under age',
  },
];

const tinExemptionFilter = () =>

  tfnExemptionReason => {
    const tinExemptionObj = find(tinExemptionReasons, obj => obj.value === tfnExemptionReason);

    return tinExemptionObj ? tinExemptionObj.label : '';
  };

export default tinExemptionFilter;
