import filtersModule from '../filters';

describe('ExemptionFilter', () => {
  let filter;
  const reasons = [{ value: 'abc' }, { value: 'non_au_resi' }, { value: '1234' }];

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('exemption');
  }));

  it('should return empty array when country undefined', () => {
    expect(filter(reasons, undefined)).to.eql([]);
  });

  it('should return empty array when country null', () => {
    expect(filter(reasons, undefined)).to.eql([]);
  });

  it('should return empty array when country empty', () => {
    expect(filter(reasons, '')).to.eql([]);
  });

  it('should return non AU resident values', () => {
    expect(filter(reasons, 'MD')).to.eql([{ value: 'non_au_resi' }]);
  });

  it('should return AU resident values', () => {
    expect(filter(reasons, 'AU')).to.eql([{ value: 'abc' }, { value: '1234' }]);
  });
});
