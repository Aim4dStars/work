import each from 'lodash/each';

const exemptionFilter = () =>
  (items, country) => {
    const filtered = [];
    if (country && country !== '') {
      each(items, item => {
        if (country === 'AU' && item.value !== 'non_au_resi') {
          filtered.push(item);
        } else if (country !== 'AU' && item.value === 'non_au_resi') {
          filtered.push(item);
        }
      });
    }

    return filtered;
  };

export default exemptionFilter;
