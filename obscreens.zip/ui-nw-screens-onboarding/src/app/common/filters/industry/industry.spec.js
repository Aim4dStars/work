import filtersModule from '../filters';

describe('industryFilter', () => {
  let filter;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('industry');
  }));

  it('should return undefined if the input is undefined', () => {
    expect(filter(undefined)).to.eql(undefined);
  });

  it('should return null if the input is null', () => {
    expect(filter(null)).to.eql(null);
  });

  it('should return camel case formatted string"', () => {
    expect(filter('FINANCIAL ASSET INVESTORS (7340)')).to.eql('Financial asset investors (7340)');
  });
});

