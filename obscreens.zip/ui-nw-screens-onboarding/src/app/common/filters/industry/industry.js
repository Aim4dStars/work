const industryFilter = () =>
  inputValue => {
    if (inputValue) {
      return inputValue.charAt(0) + inputValue.substring(1).toLowerCase();
    }

    return inputValue;
  };

export default industryFilter;
