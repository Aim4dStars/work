import filtersModule from '../filters';

describe('staticLabelFilter', () => {
  let filter;

  const staticValues = [{ value: 'NSW', label: 'New South Wales' }, { value: 'QLD', label: 'Queensland' }, { value: 'VIC', label: 'Victoria' }];

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('staticLabel');
  }));

  it('should return an empty string when when staticValues is null', () => {
    expect(filter(null, 'VIC')).to.equal('');
  });

  it('should return an empty string when the input value is undefined', () => {
    expect(filter(staticValues, undefined)).to.equal('');
  });

  it('should return an empty string when when the input value is null', () => {
    expect(filter(staticValues, null)).to.equal('');
  });

  it('should return "Victoria" when when the input value is "VIC"', () => {
    expect(filter(staticValues, 'VIC')).to.equal('Victoria');
  });

  it('should return an empty string when when the input value is not in the value list', () => {
    expect(filter(staticValues, 'anything else')).to.equal('anything else');
  });
});
