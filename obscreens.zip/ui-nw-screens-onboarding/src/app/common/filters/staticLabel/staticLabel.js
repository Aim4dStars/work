import find from 'lodash/find';

// This filter is used to return the static code label when given the static code value and static code list
// e.g. it returns "Australia" when given "AU" and the static code list for category: countries

const staticLabelFilter = () =>
  (staticLabels, staticCode) => {
    if (staticLabels != null && staticCode != null) {
      const staticLabel = find(staticLabels, ['value', staticCode]);
      return staticLabel ? staticLabel.label : staticCode;
    }

    return '';
  };

export default staticLabelFilter;
