// This filter is used to return 'Yes' or 'No' depending on the boolean value

const yesNoLabelFilter = () =>
  boolean => (boolean ? 'Yes' : 'No');

export default yesNoLabelFilter;
