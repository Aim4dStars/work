import filtersModule from '../filters';

describe('yesNoLabelFilter', () => {
  let filter;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('yesNoLabel');
  }));

  it('should return an "Yes" when passed true', () => {
    expect(filter(true)).to.equal('Yes');
  });

  it('should return an "No" when passed false', () => {
    expect(filter(false)).to.equal('No');
  });

  it('should return an "No" when passed null', () => {
    expect(filter(null)).to.equal('No');
  });
});
