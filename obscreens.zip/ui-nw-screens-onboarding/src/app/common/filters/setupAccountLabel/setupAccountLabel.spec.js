import filtersModule from '../filters';

describe('SetupAccountLabelFilter', () => {
  let filter;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('setupAccountLabel');
  }));

  it('should format to BT Invest account for an empty string', () => {
    expect(filter('')).to.eq('BT Invest account');
  });

  it('should format to BT Invest account for invest', () => {
    expect(filter('invest')).to.eq('BT Invest account');
  });

  it('should format to BT Invest account for an undefined string', () => {
    expect(filter(undefined)).to.eq('BT Invest account');
  });

  it('should format to BT Super account for super', () => {
    expect(filter('super')).to.eq('BT Super Invest account');
  });

  it('should format to BT Pension account for pension', () => {
    expect(filter('pension')).to.eq('BT Pension account');
  });

  it('should not format for unknown accountType', () => {
    expect(filter('someAccountType')).to.eq('');
  });
});
