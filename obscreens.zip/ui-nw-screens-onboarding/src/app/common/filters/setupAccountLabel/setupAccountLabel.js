const setupAccountLabelFilter = () =>
  input => {
    if (!input) {
      return 'BT Invest account';
    }

    const stringInput = input.toString();

    switch (stringInput) {
      case 'invest': return 'BT Invest account';
      case 'super': return 'BT Super Invest account';
      case 'pension': return 'BT Pension account';
      default:
        return '';
    }
  };

export default setupAccountLabelFilter;
