// This filter is used to return 'Verified' or 'Not Verified' depending on the value

const verifiedNotVerifiedLabelFilter = () =>
  verified => (verified ? 'Verified' : 'Not Verified');

export default verifiedNotVerifiedLabelFilter;
