import filtersModule from '../filters';

describe('verifiedNotVerifiedLabelFilter', () => {
  let filter;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    filter = $injector.get('$filter')('verifiedNotVerifiedLabel');
  }));

  it('should return an "Yes" when passed defined', () => {
    expect(filter('soemthing')).to.equal('Verified');
  });

  it('should return an "No" when passed undefined', () => {
    expect(filter(undefined)).to.equal('Not Verified');
  });

  it('should return an "No" when passed null', () => {
    expect(filter(null)).to.equal('Not Verified');
  });
});
