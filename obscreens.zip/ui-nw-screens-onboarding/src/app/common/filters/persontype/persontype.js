import each from 'lodash/each';

const getControllerofTrust = (hasAMLToggleOn, accountType, accountTypeEnum) => {
  if (accountType === accountTypeEnum.INDIVIDUAL_TRUST) {
    return 'Controller';
  }
  return 'Controller of the trust';
};

const getBeneficiaryOwnerRole = (hasAMLToggleOn, accountType, accountTypeEnum) => {
  if (hasAMLToggleOn && accountType === accountTypeEnum.CORPORATE_TRUST) {
    return 'Shareholder / controller of the company';
  } else if (hasAMLToggleOn) {
    return 'Shareholder / controller';
  }
  return 'Responsible person';
};

const personTypeLabel = (hasAMLToggleOn, isSingleRole, accountType, accountTypeEnum) => {
  const map = {
    beneficiary: 'Beneficiary',
    shareholder: hasAMLToggleOn ? 'Shareholder / controller of the company' : 'Shareholder',
    controlleroftrust: getControllerofTrust(hasAMLToggleOn, accountType, accountTypeEnum),
    member: isSingleRole ? 'Member under 18/legally disabled' : 'Member',
    beneficialowner: getBeneficiaryOwnerRole(hasAMLToggleOn, accountType, accountTypeEnum),
  };
  return map;
};

const persontypeFilter = permission =>
  (personRoles, accountType, accountTypeEnum) => {
    const hasAMLToggleOn = permission.hasPermission('feature.global.onboardingAmlChanges', '');
    const personTypes = [];
    if (personRoles) {
      each(personRoles, role => {
        const label = personTypeLabel(hasAMLToggleOn, personRoles.length === 1, accountType, accountTypeEnum)[role.toLowerCase()];
        personTypes.push(label || role);
      });
    }

    return personTypes;
  };

persontypeFilter.$inject = ['nw.core.common.permissions.permissionsService'];

export default persontypeFilter;
