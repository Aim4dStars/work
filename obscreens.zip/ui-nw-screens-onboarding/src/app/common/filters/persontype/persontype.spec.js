import filtersModule from '../filters';

describe('persontypeFilter', () => {
  let filter;
  let isAMLEnabled = false;
  let permissionService;
  let accountTypeEnum;

  beforeEach(window.module(filtersModule.name));

  beforeEach(inject($injector => {
    permissionService = $injector.get('nw.core.common.permissions.permissionsService');
    filter = $injector.get('$filter')('persontype');
  }));

  beforeEach(() => {
    sinon.stub(permissionService, 'hasPermission', item => {
      if (item === 'feature.global.onboardingAmlChanges') {
        return isAMLEnabled;
      }

      return true;
    });
    accountTypeEnum = {
      COMPANY: 'company',
      CORPORATE_SMSF: 'corporateSMSF',
      CORPORATE_TRUST: 'corporateTrust',
      INDIVIDUAL_SMSF: 'individualSMSF',
      INDIVIDUAL_TRUST: 'individualTrust',
      NEW_CORPORATE_SMSF: 'newCorporateSMSF',
      NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
    };
  });

  describe('when AML toggle is ON', () => {
    beforeEach(() => {
      isAMLEnabled = true;
    });
    it('should return [] if the input is undefined', () => {
      expect(filter(undefined)).to.deep.eql([]);
    });

    it('should return unknownValue if the input is unknownValue', () => {
      expect(filter(['unknownValue'], '', accountTypeEnum)).to.deep.eql(['unknownValue']);
    });

    it('should return [] if the input is null', () => {
      expect(filter(null)).to.deep.eql([]);
    });

    it('should return \'Beneficiary\' if input is [\'Beneficiary\']', () => {
      expect(filter(['Beneficiary'], '', accountTypeEnum)).to.deep.eql(['Beneficiary']);
    });

    it('should return \'Controller\' if input is [\'BeneficialOwner\']', () => {
      expect(filter(['BeneficialOwner'], '', accountTypeEnum)).to.deep.eql(['Shareholder / controller']);
    });

    it('should return \'Shareholder / controller of the company\' if input is [\'BeneficialOwner\'] and account type is corporateTrust', () => {
      expect(filter(['BeneficialOwner'], 'corporateTrust', accountTypeEnum)).to.deep.eql(['Shareholder / controller of the company']);
    });

    it('should return \'Shareholder / controller of the company\' if input is \'Shareholder\'', () => {
      expect(filter(['Shareholder'], '', accountTypeEnum)).to.deep.eql(['Shareholder / controller of the company']);
    });

    it('should return \'Controller of the trust\' if input is \'ControllerOfTrust\'', () => {
      expect(filter(['ControllerOfTrust'], '', accountTypeEnum)).to.deep.eql(['Controller of the trust']);
    });

    it('should return \'Controller\' if input is \'ControllerOfTrust\' and account type is individualTrust', () => {
      expect(filter(['ControllerOfTrust'], 'individualTrust', accountTypeEnum)).to.deep.eql(['Controller']);
    });

    it('should return correct array if input is [\'ControllerOfTrust\', \'Shareholder\'] and account type is corporateTrust', () => {
      expect(filter(['ControllerOfTrust', 'Beneficialowner'], 'corporateTrust', accountTypeEnum)).to.deep.eql(['Controller of the trust', 'Shareholder / controller of the company']);
    });
  });

  describe('when AML toggle is OFF', () => {
    beforeEach(() => {
      isAMLEnabled = false;
    });
    it('should return undefined if the input is []', () => {
      expect(filter(undefined)).to.deep.eql([]);
    });

    it('should return unknownValue if the input is unknownValue', () => {
      expect(filter(['unknownValue'], '', accountTypeEnum)).to.deep.eql(['unknownValue']);
    });

    it('should return null if the input is []', () => {
      expect(filter(null)).to.deep.eql([]);
    });

    it('should return \'Beneficiary\' if input is [\'beneficiary\']', () => {
      expect(filter(['beneficiary'], '', accountTypeEnum)).to.deep.eql(['Beneficiary']);
    });

    it('should return \'Shareholder\' if input is \'Shareholder\'', () => {
      expect(filter(['Shareholder'], '', accountTypeEnum)).to.deep.eql(['Shareholder']);
    });

    it('should return [\'Beneficiary\', \'Shareholder\'] if input is [\'Beneficiary\', \'Shareholder\']', () => {
      expect(filter(['Beneficiary', 'Shareholder'], '', accountTypeEnum)).to.deep.eql(['Beneficiary', 'Shareholder']);
    });

    it('should return \'Member under 18/legally disabled\' if input is \'Member\'', () => {
      expect(filter(['Member'], '', accountTypeEnum)).to.deep.eql(['Member under 18/legally disabled']);
    });

    it('should return [\'Beneficiary\', \'Responsible person\'] array if input is [\'Beneficiary\', \'BeneficialOwner\']', () => {
      expect(filter(['Beneficiary', 'BeneficialOwner'], '', accountTypeEnum)).to.deep.eql(['Beneficiary', 'Responsible person']);
    });
  });
});

