import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import noTfnAndSuperSearchComponent from './noTfnAndSuperSearch.component';

const noTfnAndSuperSearchModule = angular.module('nw.onboarding.common.noTfnAndSuperSearch', [
  uiRouter,
])

  .component('nw.onboarding.common.noTfnAndSuperSearch', noTfnAndSuperSearchComponent);

export default noTfnAndSuperSearchModule;
