import template from './noTfnAndSuperSearch.html';

const noTfnAndSuperSearchComponent = {
  bindings: {
    accountType: '<',
  },
  template,
};

export default noTfnAndSuperSearchComponent;
