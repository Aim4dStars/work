import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import oneoffFeeComponent from './oneoffFee.component';

const oneoffFeeModule = angular.module('nw.onboarding.common.viewApplication.fees.oneoffFee', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.fees.oneoffFee', oneoffFeeComponent);

export default oneoffFeeModule;
