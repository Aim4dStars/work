import keys from 'lodash/keys';
import OneOffFeeModule from './oneoffFee';
import OneOffFeeComponent from './oneoffFee.component';
import OneOffFeeTemplate from './oneoffFee.html';

describe('oneOffFee', () => {
  // load the module
  beforeEach(window.module(OneOffFeeModule.name));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = OneOffFeeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(OneOffFeeTemplate);
    });

    it('declares the correct bindings', () => {
      expect(component.bindings).to.contain.all.keys(['oneoffFee', 'isAdviser', 'isPrint']);
      expect(keys(component.bindings)).to.have.length(3);
    });
  });
});
