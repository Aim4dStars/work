import template from './oneoffFee.html';

const oneoffFeeComponent = {
  bindings: {
    oneoffFee: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,

};

export default oneoffFeeComponent;
