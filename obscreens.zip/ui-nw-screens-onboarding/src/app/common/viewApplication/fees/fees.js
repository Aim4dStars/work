import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import feesComponent from './fees.component';
import dollarFee from './dollarFee/dollarFee';
import percentageFee from './percentageFee/percentageFee';
import slidingscaleFee from './slidingscaleFee/slidingscaleFee';
import regularFee from './regularFee/regularFee';
import oneoffFee from './oneoffFee/oneoffFee';

const feesModule = angular.module('nw.onboarding.common.viewApplication.fees', [
  uiRouter,
  dollarFee.name,
  percentageFee.name,
  slidingscaleFee.name,
  regularFee.name,
  oneoffFee.name,
])

  .component('nw.onboarding.common.viewApplication.fees', feesComponent);

export default feesModule;
