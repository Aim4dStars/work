import keys from 'lodash/keys';
import DollarFeeModule from './dollarFee';
import DollarFeeComponent from './dollarFee.component';
import DollarFeeTemplate from './dollarFee.html';

describe('DollarFee', () => {
  // load the module
  beforeEach(window.module(DollarFeeModule.name));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = DollarFeeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(DollarFeeTemplate);
    });

    it('declares the correct bindings', () => {
      expect(component.bindings).to.contain.all.keys(['dollarFee', 'isAdviser']);
      expect(keys(component.bindings)).to.have.length(2);
    });
  });
});
