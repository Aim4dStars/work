import template from './dollarFee.html';

const dollarFeeComponent = {
  bindings: {
    dollarFee: '<',
    isAdviser: '<',
  },
  template,

};

export default dollarFeeComponent;
