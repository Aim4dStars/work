import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import dollarFeeComponent from './dollarFee.component';

const dollarFeeModule = angular.module('nw.onboarding.common.viewApplication.fees.dollarFee', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.fees.dollarFee', dollarFeeComponent);

export default dollarFeeModule;
