import template from './slidingscaleFee.html';

const slidingscaleFeeComponent = {
  bindings: {
    slidingscaleFee: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,

};

export default slidingscaleFeeComponent;
