import SlidingscaleFeeModule from './slidingscaleFee';
import SlidingscaleFeeComponent from './slidingscaleFee.component';
import SlidingscaleFeeTemplate from './slidingscaleFee.html';

describe('SlidingscaleFee', () => {
  // load the module
  beforeEach(window.module(SlidingscaleFeeModule.name));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = SlidingscaleFeeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(SlidingscaleFeeTemplate);
    });
  });
});
