import template from './percentageFee.html';

const percentageFeeComponent = {
  bindings: {
    percentageFee: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,

};

export default percentageFeeComponent;
