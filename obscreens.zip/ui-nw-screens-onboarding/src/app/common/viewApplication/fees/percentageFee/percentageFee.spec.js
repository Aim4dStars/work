import PercentageFeeModule from './percentageFee';
import PercentageFeeComponent from './percentageFee.component';
import PercentageFeeTemplate from './percentageFee.html';

describe('PercentageFee', () => {
  // load the module
  beforeEach(window.module(PercentageFeeModule.name));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = PercentageFeeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(PercentageFeeTemplate);
    });
  });
});
