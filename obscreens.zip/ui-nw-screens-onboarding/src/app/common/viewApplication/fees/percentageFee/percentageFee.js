import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import percentageFeeComponent from './percentageFee.component';

const percentageFeeModule = angular.module('nw.onboarding.common.viewApplication.fees.percentageFee', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.fees.percentageFee', percentageFeeComponent);

export default percentageFeeModule;
