import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import regularFeeComponent from './regularFee.component';

const regularFeeModule = angular.module('nw.onboarding.common.viewApplication.fees.regularFee', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.fees.regularFee', regularFeeComponent);

export default regularFeeModule;
