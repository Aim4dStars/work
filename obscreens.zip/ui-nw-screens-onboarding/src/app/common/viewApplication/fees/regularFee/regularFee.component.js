import template from './regularFee.html';

const regularFeeComponent = {
  bindings: {
    regularFee: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,

};

export default regularFeeComponent;
