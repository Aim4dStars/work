import keys from 'lodash/keys';
import RegularFeeModule from './regularFee';
import RegularFeeComponent from './regularFee.component';
import RegularFeeTemplate from './regularFee.html';

describe('RegularFee', () => {
  // load the module
  beforeEach(window.module(RegularFeeModule.name));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = RegularFeeComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(RegularFeeTemplate);
    });

    it('declares the correct bindings', () => {
      expect(component.bindings).to.contain.all.keys(['regularFee', 'isAdviser', 'isPrint']);
      expect(keys(component.bindings)).to.have.length(3);
    });
  });
});
