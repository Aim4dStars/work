import template from './fees.html';
import controller from './fees.controller';

const feesComponent = {
  bindings: {
    fees: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default feesComponent;
