import FeesModule from './fees';
import FeesController from './fees.controller';
import FeesComponent from './fees.component';
import FeesTemplate from './fees.html';

describe('Fees', () => {
  let $rootScope;
  let $componentController;
  let controller;

  // load the module
  beforeEach(window.module(FeesModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = FeesComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(FeesTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(FeesController);
    });
  });

  describe('Controller', () => {
    let $resolve;
    const feesComp = {

      feesComponent: [
        {
          amount: '5.60',
          cpiindex: false,
          label: 'Dollar fee component',
        },
        {
          cash: '5.70',
          label: 'Percentage fee component',
          managedFund: '5.40',
          managedPortfolio: '5.50',
          termDeposit: '5.60',
          listedSecurities: '9.90',
        },
        {
          cash: 'true',
          label: 'Sliding scale fee component',
          managedFund: 'false',
          managedPortfolio: 'true',
          termDeposit: 'false',
          listedSecurities: 'false',
          slidingScaleFeeTier: [
            {
              lowerBound: '0.00',
              percentage: '5.00',
              upperBound: '200.00',
            },
            {
              lowerBound: '200.00',
              percentage: '10.50',
              upperBound: '600.00',
            },
          ],
        },
      ],
    };

    describe('should adapt the establishment fee', () => {
      beforeEach(() => {
        $resolve = { fees: { estamount: '100.50' } };
        controller = $componentController('nw.onboarding.common.viewApplication.fees', {
          $scope: $rootScope.$new(),
        }, $resolve);
      });

      it('should initialize estamount and defalut values to true when there is no ongoingFees / licenseeFees', () => {
        controller.$onInit();
        expect(controller.estamount).to.equal('100.50');
        expect(controller.isDefaultOngoingFees).to.be.true;
        expect(controller.isDefaultLicenseeFees).to.be.true;
      });
      it('should initialize defalut values to false when  ongoingFees & licenseeFees present', () => {
        controller.fees.ongoingFees = feesComp;
        controller.fees.licenseeFees = feesComp;
        controller.$onInit();
        expect(controller.estamount).to.equal('100.50');
        expect(controller.isDefaultOngoingFees).to.be.false;
        expect(controller.isDefaultLicenseeFees).to.be.false;
      });
    });

    describe('adapt the ongoing fees', () => {
      beforeEach(() => {
        $resolve = { fees: { estamount: '100.50', ongoingFees: feesComp } };
        controller = $componentController('nw.onboarding.common.viewApplication.fees', {
          $scope: $rootScope.$new(),
        }, $resolve);
        controller.ongoingFees = controller.getFeeViewDataForSection(controller.fees.ongoingFees);
      });

      it('it should set  dollarfee ammount', () => {
        expect(controller.ongoingFees.dollarfee.amount).to.equal('5.60');
      });
      it('it should set dollarfee cpiindex', () => {
        expect(controller.ongoingFees.dollarfee.cpiindex).to.equal(false);
      });
      it('it should set percentagefee`s managedfund', () => {
        expect(controller.ongoingFees.percentagefee.managedfund).to.equal('5.40');
      });
      it('it should set percentagefee`s managedportfolio ', () => {
        expect(controller.ongoingFees.percentagefee.managedportfolio).to.equal('5.50');
      });
      it('it should set percentagefee`s termdeposit ', () => {
        expect(controller.ongoingFees.percentagefee.termdeposit).to.equal('5.60');
      });
      it('it should set percentagefee`s cash', () => {
        expect(controller.ongoingFees.percentagefee.cash).to.equal('5.70');
      });
      it('it should set percentagefee`s listedsecurities ', () => {
        expect(controller.ongoingFees.percentagefee.listedsecurities).to.equal('9.90');
      });
      it('it should set slidingscalefee`s appliesto ', () => {
        expect(controller.ongoingFees.slidingscalefee.appliesto).to.eql(['Cash', 'Managed portfolios']);
      });
      it('it should set  slidingscalefee`s tiers lowerBound - 1', () => {
        expect(controller.ongoingFees.slidingscalefee.tiers[0].lowerBound).to.equal('0.00');
      });
      it('it should set  slidingscalefee`s tiers upperBound - 1', () => {
        expect(controller.ongoingFees.slidingscalefee.tiers[0].upperBound).to.equal('200.00');
      });
      it('it should set slidingscalefee`s tiers percentage - 1', () => {
        expect(controller.ongoingFees.slidingscalefee.tiers[0].percentage).to.equal('5.00');
      });
      it('it should set slidingscalefee`s tiers lowerBound - 2', () => {
        expect(controller.ongoingFees.slidingscalefee.tiers[1].lowerBound).to.equal('200.00');
      });
      it('it should set slidingscalefee`s tiers upperBound - 2', () => {
        expect(controller.ongoingFees.slidingscalefee.tiers[1].upperBound).to.equal('600.00');
      });
      it('it should set slidingscalefee`s tiers percentage - 2', () => {
        expect(controller.ongoingFees.slidingscalefee.tiers[1].percentage).to.equal('10.50');
      });
    });

    describe('adapt the licensee fees', () => {
      beforeEach(() => {
        $resolve = { fees: { estamount: '100.50', licenseeFees: feesComp } };
        controller = $componentController('nw.onboarding.common.viewApplication.fees', {
          $scope: $rootScope.$new(),
        }, $resolve);
        controller.licenseeFees = controller.getFeeViewDataForSection(controller.fees.licenseeFees);
      });

      it('it should set  dollarfee ammount', () => {
        expect(controller.licenseeFees.dollarfee.amount).to.equal('5.60');
      });
      it('it should set dollarfee cpiindex', () => {
        expect(controller.licenseeFees.dollarfee.cpiindex).to.equal(false);
      });
      it('it should set percentagefee`s managedfund', () => {
        expect(controller.licenseeFees.percentagefee.managedfund).to.equal('5.40');
      });
      it('it should set percentagefee`s managedportfolio ', () => {
        expect(controller.licenseeFees.percentagefee.managedportfolio).to.equal('5.50');
      });
      it('it should set percentagefee`s termdeposit ', () => {
        expect(controller.licenseeFees.percentagefee.termdeposit).to.equal('5.60');
      });
      it('it should set percentagefee`s cash', () => {
        expect(controller.licenseeFees.percentagefee.cash).to.equal('5.70');
      });
      it('it should set percentagefee`s listedsecurities ', () => {
        expect(controller.licenseeFees.percentagefee.listedsecurities).to.equal('9.90');
      });

      it('it should set  slidingscalefee`s tiers lowerBound - 1', () => {
        expect(controller.licenseeFees.slidingscalefee.tiers[0].lowerBound).to.equal('0.00');
      });
      it('it should set  slidingscalefee`s tiers upperBound - 1', () => {
        expect(controller.licenseeFees.slidingscalefee.tiers[0].upperBound).to.equal('200.00');
      });
      it('it should set slidingscalefee`s tiers percentage - 1', () => {
        expect(controller.licenseeFees.slidingscalefee.tiers[0].percentage).to.equal('5.00');
      });
      it('it should set slidingscalefee`s tiers lowerBound - 2', () => {
        expect(controller.licenseeFees.slidingscalefee.tiers[1].lowerBound).to.equal('200.00');
      });
      it('it should set slidingscalefee`s tiers upperBound - 2', () => {
        expect(controller.licenseeFees.slidingscalefee.tiers[1].upperBound).to.equal('600.00');
      });
      it('it should set slidingscalefee`s tiers percentage - 2', () => {
        expect(controller.licenseeFees.slidingscalefee.tiers[1].percentage).to.equal('10.50');
      });
    });

    describe('adapt the contribution fees for Super client', () => {
      beforeEach(() => {
        $resolve = {
          fees: {
            contributionFees: {
              feesComponent: [{
                label: 'One-off fee component',
                employer: '1.00',
                spouse: '2.00',
                personal: '3.00',
              },
              {
                label: 'Regular fee component',
                spouse: '4.00',
                personal: '5.00',
              },
              ],
            },
          },
        };
        controller = $componentController('nw.onboarding.common.viewApplication.fees', {
          $scope: $rootScope.$new(),
        }, $resolve);
        controller.$onInit();
      });

      it('it should set oneofffee values', () => {
        expect(controller.contributionFees.oneofffee.employer).to.equal('1.00');
        expect(controller.contributionFees.oneofffee.spouse).to.equal('2.00');
        expect(controller.contributionFees.oneofffee.personal).to.equal('3.00');
      });

      it('it should set regularfee values', () => {
        expect(controller.contributionFees.regularfee.personal).to.equal('5.00');
        expect(controller.contributionFees.regularfee.spouse).to.equal('4.00');
      });
    });

    describe('adapt the contribution fees for IDPS client', () => {
      beforeEach(() => {
        $resolve = {
          fees: {
            contributionFees: {
              feesComponent: [{
                label: 'One-off fee component',
                deposit: '6.00',
              },
              {
                label: 'Regular fee component',
                deposit: '9.00',
              },
              ],
            },
          },
        };
        controller = $componentController('nw.onboarding.common.viewApplication.fees', {
          $scope: $rootScope.$new(),
        }, $resolve);
        controller.$onInit();
      });

      it('it should set oneofffee values', () => {
        expect(controller.contributionFees.oneofffee.deposit).to.equal('6.00');
      });

      it('it should set regularfee values', () => {
        expect(controller.contributionFees.regularfee.deposit).to.equal('9.00');
      });
    });

    describe('adapt the contribution fees if the fee components are empty for IDPS/Super accounts', () => {
      beforeEach(() => {
        $resolve = {
          fees: {
            contributionFees: {
              feesComponent: [],
            },
          },
        };
        controller = $componentController('nw.onboarding.common.viewApplication.fees', {
          $scope: $rootScope.$new(),
        }, $resolve);
        controller.$onInit();
      });

      it('should set the contribution fees components as blank', () => {
        expect(controller.contributionFees.oneofffee).to.equal(null);
        expect(controller.contributionFees.regularfee).to.equal(null);
        expect(controller.isDefaultContributionFees).to.equal(true);
      });
    });
  });
});
