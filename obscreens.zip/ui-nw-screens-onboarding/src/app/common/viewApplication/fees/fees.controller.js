import filter from 'lodash/filter';
import find from 'lodash/find';

class FeesController {
  constructor() {
    this.name = 'Fees';
    this.model = {};
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.estamount = this.fees.estamount;
    this.ongoingFees = this.getFeeViewDataForSection(this.fees.ongoingFees);
    this.licenseeFees = this.getFeeViewDataForSection(this.fees.licenseeFees);
    this.contributionFees = this.getFeeViewDataForSection(this.fees.contributionFees);
    this.isDefaultOngoingFees = this.ongoingFees && !this.ongoingFees.dollarfee && !this.ongoingFees.percentagefee && !this.ongoingFees.slidingscalefee;
    this.isDefaultLicenseeFees = this.licenseeFees && !this.licenseeFees.dollarfee && !this.licenseeFees.percentagefee && !this.licenseeFees.slidingscalefee;
    this.isDefaultContributionFees = this.contributionFees && !this.contributionFees.regularfee && !this.contributionFees.oneofffee;
  }

  findFeeComponent(section, componentName) {
    let result;
    if (section) {
      result = find(section.feesComponent, feesComponent => feesComponent.label === componentName);
    }
    return result;
  }

  dollarFee(section) {
    const dollarFeeComponent = this.findFeeComponent(section, 'Dollar fee component');
    if (dollarFeeComponent) {
      return {
        amount: dollarFeeComponent.amount,
        cpiindex: dollarFeeComponent.cpiindex,
      };
    }

    return null;
  }

  percentageFees(section) {
    const percentageFeesComponent = this.findFeeComponent(section, 'Percentage fee component');
    if (percentageFeesComponent) {
      return {
        listedsecurities: this.adaptListedSecurities(percentageFeesComponent),
        managedfund: percentageFeesComponent.managedFund,
        managedportfolio: percentageFeesComponent.managedPortfolio,
        cash: percentageFeesComponent.cash,
        termdeposit: percentageFeesComponent.termDeposit,
      };
    }

    return null;
  }

  regularFees(section) {
    const regularFeesComponent = this.findFeeComponent(section, 'Regular fee component');
    if (regularFeesComponent) {
      return {
        spouse: regularFeesComponent.spouse,
        personal: regularFeesComponent.personal,
        deposit: regularFeesComponent.deposit,
      };
    }

    return null;
  }

  oneoffFees(section) {
    const oneoffFeesComponent = this.findFeeComponent(section, 'One-off fee component');
    if (oneoffFeesComponent) {
      return {
        employer: oneoffFeesComponent.employer,
        spouse: oneoffFeesComponent.spouse,
        personal: oneoffFeesComponent.personal,
        deposit: oneoffFeesComponent.deposit,
      };
    }

    return null;
  }

  slidingScaleFees(section) {
    const slidingScaleFeesComponent = this.findFeeComponent(section, 'Sliding scale fee component');
    if (slidingScaleFeesComponent) {
      const lookupDisplayName = {
        cash: 'Cash',
        termDeposit: 'Term deposits',
        managedPortfolio: 'Managed portfolios',
        managedFund: 'Managed funds',
        listedSecurities: 'Listed securities',
        listedSecurity: 'Listed securities', // Frontend Db returns this as listedSecurities and avaloq returns as listedSecurity.
      };
      return {
        appliesto: filter(lookupDisplayName, (value, key) => (slidingScaleFeesComponent[key] === 'true')),
        tiers: slidingScaleFeesComponent.slidingScaleFeeTier,
      };
    }

    return null;
  }

  /**
   * @method adaptListedSecurities
   * This method adapt the listed securities. Frontend Db returns this as listedSecurities and avaloq returns as listedSecurity.
   */
  adaptListedSecurities(percentageFeesComponent) {
    return percentageFeesComponent.listedSecurities ? percentageFeesComponent.listedSecurities : percentageFeesComponent.listedSecurity;
  }

  getFeeViewDataForSection(section) {
    return {
      dollarfee: this.dollarFee(section),
      percentagefee: this.percentageFees(section),
      slidingscalefee: this.slidingScaleFees(section),
      regularfee: this.regularFees(section),
      oneofffee: this.oneoffFees(section),
    };
  }
}

export default FeesController;
