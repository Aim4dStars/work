import template from './viewApplication.html';
import controller from './viewApplication.controller';

const viewApplicationComponent = {
  bindings: {
    applicationDetails: '<',
    schemaEnums: '<',
    staticData: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default viewApplicationComponent;
