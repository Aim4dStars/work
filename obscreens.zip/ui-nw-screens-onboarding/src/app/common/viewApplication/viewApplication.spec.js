import keys from 'lodash/keys';
import ViewApplicationModule from './viewApplication';
import ViewApplicationController from './viewApplication.controller';
import ViewApplicationComponent from './viewApplication.component';
import ViewApplicationTemplate from './viewApplication.html';

describe('ViewApplication', () => {
  let $componentController;
  let controller;

  // load the module
  beforeEach(window.module(ViewApplicationModule.name));

  beforeEach(inject($injector => {
    $componentController = $injector.get('$componentController');
  }));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = ViewApplicationComponent;

    it('includes the intended in the template', () => {
      expect(component.template).to.equal(ViewApplicationTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(ViewApplicationController);
    });
    it('declares the correct bindings', () => {
      expect(component.bindings.staticData).to.not.be.undefined;
      expect(component.bindings.schemaEnums).to.not.be.undefined;
      expect(component.bindings.applicationDetails).to.not.be.undefined;
      expect(component.bindings.isAdviser).to.not.be.undefined;
      expect(component.bindings).to.contain.all.keys(['applicationDetails', 'schemaEnums', 'staticData', 'isAdviser', 'isPrint']);
      expect(keys(component.bindings)).to.have.length(5);
    });
  });

  describe('Controller', () => {
    // controller specs
    beforeEach(() => {
      controller = $componentController('nw.onboarding.common.viewApplication');
      controller.applicationDetails = { accountName: 'Angela Smith', investorAccountType: 'joint' };
      controller.$onInit();
    });

    it('should set applicationDetails to model', () => {
      expect(controller.model.applicationDetails).to.deep.equal({ accountName: 'Angela Smith', investorAccountType: 'joint' });
    });

    it('should set correct investorAccountType', () => {
      expect(controller.accountType).to.equal('joint');
    });
  });
});
