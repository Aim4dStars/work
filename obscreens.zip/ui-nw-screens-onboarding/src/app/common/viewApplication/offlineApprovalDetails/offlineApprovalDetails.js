import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import offlineApprovalDetailsComponent from './offlineApprovalDetails.component';

const offlineApprovalDetailsModule = angular.module('nw.onboarding.common.viewApplication.offlineApprovalDetails', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.offlineApprovalDetails', offlineApprovalDetailsComponent);

export default offlineApprovalDetailsModule;
