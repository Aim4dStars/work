import template from './offlineApprovalDetails.html';

const offlineApprovalDetailsComponent = {
  bindings: {
    approvalType: '<',
  },
  template,

};

export default offlineApprovalDetailsComponent;
