import keys from 'lodash/keys';
import OfflineApprovalDetailsModule from './offlineApprovalDetails';
import OfflineApprovalDetailsComponent from './offlineApprovalDetails.component';
import OfflineApprovalDetailsTemplate from './offlineApprovalDetails.html';

describe('offlineApprovalDetails', () => {
  // load the module
  beforeEach(window.module(OfflineApprovalDetailsModule.name));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = OfflineApprovalDetailsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(OfflineApprovalDetailsTemplate);
    });

    it('declares the correct bindings', () => {
      expect(component.bindings).to.contain.all.keys(['approvalType']);
      expect(keys(component.bindings)).to.have.length(1);
    });
  });
});
