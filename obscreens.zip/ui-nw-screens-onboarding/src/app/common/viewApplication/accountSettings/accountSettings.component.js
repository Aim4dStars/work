import template from './accountSettings.html';
import controller from './accountSettings.controller';

const accountSettingsComponent = {
  bindings: {
    accountSettings: '<',
    adviser: '<',
    accountType: '<',
    schemaEnums: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default accountSettingsComponent;
