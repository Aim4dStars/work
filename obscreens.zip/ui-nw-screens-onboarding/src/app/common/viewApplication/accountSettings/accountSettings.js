import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import accountSettingsComponent from './accountSettings.component';

const accountSettingsModule = angular.module('nw.onboarding.common.viewApplication.accountSettings', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.accountSettings', accountSettingsComponent);

export default accountSettingsModule;
