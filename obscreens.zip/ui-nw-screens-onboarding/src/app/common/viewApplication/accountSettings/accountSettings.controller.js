import includes from 'lodash/includes';
import each from 'lodash/each';
import isEmpty from 'lodash/isEmpty';
import intersection from 'lodash/intersection';
import assignIn from 'lodash/assignIn';
import accountSettingsConfig from './accountSettings.config';

class AccountSettingsController {
  constructor() {
    this.name = 'Account settings';
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.setAccountSpecificAttributes();
    this.adaptAccountSettingsForView(this.accountSettings);
    this.adaptPowerOfAttorney(this.accountSettings);
  }

  setAccountSpecificAttributes() {
    this.sectionTitle = accountSettingsConfig[this.accountType].sectionTitle;
    this.hasRoles = accountSettingsConfig[this.accountType].hasRoles;
    this.hasApprovers = accountSettingsConfig[this.accountType].hasApprovers;
    this.minApprovers = accountSettingsConfig[this.accountType].minApprovers;
    this.sourceOfFunds = accountSettingsConfig[this.accountType].sourceOfFunds;
  }

  adaptAccountSettingsForView(accountSettings) {
    const investorsSettings = [];
    const advisersSettings = [];
    each(accountSettings.personRelations, personRelation => {
      if (personRelation.adviser) {
        advisersSettings.push(this.withAdviserLocation(personRelation));
      } else if (this.isInvestor(personRelation)) {
        this.adaptInvestorSetting(personRelation);
        investorsSettings.push(personRelation);
      }
    });

    this.investorsSettings = investorsSettings;
    this.advisersSettings = advisersSettings;
  }

  adaptPowerOfAttorney(accountSettings) {
    const isAccountTypeSuper = this.accountType === this.schemaEnums.AccountTypeEnum.SUPER_ACCUMULATION ||
     this.accountType === this.schemaEnums.AccountTypeEnum.SUPER_PENSION;
    if (!isAccountTypeSuper) {
      this.powerOfAttorney = accountSettings.powerOfAttorney;
    }
  }

  isInvestor(personRelation) {
    const accountType = this.accountType;
    const conf = {
      individualSMSF: ['Trustee'],
      newIndividualSMSF: ['Trustee'],
      newCorporateSMSF: ['Director'],
      corporateSMSF: ['Director'],
      corporateTrust: ['Director'],
      individualTrust: ['Trustee'],
      company: ['Director', 'Secretary', 'Signatory'],
    };
    const individualAccountTypes = [this.schemaEnums.AccountTypeEnum.JOINT, this.schemaEnums.AccountTypeEnum.INDIVIDUAL, this.schemaEnums.AccountTypeEnum.SUPER_ACCUMULATION, this.schemaEnums.AccountTypeEnum.SUPER_PENSION];
    return includes(individualAccountTypes, accountType) || (personRelation.personRoles && !isEmpty(intersection(personRelation.personRoles, conf[accountType])));
  }

  adaptInvestorSetting(personRelation) {
    if (this.accountType === this.schemaEnums.AccountTypeEnum.COMPANY) {
      personRelation.role = intersection(personRelation.personRoles, ['Director', 'Secretary', 'Signatory']);
    }
  }

  withAdviserLocation(adviserObj) {
    const location = this.adviser.addresses[0].stateAbbr;
    return assignIn({ adviserLocation: location }, adviserObj);
  }
}

export default AccountSettingsController;
