const accountSettingsConfig = {
  individual: {
    hasRoles: false,
    hasApprovers: false,
    minApprovers: 2,
    sourceOfFunds: 'individual',
    sectionTitle: 'Investor',
  },
  joint: {
    hasRoles: false,
    hasApprovers: false,
    minApprovers: 2,
    sourceOfFunds: 'individual',
    sectionTitle: 'Investors',

  },
  corporateSMSF: {
    hasRoles: false,
    hasApprovers: true,
    minApprovers: 2,
    sourceOfFunds: 'organisation',
    sectionTitle: 'Directors',
  },
  newCorporateSMSF: {
    hasRoles: false,
    hasApprovers: true,
    minApprovers: 2,
    sourceOfFunds: 'organisation',
    sectionTitle: 'Directors',
  },
  individualSMSF: {
    hasRoles: false,
    hasApprovers: true,
    minApprovers: 4,
    sourceOfFunds: 'organisation',
    sectionTitle: 'Trustees',
  },
  newIndividualSMSF: {
    hasRoles: false,
    hasApprovers: true,
    minApprovers: 4,
    sourceOfFunds: 'organisation',
    sectionTitle: 'Trustees',
  },
  individualTrust: {
    hasRoles: false,
    hasApprovers: true,
    minApprovers: 10,
    sourceOfFunds: 'organisation',
    sectionTitle: 'Trustees',
  },
  corporateTrust: {
    hasRoles: false,
    hasApprovers: true,
    minApprovers: 2,
    sourceOfFunds: 'organisation',
    sectionTitle: 'Directors',
  },
  company: {
    hasRoles: true,
    hasApprovers: true,
    minApprovers: 2,
    sectionTitle: 'Directors, secretaries and signatories',
  },
  superAccumulation: {
    hasRoles: false,
    hasApprovers: false,
    minApprovers: 2,
    sectionTitle: 'Investor',
  },
  superPension: {
    hasRoles: false,
    hasApprovers: false,
    minApprovers: 2,
    sectionTitle: 'Investor',

  },
};

export default accountSettingsConfig;
