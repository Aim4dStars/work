import keys from 'lodash/keys';
import AccountSettingsModule from './accountSettings';
import AccountSettingsController from './accountSettings.controller';
import AccountSettingsComponent from './accountSettings.component';
import AccountSettingsTemplate from './accountSettings.html';

describe('AccountSettings', () => {
  let $rootScope;
  let $componentController;
  let scope;
  let controller;

  // load the module
  beforeEach(window.module(AccountSettingsModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    scope = $rootScope.$new();
  }));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = AccountSettingsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(AccountSettingsTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(AccountSettingsController);
    });

    it('declares the correct bindings', () => {
      expect(component.bindings).to.contain.all.keys(['accountSettings', 'adviser', 'accountType', 'schemaEnums', 'isAdviser', 'isPrint']);
      expect(keys(component.bindings)).to.have.length(6);
    });
  });

  describe('Controller', () => {
    // controller specs

    describe('onInit', () => {
      let $resolve;
      beforeEach(() => {
        const accountTypeEnum = {
          COMPANY: 'company',
          CORPORATE_SMSF: 'corporateSMSF',
          CORPORATE_TRUST: 'corporateTrust',
          INDIVIDUAL: 'individual',
          INDIVIDUAL_SMSF: 'individualSMSF',
          INDIVIDUAL_TRUST: 'individualTrust',
          JOINT: 'joint',
          NEW_CORPORATE_SMSF: 'newCorporateSMSF',
          NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
          SUPER_ACCUMULATION: 'superAccumulation',
          SUPER_PENSION: 'superPension',
        };

        $resolve = {
          accountSettings: {}, accountType: 'joint', sectionIndex: '2', adviser: '123456', schemaEnums: { AccountTypeEnum: accountTypeEnum },
        };

        controller = $componentController('nw.onboarding.common.viewApplication.accountSettings', {
          scope,
        }, $resolve);

        controller.setAccountSpecificAttributes = sinon.spy();
        controller.adaptAccountSettingsForView = sinon.spy();
        controller.adaptPowerOfAttorney = sinon.spy();

        controller.$onInit();
      });

      it('has accountSettings details set in controller', () => {
        expect(controller.accountSettings).to.equal($resolve.accountSettings);
      });

      it('has account name set in controller', () => {
        expect(controller.accountType).to.equal($resolve.accountType);
      });

      it('has sectionIndex set in controller', () => {
        expect(controller.sectionIndex).to.equal($resolve.sectionIndex);
      });

      it('has adviser set in controller', () => {
        expect(controller.adviser).to.equal($resolve.adviser);
      });

      it('setAccountSpecificAttributes should have been called', () => {
        expect(controller.setAccountSpecificAttributes).to.have.been.called;
      });

      it('adaptAccountSettingsForView should have been called', () => {
        expect(controller.adaptAccountSettingsForView).to.have.been.called;
      });

      it('adaptPowerOfAttorney should have been called', () => {
        expect(controller.adaptPowerOfAttorney).to.have.been.called;
      });
    });

    describe('adaptAccountSettingsForView', () => {
      let $resolve;
      const trustee = {
        name: 'Trustee One',
        personRoles: ['Trustee'],
      };
      const owner = {
        name: 'Owner One',
        personRoles: ['Owner'],
      };
      const someSetting = {
        name: 'Some setting',
        personRoles: ['SomeRole'],
      };
      const director = {
        name: 'Director One',
        personRoles: ['Director'],
      };
      const signatory = {
        name: 'Signatory One',
        personRoles: ['Signatory'],
      };
      const secretary = {
        name: 'Secretary One',
        personRoles: ['Secretary'],
      };
      const director2 = {
        name: 'Director Two',
        personRoles: ['Director', 'Shareholder'],
      };

      const accountTypeEnum = {
        COMPANY: 'company',
        CORPORATE_SMSF: 'corporateSMSF',
        CORPORATE_TRUST: 'corporateTrust',
        INDIVIDUAL: 'individual',
        INDIVIDUAL_SMSF: 'individualSMSF',
        INDIVIDUAL_TRUST: 'individualTrust',
        JOINT: 'joint',
        NEW_CORPORATE_SMSF: 'newCorporateSMSF',
        NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
        SUPER_ACCUMULATION: 'superAccumulation',
        SUPER_PENSION: 'superPension',
      };

      beforeEach(() => {
        $resolve = { accountType: 'superAccumulation', schemaEnums: { AccountTypeEnum: accountTypeEnum } };
        controller = $componentController('nw.onboarding.common.viewApplication.accountSettings', { scope }, $resolve);
      });

      it('when accoun type is super accumulation', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner],
        };
        controller.accountType = 'superAccumulation';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(3);
      });

      it('when accoun type is super pension', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner],
        };
        controller.accountType = 'superPension';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(3);
      });

      it('should select only trustees of the account to display when individualSMSF', () => {
        controller.accountSettings = {
          personRelations: [someSetting, trustee, owner],
        };
        controller.accountType = 'individualSMSF';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(1);
      });

      it('should select only directors of the account to display when corporateSMSF', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner],
        };
        controller.accountType = 'corporateSMSF';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(1);
      });

      it('should select only directors of the account to display when account type is new corporate SMSF', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner],
        };
        controller.accountType = 'newCorporateSMSF';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(1);
      });

      it('should select only directors of the account to display when corporateTrust', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner],
        };
        controller.accountType = 'corporateTrust';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(1);
      });

      it('should select only trustees of the account to display when individualTrust', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner, trustee],
        };
        controller.accountType = 'individualTrust';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(1);
        expect(controller.investorsSettings[0].name).to.equal(trustee.name);
      });

      it('should select only directors, secretaries and signatories of the account to display when Company', () => {
        controller.accountSettings = {
          personRelations: [someSetting, director, owner, trustee, signatory, secretary, director2],
        };
        controller.accountType = 'company';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings.length).to.equal(4);
        expect(controller.investorsSettings[0].name).to.equal(director.name);
        expect(controller.investorsSettings[1].name).to.equal(signatory.name);
        expect(controller.investorsSettings[2].name).to.equal(secretary.name);
        expect(controller.investorsSettings[3].name).to.equal(director2.name);
      });

      it('should set role as Director when it is the only role when Company', () => {
        controller.accountSettings = {
          personRelations: [director],
        };
        controller.accountType = 'company';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings[0].role).to.eql(director.personRoles);
      });

      it('should set role as Director if the roles are Shareholder and Director when Company', () => {
        director.personRoles = ['Shareholder', 'Director'];
        controller.accountSettings = {
          personRelations: [director],
        };
        controller.accountType = 'company';
        controller.adaptAccountSettingsForView(controller.accountSettings);
        expect(controller.investorsSettings[0].role).to.eql(['Director']);
      });
    });

    describe('setAccountTypeSpecificAttributes', () => {
      let $resolve;
      beforeEach(() => {
        $resolve = { accountType: 'superAccumulation', accountSettings: {} };
        controller = $componentController('nw.onboarding.common.viewApplication.accountSettings', { scope }, $resolve);
      });

      describe('when accoun type is super accumulation', () => {
        beforeEach(() => {
          controller.accountType = 'superAccumulation';
          controller.setAccountSpecificAttributes();
        });

        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Investor');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.false;
        });
      });

      describe('when accoun type is  superPension', () => {
        beforeEach(() => {
          controller.accountType = 'superPension';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Investor');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.false;
        });
      });

      describe('when accoun type is  individual', () => {
        beforeEach(() => {
          controller.accountType = 'individual';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Investor');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.false;
        });
      });

      describe('when accoun type is  joint', () => {
        beforeEach(() => {
          controller.accountType = 'joint';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Investors');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.false;
        });
      });

      describe('when accoun type is  corporateSMSF', () => {
        beforeEach(() => {
          controller.accountType = 'corporateSMSF';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Directors');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.true;
        });
      });

      describe('when accoun type is  corporateTrust', () => {
        beforeEach(() => {
          controller.accountType = 'corporateTrust';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Directors');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.true;
        });
      });

      describe('when accoun type is  individualTrust', () => {
        beforeEach(() => {
          controller.accountType = 'individualTrust';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Trustees');
        });
        it('should set hasApprovers to false', () => {
          expect(controller.hasApprovers).to.be.true;
        });
      });

      describe('when accoun type is  company', () => {
        beforeEach(() => {
          controller.accountType = 'company';
          controller.setAccountSpecificAttributes();
        });
        it('<should set section subtitle to Investor', () => {
          expect(controller.sectionTitle).to.equal('Directors, secretaries and signatories');
        });
        it('should set hasApprovers to true', () => {
          expect(controller.hasApprovers).to.be.true;
        });
        it('should set hasRoles to true', () => {
          expect(controller.hasRoles).to.be.true;
        });
      });
    });

    describe('adaptPowerOfAttorney', () => {
      let $resolve;
      const accountTypeEnum = {
        COMPANY: 'company',
        CORPORATE_SMSF: 'corporateSMSF',
        CORPORATE_TRUST: 'corporateTrust',
        INDIVIDUAL: 'individual',
        INDIVIDUAL_SMSF: 'individualSMSF',
        INDIVIDUAL_TRUST: 'individualTrust',
        JOINT: 'joint',
        NEW_CORPORATE_SMSF: 'newCorporateSMSF',
        NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
        SUPER_ACCUMULATION: 'superAccumulation',
        SUPER_PENSION: 'superPension',
      };

      beforeEach(() => {
        $resolve = { accountType: 'corporateTrust', schemaEnums: { AccountTypeEnum: accountTypeEnum } };
        controller = $componentController('nw.onboarding.common.viewApplication.accountSettings', { scope }, $resolve);
      });

      it('should set the value of powerOfAttorney for corporateTrust', () => {
        controller.accountSettings = {
          personRelations: [
            {
              adviser: true,
            },
          ],
          powerOfAttorney: 'Yes',
        };
        controller.accountType = 'corporateTrust';
        controller.adaptPowerOfAttorney(controller.accountSettings);
        expect(controller.powerOfAttorney).to.equal('Yes');
      });

      it('should set the value of powerOfAttorney for corporateSMSF', () => {
        controller.accountSettings = {
          personRelations: [
            {
              adviser: true,
            },
          ],
          powerOfAttorney: 'No',
        };
        controller.accountType = 'corporateSMSF';
        controller.adaptPowerOfAttorney(controller.accountSettings);
        expect(controller.powerOfAttorney).to.equal('No');
      });

      it('should not set the value of powerOfAttorney for super accounts', () => {
        controller.accountSettings = {
          personRelations: [
            {
              adviser: true,
            },
          ],
        };
        controller.accountType = 'superAccumulation';
        controller.adaptPowerOfAttorney(controller.accountSettings);
        expect(controller.powerOfAttorney).to.be.undefined;
      });
    });
  });
});
