class ViewApplicationController {
  constructor() {
    this.name = 'View application';
    this.model = {};
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.model.applicationDetails = this.applicationDetails;
    this.accountType = this.model.applicationDetails.investorAccountType;
  }
}

export default ViewApplicationController;
