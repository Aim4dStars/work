import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import viewApplicationComponent from './viewApplication.component';
import companyDetails from './companyDetails/companyDetails';
import personDetails from './personDetails/personDetails';
import trustDetails from './trustDetails/trustDetails';
import accountSettings from './accountSettings/accountSettings';
import linkedAccounts from './linkedAccounts/linkedAccounts';
import fees from './fees/fees';
import offlineApprovalDetails from './offlineApprovalDetails/offlineApprovalDetails';
import pensionEligibility from './pensionEligibility/pensionEligibility';
import smsfDetails from './smsfDetails/smsfDetails';
import shareholdersAndMembers from './shareholdersAndMembers/shareholdersAndMembers';

const viewApplicationModule = angular.module('nw.onboarding.common.viewApplication', [
  uiRouter,
  personDetails.name,
  trustDetails.name,
  accountSettings.name,
  linkedAccounts.name,
  fees.name,
  offlineApprovalDetails.name,
  companyDetails.name,
  pensionEligibility.name,
  smsfDetails.name,
  shareholdersAndMembers.name,
])

  .component('nw.onboarding.common.viewApplication', viewApplicationComponent);

export default viewApplicationModule;
