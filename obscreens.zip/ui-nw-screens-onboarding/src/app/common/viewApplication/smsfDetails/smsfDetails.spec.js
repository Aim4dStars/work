import smsfDetailsModule from './smsfDetails';
import smsfDetailsController from './smsfDetails.controller';
import smsfDetailsComponent from './smsfDetails.component';
import smsfDetailsTemplate from './smsfDetails.html';

describe('SmsfDetails', () => {
  let $rootScope;
  let $componentController;
  let scope;
  let controller;

  // load the module
  beforeEach(window.module(smsfDetailsModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    scope = $rootScope.$new();
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = smsfDetailsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(smsfDetailsTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(smsfDetailsController);
    });
  });

  describe('Controller', () => {
    describe('onInit', () => {
      let $resolve;

      // controller specs
      beforeEach(() => {
        $resolve = {
          smsfDetails: [{}],
        };

        // use $componentController helper to init the controller
        // https://docs.angularjs.org/api/ngMock/service/$componentController

        controller = $componentController('nw.onboarding.common.viewApplication.smsfDetails', {
          $scope: $rootScope.$new(),
        }, $resolve);

        controller.adaptDomicileAddress = sinon.spy();
        controller.adaptTfnExemptionValue = sinon.spy();
        controller.adaptIndustry = sinon.spy();

        controller.$onInit();
      });

      it('has smsf details set in controller', () => {
        expect(controller.smsfDetails).to.equal($resolve.smsfDetails);
      });

      it('adaptDomicileAddress should get called  in controller', () => {
        expect(controller.adaptDomicileAddress).to.have.been.called;
      });

      it('adaptTfnExemptionValue should get called  in controller', () => {
        expect(controller.adaptTfnExemptionValue).to.have.been.called;
      });
    });

    describe('onInit methods', () => {
      let $resolve;

      beforeEach(() => {
        $resolve = {};
        controller = $componentController('nw.onboarding.common.viewApplication.smsfDetails', {
          scope,
        }, $resolve);
      });
      describe('adaptDomicileAddress', () => {
        describe('when there is a domicile address', () => {
          it('it should format the address and assign it to domicileAddress in the model', () => {
            controller.smsfDetails = {
              addresses: [{
                streetNumber: '1',
                streetName: 'Domi',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
                domicile: true,
              }, {
                streetNumber: '1',
                streetName: 'Postal',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
              },
              ],
            };
            controller.adaptDomicileAddress();
            expect(controller.smsfDetails.domicileAddress).to.equal('1 Domi Street Sydney NSW 2000 Australia');
          });
        });

        describe('when there is no domicile address', () => {
          it('it should set domicileAddress to be empty', () => {
            controller.smsfDetails = {
              addresses: [{
                streetNumber: '1',
                streetName: 'Domi',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
              }, {
                streetNumber: '1',
                streetName: 'Postal',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
              },
              ],
            };
            controller.adaptDomicileAddress();
            expect(controller.smsfDetails.domicileAddress).to.equal('');
          });
        });
      });

      describe('adaptTfnExemptionValue', () => {
        it('should set tfnExemptionValue to "Supplied" when tfnProvided is true', () => {
          controller.smsfDetails = { tfnProvided: true };
          controller.adaptTfnExemptionValue();
          expect(controller.smsfDetails.tfnExemptionValue).to.equal('Supplied');
        });

        it('should set tfnExemptionValue to "Not supplied" when tfnProvided is false', () => {
          controller.smsfDetails = { tfnProvided: false };
          controller.adaptTfnExemptionValue();
          expect(controller.smsfDetails.tfnExemptionValue).to.equal('Not supplied');
        });

        it('should set tfnExemptionValue to "Not supplied" when tfnProvided is false and exemptionReason is "No exemption"', () => {
          controller.smsfDetails = {
            tfnProvided: false,
            exemptionReason: 'No exemption',
          };
          controller.adaptTfnExemptionValue();
          expect(controller.smsfDetails.tfnExemptionValue).to.equal('Not supplied');
        });

        it('should set tfnExemptionValue to "Not supplied" when tfnProvided is false and tfnExemptId is "99"', () => {
          controller.smsfDetails = {
            tfnProvided: false,
            tfnExemptId: '99',
          };
          controller.adaptTfnExemptionValue();
          expect(controller.smsfDetails.tfnExemptionValue).to.equal('Not supplied');
        });

        it('should set tfnExemptionValue to "Exempt" when tfnProvided is false and exemptionReason is not "No exemption"', () => {
          controller.smsfDetails = {
            tfnProvided: false,
            exemptionReason: 'Any other reason',
          };
          controller.adaptTfnExemptionValue();
          expect(controller.smsfDetails.tfnExemptionValue).to.equal('Exempt');
        });
      });
    });
  });
});
