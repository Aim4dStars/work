import find from 'lodash/find';
import { formatAddressForAvaloqData, getTfnExemptionValue } from '../../../helper/utilities';

class smsfDetailsController {
  constructor() {
    this.name = 'smsfDetails';
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.adaptDomicileAddress();
    this.adaptTfnExemptionValue();
  }

  adaptDomicileAddress() {
    const domicileAddress = find(this.smsfDetails.addresses, address => address.domicile);
    this.smsfDetails.domicileAddress = formatAddressForAvaloqData(domicileAddress);
  }

  adaptTfnExemptionValue() {
    this.smsfDetails.tfnExemptionValue = getTfnExemptionValue(this.smsfDetails);
  }
}

export default smsfDetailsController;
