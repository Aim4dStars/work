import template from './smsfDetails.html';
import controller from './smsfDetails.controller';

const smsfDetailsComponent = {
  bindings: {
    smsfDetails: '<',
    schemaEnums: '<',
    staticData: '<',
    accountType: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default smsfDetailsComponent;
