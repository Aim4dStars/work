import angular from 'angular';
import smsfDetailsComponent from './smsfDetails.component';

const smsfDetailsModule = angular.module('nw.onboarding.common.viewApplication.smsfDetails', [])

  .component('nw.onboarding.common.viewApplication.smsfDetails', smsfDetailsComponent);

export default smsfDetailsModule;
