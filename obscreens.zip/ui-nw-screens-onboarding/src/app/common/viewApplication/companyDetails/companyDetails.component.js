import template from './companyDetails.html';
import controller from './companyDetails.controller';

const companyDetailsComponent = {
  bindings: {
    company: '<',
    accountType: '<',
    schemaEnums: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default companyDetailsComponent;
