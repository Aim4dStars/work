import find from 'lodash/find';
import { formatAddressForAvaloqData, getTfnExemptionValue } from '../../../helper/utilities';

class CompanyDetailsController {
  /**
     * @method $onInit
     * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
     */
  $onInit() {
    this.adaptAddress(this.company, true, 'companyOffice');
    this.adaptAddress(this.company, false, 'placeOfBusiness');
    this.company.tfnExemptionValue = getTfnExemptionValue(this.company);
  }

  adaptAddress(company, isDomicile, propertyName) {
    const addresses = company.addresses;
    if (addresses) {
      const foundAddress = find(addresses, address => {
        if (isDomicile) {
          return address.domicile;
        }

        return !address.domicile;
      });

      if (foundAddress) {
        company[propertyName] = formatAddressForAvaloqData(foundAddress);
      }
    }
  }
}

export default CompanyDetailsController;
