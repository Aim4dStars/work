import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import companyDetailsComponent from './companyDetails.component';

const companyDetailsModule = angular.module('nw.onboarding.companyDetails', [
  uiRouter,
])
  .component('nw.onboarding.common.viewApplication.companyDetails', companyDetailsComponent);

export default companyDetailsModule;
