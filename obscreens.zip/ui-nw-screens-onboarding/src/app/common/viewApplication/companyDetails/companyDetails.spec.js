import keys from 'lodash/keys';
import CompanyDetailsModule from './companyDetails';
import CompanyDetailsController from './companyDetails.controller';
import CompanyDetailsComponent from './companyDetails.component';
import CompanyDetailsTemplate from './companyDetails.html';

describe('CompanyDetails', () => {
  let $rootScope;
  let $componentController;
  let controller;

  // load the module
  beforeEach(window.module(CompanyDetailsModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
  }));

  describe('Component', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = CompanyDetailsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(CompanyDetailsTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(CompanyDetailsController);
    });

    it('declares the correct bindings', () => {
      expect(component.bindings).to.contain.all.keys(['company', 'accountType', 'schemaEnums', 'isAdviser', 'isPrint']);
      expect(keys(component.bindings)).to.have.length(5);
    });
  });

  describe('Controller', () => {
    describe('onInit', () => {
      let $resolve;
      beforeEach(() => {
        $resolve = {
          company: {
            fullName: 'Borden Family Company',
            addresses: [
              {
                streetNumber: '12',
                streetName: 'Pitt',
                streetType: 'Artery',
                suburb: 'MELBOURNE',
                state: 'New South Wales',
                stateAbbr: 'NSW',
                stateCode: 'btfg$au_nsw',
                postcode: '2000',
                countryCode: 'au',
                country: 'Australia',
                modificationSeq: '1',
                mailingAddress: true,
                addressType: 'Residential',
                addressKey: {
                  addressId: '1AAC4C3C0A9631F81EF0EB971A8E85CF52ED75AE9FD9F1BA',
                },
                type: 'Address',
              },
              {
                streetNumber: '12',
                streetName: 'Pitt',
                streetType: 'Artery',
                suburb: 'SYDNEY',
                state: 'New South Wales',
                stateAbbr: 'NSW',
                stateCode: 'btfg$au_nsw',
                postcode: '2000',
                countryCode: 'au',
                country: 'Australia',
                modificationSeq: '1',
                domicile: true,
                mailingAddress: false,
                addressType: 'Postal',
                addressKey: {
                  addressId: '86EEFA79E429EFA53C7714812E261E97D1798FF029E05444',
                },
                type: 'Address',
              },
            ],
            tfnProvided: true,
          },
          accountType: 'company',
        };

        // use $componentController helper to init the controller
        // https://docs.angularjs.org/api/ngMock/service/$componentController

        controller = $componentController('nw.onboarding.common.viewApplication.companyDetails', {
          $scope: $rootScope.$new(),
        }, $resolve);

        controller.$onInit();
      });

      it('has company details set', () => {
        expect(controller.company).to.equal($resolve.company);
      });

      it('has account name set in controller', () => {
        expect(controller.accountType).to.equal($resolve.accountType);
      });

      it('company has place of business address formatted', () => {
        expect(controller.company.placeOfBusiness).to.eq('12 Pitt Artery MELBOURNE NSW 2000 Australia');
      });

      it('company has company office formatted', () => {
        expect(controller.company.companyOffice).to.eq('12 Pitt Artery SYDNEY NSW 2000 Australia');
      });

      it('company has tfn exemption value set to Supplied', () => {
        expect(controller.company.tfnExemptionValue).to.eq('Supplied');
      });
    });

    describe('adaptAddress', () => {
      beforeEach(() => {
        controller = $componentController('nw.onboarding.common.viewApplication.companyDetails', {
          $scope: $rootScope.$new(),
        });
      });

      it('should set companyOffice to undefined if no domicile address is present', () => {
        const company = {
          company: {
            fullName: 'Borden Family Company',
            addresses: [{
              streetNumber: '12',
              streetName: 'Pitt',
              streetType: 'Artery',
              suburb: 'SYDNEY',
              state: 'New South Wales',
              stateAbbr: 'NSW',
              stateCode: 'btfg$au_nsw',
              postcode: '2000',
              countryCode: 'au',
              country: 'Australia',
              modificationSeq: '1',
              domicile: false,
              mailingAddress: false,
              addressType: 'Postal',
              addressKey: {
                addressId: '86EEFA79E429EFA53C7714812E261E97D1798FF029E05444',
              },
              type: 'Address',
            },
            ],
            tfnProvided: true,
          },
        };
        controller.adaptAddress(company, true, 'companyOffice');
        expect(company.companyOffice).to.equal(undefined);
      });

      it('should set placeOfBusiness to undefined if no non-domicile address is present', () => {
        const company = {
          company: {
            fullName: 'Borden Family Company',
            addresses: [{
              streetNumber: '12',
              streetName: 'Pitt',
              streetType: 'Artery',
              suburb: 'SYDNEY',
              state: 'New South Wales',
              stateAbbr: 'NSW',
              stateCode: 'btfg$au_nsw',
              postcode: '2000',
              countryCode: 'au',
              country: 'Australia',
              modificationSeq: '1',
              domicile: true,
              mailingAddress: false,
              addressType: 'Postal',
              addressKey: {
                addressId: '86EEFA79E429EFA53C7714812E261E97D1798FF029E05444',
              },
              type: 'Address',
            },
            ],
            tfnProvided: true,
          },
        };
        controller.adaptAddress(company, true, 'placeOfBusiness');
        expect(company.placeOfBusiness).to.equal(undefined);
      });
    });
  });
});
