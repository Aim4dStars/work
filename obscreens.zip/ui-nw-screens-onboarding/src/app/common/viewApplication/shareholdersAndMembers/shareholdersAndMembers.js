import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import shareholdersAndMembersComponent from './shareholdersAndMembers.component';

const shareholdersAndMembersModule = angular.module('nw.onboarding.shareholdersAndMembers', [
  'nw.core.common.permissions',
  'nw.onboarding.common.filters',
  uiRouter,
])
  .component('nw.onboarding.common.viewApplication.shareholdersAndMembers', shareholdersAndMembersComponent);

export default shareholdersAndMembersModule;
