import ShareholdersAndMembersModule from './shareholdersAndMembers';
import ShareholdersAndMembersController from './shareholdersAndMembers.controller';
import ShareholdersAndMembersComponent from './shareholdersAndMembers.component';
import ShareholdersAndMembersTemplate from './shareholdersAndMembers.html';

describe('ShareholdersAndMembers', () => {
  let $rootScope;
  let $componentController;
  let permissionService;
  let controller;
  let persontypeFilter;
  let isAMLEnabled = false;
  let accountTypeEnum;

  // load the module
  beforeEach(window.module(ShareholdersAndMembersModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    permissionService = $injector.get('nw.core.common.permissions.permissionsService');
    persontypeFilter = $injector.get('$filter')('persontype');
  }));

  beforeEach(() => {
    sinon.stub(permissionService, 'hasPermission', item => {
      if (item === 'feature.global.onboardingAmlChanges') {
        return isAMLEnabled;
      }

      return true;
    });
  });

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = ShareholdersAndMembersComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(ShareholdersAndMembersTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(ShareholdersAndMembersController);
    });
  });

  describe('Controller', () => {
    // controller specs
    const schemaEnums = {
      AccountTypeEnum: {
        COMPANY: 'company',
        CORPORATE_SMSF: 'corporateSMSF',
        CORPORATE_TRUST: 'corporateTrust',
        INDIVIDUAL_SMSF: 'individualSMSF',
        INDIVIDUAL_TRUST: 'individualTrust',
        NEW_CORPORATE_SMSF: 'newCorporateSMSF',
        NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
      },
      TrustTypeEnum: {
        FAMILY: 'family',
        OTHER: 'other',
      },
      AnswerTypeEnum: {
        NO: 'no',
        YES: 'yes',
      },
    };

    describe('Account specific attributes', () => {
      let $resolve;

      describe('when AML toggle is ON', () => {
        beforeEach(() => {
          isAMLEnabled = true;
        });

        it('should set AML account specific config for company account type', () => {
          $resolve = {
            accountType: 'company',
            schemaEnums,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Shareholders and controllers');
          expect(controller.config.sectionSubtitle).to.equal('shareholders and controllers');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional shareholders and controllers');
          expect(controller.config.needsShareholder).to.equal(true);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(false);
          expect(controller.config.needsBeneficialOwner).to.equal(false);
          expect(controller.config.hasNoMajorShareholder).to.be.undefined;
        });

        it('should set AML account specific config for corporateTrust account type', () => {
          $resolve = {
            accountType: 'corporateTrust',
            schemaEnums,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Beneficiaries, shareholders and controllers');
          expect(controller.config.sectionSubtitle).to.equal('beneficiaries, shareholders and controllers');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional beneficiaries, shareholders and controllers');
          expect(controller.config.needsShareholder).to.equal(true);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(true);
          expect(controller.config.needsBeneficialOwner).to.equal(false);
          expect(controller.config.needsControllerOfTrust).to.equal(true);
          expect(controller.config.hasNoMajorShareholder).to.be.undefined;
        });

        it('should set account specific config for Individual trust and family trust type', () => {
          $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            trustDetails: {
              trustType: 'family',
            },
          };

          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Beneficiaries');
          expect(controller.config.sectionSubtitle).to.equal('beneficiaries');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional beneficiaries and controllers');
          expect(controller.config.needsShareholder).to.equal(false);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(true);
        });

        it('should set AML account specific config for corporateSMSF account type', () => {
          $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Members, shareholders and controllers');
          expect(controller.config.sectionSubtitle).to.equal('members, shareholders and controllers');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional members, shareholders and controllers');
          expect(controller.config.needsShareholder).to.equal(false);
          expect(controller.config.needsMember).to.equal(true);
          expect(controller.config.needsBeneficiary).to.equal(false);
          expect(controller.config.needsBeneficialOwner).to.equal(true);
          expect(controller.config.hasNoMajorShareholder).to.be.undefined;
        });
      });

      describe('when AML toggle is OFF', () => {
        beforeEach(() => {
          isAMLEnabled = false;
        });

        it('should set account specific config for company account type', () => {
          $resolve = {
            accountType: 'company',
            schemaEnums,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Shareholders');
          expect(controller.config.sectionSubtitle).to.equal('shareholders');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional shareholders');
          expect(controller.config.needsShareholder).to.equal(true);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(false);
          expect(controller.config.needsBeneficialOwner).to.equal(false);
        });

        it('should set account specific config for CorporateSMSF', () => {
          $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Members & shareholders');
          expect(controller.config.sectionSubtitle).to.equal('members / shareholders');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional members or shareholders');
          expect(controller.config.needsShareholder).to.equal(true);
          expect(controller.config.needsMember).to.equal(true);
          expect(controller.config.needsBeneficiary).to.equal(false);
          expect(controller.config.needsBeneficialOwner).to.equal(false);
        });

        it('should set account specific config for CorporateSMSF with isMajorShareHolder=== "no"', () => {
          $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
            isMajorShareholder: 'no',
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Members & shareholders');
          expect(controller.config.sectionSubtitle).to.equal('members / responsible Persons');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional members or responsible persons');
          expect(controller.config.needsShareholder).to.equal(false);
          expect(controller.config.needsMember).to.equal(true);
          expect(controller.config.needsBeneficiary).to.equal(false);
          expect(controller.config.needsBeneficialOwner).to.equal(true);
        });

        it('should set account specific config for Individual trust account type', () => {
          $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Beneficiaries');
          expect(controller.config.sectionSubtitle).to.equal('beneficiaries');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional beneficiaries');
          expect(controller.config.needsShareholder).to.equal(false);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(true);
        });

        it('should set account specific config for Individual trust and other trust type', () => {
          $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            trustDetails: {
              trustType: 'other',
            },
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Beneficiaries');
          expect(controller.config.sectionSubtitle).to.equal('beneficiaries');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional beneficiaries or responsible persons');
          expect(controller.config.needsShareholder).to.equal(false);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(true);
        });

        it('should set account specific config for Individual trust and family trust type', () => {
          $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            trustDetails: {
              trustType: 'family',
            },
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();
          expect(controller.accountType).to.equal($resolve.accountType);
          expect(controller.config.sectionTitle).to.equal('Beneficiaries');
          expect(controller.config.sectionSubtitle).to.equal('beneficiaries');
          expect(controller.config.additionalSectionSubtitle).to.equal('Additional beneficiaries or responsible persons');
          expect(controller.config.needsShareholder).to.equal(false);
          expect(controller.config.needsMember).to.equal(false);
          expect(controller.config.needsBeneficiary).to.equal(true);
        });
      });
    });

    describe('Investor details for view', () => {
      describe('when AML toggle is OFF', () => {
        beforeEach(() => {
          isAMLEnabled = false;
        });

        it('should set the role information and full name for directors/Secretaries/Signatories (Company account)', () => {
          const $resolve = {
            accountType: 'company',
            schemaEnums,
            investorsDetails: [{
              firstName: 'Rajah',
              lastName: 'Powell',
              personRoles: [
                'Director', 'BeneficialOwner',
              ],
            },
            ],
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();

          expect(controller.investorsDetails[0].fullName).to.equal('Rajah Powell');
          expect(controller.investorsDetails[0].isMember).to.equal(false);
          expect(controller.investorsDetails[0].isShareholder).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficiary).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficialOwner).to.equal(true);
          expect(controller.investorsDetails[0].isCompanySecretary).to.equal(false);
        });

        it('should set the role information and full name for Directors(corporateSMSF)', () => {
          const $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
            investorsDetails: [{
              firstName: 'test',
              lastName: 'CorpSMSF',
              personRoles: [
                'Member', 'BeneficialOwner',
              ],
            },
            ],
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();

          expect(controller.investorsDetails[0].fullName).to.equal('test CorpSMSF');
          expect(controller.investorsDetails[0].isMember).to.equal(true);
          expect(controller.investorsDetails[0].isShareholder).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficiary).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficialOwner).to.equal(true);
          expect(controller.investorsDetails[0].isCompanySecretary).to.equal(false);
        });
        it('should set the role information and full name for trustees (individualSMSF)', () => {
          const $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
            investorsDetails: [{
              firstName: 'Rajah',
              lastName: 'Powell',
              personRoles: [
                'Trustee', 'Member',
              ],
            },
            ],
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();

          expect(controller.investorsDetails[0].fullName).to.equal('Rajah Powell');
          expect(controller.investorsDetails[0].isMember).to.equal(true);
          expect(controller.investorsDetails[0].isShareholder).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficiary).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficialOwner).to.equal(false);
          expect(controller.investorsDetails[0].isCompanySecretary).to.equal(false);
        });

        it('should set the role information and full name for directors (corporate trust)', () => {
          const $resolve = {
            accountType: 'corporateTrust',
            schemaEnums,
            investorsDetails: [{
              firstName: 'Rajah',
              lastName: 'Powell',
              personRoles: [
                'Director', 'Beneficiary',
              ],
            },
            {
              firstName: 'One',
              lastName: 'Powell',
              personRoles: [
                'Director', 'Account_Beneficiary',
              ],
            },
            {
              firstName: 'Two',
              lastName: 'Powell',
              personRoles: [
                'Director', 'Shareholder',
              ],
            },
            ],
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();

          expect(controller.investorsDetails[0].fullName).to.equal('Rajah Powell');
          expect(controller.investorsDetails[0].isMember).to.equal(false);
          expect(controller.investorsDetails[0].isShareholder).to.equal(false);
          expect(controller.investorsDetails[0].isBeneficiary).to.equal(true);
          expect(controller.investorsDetails[0].isBeneficialOwner).to.equal(false);
          expect(controller.investorsDetails[0].isCompanySecretary).to.equal(false);

          expect(controller.investorsDetails[1].fullName).to.equal('One Powell');
          expect(controller.investorsDetails[1].isMember).to.equal(false);
          expect(controller.investorsDetails[1].isShareholder).to.equal(false);
          expect(controller.investorsDetails[1].isBeneficiary).to.equal(true);
          expect(controller.investorsDetails[1].isBeneficialOwner).to.equal(false);
          expect(controller.investorsDetails[1].isCompanySecretary).to.equal(false);

          expect(controller.investorsDetails[2].fullName).to.equal('Two Powell');
          expect(controller.investorsDetails[2].isMember).to.equal(false);
          expect(controller.investorsDetails[2].isShareholder).to.equal(true);
          expect(controller.investorsDetails[2].isBeneficiary).to.equal(false);
          expect(controller.investorsDetails[2].isBeneficialOwner).to.equal(false);
          expect(controller.investorsDetails[2].isCompanySecretary).to.equal(false);
        });
      });
    });

    describe('Additional persons for view', () => {
      beforeEach(() => {
        accountTypeEnum = {
          COMPANY: 'company',
          CORPORATE_SMSF: 'corporateSMSF',
          CORPORATE_TRUST: 'corporateTrust',
          INDIVIDUAL_SMSF: 'individualSMSF',
          INDIVIDUAL_TRUST: 'individualTrust',
          NEW_CORPORATE_SMSF: 'newCorporateSMSF',
          NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
        };
      });

      describe('when AML toggle is OFF', () => {
        beforeEach(() => {
          isAMLEnabled = false;
        });

        it('should set details for personRoles Beneficiary', () => {
          const additionalPersons = [
            {
              firstName: 'Beneficiary',
              lastName: 'Test',
              personRoles: [
                'Beneficiary',
              ],
            },
          ];

          const $resolve = {
            accountType: 'corporateTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Beneficiary Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Beneficiary']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(false);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(false);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(false);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(false);
        });

        it('should set details for personRoles Member', () => {
          const additionalPersons = [
            {
              firstName: 'Member',
              lastName: 'Test',
              personRoles: [
                'Member',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'individualSMSF',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();

          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Member Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Member under 18/legally disabled']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(false);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(false);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should set details for personRoles BeneficialOwner ', () => {
          const additionalPersons = [
            {
              firstName: 'BeneficialOwner',
              lastName: 'Test',
              personRoles: [
                'BeneficialOwner',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'company',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('BeneficialOwner Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Responsible person']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should set details for personRoles Shareholder ', () => {
          const additionalPersons = [
            {
              firstName: 'BeneficialOwner',
              lastName: 'Test',
              personRoles: [
                'Shareholder',
              ],
              resiCountryforTax: 'Australia',
              addresses: [
                {
                  streetNumber: '51',
                  streetName: 'Martin',
                  streetType: 'Path',
                  suburb: 'SYDNEY',
                  state: 'New South Wales',
                  stateAbbr: 'NSW',
                  stateCode: 'btfg$au_nsw',
                  postcode: '2000',
                  countryCode: 'au',
                  country: 'Australia',
                  domicile: true,
                  mailingAddress: false,
                  addressType: 'Postal',
                  addressKey: {
                    addressId: '8B7166DA77D2D128DF22FDEEDB2FF92BF9F6AAFD00F870CD',
                  },
                  type: 'Address',
                },
              ],
            },
          ];

          const $resolve = {
            accountType: 'company',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('BeneficialOwner Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Shareholder']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].resaddress).to.equal('51 Martin Path SYDNEY NSW 2000 Australia');
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should set details for personRoles with roles > 1 and NO BeneficialOwner', () => {
          const additionalPersons = [
            {
              firstName: 'Rahul',
              lastName: 'Test',
              personRoles: [
                'Shareholder', 'Member',
              ],
              resiCountryforTax: 'Australia',
              addresses: [
                {
                  streetNumber: '51',
                  streetName: 'Martin',
                  streetType: 'Path',
                  suburb: 'SYDNEY',
                  state: 'New South Wales',
                  stateAbbr: 'NSW',
                  stateCode: 'btfg$au_nsw',
                  postcode: '2000',
                  countryCode: 'au',
                  country: 'Australia',
                  domicile: false,
                  mailingAddress: true,
                  addressType: 'Postal',
                  addressKey: {
                    addressId: '8B7166DA77D2D128DF22FDEEDB2FF92BF9F6AAFD00F870CD',
                  },
                  type: 'Address',
                },
              ],
            },
          ];

          const $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Rahul Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Shareholder', 'Member']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].resaddress).to.equal('51 Martin Path SYDNEY NSW 2000 Australia');
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should set details for personRoles with roles > 1 and WITH BeneficialOwner', () => {
          const additionalPersons = [
            {
              firstName: 'Rahul',
              lastName: 'Test',
              personRoles: [
                'Member', 'BeneficialOwner',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'corporateTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Rahul Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Member', 'Responsible person']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should NOT show Proof of identity for Additional personType as Beneficiary', () => {
          const additionalPersons = [
            {
              firstName: 'Additional',
              lastName: 'One',
              personRoles: [
                'Beneficiary',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();
          expect(controller.additionalPersonDetails[0].fullName).to.equal('Additional One');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Beneficiary']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(false);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(false);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(false);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(false);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should show Proof of identity for Additional personType as BeneficialOwner', () => {
          const additionalPersons = [
            {
              firstName: 'Additional',
              lastName: 'Two',
              personRoles: [
                'BeneficialOwner',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();
          expect(controller.additionalPersonDetails[0].fullName).to.equal('Additional Two');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, '', accountTypeEnum)).to.deep.equal(['Responsible person']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });
      });

      describe('when AML toggle is ON', () => {
        beforeEach(() => {
          isAMLEnabled = true;
        });

        it('should not set personType and have details for personRoles Beneficiary when corporateTrust', () => {
          const additionalPersons = [
            {
              firstName: 'Beneficiary',
              lastName: 'Test',
              personRoles: [
                'Beneficiary',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'corporateTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Beneficiary Test');
          expect(controller.additionalPersonDetails[0].personRoles[0]).to.equal('Beneficiary');
          expect(controller.additionalPersonDetails[0].persontype).to.be.undefined;
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(false);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(false);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(false);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(false);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
          expect(controller.additionalPersonDetails[0].isEligibleForTaxPurposes).to.equal(false);
        });

        it('should not set personType and have details for personRoles Shareholder when company', () => {
          const additionalPersons = [
            {
              firstName: 'BeneficialOwner',
              lastName: 'Test',
              personRoles: [
                'Shareholder',
              ],
              resiCountryforTax: 'Australia',
              addresses: [
                {
                  streetNumber: '51',
                  streetName: 'Martin',
                  streetType: 'Path',
                  suburb: 'SYDNEY',
                  state: 'New South Wales',
                  stateAbbr: 'NSW',
                  stateCode: 'btfg$au_nsw',
                  postcode: '2000',
                  countryCode: 'au',
                  country: 'Australia',
                  domicile: true,
                  mailingAddress: false,
                  addressType: 'Postal',
                  addressKey: {
                    addressId: '8B7166DA77D2D128DF22FDEEDB2FF92BF9F6AAFD00F870CD',
                  },
                  type: 'Address',
                },
              ],
            },
          ];

          const $resolve = {
            accountType: 'company',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('BeneficialOwner Test');
          expect(controller.additionalPersonDetails[0].persontype).to.be.undefined;
          expect(controller.additionalPersonDetails[0].personRoles[0]).to.equal('Shareholder');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, controller.accountType, accountTypeEnum)).to.deep.equal(['Shareholder / controller of the company']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].resaddress).to.equal('51 Martin Path SYDNEY NSW 2000 Australia');
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
          expect(controller.additionalPersonDetails[0].isEligibleForTaxPurposes).to.equal(true);
        });

        it('should not set personType and have details for personRoles when corporateTrust', () => {
          const additionalPersons = [
            {
              firstName: 'Rahul',
              lastName: 'Test',
              personRoles: [
                'Member', 'ComtrollerOfTrust',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'corporateTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Rahul Test');
          expect(controller.additionalPersonDetails[0].persontype).to.be.undefined;
          expect(controller.additionalPersonDetails[0].personRoles[0]).to.equal('Member');
          expect(controller.additionalPersonDetails[0].personRoles[1]).to.equal('ComtrollerOfTrust');
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
          expect(controller.additionalPersonDetails[0].isEligibleForTaxPurposes).to.equal(true);
        });

        it('should not set personType and have details for personRoles when account is corporateSMSF', () => {
          const additionalPersons = [
            {
              firstName: 'Rahul',
              lastName: 'Test',
              personRoles: [
                'Member', 'BeneficialOwner',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Rahul Test');
          expect(controller.additionalPersonDetails[0].persontype).to.be.undefined;
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, controller.accountType, accountTypeEnum)).to.deep.equal(['Member', 'Shareholder / controller']);
          expect(controller.additionalPersonDetails[0].personRoles[0]).to.equal('Member');
          expect(controller.additionalPersonDetails[0].personRoles[1]).to.equal('BeneficialOwner');
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should not set personType and have details for personRoles(with single role) when account is corporateSMSF', () => {
          const additionalPersons = [
            {
              firstName: 'Rahul',
              lastName: 'Test',
              personRoles: [
                'Member',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'corporateSMSF',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();

          expect(controller.additionalPersonDetails[0].fullName).to.equal('Rahul Test');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, controller.accountType, accountTypeEnum)).to.deep.equal(['Member under 18/legally disabled']);
          expect(controller.additionalPersonDetails[0].personRoles[0]).to.equal('Member');
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(false);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(false);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
          expect(controller.additionalPersonDetails[0].isEligibleForTaxPurposes).to.equal(false);
        });

        it('should NOT show Proof of identity for Additional personType as Beneficiary', () => {
          const additionalPersons = [
            {
              firstName: 'Additional',
              lastName: 'One',
              personRoles: [
                'Beneficiary',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);

          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();
          expect(controller.additionalPersonDetails[0].fullName).to.equal('Additional One');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, controller.accountType, accountTypeEnum)).to.deep.equal(['Beneficiary']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(false);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(false);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(false);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(false);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });

        it('should show Proof of identity for Additional personType as BeneficialOwner', () => {
          const additionalPersons = [
            {
              firstName: 'Additional',
              lastName: 'Two',
              personRoles: [
                'BeneficialOwner',
              ],
              resiCountryforTax: 'Australia',
            },
          ];

          const $resolve = {
            accountType: 'individualTrust',
            schemaEnums,
            additionalPersonDetails: additionalPersons,
          };
          controller = $componentController('nw.onboarding.common.viewApplication.shareholdersAndMembers', {
            $scope: $rootScope.$new(),
          }, $resolve);
          controller.isAustraliaTaxResident = sinon.spy();
          controller.$onInit();
          expect(controller.additionalPersonDetails[0].fullName).to.equal('Additional Two');
          expect(persontypeFilter(controller.additionalPersonDetails[0].personRoles, controller.accountType, accountTypeEnum)).to.deep.equal(['Shareholder / controller']);
          expect(controller.additionalPersonDetails[0].showAddress).to.equal(true);
          expect(controller.additionalPersonDetails[0].showDateOfBirth).to.equal(true);
          expect(controller.additionalPersonDetails[0].showGender).to.equal(true);
          expect(controller.additionalPersonDetails[0].showProofOfIdentity).to.equal(true);
          expect(controller.isAustraliaTaxResident).to.have.been.calledWith(controller.additionalPersonDetails[0].resiCountryforTax);
        });
      });
    });
  });
});
