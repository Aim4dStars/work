import extend from 'lodash/extend';
import each from 'lodash/each';
import find from 'lodash/find';
import { formatAddressForAvaloqData, adaptFullName } from '../../../helper/utilities';
import shareholdersAndMembersConfig from './shareholdersAndMembers.config';

const personRolesEnum = {
  BENEFICIAL_OWNER: 'BeneficialOwner',
  MEMBER: 'Member',
  SHAREHOLDER: 'Shareholder',
  BENEFICIARY: 'Beneficiary',
  ACCOUNT_BENEFICIARY: 'Account_Beneficiary',
  CONTROLLER_OF_TRUST: 'ControllerOfTrust',
  SECRETARY: 'Secretary',
};

class ShareholdersAndMembersController {
  constructor(permission) {
    this.config = {};
    this.hasAMLToggleOn = permission.hasPermission('feature.global.onboardingAmlChanges', '');
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.adaptAccountTypeSpecificAttributes();
    this.adaptInvestorsDetailsForView();
    this.adaptAdditionalRolesForView();
  }

  adaptAdditionalRolesForView() {
    each(this.additionalPersonDetails, personDetails => {
      this.adaptAddressOnObject(personDetails);
      adaptFullName(personDetails);
      if (personDetails.personRoles) {
        personDetails.showAddress = !this.hasSingleRole(personDetails.personRoles, [personRolesEnum.BENEFICIARY]);
        personDetails.showDateOfBirth = !this.hasSingleRole(personDetails.personRoles, [personRolesEnum.BENEFICIARY]);
        personDetails.showGender = !this.hasSingleRole(personDetails.personRoles, [personRolesEnum.MEMBER, personRolesEnum.BENEFICIARY]);
        personDetails.showProofOfIdentity = !this.hasSingleRole(personDetails.personRoles, [personRolesEnum.MEMBER, personRolesEnum.BENEFICIARY]);
        personDetails.isEligibleForTaxPurposes = !this.hasSingleRole(personDetails.personRoles, [personRolesEnum.MEMBER, personRolesEnum.BENEFICIARY]);
      }

      personDetails.isCountryOfResidenceAus = this.isAustraliaTaxResident(personDetails.resiCountryforTax);
    });
  }

  adaptAccountTypeSpecificAttributes() {
    let trustType;
    if (this.trustDetails) {
      trustType = this.trustDetails.trustType;
    }

    this.setAccountTypeConfig(this.accountType, trustType);
  }

  setAccountTypeConfig(accountType, trustType) {
    let familyOrOther = {};
    let hasNoMajorShareholder = {};
    let accountConfig = shareholdersAndMembersConfig[accountType];
    this.config = {};

    // check if AML feature enabled and AML configuration is provided
    if (this.hasAMLToggleOn && accountConfig.aml) {
      accountConfig = accountConfig.aml;
    }

    if (accountConfig) {
      const accountTypeEnum = this.schemaEnums.AccountTypeEnum;
      if (accountType === accountTypeEnum.INDIVIDUAL_TRUST && this.isFamilyOrOtherType(trustType)) {
        familyOrOther = this.hasAMLToggleOn ? accountConfig.familyOrOther.aml : accountConfig.familyOrOther;
      }
    }

    if (this.isMajorShareholder === this.schemaEnums.AnswerTypeEnum.NO) {
      hasNoMajorShareholder = accountConfig.hasNoMajorShareholder;
    }

    extend(this.config, accountConfig, familyOrOther, hasNoMajorShareholder);
  }

  isFamilyOrOtherType(trustType) {
    const trustTypeEnum = this.schemaEnums.TrustTypeEnum;
    return (trustType === trustTypeEnum.FAMILY || trustType === trustTypeEnum.OTHER || trustType === 'Other (Family, Unit, Charitable or Estate)');
  }

  adaptAddressOnObject(obj) {
    const addresses = obj.addresses;
    if (addresses) {
      const foundAddress = find(addresses, address => address.domicile) || find(addresses, address => !address.domicile);
      if (foundAddress) {
        obj.resaddress = formatAddressForAvaloqData(foundAddress);
      }
    }
  }

  hasAnyRole(personRoles, roleArray) {
    for (let i = 0, len = roleArray.length; i < len; i += 1) {
      if (personRoles.indexOf(roleArray[i]) > -1) {
        return true;
      }
    }

    return false;
  }

  hasRole(personRoles, role) {
    return personRoles.indexOf(role) > -1;
  }

  hasSingleRole(personRoles, rolesArray) {
    return (personRoles.length === 1 && this.hasAnyRole(personRoles, rolesArray));
  }

  adaptInvestorsDetailsForView() {
    each(this.investorsDetails, elem => {
      this.adaptInvestorsRoles(elem);
      adaptFullName(elem);
    });
  }

  isAustraliaTaxResident(taxResidenceCountry) {
    const defaultCountry = 'Australia';
    return taxResidenceCountry === defaultCountry;
  }

  adaptInvestorsRoles(obj) {
    const personRoles = obj.personRoles;
    if (!personRoles) {
      return;
    }

    obj.isMember = this.hasRole(personRoles, personRolesEnum.MEMBER);
    obj.isShareholder = this.hasRole(personRoles, personRolesEnum.SHAREHOLDER);
    obj.isBeneficiary = this.hasAnyRole(personRoles, [personRolesEnum.BENEFICIARY, personRolesEnum.ACCOUNT_BENEFICIARY]);
    obj.isBeneficialOwner = this.hasRole(personRoles, personRolesEnum.BENEFICIAL_OWNER);
    obj.isControllerOfTrust = this.accountType === this.schemaEnums.AccountTypeEnum.CORPORATE_TRUST && this.hasRole(personRoles, personRolesEnum.CONTROLLER_OF_TRUST);
    obj.isCompanySecretary = this.accountType === this.schemaEnums.AccountTypeEnum.NEW_CORPORATE_SMSF && this.hasRole(personRoles, personRolesEnum.SECRETARY);
  }
}

ShareholdersAndMembersController.$inject = ['nw.core.common.permissions.permissionsService'];

export default ShareholdersAndMembersController;
