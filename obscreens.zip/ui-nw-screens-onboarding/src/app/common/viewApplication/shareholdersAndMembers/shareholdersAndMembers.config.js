const shareholdersAndMembersConfig = {

  corporateSMSF: {
    sectionTitle: 'Members & shareholders',
    sectionSubtitle: 'members / shareholders',
    additionalSectionSubtitle: 'Additional members or shareholders',
    needsShareholder: true,
    needsMember: true,
    needsBeneficiary: false,
    needsBeneficialOwner: false,
    hasNoMajorShareholder: {
      sectionSubtitle: 'members / responsible Persons',
      additionalSectionSubtitle: 'Additional members or responsible persons',
      needsShareholder: false,
      needsBeneficialOwner: true,
    },
    aml: {
      sectionTitle: 'Members, shareholders and controllers',
      sectionSubtitle: 'members, shareholders and controllers',
      additionalSectionSubtitle: 'Additional members, shareholders and controllers',
      needsShareholder: false,
      needsMember: true,
      needsBeneficiary: false,
      needsBeneficialOwner: true,
      needsControllerOfTrust: false,
    },
  },

  newCorporateSMSF: {
    sectionTitle: 'Members & shareholders',
    sectionSubtitle: 'company shareholders & SMSF members',
    needsShareholder: true,
    needsMember: true,
    needsBeneficiary: false,
    needsBeneficialOwner: false,
  },

  individualSMSF: {
    sectionTitle: 'Members',
    sectionSubtitle: 'members',
    additionalSectionSubtitle: 'Members under 18 and/or legally disabled',
    needsShareholder: false,
    needsMember: true,
    needsTrustees: true,
    needsBeneficiary: false,
  },

  newIndividualSMSF: {
    sectionTitle: 'Members',
    sectionSubtitle: 'members',
    needsShareholder: false,
    needsMember: true,
    needsTrustees: true,
    needsBeneficiary: false,
  },

  corporateTrust: {
    sectionTitle: 'Beneficiaries & shareholders',
    sectionSubtitle: 'beneficiaries / shareholders',
    additionalSectionSubtitle: 'Additional beneficiaries or shareholders',
    needsShareholder: true,
    needsMember: false,
    needsBeneficiary: true,
    needsBeneficialOwner: false,
    hasNoMajorShareholder: {
      sectionSubtitle: 'beneficiaries / responsible persons',
      additionalSectionSubtitle: 'Additional beneficiaries or responsible persons',
      needsShareholder: false,
      needsBeneficialOwner: true,
    },
    aml: {
      sectionTitle: 'Beneficiaries, shareholders and controllers',
      sectionSubtitle: 'beneficiaries, shareholders and controllers',
      additionalSectionSubtitle: 'Additional beneficiaries, shareholders and controllers',
      needsShareholder: true,
      needsMember: false,
      needsBeneficiary: true,
      needsBeneficialOwner: false,
      needsControllerOfTrust: true,
    },
  },
  individualTrust: {
    sectionTitle: 'Beneficiaries',
    sectionSubtitle: 'beneficiaries',
    additionalSectionSubtitle: 'Additional beneficiaries',
    needsShareholder: false,
    needsMember: false,
    needsBeneficiary: true,
    familyOrOther: {
      additionalSectionSubtitle: 'Additional beneficiaries or responsible persons',
      aml: {
        additionalSectionSubtitle: 'Additional beneficiaries and controllers',
      },
    },
  },
  company: {
    sectionTitle: 'Shareholders',
    sectionSubtitle: 'shareholders',
    additionalSectionSubtitle: 'Additional shareholders',
    needsShareholder: true,
    needsMember: false,
    needsBeneficiary: false,
    needsBeneficialOwner: false,
    hasNoMajorShareholder: {
      sectionSubtitle: 'responsible persons',
      additionalSectionSubtitle: 'Additional responsible persons',
      needsShareholder: false,
      needsBeneficialOwner: true,
    },
    aml: {
      sectionTitle: 'Shareholders and controllers',
      sectionSubtitle: 'shareholders and controllers',
      additionalSectionSubtitle: 'Additional shareholders and controllers',
      needsShareholder: true,
      needsMember: false,
      needsBeneficiary: false,
      needsBeneficialOwner: false,
    },
  },
};

export default shareholdersAndMembersConfig;
