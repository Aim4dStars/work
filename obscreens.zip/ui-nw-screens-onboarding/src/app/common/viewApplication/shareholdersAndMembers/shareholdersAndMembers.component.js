import template from './shareholdersAndMembers.html';
import controller from './shareholdersAndMembers.controller';

const shareholdersAndMembersComponent = {
  bindings: {
    investorsDetails: '<',
    additionalPersonDetails: '<',
    accountType: '<',
    schemaEnums: '<',
    trustDetails: '<',
    isMajorShareholder: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default shareholdersAndMembersComponent;
