const personDetailsConfig = {
  individual: {
    sectionTitle: 'Investor',
    needsTaxRelatedFields: true,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  joint: {
    sectionTitle: 'Investors',
    needsTaxRelatedFields: true,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  individualSMSF: {
    sectionTitle: 'Trustees',
    needsTaxRelatedFields: false,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  newIndividualSMSF: {
    sectionTitle: 'Trustees',
    needsTaxRelatedFields: true,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  corporateSMSF: {
    sectionTitle: 'Directors',
    needsTaxRelatedFields: false,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  newCorporateSMSF: {
    sectionTitle: 'Directors',
    needsTaxRelatedFields: true,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: true,
  },
  corporateTrust: {
    sectionTitle: 'Directors',
    needsTaxRelatedFields: false,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  individualTrust: {
    sectionTitle: 'Trustees',
    needsTaxRelatedFields: false,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  company: {
    sectionTitle: 'Directors, secretaries and signatories',
    needsTaxRelatedFields: false,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
  superAccumulation: {
    sectionTitle: 'Investor',
    needsTaxRelatedFields: true,
    needsTFNSuppliedField: true,
    needsPlaceOfBirth: false,
  },
  superPension: {
    sectionTitle: 'Investor',
    needsTaxRelatedFields: true,
    needsTFNSuppliedField: false,
    needsPlaceOfBirth: false,
  },
};

export default personDetailsConfig;

