import template from './personDetails.html';
import controller from './personDetails.controller';

const personDetailsComponent = {
  bindings: {
    person: '<',
    accountType: '<',
    schemaEnums: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default personDetailsComponent;
