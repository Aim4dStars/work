import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import personDetailsComponent from './personDetails.component';

const personDetailsComponentModule = angular.module('nw.onboarding.common.viewApplication.personDetails', [
  uiRouter,
])

  .component('nw.onboarding.common.viewApplication.personDetails', personDetailsComponent);

export default personDetailsComponentModule;
