import assignIn from 'lodash/assignIn';
import keys from 'lodash/keys';
import personDetailsModule from './personDetails';
import personDetailsController from './personDetails.controller';
import personDetailsComponent from './personDetails.component';
import personDetailsTemplate from './personDetails.html';
import personDetailsConfig from './personDetails.config';

describe('PersonDetails', () => {
  let $rootScope;
  let $componentController;
  let controller;
  // load the module
  beforeEach(window.module(personDetailsModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = personDetailsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(personDetailsTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(personDetailsController);
    });
  });

  describe('Controller', () => {
    describe('onInit', () => {
      let $resolve;

      // controller specs
      beforeEach(() => {
        $resolve = { person: [{}, {}], accountType: 'joint', resiCountryforTax: 'Australia' };

        // use $componentController helper to init the controller
        // https://docs.angularjs.org/api/ngMock/service/$componentController

        controller = $componentController('nw.onboarding.common.viewApplication.personDetails', {
          $scope: $rootScope.$new(),
        }, $resolve);

        controller.adaptPhoneTypes = sinon.spy();
        controller.adaptPreferredContact = sinon.spy();
        controller.adaptAddresses = sinon.spy();
        controller.adaptPlaceOfBirth = sinon.spy();
        controller.adaptContactPriority = sinon.spy();
        controller.adaptTfnExemptionValue = sinon.spy();
        controller.handleCrsTaxData = sinon.spy();

        controller.$onInit();
      });

      it('has peron details set in controller', () => {
        expect(controller.person).to.equal($resolve.person);
      });

      it('has account name set in controller', () => {
        expect(controller.accountType).to.equal($resolve.accountType);
      });

      it('adaptPhoneTypes should get called  in controller', () => {
        expect(controller.adaptPhoneTypes).to.have.been.called;
      });

      it('adaptPreferredContact should get called  in controller', () => {
        expect(controller.adaptPreferredContact).to.have.been.called;
      });

      it('adaptAddresses should get called  in controller', () => {
        expect(controller.adaptAddresses).to.have.been.called;
      });

      it('adaptPlaceOfBirth should get called  in controller', () => {
        expect(controller.adaptPlaceOfBirth).to.have.been.called;
      });

      it('adaptContactPriority should get called  in controller', () => {
        expect(controller.adaptContactPriority).to.have.been.called;
      });

      it('needsTaxRelatedFields should get set on person detail', () => {
        expect(controller.person[0].needsTaxRelatedFields).to.equal(personDetailsConfig[controller.accountType].needsTaxRelatedFields);
      });

      it('needsTFNSuppliedField should get set on person detail', () => {
        expect(controller.person[0].needsTFNSuppliedField).to.equal(personDetailsConfig[controller.accountType].needsTFNSuppliedField);
      });

      it('needsPlaceOfBirth should get set on person detail', () => {
        expect(controller.person[0].needsPlaceOfBirth).to.equal(personDetailsConfig[controller.accountType].needsPlaceOfBirth);
      });

      it('adaptTfnExemptionValue should get called  in controller', () => {
        expect(controller.adaptTfnExemptionValue).to.have.been.called;
      });

      it('handleCrsTaxData should get called in controller', () => {
        expect(controller.handleCrsTaxData).to.have.been.called;
      });
    });

    describe('adaptPhoneTypes', () => {
      const adaptPhone = (key, value) => {
        describe(`when the JSON phone type is  ${key}`, () => {
          it(`should change the phone type to ${value} and replace 61 with 0`, () => {
            const phones = [
              {
                phoneType: key,
                number: value[1],
              },
            ];
            const investorObj = { phones };
            controller.adaptPhoneTypes(investorObj);
            expect(investorObj.phones[0].label).to.equal(value[0]);
            expect(investorObj.phones[0].number).to.equal(value[2]);
          });
        });
      };

      const types = {
        Secondary: ['Mobile - secondary', '61426111222', '0426111222'],
        Primary: ['Mobile - primary', '0426888999', '0426888999'],
        Work: ['Work number', '61233337777', '0233337777'],
        Home: ['Home number', '92111555666', '92111555666'],
      };

      const phoneKeys = keys(types);

      beforeEach(() => {
        controller = $componentController('nw.onboarding.common.viewApplication.personDetails', {
          $scope: $rootScope.$new(),
        });
      });

      for (let i = 0; i < phoneKeys.length; i += 1) {
        adaptPhone(phoneKeys[i], types[phoneKeys[i]]);
      }
    });

    describe('adaptPreferredContact', () => {
      describe('when a primary email is the preferred contact type', () => {
        it("should set preferredContact to 'Email - primary'", () => {
          const emails = [
            {
              preferred: true,
              emailType: 'Primary',
              type: 'Email',
            },
          ];
          const investorObj = {
            emails,
          };
          controller.adaptPreferredContact(investorObj);

          expect(investorObj.preferredContact).to.equal('Email - primary');
        });

        describe('when there is more than one email', () => {
          it("should set preferred contact type to 'Email - secondary'", () => {
            const emails = [
              {
                preferred: false,
                emailType: 'Primary',
                type: 'Email',
              },
              {
                preferred: true,
                emailType: 'Secondary',
                type: 'Email',
              },
            ];
            const investorObj = {
              emails,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Email - secondary');
          });
          it('should set preferred contact value to selected email, when there are more than one secondary email', () => {
            const emails = [
              {
                preferred: false,
                emailType: 'Primary',
                type: 'Email',
                email: 'primary@fo.com',
              },
              {
                preferred: true,
                emailType: 'Secondary',
                type: 'Email',
                email: 'seconda@fo.com',
              },
              {
                preferred: false,
                emailType: 'Secondary',
                type: 'Email',
                email: 'thirda@fo.com',
              },
            ];
            const investorObj = {
              emails,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Email - secondary');
            expect(investorObj.preferredContactValue).to.equal('seconda@fo.com');
          });
        });
      });

      describe('when a phone type is the preferred contact type', () => {
        it("should set preferredContact to 'Mobile - primary' when a primary mobile is preferred and when email is present", () => {
          const emails = [
            {
              preferred: false,
              emailType: 'Primary',
              type: 'Email',
            },
          ];
          const phones = [
            {
              preferred: true,
              phoneType: 'Primary',
              type: 'Phone',
            },
          ];
          const investorObj = {
            emails,
            phones,
          };
          controller.adaptPreferredContact(investorObj);

          expect(investorObj.preferredContact).to.equal('Mobile - primary');
        });

        describe('when there is more than one phone', () => {
          it("should set preferred contact type to 'Mobile - secondary' when a secondary mobile is preferred", () => {
            const phones = [
              {
                preferred: false,
                phoneType: 'Primary',
                type: 'Phone',
              },
              {
                preferred: true,
                phoneType: 'Secondary',
                type: 'Phone',
              },
            ];
            const investorObj = {
              phones,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Mobile - secondary');
          });
          it('should set preferred contact value to preferred mobile, when there is more than one secondary mobile', () => {
            const phones = [
              {
                preferred: false,
                phoneType: 'Primary',
                type: 'Phone',
                number: '04343434334',
              },
              {
                preferred: true,
                phoneType: 'Secondary',
                type: 'Phone',
                number: '053434343434',
              },
              {
                preferred: false,
                phoneType: 'Secondary',
                type: 'Phone',
                number: '04060606060',
              },
            ];
            const investorObj = {
              phones,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Mobile - secondary');
            expect(investorObj.preferredContactValue).to.equal('053434343434');
          });
          it("should set preferred contact value to preferred work number, when there is more than one work number and set contact type as 'Work number'", () => {
            const phones = [
              {
                preferred: false,
                phoneType: 'Primary',
                type: 'Phone',
                number: '04343434334',
              },
              {
                preferred: true,
                phoneType: 'Work',
                type: 'Phone',
                number: '053434343434',
              },
              {
                preferred: false,
                phoneType: 'Work',
                type: 'Phone',
                number: '04060606060',
              },
            ];
            const investorObj = {
              phones,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Work number');
            expect(investorObj.preferredContactValue).to.equal('053434343434');
          });
          it("should set preferred contact value to preferred home number, when there is more than one home number and set contact type as 'Home number'", () => {
            const phones = [
              {
                preferred: false,
                phoneType: 'Primary',
                type: 'Phone',
                number: '04343434334',
              },
              {
                preferred: true,
                phoneType: 'Home',
                type: 'Phone',
                number: '053434343434',
              },
              {
                preferred: false,
                phoneType: 'Home',
                type: 'Phone',
                number: '04060606060',
              },
            ];
            const investorObj = {
              phones,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Home number');
            expect(investorObj.preferredContactValue).to.equal('053434343434');
          });
          it("should set preferred contact value to preferred other number, when there is more than one 'other' number and set contact type as 'Other number'", () => {
            const phones = [
              {
                preferred: false,
                phoneType: 'Primary',
                type: 'Phone',
                number: '04343434334',
              },
              {
                preferred: true,
                phoneType: 'Other',
                type: 'Phone',
                number: '053434343434',
              },
              {
                preferred: false,
                phoneType: 'Other',
                type: 'Phone',
                number: '04060606060',
              },
            ];
            const investorObj = {
              phones,
            };
            controller.adaptPreferredContact(investorObj);

            expect(investorObj.preferredContact).to.equal('Other number');
            expect(investorObj.preferredContactValue).to.equal('053434343434');
          });
        });
      });
    });

    describe('adaptAddresses', () => {
      let baseAddress;

      beforeEach(() => {
        baseAddress = {
          streetNumber: '7',
          streetName: 'Goolgaong',
          streetType: 'Street',
          suburb: 'Dapto',
          stateAbbr: 'NSW',
          state: 'New South Wales',
          country: 'Australia',
          postcode: '2530',
          addressType: 'Postal',
          type: 'Address',
        };
      });

      describe('when there is only one residential address provided', () => {
        it('should assign it to residentialAddress field in the model', () => {
          const address = assignIn(baseAddress, {
            domicile: true,
            mailingAddress: false,
          });
          const investorObj = {
            addresses: [address],
          };

          controller.adaptAddresses(investorObj);

          expect(investorObj.residentialAddress).to.equal('7 Goolgaong Street Dapto NSW 2530 Australia');
        });
      });

      describe('when there is only one postal address provided', () => {
        it('should assign it to postalAddress field in the model', () => {
          const address = assignIn(baseAddress, {
            domicile: false,
            mailingAddress: true,
          });
          const investorObj = {
            addresses: [address],
          };

          controller.adaptAddresses(investorObj);

          expect(investorObj.postalAddress).to.equal('7 Goolgaong Street Dapto NSW 2530 Australia');
        });
      });

      describe('when there is one address which is residential and postal', () => {
        it('should assign it to residentialAddress and postalAddress fields in the model', () => {
          const address = assignIn(baseAddress, {
            domicile: true,
            mailingAddress: true,
          });
          const investorObj = {
            addresses: [address],
          };

          controller.adaptAddresses(investorObj);

          expect(investorObj.residentialAddress).to.equal('7 Goolgaong Street Dapto NSW 2530 Australia');
          expect(investorObj.postalAddress).to.equal('7 Goolgaong Street Dapto NSW 2530 Australia');
        });
      });

      describe('<when there is one address for residential and one for postal>', () => {
        it('<should assign correct values to residentialAddress and postalAddress fields in the model>', () => {
          const addressResidential = assignIn(baseAddress, {
            domicile: true,
            mailingAddress: false,
            suburb: 'Residential Suburb',
          });
          const addressPostal = {
            streetNumber: '7',
            streetName: 'Goolgaong',
            streetType: 'Street',
            suburb: 'Postal Suburb',
            stateAbbr: 'NSW',
            state: 'New South Wales',
            postcode: '2530',
            country: 'Australia',
            domicile: false,
            mailingAddress: true,
          };
          const investorObj = {
            addresses: [addressPostal, addressResidential],
          };
          controller.adaptAddresses(investorObj);

          expect(investorObj.residentialAddress).to.equal('7 Goolgaong Street Residential Suburb NSW 2530 Australia');
          expect(investorObj.postalAddress).to.equal('7 Goolgaong Street Postal Suburb NSW 2530 Australia');
        });
      });
    });

    describe('<adaptPlaceOfBirth>', () => {
      let basePlaceOfBirth;
      describe('<when there is an Australian place of birth provided>', () => {
        it('<should assign it to placeofbirth field in the model>', () => {
          const investorObj = {
            placeOfBirthCountry: 'Australia',
            placeOfBirthState: 'ACT',
            placeOfBirthSuburb: 'BELCONNEN',
          };
          controller.adaptPlaceOfBirth(investorObj);
          expect(investorObj.placeofbirth).to.equal('BELCONNEN ACT Australia');
        });
      });

      describe('<when there is an International place of birth provided>', () => {
        it('<should assign it to placeofbirth field in the model', () => {
          const investorObj = {
            placeOfBirthCountry: 'Italy',
            placeOfBirthState: 'Calabria',
            placeOfBirthSuburb: 'CATANZARO',
          };
          controller.adaptPlaceOfBirth(investorObj);
          expect(investorObj.placeofbirth).to.equal('CATANZARO Calabria Italy');
        });
      });

      describe('<when there is no place of birth provided>', () => {
        it('<should return nothing>', () => {
          basePlaceOfBirth = null;

          const investorObj = {
            placeofbirth: basePlaceOfBirth,
          };

          controller.adaptPlaceOfBirth(investorObj);

          expect(investorObj.placeofbirth).to.be.null;
        });
      });
    });

    describe('<adaptContactPriority>', () => {
      describe('<when there is more than one phone>', () => {
        let investorObj;
        beforeEach(() => {
          investorObj = {
            phones: [
              {
                number: '21212',
                phoneType: 'Secondary',
              },
              {
                number: '44444',
                phoneType: 'Primary',
              },
            ],
          };
        });

        it('<should make the primary mobile first in the phones array in the model>', () => {
          controller.adaptContactPriority(investorObj, 'phones', 'phoneType');
          expect(investorObj.phones[0].phoneType).to.equal('Primary');
        });

        describe('<when home and work numbers are present>', () => {
          it('<should sort the phones correctly>', () => {
            investorObj.phones.push({
              number: '28347',
              phoneType: 'Home',
            });
            investorObj.phones.push({
              number: '88888',
              phoneType: 'Work',
            });

            controller.adaptContactPriority(investorObj, 'phones', 'phoneType');

            expect(investorObj.phones[0].phoneType).to.equal('Primary');
            expect(investorObj.phones[1].phoneType).to.equal('Secondary');
            expect(investorObj.phones[2].phoneType).to.equal('Work');
            expect(investorObj.phones[3].phoneType).to.equal('Home');
          });
        });
      });

      describe('<when there is more than one email>', () => {
        const investorObj = {
          emails: [
            {
              email: 'michael@testingme.com',
              emailType: 'Secondary',
            },
            {
              email: 'michael@testingme.com',
              emailType: 'Primary',
            },
          ],
        };

        it('<should make the primary email first in the email array in the model>', () => {
          controller.adaptContactPriority(investorObj, 'emails', 'emailType');
          expect(investorObj.emails[0].emailType).to.equal('Primary');
        });
      });
    });

    describe('adaptTfnExemptionValue', () => {
      let investorObj = {
        tfnProvided: true,
        exemptionReason: '',
      };

      it('when account type is individual/joint and tfn provided', () => {
        investorObj = assignIn(investorObj, personDetailsConfig.individual);
        controller.adaptTfnExemptionValue(investorObj);
        expect(investorObj.tfnExemptionValue).to.equal('Supplied');
        expect(investorObj.tfnExemptionLabel).to.equal('TFN / exemption');
      });

      it('when account type is individual/joint and tfn not provided and no exemption reason', () => {
        investorObj = assignIn(investorObj, personDetailsConfig.individual);
        investorObj.tfnProvided = false;
        controller.adaptTfnExemptionValue(investorObj);
        expect(investorObj.tfnExemptionValue).to.equal('Not supplied');
        expect(investorObj.tfnExemptionLabel).to.equal('TFN / exemption');
      });

      it('when account type is super accumulation/pension tfn not provided but exemption reason comes though ', () => {
        investorObj = assignIn(investorObj, personDetailsConfig.superAccumulation);
        investorObj.exemptionReason = 'Exempt';
        controller.adaptTfnExemptionValue(investorObj);
        expect(investorObj.tfnExemptionValue).to.equal('Exempt');
        expect(investorObj.tfnExemptionLabel).to.equal('Tax file number');
      });

      it('when account type is super accumulation/pension tfn not provided but exemption reason comes though value - No exemption ', () => {
        investorObj = assignIn(investorObj, personDetailsConfig.superAccumulation);
        investorObj.exemptionReason = 'No exemption';
        controller.adaptTfnExemptionValue(investorObj);
        expect(investorObj.tfnExemptionValue).to.equal('Not supplied');
        expect(investorObj.tfnExemptionLabel).to.equal('Tax file number');
      });

      it('when account type is corporateSMSF, individualTrust and  corporateTrust,  company there wont be tfn field  ', () => {
        investorObj = assignIn(investorObj, personDetailsConfig.corporateSMSF);
        controller.adaptTfnExemptionValue(investorObj);
        expect(investorObj.tfnExemptionValue).to.be.undefined;
        expect(investorObj.tfnExemptionLabel).to.be.undefined;
      });
    });

    describe('handleCrsTaxData', () => {
      let resiCountryforTax;
      let taxResidenceCountries;
      beforeEach(() => {
        taxResidenceCountries = [
          {
            taxResidenceCountry: 'India',
            taxExemptionReason: 'Tin Pending',
          },
          {
            taxResidenceCountry: 'Afganistan',
            taxExemptionReason: 'Tin never issued',
          },
        ];
        resiCountryforTax = 'India';
      });

      it('when overseas countries count is greater than 1', () => {
        const investorObj = { taxResidenceCountries, resiCountryforTax };
        controller.handleCrsTaxData(investorObj);
        expect(investorObj.isCountryOfResidenceAus).to.equal(false);
        expect(investorObj.isForeignRegisteredUndefinedOrNull).to.equal(false);
        expect(investorObj.isCountryforTaxCalTobeShown).to.equal(true);
      });

      it('when overseas countries count is greater is 1', () => {
        const investorObj = { taxResidenceCountries: { taxResidenceCountry: 'India' }, resiCountryforTax };
        controller.handleCrsTaxData(investorObj);
        expect(investorObj.isCountryOfResidenceAus).to.equal(false);
        expect(investorObj.isForeignRegisteredUndefinedOrNull).to.equal(false);
        expect(investorObj.isCountryforTaxCalTobeShown).to.equal(false);
      });

      it('when overseas countries null and resiCountryforTax is not aus  means ForeignRegistered is UndefinedOrNull', () => {
        const investorObj = { taxResidenceCountries: null, resiCountryforTax };
        controller.handleCrsTaxData(investorObj);
        expect(investorObj.isCountryOfResidenceAus).to.equal(false);
        expect(investorObj.isForeignRegisteredUndefinedOrNull).to.equal(true);
        expect(investorObj.isCountryforTaxCalTobeShown).to.equal(false);
      });

      it('resiCountryforTax is aus with overseas countries count is greater than 1', () => {
        const investorObj = { taxResidenceCountries, resiCountryforTax: 'Australia' };
        controller.handleCrsTaxData(investorObj);
        expect(investorObj.isCountryOfResidenceAus).to.equal(true);
        expect(investorObj.isForeignRegisteredUndefinedOrNull).to.equal(false);
        expect(investorObj.isCountryforTaxCalTobeShown).to.equal(false);
      });
    });
  });
});
