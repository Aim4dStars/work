import each from 'lodash/each';
import map from 'lodash/map';
import find from 'lodash/find';
import union from 'lodash/union';
import sortBy from 'lodash/sortBy';
import personDetailsConfig from './personDetails.config';
import { countryAus, phoneTypeLabels, formatAddressForAvaloqData, orderedContactTypes, adaptFullName } from '../../../helper/utilities';

class personDetailsController {
  constructor() {
    this.name = 'personDetails';
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.sectionTitle = personDetailsConfig[this.accountType].sectionTitle;
    each(this.person, person => {
      adaptFullName(person);
      this.adaptPhoneTypes(person);
      this.adaptPreferredContact(person);
      this.adaptAddresses(person);
      this.adaptPlaceOfBirth(person);
      this.adaptContactPriority(person, 'phones', 'phoneType');
      this.adaptContactPriority(person, 'emails', 'emailType');
      person.needsTaxRelatedFields = personDetailsConfig[this.accountType].needsTaxRelatedFields;
      person.needsTFNSuppliedField = personDetailsConfig[this.accountType].needsTFNSuppliedField;
      person.needsPlaceOfBirth = personDetailsConfig[this.accountType].needsPlaceOfBirth;
      this.adaptTfnExemptionValue(person);
      this.handleCrsTaxData(person);
    });
  }

  adaptPhoneTypes(investorModelObject) {
    const investorPhones = map(investorModelObject.phones, phone => {
      if (phone.countryCode && phone.countryCode === countryAus) {
        phone.number = `${phone.countryCode}${phone.areaCode.charAt(1)}${phone.number}`;
      } else if (phone.countryCode) {
        phone.number = `${phone.countryCode}${phone.areaCode}${phone.number}`;
      }

      if (phone.number.substr(0, 2) === countryAus) {
        phone.number = phone.number.replace(countryAus, '0');
      }

      phone.label = phoneTypeLabels[phone.phoneType];
      return phone;
    });
    investorModelObject.phones = investorPhones;
  }

  adaptPreferredContact(investorModelObject) {
    const preferredContact = find(union(investorModelObject.emails, investorModelObject.phones), elem => elem.preferred);

    if (preferredContact) {
      if (preferredContact.type === 'Email') {
        investorModelObject.preferredContact = `Email - ${preferredContact.emailType.toLowerCase()}`;
        if (preferredContact.emailType === 'Secondary') {
          this.setPreferredEmail(investorModelObject, preferredContact);
        }
      } else {
        investorModelObject.preferredContact = phoneTypeLabels[preferredContact.phoneType];
        this.setPreferredPhoneNumber(investorModelObject, preferredContact);
      }
    }
  }

  setPreferredPhoneNumber(investorModelObject, preferredPhone) {
    const nextPhoneOfPreferredPhoneType = find(investorModelObject.phones, elem => (elem.phoneType === preferredPhone.phoneType && elem.number !== preferredPhone.number));
    if (nextPhoneOfPreferredPhoneType) {
      investorModelObject.preferredContactValue = preferredPhone.number;
    }
  }

  setPreferredEmail(investorModelObject, preferredEmail) {
    const nextSecondaryEmail = find(investorModelObject.emails, elem => (elem.emailType === preferredEmail.emailType && elem.email !== preferredEmail.email));
    if (nextSecondaryEmail) {
      investorModelObject.preferredContactValue = preferredEmail.email;
    }
  }

  adaptAddresses(investorModelObject) {
    const addresses = investorModelObject.addresses;
    if (addresses) {
      this.findAndSetAddress(investorModelObject, addresses, 'domicile', 'residentialAddress');
      this.findAndSetAddress(investorModelObject, addresses, 'mailingAddress', 'postalAddress');
    }
  }

  findAndSetAddress(investorModelObject, addresses, fieldName, propertyName) {
    const foundAddress = find(addresses, address => address[fieldName]);
    if (foundAddress) {
      investorModelObject[propertyName] = formatAddressForAvaloqData(foundAddress);
    }
  }

  adaptPlaceOfBirth(investorModelObject) {
    const placeOfBirthCountry = investorModelObject.placeOfBirthCountry;
    if (placeOfBirthCountry) {
      investorModelObject.placeofbirth = `${investorModelObject.placeOfBirthSuburb} ${investorModelObject.placeOfBirthState} ${placeOfBirthCountry}`;
    }
  }

  adaptContactPriority(investorModelObject, contactMethodName, priorityField) {
    const contactMethods = investorModelObject[contactMethodName];
    if (contactMethods) {
      const orderedContactMethods = sortBy(contactMethods, contactMethod => orderedContactTypes.indexOf(contactMethod[priorityField]));
      investorModelObject[contactMethodName] = orderedContactMethods;
    }
  }

  adaptTfnExemptionValue(person) {
    let tfnExemptionValue;
    let tfnExemptionLabel;
    if (person.needsTaxRelatedFields) {
      tfnExemptionLabel = person.needsTFNSuppliedField ? 'Tax file number' : 'TFN / exemption';
      if (person.tfnProvided) {
        tfnExemptionValue = 'Supplied';
      } else if (person.exemptionReason) {
        tfnExemptionValue = person.exemptionReason === 'No exemption' ? 'Not supplied' : 'Exempt';
      } else {
        tfnExemptionValue = 'Not supplied';
      }
    }

    person.tfnExemptionValue = tfnExemptionValue;
    person.tfnExemptionLabel = tfnExemptionLabel;
  }

  handleCrsTaxData(person) {
    person.isCountryOfResidenceAus = (person.resiCountryforTax === 'Australia');
    person.isForeignRegisteredUndefinedOrNull = (!person.isCountryOfResidenceAus && !person.taxResidenceCountries);
    person.isCountryforTaxCalTobeShown = (!person.isCountryOfResidenceAus && person.taxResidenceCountries !== null && person.taxResidenceCountries.length > 1);
  }
}

export default personDetailsController;
