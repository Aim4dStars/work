import template from './pensionEligibility.html';

const pensionEligibilityComponent = {
  bindings: {
    pensionEligibility: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
};

export default pensionEligibilityComponent;
