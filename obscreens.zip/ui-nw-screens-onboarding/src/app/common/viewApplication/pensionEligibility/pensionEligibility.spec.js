import PensionEligibilityModule from './pensionEligibility';
import PensionEligibilityComponent from './pensionEligibility.component';
import PensionEligibilityTemplate from './pensionEligibility.html';

describe('PensionEligibility', () => {
  // load the module
  beforeEach(window.module(PensionEligibilityModule.name));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = PensionEligibilityComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(PensionEligibilityTemplate);
    });
  });
});
