import angular from 'angular';
import pensionEligibilityComponent from './pensionEligibility.component';

const pensionEligibilityModule = angular.module('nw.onboarding.common.viewApplication.pensionEligibility', [])

  .component('nw.onboarding.common.viewApplication.pensionEligibility', pensionEligibilityComponent);

export default pensionEligibilityModule;
