import trustDetailsModule from './trustDetails';
import trustDetailsController from './trustDetails.controller';
import trustDetailsComponent from './trustDetails.component';
import trustDetailsTemplate from './trustDetails.html';

describe('trustDetails', () => {
  let $rootScope;
  let $componentController;
  let scope;
  let controller;

  // load the module
  beforeEach(window.module(trustDetailsModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    scope = $rootScope.$new();
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = trustDetailsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(trustDetailsTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(trustDetailsController);
    });
  });

  describe('Controller', () => {
    describe('onInit', () => {
      let $resolve;

      // controller specs
      beforeEach(() => {
        $resolve = {
          trust: [{}],
        };

        // use $componentController helper to init the controller
        // https://docs.angularjs.org/api/ngMock/service/$componentController

        controller = $componentController('nw.onboarding.common.viewApplication.trustDetails', {
          $scope: $rootScope.$new(),
        }, $resolve);

        controller.adaptTrustAddress = sinon.spy();
        controller.adaptTrustDescription = sinon.spy();
        controller.adaptTfnExemptionValue = sinon.spy();

        controller.$onInit();
      });

      it('has trust details set in controller', () => {
        expect(controller.trust).to.equal($resolve.trust);
      });

      it('adaptTrustAddress should get called  in controller', () => {
        expect(controller.adaptTrustAddress).to.have.been.called;
      });

      it('adaptTrustDescription should get called  in controller', () => {
        expect(controller.adaptTrustDescription).to.have.been.called;
      });

      it('adaptTfnExemptionValue should get called  in controller', () => {
        expect(controller.adaptTfnExemptionValue).to.have.been.called;
      });
    });

    describe('onInit methods', () => {
      let $resolve;

      beforeEach(() => {
        $resolve = {};
        controller = $componentController('nw.onboarding.common.viewApplication.trustDetails', {
          scope,
        }, $resolve);
      });
      describe('adaptTrustAddress', () => {
        describe('when there is a domicile address', () => {
          it('it should format the address and assign it to trustAddress in the model', () => {
            controller.trust = {
              addresses: [{
                streetNumber: '1',
                streetName: 'Domi',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
                domicile: true,
              }, {
                streetNumber: '1',
                streetName: 'Postal',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
              },
              ],
            };
            controller.adaptTrustAddress();
            expect(controller.trust.trustAddress).to.equal('1 Domi Street Sydney NSW 2000 Australia');
          });
        });

        describe('when there is no domicile address', () => {
          it('it should set trustAddress to be empty', () => {
            controller.trust = {
              addresses: [{
                streetNumber: '1',
                streetName: 'Domi',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
              }, {
                streetNumber: '1',
                streetName: 'Postal',
                streetType: 'Street',
                suburb: 'Sydney',
                stateAbbr: 'NSW',
                state: 'New South Wales',
                country: 'Australia',
                postcode: '2000',
                addressType: 'Postal',
                type: 'Address',
              },
              ],
            };
            controller.adaptTrustAddress();
            expect(controller.trust.trustAddress).to.equal('');
          });
        });
      });

      describe('adaptTrustDescription', () => {
        it('should set `Testamentary trust` when businessClassificationDesc is `testamentary`', () => {
          controller.trust = { businessClassificationDesc: 'testamentary' };
          controller.adaptTrustDescription();
          expect(controller.trust.businessClassificationDesc).to.equal('Testamentary trust');
        });

        it('should set `Unit trust` when businessClassificationDesc is `unittrust`', () => {
          controller.trust = { businessClassificationDesc: 'unittrust' };
          controller.adaptTrustDescription();
          expect(controller.trust.businessClassificationDesc).to.equal('Unit trust');
        });

        it('should set `Unregistered managed investment scheme` when businessClassificationDesc is `unregmanagedinv`', () => {
          controller.trust = { businessClassificationDesc: 'unregmanagedinv' };
          controller.adaptTrustDescription();
          expect(controller.trust.businessClassificationDesc).to.equal('Unregistered managed investment scheme');
        });

        it('should set `Other` when businessClassificationDesc is `other`', () => {
          controller.trust = { businessClassificationDesc: 'other' };
          controller.adaptTrustDescription();
          expect(controller.trust.businessClassificationDesc).to.equal('Other');
        });

        it('should set same value when businessClassificationDesc is unknown', () => {
          controller.trust = { businessClassificationDesc: 'unknown_value' };
          controller.adaptTrustDescription();
          expect(controller.trust.businessClassificationDesc).to.equal('unknown_value');
        });

        it('should set `undefined` when businessClassificationDesc is `undefined`', () => {
          controller.trust = { };
          controller.adaptTrustDescription();
          expect(controller.trust.businessClassificationDesc).to.equal(undefined);
        });
      });

      describe('adaptTfnExemptionValue', () => {
        it('should set tfnExemptionValue to "Supplied" when tfnProvided is true', () => {
          controller.trust = { tfnProvided: true };
          controller.adaptTfnExemptionValue();
          expect(controller.trust.tfnExemptionValue).to.equal('Supplied');
        });

        it('should set tfnExemptionValue to "Not supplied" when tfnProvided is false', () => {
          controller.trust = { tfnProvided: false };
          controller.adaptTfnExemptionValue();
          expect(controller.trust.tfnExemptionValue).to.equal('Not supplied');
        });

        it('should set tfnExemptionValue to "Not supplied" when tfnProvided is false and exemptionReason is "No exemption"', () => {
          controller.trust = {
            tfnProvided: false,
            exemptionReason: 'No exemption',
          };
          controller.adaptTfnExemptionValue();
          expect(controller.trust.tfnExemptionValue).to.equal('Not supplied');
        });

        it('should set tfnExemptionValue to "Not supplied" when tfnProvided is false and tfnExemptId is "99"', () => {
          controller.trust = {
            tfnProvided: false,
            tfnExemptId: '99',
          };
          controller.adaptTfnExemptionValue();
          expect(controller.trust.tfnExemptionValue).to.equal('Not supplied');
        });

        it('should set tfnExemptionValue to "Exempt" when tfnProvided is false and exemptionReason is not "No exemption"', () => {
          controller.trust = {
            tfnProvided: false,
            exemptionReason: 'Any other reason',
          };
          controller.adaptTfnExemptionValue();
          expect(controller.trust.tfnExemptionValue).to.equal('Exempt');
        });
      });
    });
  });
});
