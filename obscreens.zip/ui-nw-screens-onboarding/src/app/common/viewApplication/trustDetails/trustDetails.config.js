export default {
  testamentary: 'Testamentary trust',
  unittrust: 'Unit trust',
  unregmanagedinv: 'Unregistered managed investment scheme',
  other: 'Other',
};

