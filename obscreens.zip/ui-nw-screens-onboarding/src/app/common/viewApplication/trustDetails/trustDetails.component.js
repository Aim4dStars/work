import template from './trustDetails.html';
import controller from './trustDetails.controller';

const trustDetailsComponent = {
  bindings: {
    trust: '<',
    schemaEnums: '<',
    staticData: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default trustDetailsComponent;
