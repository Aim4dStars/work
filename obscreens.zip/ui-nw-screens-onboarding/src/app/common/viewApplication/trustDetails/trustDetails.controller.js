import find from 'lodash/find';
import trustDescriptionOthersOptions from './trustDetails.config';
import { formatAddressForAvaloqData, getTfnExemptionValue } from '../../../helper/utilities';

class trustDetailsController {
  constructor() {
    this.name = 'trustDetails';
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.adaptTrustAddress();
    this.adaptTrustDescription();
    this.adaptTfnExemptionValue();
  }

  adaptTrustAddress() {
    const addresses = this.trust.addresses;
    if (addresses) {
      this.findAndSetAddress(addresses, 'domicile', 'trustAddress');
    }
  }

  findAndSetAddress(addresses, fieldName, propertyName) {
    const foundAddress = find(addresses, address => address[fieldName]);
    if (foundAddress) {
      this.trust[propertyName] = formatAddressForAvaloqData(foundAddress);
    } else {
      this.trust[propertyName] = '';
    }
  }

  adaptTfnExemptionValue() {
    this.trust.tfnExemptionValue = getTfnExemptionValue(this.trust);
  }

  adaptTrustDescription() {
    if (this.trust.businessClassificationDesc && trustDescriptionOthersOptions[this.trust.businessClassificationDesc]) {
      this.trust.businessClassificationDesc = trustDescriptionOthersOptions[this.trust.businessClassificationDesc];
    }
  }
}

export default trustDetailsController;
