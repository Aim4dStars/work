import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import trustDetailsComponent from './trustDetails.component';

const trustDetailsComponentModule = angular.module('nw.onboarding.common.viewApplication.trustDetails', [
  uiRouter,
  'nw.onboarding.common.filters',
])

  .component('nw.onboarding.common.viewApplication.trustDetails', trustDetailsComponent);

export default trustDetailsComponentModule;
