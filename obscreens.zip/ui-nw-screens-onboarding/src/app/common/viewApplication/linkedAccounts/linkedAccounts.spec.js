import LinkedAccountsModule from './linkedAccounts';
import LinkedAccountsController from './linkedAccounts.controller';
import LinkedAccountsComponent from './linkedAccounts.component';

import LinkedAccountsTemplate from './linkedAccounts.html';

describe('LinkedAccounts', () => {
  let $rootScope;
  let $compile;
  let $componentController;
  let scope;
  let controller;
  let sandbox;
  let permission;

  // load the module
  beforeEach(window.module(LinkedAccountsModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
    permission = $injector.get('nw.core.common.permissions.permissionsService');
  }));

  // sinon setup
  beforeEach(() => {
    sandbox = sinon.sandbox.create();
  });

  // sinon cleanup
  afterEach(() => {
    sandbox.restore();
  });

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = LinkedAccountsComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(LinkedAccountsTemplate);
    });

    it('invokes the right controller', () => {
      expect(component.controller).to.equal(LinkedAccountsController);
    });
  });

  describe('Controller', () => {
    beforeEach(() => {
      controller = $componentController('nw.onboarding.common.viewApplication.linkedAccounts', {
        $scope: $rootScope.$new(),
      });
    });

    describe('$onInit', () => {
      it('should call initilise data ', () => {
        controller.hasDirectDebitDeposit = sinon.spy();
        controller.linkedAccounts = [];
        controller.accountType = '';
        controller.$onInit();
        expect(controller.hasDirectDebitDeposit).to.have.been.called;
      });
    });

    describe('hasDirectDebitDeposit', () => {
      it('should be set to true when at least one directDebitDeposit > 0', () => {
        const linkedAccounts = [
          {
            bsb: '062005',
            accountNumber: '3141592',
            directDebitAmount: null,
          },
          {
            bsb: '062004',
            accountNumber: '27182818',
            directDebitAmount: 25,
          },
        ];

        expect(controller.hasDirectDebitDeposit(linkedAccounts)).to.be.true;
      });

      it('should be set to false when  directDebitDeposit are 0 or null or undefined', () => {
        const linkedAccounts = [
          {
            bsb: '062005',
            accountNumber: '3141592',
          },
          {
            bsb: '062004',
            accountNumber: '27182818',
            directDebitAmount: 0,
          },
        ];

        expect(controller.hasDirectDebitDeposit(linkedAccounts)).to.be.false;
      });
    });
  });

  describe('View', () => {
    let template;

    describe('For Investor when no linked accounts and onboardingLinkedAccount toggle is ON', () => {
      beforeEach(() => {
        sandbox.stub(permission, 'hasPermission').returns(true);

        scope.accountType = 'individualSMSF';
        scope.linkedAccounts = [];
        scope.isAdviser = false;
        scope.isPrint = false;

        template = $compile('<nw.onboarding.common.view-application.linked-accounts is-adviser="isAdviser" account-type="accountType" linked-accounts="linkedAccounts" is-print="isPrint"></nw.onboarding.common.view-application.linked-accounts>')(scope);
        scope.$apply();
      });

      it('has Linked accounts as sub-heading when an investor', () => {
        expect(template.find('h2').html()).to.eq('Linked accounts');
      });

      it('has text when an investor', () => {
        expect(template.find('dl').find('p').html()).to.eq('There is no linked bank account provided for this account.');
        expect(template.find('dl').html()).to.not.match(/Supplying a linked bank account ensures you and your clients can move money into and out of this Panorama account. If a linked bank account is not supplied, only your client can supply one after registering./g);
        expect(template.find('dl').html()).to.match(/Linked accounts are bank accounts that can be used to deposit and transfer money in and out of your Panorama account. This type of payments you can make depend on your investor and professional payments settings./g);
        expect(template.find('dl').html()).to.match(/If a linked account is not supplied, you can supply one online./g);
      });

      it('does NOT HAVE a row line below text if NOT in print mode', () => {
        expect(template[0].querySelector('hr.hr-thin')).to.not.exist;
      });

      it('has a row line below text if in print mode', () => {
        scope.accountType = 'individualSMSF';
        scope.linkedAccounts = [];
        scope.isAdviser = false;
        scope.isPrint = true;
        template = $compile('<nw.onboarding.common.view-application.linked-accounts is-adviser="isAdviser" account-type="accountType" linked-accounts="linkedAccounts" is-print="isPrint"></nw.onboarding.common.view-application.linked-accounts>')(scope);
        scope.$apply();

        expect(template[0].querySelector('hr.hr-thin')).to.exist;
      });
    });

    describe('For Adviser when no linked accounts and onboardingLinkedAccount toggle is ON', () => {
      beforeEach(() => {
        sandbox.stub(permission, 'hasPermission').returns(true);

        scope.accountType = 'individualSMSF';
        scope.linkedAccounts = [];
        scope.isAdviser = true;
        scope.isPrint = false;

        template = $compile('<nw.onboarding.common.view-application.linked-accounts is-adviser="isAdviser" account-type="accountType" linked-accounts="linkedAccounts" is-print="isPrint"></nw.onboarding.common.view-application.linked-accounts>')(scope);
        scope.$apply();
      });

      it('has Linked accounts as sub-heading when an adviser', () => {
        expect(template.find('h3').html()).to.match(/Linked accounts/g);
      });

      it('has text when an adviser', () => {
        expect(template.find('dl').find('p').html()).to.eq('There is no linked bank account provided for this account.');
        expect(template.find('dl').html()).to.match(/Supplying a linked bank account ensures you and your clients can move money into and out of this Panorama account. If a linked account is not supplied, only your client can supply one after registering./g);
        expect(template.find('dl').html()).to.not.match(/Linked accounts are bank accounts that can be used to deposit and transfer money in and out of your Panorama account. This type of payments you can make depend on your investor and professional payments settings./g);
        expect(template.find('dl').html()).to.not.match(/If a linked account is not supplied, you can supply one online./g);
      });
    });

    describe('For Adviser when some linked accounts and onboardingLinkedAccount toggle is OFF', () => {
      beforeEach(() => {
        sandbox.stub(permission, 'hasPermission').returns(false);
        const linkedAccounts = [
          {
            bsb: '062005',
            accountNumber: '3141592',
            directDebitAmount: null,
          },
          {
            bsb: '062004',
            accountNumber: '27182818',
            directDebitAmount: 25,
          },
        ];

        scope.accountType = 'individualSMSF';
        scope.linkedAccounts = linkedAccounts;
        scope.isAdviser = true;
        scope.isPrint = false;

        template = $compile('<nw.onboarding.common.view-application.linked-accounts is-adviser="isAdviser" account-type="accountType" linked-accounts="linkedAccounts" is-print="isPrint"></nw.onboarding.common.view-application.linked-accounts>')(scope);
        scope.$apply();
      });

      it('has Linked accounts as sub-heading when an adviser', () => {
        expect(template.find('h3').html()).to.match(/Linked accounts/g);
        expect(template.find('h3').html()).to.not.match(/(optional)/g);
        expect(template.find('p').html()).to.eq('Linked accounts are bank accounts that can be used to deposit and transfer money in and out of your Panorama account. The type of payments you can make depend on your investor and professional payment settings.');
      });
    });
  });
});
