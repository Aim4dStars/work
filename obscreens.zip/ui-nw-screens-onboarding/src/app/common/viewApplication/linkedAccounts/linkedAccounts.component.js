import template from './linkedAccounts.html';
import controller from './linkedAccounts.controller';

const linkedAccountsComponent = {
  bindings: {
    accountType: '<',
    linkedAccounts: '<',
    isAdviser: '<',
    isPrint: '<',
  },
  template,
  controller,
};

export default linkedAccountsComponent;
