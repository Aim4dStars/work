import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import linkedAccountsComponent from './linkedAccounts.component';

const linkedAccountsModule = angular.module('nw.onboarding.common.viewApplication.linkedAccounts', [
  uiRouter,
  'nw.core.common.permissions',
])

  .component('nw.onboarding.common.viewApplication.linkedAccounts', linkedAccountsComponent);

export default linkedAccountsModule;
