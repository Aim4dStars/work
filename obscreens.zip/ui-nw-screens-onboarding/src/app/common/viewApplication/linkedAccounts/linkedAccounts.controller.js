import some from 'lodash/some';

class LinkedAccountsController {
  constructor(permission) {
    this.name = 'Linked accounts';
    this.model = {};
    this.permission = permission;
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.hasDirectDebit = this.hasDirectDebitDeposit(this.linkedAccounts);
  }

  hasDirectDebitDeposit(linkedAccounts) {
    return some(linkedAccounts, 'directDebitAmount');
  }
}

LinkedAccountsController.$inject = ['nw.core.common.permissions.permissionsService'];

export default LinkedAccountsController;
