import angular from 'angular';

class Queue {
  constructor(options, $timeout) {
    this.delay = options.delay || 0;
    this.$timeout = $timeout;
    this.queue = [];
  }

  addQueue(item) {
    this.queue.push(item);
  }

  dequeue() {
    if (this.queue.length !== 0) {
      const item = this.queue.shift();
      if (!angular.isFunction(item)) {
        return item;
      }

      this.$timeout(() => item.call(), this.delay);
    }

    return this.queue.length;
  }

  startQueue() {
    return this.dequeue();
  }

  clearQueue() {
    this.queue = [];
  }
}

class QueueService {
  constructor($timeout) {
    this.$timeout = $timeout;
  }

  createQueue(options) {
    return new Queue(options, this.$timeout);
  }
}

QueueService.$inject = ['$timeout'];

export default QueueService;
