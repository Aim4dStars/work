import queue from './queue';

describe('queue', () => {
  let service;

  beforeEach(window.module(queue.name));

  beforeEach(inject($injector => {
    service = $injector.get('nw.onboarding.common.queue.newqueueService');
  }));

  describe('QueueService', () => {
    let newQueue;
    it('should give new instace of queue', () => {
      newQueue = service.createQueue({ delay: 1000 });
      expect(newQueue.queue).not.to.be.undefined;
      expect(newQueue.queue.length).to.equals(0);
      expect(newQueue.delay).to.equals(1000);
    });
  });

  describe('Queue', () => {
    let newQueue;
    beforeEach(() => {
      newQueue = service.createQueue({ delay: 1000 });
      sinon.stub(newQueue, '$timeout');
    });

    it('when adding object into the queue', () => {
      newQueue.addQueue('AAA');
      newQueue.addQueue('EEEE');
      expect(newQueue.queue.length).to.equals(2);
    });
    it('when dequue object', () => {
      newQueue.addQueue('AAA');
      newQueue.addQueue('EEEE');
      expect(newQueue.dequeue()).to.equals('AAA');
      expect(newQueue.dequeue()).to.equals('EEEE');
      expect(newQueue.queue.length).to.equals(0);
    });

    it('when adding functions into the queue', () => {
      newQueue.addQueue(() => {});
      newQueue.addQueue(() => {});
      expect(newQueue.queue.length).to.equals(2);
    });
    it('when dequue it wll call function and returns current length queue', () => {
      newQueue.addQueue(() => {});
      newQueue.addQueue(() => {});
      expect(newQueue.dequeue()).to.equals(1);
      expect(newQueue.$timeout).to.have.been.called;
      expect(newQueue.dequeue()).to.equals(0);
      expect(newQueue.$timeout).to.have.been.called;
      expect(newQueue.queue.length).to.equals(0);
    });

    it('clearQueue makes queue empty', () => {
      newQueue.addQueue('AAA');
      newQueue.addQueue('EEEE');
      newQueue.clearQueue();
      expect(newQueue.queue.length).to.equals(0);
    });

    it('startQueue starts the queue by retuning first item', () => {
      newQueue.addQueue('AAA');
      newQueue.addQueue('EEEE');
      expect(newQueue.startQueue()).to.equals('AAA');
    });
  });
});
