import angular from 'angular';
import queueService from './queue.service';

const queueModule = angular.module('nw.onboarding.common.queue', [])
  .service('nw.onboarding.common.queue.newqueueService', queueService);

export default queueModule;
