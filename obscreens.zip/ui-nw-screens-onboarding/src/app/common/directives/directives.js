import angular from 'angular';
import ngDisabled from './ngDisabled/ngDisabled';
import bsbValidation from './bsbValidation/bsbValidation';
import tfn from './tfn/tfn';

const directivesModule = angular.module('nw.onboarding.common.directives', ['nw.onboarding.common.api', 'nw.onboarding.common.filters'])
  .directive('nw.onboarding.common.directives.ngDisabled', ngDisabled)
  .directive('nw.onboarding.common.directives.tfn', tfn)
  .directive('nw.onboarding.common.bsbValidation', bsbValidation);

export default directivesModule;
