import angular from 'angular';
import DirectivesModule from '../directives';

describe('Tfn directive', () => {
  let $compile;
  let scope;
  let template;

  // load the module
  beforeEach(window.module(DirectivesModule.name));

  beforeEach(inject($injector => {
    $compile = $injector.get('$compile');
    scope = $injector.get('$rootScope').$new();
  }));

  describe('input behaviour', () => {
    let input;
    beforeEach(() => {
      scope.elModel = '';
      template = $compile(`<body><form name="testFrom" novalidate>
            <input id="test-id" nw.onboarding.common.directives.tfn ng-model="elModel" name="tfn"/></form></body>`)(scope);
      scope.$apply();
      input = template.find('input')[0];
    });

    it('should allow correct characters but can not be updated in model value if not valid', () => {
      angular.element(input).val('123456789').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('123456789');
      expect(scope.elModel).to.eq(undefined); // model value should not get updated with invalid values.
    });

    it('should allow correct characters and should be updated in model as value is valid', () => {
      angular.element(input).val('111 111 11').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('111 111 11');
      expect(scope.elModel).to.eq('11111111');
    });

    it('should allow incorrect characters and not change model', () => {
      angular.element(input).val('Some text here').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('Some text here');
      expect(scope.elModel).to.eq(undefined);
    });

    it('should not format incorrect tfn value on blur', () => {
      angular.element(input).val('123456789').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('123456789');
      angular.element(input).triggerHandler('blur');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('123456789');

      angular.element(input).val('someinvalid').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('someinvalid');
      angular.element(input).triggerHandler('blur');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('someinvalid');
    });

    it('should format correct tfn value on blur', () => {
      angular.element(input).val('11111111').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('11111111');
      angular.element(input).triggerHandler('blur');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('111 111 11');
    });

    it('should pass validation of CustomFormat and format view', () => {
      angular.element(input).val('123456782').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error).to.deep.equal({});
      angular.element(input).triggerHandler('blur');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('123 456 782');
      expect(scope.elModel).to.eq('123456782');
    });

    it('should pass validation of CustomFormat and change model', () => {
      angular.element(input).val('123 456 782').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error).to.deep.equal({});
      expect(scope.elModel).to.eq('123456782');
    });

    it('should pass validation of CustomFormat and change model for empty value', () => {
      angular.element(input).val('').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error).to.deep.equal({});
    });

    it('should pass validation of CustomFormat and change model and format view', () => {
      angular.element(input).val('12 3 45 6 782').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error).to.deep.equal({});
      angular.element(input).triggerHandler('blur');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('123 456 782');
      expect(scope.elModel).to.eq('123456782');
    });

    it('should not pass validation of CustomFormat and not change model', () => {
      angular.element(input).val('some text').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error.tfn).to.eq(true);
      expect(scope.elModel).to.eq(undefined);

      angular.element(input).val('123456789').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error.tfn).to.eq(true);
      expect(scope.elModel).to.eq(undefined);
    });

    it('should return properly if blank value is passed', () => {
      angular.element(input).val('').triggerHandler('input');
      scope.$apply();
      expect(angular.element(input).val()).to.eq('');
      expect(scope.elModel).to.eq('');
    });

    it('should not pass validation of custom format', () => {
      angular.element(input).val('1234').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error.tfn).to.eq(true);
      expect(scope.elModel).to.eq(undefined);
    });
  });

  describe('when input field disabled status changes', () => {
    let input;
    beforeEach(() => {
      scope.elModel = '';
      scope.disabled = false;
      template = $compile(`<body><form name="testFrom" novalidate>
            <input id="test-id" nw.onboarding.common.directives.tfn ng-model="elModel" name="tfn" ng-disabled="disabled"/></form></body>`)(scope);
      scope.$apply();
      input = template.find('input')[0];
    });

    it('should skip the tfn validation when the field is disabled', () => {
      scope.disabled = true;
      scope.elModel = 'invalid';
      scope.$apply();
      angular.element(input).triggerHandler('input');
      expect(scope.elModel).to.eq('invalid');
      expect(scope.testFrom.tfn.$error).to.deep.equal({});
    });

    it('should not skip the tfn validation when the field is enabled', () => {
      scope.disabled = false;
      scope.elModel = 'invalid';
      scope.$apply();
      angular.element(input).val('123.xmas').triggerHandler('input');
      scope.$apply();
      expect(scope.testFrom.tfn.$error.tfn).to.eq(true);
    });
  });
});
