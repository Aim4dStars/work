import isNil from 'lodash/isNil';
import reduce from 'lodash/reduce';

const regex = /^[0-9]*$/;

const hasCustomFormat = mValue => {
  // empty value always must be true of any directive as it is handled by required
  if (!mValue) {
    return true;
  }

  const modelValue = mValue.replace(/\s/g, '');
  if (!regex.test(modelValue)) {
    return false;
  }

  let sum = 0;
  const weight = {
    8: [10, 7, 8, 4, 6, 3, 5, 1],
    9: [10, 7, 8, 4, 6, 3, 5, 2, 1],
  };
  const tfnLength = modelValue.length;
  if (!/^\d{8,9}$/.test(modelValue)) {
    return false;
  }

  const tfnWeight = weight[tfnLength];
  sum = reduce(modelValue, (_sum, value, index) => _sum + (value * tfnWeight[index]), sum);
  return ((sum % 11) === 0);
};

const convertForModel = value => {
  if (isNil(value)) {
    return value;
  }

  const newValue = value.replace(/\s/g, '');
  return hasCustomFormat(newValue) ? newValue : value;
};

const TfnDirective = $filter => ({
  require: '?ngModel',
  link(scope, el, attrs, ngModel) {
    // disable the tfn validation if the field is disabled
    attrs.$observe('disabled', nv => {
      if (nv) { // disabled
        ngModel.$setValidity('tfn', true);
      } else {
        ngModel.$validate();
      }
    });
    ngModel.$formatters.push(value => $filter('tfn')(value));
    ngModel.$parsers.push(convertForModel);

    ngModel.$validators.tfn = (modelValue, viewValue) => hasCustomFormat(viewValue);

    el.on('blur', () => {
      let result;
      // remove white spaces from $viewValue
      const value = convertForModel(ngModel.$viewValue);
      if (!value) {
        result = true;
      } else if (value !== ngModel.$viewValue || hasCustomFormat(value)) {
        // if value has changed -> value has custom format valid -> apply filter for view
        // if value has not changed but has custom format -> apply filter for view
        ngModel.$setViewValue($filter('tfn')(value));
        ngModel.$render();
      }

      return result;
    });
  },
});
TfnDirective.$inject = ['$filter'];

export default TfnDirective;
