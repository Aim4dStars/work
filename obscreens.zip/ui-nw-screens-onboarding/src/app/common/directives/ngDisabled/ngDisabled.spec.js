import angular from 'angular';
import DirectivesModule from '../directives';

describe('ngDisabled Directive', () => {
  let $rootScope;
  let $compile;
  let $window;
  let scope;
  let template;

  // load the module
  beforeEach(window.module(DirectivesModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $window = $injector.get('$window');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
    $window.sessionStorage.clear();
  }));

  describe('Test cases', () => {
    let input;
    beforeEach(() => {
      scope.elModel = 2;
      scope.isDisabled = false;
      template = $compile(`<body><form name="testFrom" novalidate>
            <input id="test-id" ng-disabled = "isDisabled" nw.onboarding.common.directives.ng-disabled  min="10"  max = "20" ng-model="elModel" name="test" type="number"/></form></body>`)(scope);
      scope.$apply();

      input = template.find('input')[0];
    });

    it('should set min validations as value is less than minimum allowed value(10) and input is not disabled', () => {
      angular.element(input).val('5').triggerHandler('input');
      scope.isDisabled = false;
      scope.$apply();
      expect(scope.testFrom.test.$error.min).to.eq(true);
    });

    it('should set max validations as value is greater than maximum allowed value(20) and input is not disabled', () => {
      angular.element(input).val('25').triggerHandler('input');
      scope.isDisabled = false;
      scope.$apply();
      expect(scope.testFrom.test.$error.max).to.eq(true);
    });

    it('should not set min validations even though value is less than minimum allowed value(10) as input is disabled', () => {
      angular.element(input).val('5').triggerHandler('input');
      scope.isDisabled = true;
      scope.$apply();
      expect(scope.testFrom.test.$error).to.eql({});
    });

    it('should not set max validations even though  value is greater than maximum allowed value(20) as  input is disabled', () => {
      angular.element(input).val('25').triggerHandler('input');
      scope.isDisabled = true;
      scope.$apply();
      expect(scope.testFrom.test.$error).to.eql({});
    });

    it('should not set max validations even though  value is greater than maximum allowed value(25) as  input is disabled', () => {
      scope.elModel = 2;
      scope.isDisabled = false;
      template = $compile(`<body><form name="testFrom" novalidate>
            <input id="test-id" ng-disabled = "isDisabled" nw.onboarding.common.directives.ng-disabled min="10"  max = "20" name="test" type="number"/></form></body>`)(scope);
      scope.$apply();

      input = template.find('input')[0];
      angular.element(input).val('25').triggerHandler('input');
      expect(scope.testFrom.test).to.be.undefined;
    });
  });
});
