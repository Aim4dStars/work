import keys from 'lodash/keys';
import union from 'lodash/union';

const ngDisabledDirective = () => ({
  require: '?ngModel',
  link: (scope, el, attrs) => {
    const ngModelController = el.controller('ngModel');
    if (!ngModelController) {
      return;
    }

    scope.$watch(attrs.ngDisabled, value => {
      if (value) { // disabled
        // reset all inidvidual errors as it should not be part of submit
        union(keys(ngModelController.$validators), keys(ngModelController.$error))
          .forEach(type => ngModelController.$setValidity(type, true));
      } else {
        ngModelController.$validate();
      }
    });
  },
});

export default ngDisabledDirective;
