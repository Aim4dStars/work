const BsbValidateDirective = ($q, bsbValidationService) => ({
  require: '?ngModel',

  link(scope, el, attrs, ctrl) {
    ctrl.$asyncValidators.bsbNumber = modelValue => {
      if (ctrl.$isEmpty(modelValue)) {
        // consider empty model valid
        return $q.when();
      }

      return bsbValidationService.getBsbValidation(modelValue)
        .catch(() => $q.reject())
        .then(() => $q.resolve());
    };
  },
});

BsbValidateDirective.$inject = ['$q', 'nw.onboarding.common.api.bsb'];

export default BsbValidateDirective;
