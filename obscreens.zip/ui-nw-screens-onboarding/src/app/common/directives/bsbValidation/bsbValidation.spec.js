import directive from '../directives';
import '../../api/api';

describe('BSB Validate Directive', () => {
  let $rootScope;
  let $compile;
  let $httpBackend;
  let sandbox;
  let scope;

  // load the module
  beforeEach(window.module(directive.name));

  beforeEach(inject($injector => {
    $httpBackend = $injector.get('$httpBackend');
    $rootScope = $injector.get('$rootScope');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
  }));

  beforeEach(() => {
    sandbox = sinon.sandbox.create();
  });

  afterEach(() => {
    $httpBackend.verifyNoOutstandingExpectation();
    $httpBackend.verifyNoOutstandingRequest();
    sandbox.restore();
  });

  describe('bsb validate directive', () => {
    // view layer specs.
    let template;

    beforeEach(() => {
      template = $compile(`<div>
          <form name="testForm">
            <input name="bsbNumber" ng-model="bsbNumber" nw.onboarding.common.bsb-validation>
          </form>
        </div>`)(scope);
      scope.$apply();
    });

    it('if api returns true then $valid', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/branches/222222')
        .respond(true);

      scope.testForm.bsbNumber.$setViewValue('222222');
      $httpBackend.flush();

      expect(template.html()).to.match(/ng-valid/);
    });

    it('if api returns false then $invalid', () => {
      $httpBackend.whenGET(u => u === '../api/v1_0/branches/222222')
        .respond(() => [500]);

      scope.testForm.bsbNumber.$setViewValue('222222');
      $httpBackend.flush();

      expect(template.html()).to.match(/ng-invalid/);
    });
  });
});
