import angular from 'angular';
import uiRouter from 'angular-ui-router'; // eslint-disable-line import/no-extraneous-dependencies, import/no-unresolved
import defaultExistingOptionComponent from './defaultExistingOption.component';

const defaultExistingOptionModule = angular.module('nw.onboarding.common.defaultExistingOption', [
  uiRouter,
])

  .component('nw.onboarding.common.defaultExistingOption', defaultExistingOptionComponent);

export default defaultExistingOptionModule;
