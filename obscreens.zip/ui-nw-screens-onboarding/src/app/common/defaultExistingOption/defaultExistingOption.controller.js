class DefaultExistingOptionController {
  constructor() {
    this.name = 'DefaultExistingOption';
  }

  /**
   * @method $onInit
   * This lifecycle hook will be executed when all controllers on an element have been constructed and after their bindings are initialized
   */
  $onInit() {
    this.setAccountLabel();
  }

  setAccountLabel() {
    switch (this.accountType) {
      case 'invest': {
        this.accountLabel = 'BT Invest';
        break;
      }

      case 'super': {
        this.accountLabel = 'BT Super Invest';
        break;
      }

      case 'pension': {
        this.accountLabel = 'BT Pension';
        break;
      }

      default:
    }
  }
}

export default DefaultExistingOptionController;
