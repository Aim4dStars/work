import defaultExistingOptionModule from './defaultExistingOption';
import defaultExistingOptionComponent from './defaultExistingOption.component';
import defaultExistingOptionTemplate from './defaultExistingOption.html';

describe('defaultExistingOption', () => {
  let $rootScope;
  let $compile;
  let $componentController;
  let scope;
  let controller;

  // load the module
  beforeEach(window.module(defaultExistingOptionModule.name));

  beforeEach(inject($injector => {
    $rootScope = $injector.get('$rootScope');
    $componentController = $injector.get('$componentController');
    $compile = $injector.get('$compile');
    scope = $rootScope.$new();
  }));

  describe('Module', () => {
    // top-level specs: i.e., routes, injection, naming
    // component/directive specs
    const component = defaultExistingOptionComponent;

    it('includes the intended template', () => {
      expect(component.template).to.equal(defaultExistingOptionTemplate);
    });
  });

  describe('View', () => {
    // view layer specs.
    let template;

    it('if account type is super', () => {
      scope.accountType = 'super';
      template = $compile('<nw.onboarding.common.default-existing-option account-type = "accountType"></nw.onboarding.common.default-existing-option>')(scope);
      scope.$apply();
      expect(template.html()).to.match(/BT Super Invest is powered by the BT Panorama operating system. We have detected that you are an existing Panorama client./g);
    });

    it('if account type is pension', () => {
      scope.accountType = 'pension';
      template = $compile('<nw.onboarding.common.default-existing-option account-type = "accountType"></nw.onboarding.common.default-existing-option>')(scope);
      scope.$apply();
      expect(template.html()).to.match(/BT Pension is powered by the BT Panorama operating system. We have detected that you are an existing Panorama client./g);
    });

    it('if account type is invest', () => {
      scope.accountType = 'invest';
      template = $compile('<nw.onboarding.common.default-existing-option account-type = "accountType"></nw.onboarding.common.default-existing-option>')(scope);
      scope.$apply();
      expect(template.html()).to.match(/BT Invest is powered by the BT Panorama operating system. We have detected that you are an existing Panorama client./g);
    });
  });

  describe('Controller', () => {
    beforeEach(() => {
      controller = $componentController('nw.onboarding.common.defaultExistingOption', { $scope: $rootScope.$new() });
    });

    describe('$onInit / setAccountLabel', () => {
      it('when accountType is invest should set accountLabel as BT Invest', () => {
        controller.accountType = 'invest';
        controller.$onInit();
        expect(controller.accountLabel).to.equal('BT Invest');
      });

      it('when accountType is super should set accountLabel as BT Super Invest', () => {
        controller.accountType = 'super';
        controller.$onInit();
        expect(controller.accountLabel).to.equal('BT Super Invest');
      });

      it('when accountType is pension should set accountLabel as BT Pension', () => {
        controller.accountType = 'pension';
        controller.$onInit();
        expect(controller.accountLabel).to.equal('BT Pension');
      });
    });
  });
});
