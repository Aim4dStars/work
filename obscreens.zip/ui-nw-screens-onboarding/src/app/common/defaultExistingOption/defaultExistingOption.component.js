import template from './defaultExistingOption.html';
import controller from './defaultExistingOption.controller';

const defaultExistingOptionComponent = {
  bindings: {
    accountType: '<',
  },
  template,
  controller,
};

export default defaultExistingOptionComponent;
