import api from './api';

describe('api', () => {
  let $httpBackend;
  let service;
  let cache;
  let sandbox;

  beforeEach(() => {
    sandbox = sinon.sandbox.create();
  });

  afterEach(() => {
    sandbox.restore();
  });

  // load the module
  beforeEach(window.module(api.name));

  beforeEach(inject($injector => {
    $httpBackend = $injector.get('$httpBackend');
    service = $injector.get('nw.onboarding.common.api.static');
    cache = $injector.get('nw.onboarding.common.api.staticCache');
  }));

  describe('StaticService', () => {
    let res;
    const countries = [
      {
        id: '2210',
        value: 'MD',
        listName: 'country',
        label: 'Moldavia',
        type: 'StaticCode',
      },
      {
        id: '2061',
        value: 'AU',
        listName: 'country',
        label: 'Australia',
        type: 'StaticCode',
      },
      {
        id: '2063',
        value: 'Ita',
        listName: 'country',
        label: 'Italy',
        type: 'StaticCode',
      },
      {
        id: '2234',
        value: 'OTHER',
        listName: 'country',
        label: 'Other',
        type: 'StaticCode',
      },
    ];
    const exemptions = [
      {
        id: '3',
        value: '444444442',
        intlId: 'social_ben',
        listName: 'exemption_reason',
        label: 'Centrelink Benefits',
        type: 'StaticCode',
      }, {
        id: '2',
        value: '444444441',
        intlId: 'pensioner',
        listName: 'exemption_reason',
        label: 'Pensioner Investor',
        type: 'StaticCode',
      }, {
        id: '9',
        value: 'NONE',
        intlId: 'pensionernone',
        listName: 'exemption_reason',
        label: 'Pensioner Investor None',
        type: 'StaticCode',
      },
    ];
    const states = [
      {
        id: '5002',
        value: 'QLD',
        listName: 'states',
        label: 'Queensland',
        type: 'StaticCode',
      }, {
        id: '5001',
        value: 'VIC',
        listName: 'states',
        label: 'Victoria',
        type: 'StaticCode',
      },
    ];

    const conditionOfRelease = [
      {
        value: 'TURN_AGE_65',
        label: 'Attaing age 65',
      },
      {
        value: 'RETIR',
        label: 'retirement',
      },
      {
        value: 'DEATH',
        label: 'death',
      },
    ];

    const pensionTaxOptions = [
      {
        label: 'Enter tax file number (TFN)',
        value: 'Tax File Number provided',
      }, {
        label: 'Exempt as payee is a pensioner',
        value: 'pensioner',
      },
    ];

    const mockApiResponse = {
      resultMap: {
        country: countries,
        exemption_reason: exemptions,
        states,
        pension_condition_release: conditionOfRelease,
        pension_exemption_reason: pensionTaxOptions,
      },
    };

    function mockStaticAPI(...categories) {
      let url = '../api/v1_0/static?';
      categories.forEach(cat => {
        url = [url.toString(), 'category=', cat, '&'].join('');
      });
      url = [url.toString(), 'panorama=true'].join('');
      return $httpBackend.whenGET(u => u === url);
    }

    it('getStaticData has default cache values defined', () => {
      service.getStaticData('taxOptions', 'taxOptionsDirect', 'pensionEligibilityOptions').then(r => {
        res = r;
      });
      expect(cache.info().size).to.be.eq(3);
      expect(cache.get('taxOptions')).to.not.be.undefined;
      expect(cache.get('taxOptionsDirect')).to.not.be.undefined;
      expect(cache.get('pensionEligibilityOptions')).to.not.be.undefined;
      expect(cache.get('pensionEligibilityOptions')).to.contain({
        label: 'All the money I am adding to my pension will be transferred from other super providers and I have previously satisfied eligibility criteria to access this money.',
        value: 'UNPSV',
        tooltip: 'This means the money you are transferring to your pension is 100% unrestricted non-preserved. If you are unsure, you can check your last super account statement or contact your other super provider/s.',
      });
    });

    it('getStaticData resolves promise with correct data', () => {
      mockStaticAPI('country', 'states', 'exemption_reason').respond({
        data: mockApiResponse,
      });
      service.getStaticData('countries', 'states', 'taxExemptions', 'taxOptions', 'taxOptionsDirect').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res.countries).to.not.be.undefined;
      expect(res.countries).to.contain({
        id: '2061',
        value: 'AU',
        listName: 'country',
        label: 'Australia',
        type: 'StaticCode',
      });

      expect(res.countries).to.not.contain({
        id: '2234',
        value: 'OTHER',
        listName: 'country',
        label: 'Other',
        type: 'StaticCode',
      });
      expect(res.taxExemptions).to.not.be.undefined;
      expect(res.taxExemptions.length).to.be.eq(2);
      expect(res.taxExemptions).to.contain({
        id: '2',
        value: 'pensioner',
        intlId: 'pensioner',
        listName: 'exemption_reason',
        label: 'Pensioner Investor',
        type: 'StaticCode',
      });

      expect(res.taxOptions).to.not.be.undefined;
      expect(res.taxOptions.length).to.be.eq(3);
      expect(res.taxOptions).to.contain({
        label: 'Provide Exemption Reason',
        value: 'Exemption Reason provided',
      });

      expect(res.taxOptionsDirect).to.not.be.undefined;
      expect(res.taxOptionsDirect.length).to.be.eq(4);
      expect(res.taxOptionsDirect).to.contain({
        label: 'Provide later',
        value: 'Will provide Tax File Number later',
      });

      expect(res.states).to.not.be.undefined;
      expect(res.states.length).to.be.eq(2);
      expect(res.states).to.contain({
        id: '5001',
        value: 'VIC',
        listName: 'states',
        label: 'Victoria',
        type: 'StaticCode',
      });
    });

    it('getStaticData resolves promise and caches data', () => {
      mockStaticAPI('country', 'states', 'exemption_reason').respond({
        data: mockApiResponse,
      });
      service.getStaticData('countries', 'states', 'taxExemptions').then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(cache.info().size).to.be.eq(8);
      expect(cache.get('countries')).to.not.be.undefined;
      expect(cache.get('taxOptions')).to.not.be.undefined;
      expect(cache.get('taxOptionsDirect')).to.not.be.undefined;
      expect(cache.get('states')).to.not.be.undefined;
      expect(cache.get('countries')).to.contain({
        id: '2061',
        value: 'AU',
        listName: 'country',
        label: 'Australia',
        type: 'StaticCode',
      });

      expect(res.countries).to.not.contain({
        id: '2234',
        value: 'OTHER',
        listName: 'country',
        label: 'Other',
        type: 'StaticCode',
      });

      expect(cache.get('states')).to.contain({
        id: '5001',
        value: 'VIC',
        listName: 'states',
        label: 'Victoria',
        type: 'StaticCode',
      });
    });

    it('getStaticData reject promise on error', () => {
      mockStaticAPI('country').respond(() => [500]);
      service.getStaticData('countries').catch(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res.status).to.eq(500);
    });

    it('getStaticData throws Error when static API data key is not mapped', () => {
      mockStaticAPI('country', 'states', 'exemption_reason').respond({
        data: mockApiResponse,
      });
      try {
        service.getStaticData('ABC', 'countries', 'states', 'taxExemptions');
      } catch (err) {
        expect(`${err}`).to.eq('Error: unknown or unmapped staticCache key: ABC. Did you forget to set the StaticDataMapper?');
      }
    });

    it('getStaticData throws Error when static API data is not loaded into cache', () => {
      mockStaticAPI('country', 'exemption_reason').respond({
        data: {
          resultMap: {
            country: countries,
          },
        },
      });
      try {
        service.getStaticData('countries', 'taxExemptions');
        $httpBackend.flush();
      } catch (err) {
        expect(`${err}`).to.eq('Error: staticCache empty for key: taxExemptions. Did you forget to populate the cache from API response?');
      }
    });
  });

  describe('fetchPreservationAge', () => {
    let res;
    const preservationAgeRes = {
      data: {
        resultList: [{ age: 58 }, { age: 57 }],
      },
    };

    it('resolves promise with correct data', () => {
      sinon.spy(service.$http, 'get');
      $httpBackend.whenGET(u => u === '../api/v1_0/client_application/preservation_age').respond(preservationAgeRes);
      service.fetchPreservationAge().then(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(service.$http.get).to.have.been.called;
      expect(res).to.deep.equal(preservationAgeRes.data.resultList);
    });

    it('when preservationAgeOptions present inside the cache, resolves promise  with cached data', () => {
      cache.put('preservationAgeOptions', preservationAgeRes.data.resultList);
      sinon.spy(service.$http, 'get');
      $httpBackend.whenGET(u => u === '../api/v1_0/client_application/preservation_age').respond(preservationAgeRes);
      service.fetchPreservationAge().then(r => {
        res = r;
      });

      expect(service.$http.get).not.to.have.been.called;
      expect(res).to.deep.equal(preservationAgeRes.data.resultList);
    });

    it('whens ervice failes, should throw the error', () => {
      sinon.spy(service.$http, 'get');
      $httpBackend.whenGET(u => u === '../api/v1_0/client_application/preservation_age').respond(() => [500]);
      try {
        service.fetchPreservationAge();
        $httpBackend.flush();
      } catch (err) {
        expect(service.$http.get).to.have.been.called;
        expect(`${err}`).to.eq('Error: staticCache empty for preservationAgeOptions. Did you forget to populate the cache from API response?');
      }
    });
  });
});
