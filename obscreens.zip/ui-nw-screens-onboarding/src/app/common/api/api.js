import angular from 'angular';
import staticDataService from './api.static';
import bsbValidationService from './api.bsb';
import schemaEnumsService from './api.schema';

const apiModule = angular.module('nw.onboarding.common.api', [])
  .service('nw.onboarding.common.api.static', staticDataService)
  .service('nw.onboarding.common.api.schemaEnums', schemaEnumsService)
  .service('nw.onboarding.common.api.bsb', bsbValidationService)
  .factory('nw.onboarding.common.api.staticCache', ['$cacheFactory', $cacheFactory => $cacheFactory('nw.onboarding.common.api.staticCache')]);

export default apiModule;
