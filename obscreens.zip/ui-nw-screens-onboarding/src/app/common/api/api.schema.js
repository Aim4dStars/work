class SchemaService {
  constructor($http, $q, cache) {
    this.$http = $http;
    this.$q = $q;
    this.cache = cache;
  }

  getSchemaEnums() {
    let enums;
    if (this.cache.get('schemaEnums')) {
      enums = this.cache.get('schemaEnums');
      return this.$q.resolve(enums);
    }
    return this.$http.get('../api/v1_0/ob_schema/enums', { cache: true })
      .then(res => {
        enums = res.data.data;
        this.cache.put('schemaEnums', enums);
        return enums;
      });
  }
}

SchemaService.$inject = ['$http', '$q', 'nw.onboarding.common.api.staticCache'];

export default SchemaService;
