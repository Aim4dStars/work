import isEmpty from 'lodash/isEmpty';
import has from 'lodash/has';
import sortBy from 'lodash/sortBy';
import concat from 'lodash/concat';
import reject from 'lodash/reject';
import each from 'lodash/each';
import flow from 'lodash/fp/flow';
import filter from 'lodash/fp/filter';
import fpSortBy from 'lodash/fp/sortBy';

/**
* mappings the key in the service's cache --> the /static API 'category' param value
*/
const StaticDataMapper = {
  countries: 'country',
  taxExemptions: 'exemption_reason',
  states: 'states',
  conditionReleaseOptions: 'pension_condition_release',
  pensionTaxOptions: 'pension_exemption_reason',
};

/**
* TODO: add all hard-coded DEFAULT staticData options in here
* (NOTE: these are the same hard-coded values from /dropDownUtilities.js on the OldWorld)
*/
function defaultStaticData(cache) {
  // Tax Options
  cache.put('taxOptions', [
    {
      label: 'Enter tax file number (TFN)',
      value: 'Tax File Number provided',
    }, {
      label: 'Provide Exemption Reason',
      value: 'Exemption Reason provided',
    }, {
      label: 'Do not quote TFN or exemption',
      value: 'Tax File Number or exemption not provided',
    },
  ]);

  // Tax Options Direct
  const taxOptionsDirect = concat(cache.get('taxOptions'), {
    label: 'Provide later',
    value: 'Will provide Tax File Number later',
  });
  cache.put('taxOptionsDirect', taxOptionsDirect);

  // Pension Eligibility Option
  cache.put('pensionEligibilityOptions', [
    {
      label: 'You are eligible to open a BT Pension account as you are over age 65.',
      value: 'OVER_65',
    }, {
      label: 'I have retired and do not ever intend to work for more than 10 hours a week',
      value: 'RETIRE_COND_OF_RELEASE_1',
    }, {
      label: 'I left my employer on or after I turned 60',
      value: 'RETIRE_COND_OF_RELEASE_2',
    }, {
      label: 'I am commencing a transition to retirement pension',
      value: 'PSV_AGE_TTR',
    }, {
      label: 'All the money I am adding to my pension will be transferred from other super providers and I have previously satisfied eligibility criteria to access this money.',
      value: 'UNPSV',
      tooltip: 'This means the money you are transferring to your pension is 100% unrestricted non-preserved. If you are unsure, you can check your last super account statement or contact your other super provider/s.',
    },
  ]);
}

/**
* Save in cache based on API response data
*/
function populateCache(cache, resultMap) {
  // Countries
  if (!cache.get('countries') && has(resultMap, 'country')) {
    cache.put(
      'countries',
      flow(
        filter(country => ['OTHER'].indexOf(country.value) === -1),
        fpSortBy(country => country.label),
      )(resultMap.country),
    );
  }

  // Tax exemption reasons
  if (!cache.get('taxExemptions') && has(resultMap, 'exemption_reason')) {
    const exemptionReasons = reject(resultMap.exemption_reason, elem => elem.value === 'NONE');
    each(exemptionReasons, option => {
      option.value = option.intlId;
    });
    cache.put('taxExemptions', exemptionReasons);
  }

  // Australian States
  if (!cache.get('states') && has(resultMap, 'states')) {
    cache.put('states', sortBy(resultMap.states, state => state.label));
  }

  // pension_condition_release
  if (!cache.get('conditionReleaseOptions') && has(resultMap, 'pension_condition_release')) {
    cache.put('conditionReleaseOptions', resultMap.pension_condition_release);
  }

  // pension exemption reason
  if (!cache.get('pensionExemptionReason') && has(resultMap, 'pension_exemption_reason')) {
    const tfnOption = {
      label: 'Enter tax file number (TFN)',
      value: 'Tax File Number provided',
    };

    each(resultMap.pension_exemption_reason, option => {
      option.value = option.intlId;
    });
    cache.put('pensionTaxOptions', concat(tfnOption, resultMap.pension_exemption_reason));
  }

  // TODO: add all other categories here
}

/**
* This service deals with /static REST API.
*/
class StaticDataService {
  constructor($http, $q, cache) {
    this.$http = $http;
    this.$q = $q;
    this.cache = cache;
    defaultStaticData(this.cache);
  }

  /**
   * Retrieve data from /static API and cache it inside this service under `this.cache` object
   */
  getStaticData(...staticKeys) {
    const result = {};
    const categories = [];
    staticKeys.forEach(key => {
      if (!this.cache.get(key)) {
        if (StaticDataMapper[key]) {
          categories.push(StaticDataMapper[key]);
        } else {
          throw new Error(`unknown or unmapped staticCache key: ${key}. Did you forget to set the StaticDataMapper?`);
        }
      }
    });
    if (isEmpty(categories)) { // all required data already in cache
      each(staticKeys, key => {
        result[key] = this.cache.get(key);
      });
      return this.$q.resolve(result);
    }
    const url = '../api/v1_0/static';
    return this.$http.get(url, {
      cache: true,
      params: { category: categories, panorama: true },
    })
      .then(res => {
        populateCache(this.cache, res.data.data.resultMap);
        each(staticKeys, key => {
          const keyValue = this.cache.get(key);
          if (!keyValue) {
            throw new Error(`staticCache empty for key: ${key}. Did you forget to populate the cache from API response?`);
          }

          result[key] = keyValue;
        });
        return result;
      });
  }

  /**
   * Retrieve data for preservationAgeOptions and cache it inside this service under `this.cache` object
   */

  fetchPreservationAge() {
    if (this.cache.get('preservationAgeOptions')) {
      return this.$q.resolve(this.cache.get('preservationAgeOptions'));
    }
    const url = '../api/v1_0/client_application/preservation_age';
    return this.$http.get(url, {
      cache: true,
    })
      .then(res => {
        this.cache.put('preservationAgeOptions', res.data.data.resultList);
        return res.data.data.resultList;
      })
      .catch(() => {
        throw new Error('staticCache empty for preservationAgeOptions. Did you forget to populate the cache from API response?');
      });
  }
}

StaticDataService.$inject = ['$http', '$q', 'nw.onboarding.common.api.staticCache'];

export default StaticDataService;

