import api from './api';

describe('api', () => {
  let $httpBackend;
  let service;
  let cache;
  let sandbox;

  beforeEach(() => {
    sandbox = sinon.sandbox.create();
  });

  afterEach(() => {
    sandbox.restore();
  });

  // load the module
  beforeEach(window.module(api.name));

  beforeEach(inject($injector => {
    $httpBackend = $injector.get('$httpBackend');
    service = $injector.get('nw.onboarding.common.api.schemaEnums');
    cache = $injector.get('nw.onboarding.common.api.staticCache');
  }));

  describe('SchemaService', () => {
    it('should  retrieve data from the server and set the cache', () => {
      const data = {
        data:
        {
          AccountTypeEnum:
          {
            INDIVIDUAL: 'individual',
            JOINT: 'joint',
            COMPANY: 'company',
            INDIVIDUAL_TRUST: 'individualTrust',
            CORPORATE_TRUST: 'corporateTrust',
            NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
            NEW_CORPORATE_SMSF: 'newCorporateSMSF',
            INDIVIDUAL_SMSF: 'individualSMSF',
            CORPORATE_SMSF: 'corporateSMSF',
            SUPER_ACCUMULATION: 'superAccumulation',
            SUPER_PENSION: 'superPension',
          },
        },
      };
      $httpBackend.whenGET(u => u === '../api/v1_0/ob_schema/enums').respond(data);
      service.getSchemaEnums();
      $httpBackend.flush();
      expect(cache.info().size).to.be.eq(1);
      expect(cache.get('schemaEnums')).to.not.be.undefined;
    });

    it('should  retrieve data from the cache from the second request', () => {
      const data = {
        data:
        {
          AccountTypeEnum:
            {
              INDIVIDUAL: 'individual',
              JOINT: 'joint',
              COMPANY: 'company',
              INDIVIDUAL_TRUST: 'individualTrust',
              CORPORATE_TRUST: 'corporateTrust',
              NEW_INDIVIDUAL_SMSF: 'newIndividualSMSF',
              NEW_CORPORATE_SMSF: 'newCorporateSMSF',
              INDIVIDUAL_SMSF: 'individualSMSF',
              CORPORATE_SMSF: 'corporateSMSF',
              SUPER_ACCUMULATION: 'superAccumulation',
              SUPER_PENSION: 'superPension',
            },
        },
      };
      $httpBackend.whenGET(u => u === '../api/v1_0/ob_schema/enums').respond(data);
      service.getSchemaEnums();
      $httpBackend.flush();
      service.getSchemaEnums();
      expect($httpBackend.flush).to.throw('No pending request to flush !');
    });

    it('getSchemaEnums should fail and cache should not be set if there is a service side error', () => {
      let res;
      $httpBackend.whenGET(u => u === '../api/v1_0/ob_schema/enums').respond(() => [500]);
      service.getSchemaEnums().catch(r => {
        res = r;
      });
      $httpBackend.flush();
      expect(res.status).to.eq(500);
      expect(cache.info().size).to.be.eq(0);
      expect(cache.get('schemaEnums')).to.not.be.defined;
    });
  });
});
