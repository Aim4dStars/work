class BsbValidationService {
  constructor($http) {
    this.$http = $http;
  }

  getBsbValidation(bsb) {
    return this.$http.get(`../api/v1_0/branches/${bsb}`);
  }
}

BsbValidationService.$inject = ['$http'];

export default BsbValidationService;
