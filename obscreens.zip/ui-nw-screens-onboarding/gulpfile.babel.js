import gulp from 'gulp';
import changed from 'gulp-changed';
import webpack from 'webpack';
import path from 'path';
import rename from 'gulp-rename';
import template from 'gulp-template';
import yargs from 'yargs';
import gutil from 'gulp-util';
import serve from 'browser-sync';
import proxy from 'http-proxy-middleware';
import webpackDevMiddelware from 'webpack-dev-middleware';
import webpachHotMiddelware from 'webpack-hot-middleware';
import colorsSupported from 'supports-color';
import capitalize from 'lodash/capitalize';
import HttpsProxyAgent from 'https-proxy-agent';
import compress from 'compression';
import { endpoints } from 'ui-salad/config';
import assign from 'lodash/assign';
import map from 'lodash/map';
import startsWith from 'lodash/startsWith';
import filter from 'lodash/filter';
import keys from 'lodash/keys';
import runSequence from 'run-sequence';
import packageJson from './package';

const root = 'src';

// helper method for resolving paths
const resolveToApp = (glob = '') => path.join(root, 'app', glob); // app/{glob}

const resolveToComponents = (glob = '') => path.join(root, 'app/components', glob); // app/components/{glob}

// map of all paths
const paths = {
  js: resolveToComponents('**/*!(.spec.js).js'), // exclude spec files
  scss: resolveToApp('**/*.scss'), // stylesheets
  html: [
    resolveToApp('**/*.html'),
    path.join(root, 'index.html'),
  ],
  entry: path.join(__dirname, root, 'app/app.js'),
  output: root,
  blankTemplates: path.join(__dirname, 'node_modules/ui-salad/generator', 'component/**/*.**'),
};

// use webpack.config.js to build modules
gulp.task('webpack', cb => {
  webpack(require('./webpack.config'), (err, stats) => { // eslint-disable-line global-require
    if (err) {
      throw new gutil.PluginError('webpack', err);
    }

    gutil.log('[webpack]', stats.toString({
      colors: colorsSupported,
      chunks: false,
      errorDetails: true,
    }));

    cb();
  });
});

gulp.task('serve', () => {
  const webpackConfig = require('./webpack.config'); // eslint-disable-line global-require
  const compiler = webpack(webpackConfig);
  const env = yargs.argv.env || 'mock';
  const envConfig = endpoints[env];
  envConfig.endpoint = yargs.argv.endpoint || envConfig.endpoint;
  const context = envConfig.context || 'ng';
  let rewriteApiPath = { '^/api': `/${context}/secure/api` };
  const corporateProxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
  let agent = false;

  if (envConfig.proxy && corporateProxy) {
    agent = new HttpsProxyAgent(corporateProxy);
  }

  if (env === 'mock') {
    rewriteApiPath = {};
  }

  const proxyConfig = {
    secure: false, agent, changeOrigin: envConfig.changeOrigin, autoRewrite: envConfig.autoRewrite, protocolRewrite: 'https',
  };

  serve({
    port: process.env.PORT || 3000,
    open: false,
    server: { baseDir: 'dist', https: true },
    snippetOptions: {
      rule: {
        match: /qqqqqqqqq/,
      },
    },
    middleware: [
      proxy(`${envConfig.endpoint}/pkmslogout`, assign({}, proxyConfig)),
      proxy(`${envConfig.endpoint}/${context}`, assign({}, proxyConfig)),
      proxy(`${envConfig.endpoint}/eam`, assign({}, proxyConfig)),
      proxy(`${envConfig.endpoint}/sps`, assign({}, proxyConfig)),
      proxy(`${envConfig.endpoint}/upload`, assign({ pathRewrite: { '^/': `/${context}/secure/` } }, proxyConfig)),
      proxy(`${envConfig.endpoint}/api`, assign({ pathRewrite: rewriteApiPath }, proxyConfig)),
      proxy(`${envConfig.endpoint}/content`, assign({}, proxyConfig)),
      proxy(`${envConfig.endpoint}/security`, assign({ pathRewrite: { '^/security': `/${context}/security` } }, proxyConfig)),
      proxy(`${envConfig.endpoint}/public`, assign({ pathRewrite: { '^/public/api': `/${context}/public/api`, '^/public/page': `/${context}/public/page`, '^/public/static': `/${context}/public/static` } }, proxyConfig)),
      compress(),
      webpackDevMiddelware(compiler, {
        stats: {
          colors: colorsSupported,
          chunks: false,
          modules: false,
        },
      }),
      webpachHotMiddelware(compiler),
    ],
  });
});

gulp.task('watch', () => runSequence('watch:modules', 'serve'));

gulp.task('watch:modules', () => {
  // pull package json deps
  const deps = keys(packageJson.dependencies);

  return Promise.all(map(filter(deps, d => startsWith(d, 'ui-')), name => {
    const src = path.join(__dirname, `../${name}/src/**/*`);
    const dest = path.join(__dirname, `./node_modules/${name}/src/`);

    // set a watcher to copy again on file changes
    gulp.watch(src, e => {
      gutil.log(`file ${e.type}: ${e.path}`);

      gulp.src(src)
        .pipe(changed(dest))
        .pipe(gulp.dest(dest));
    });

    // do an initial copy to make sure files are up to date
    return gulp.src(src)
      .pipe(changed(dest))
      .pipe(gulp.dest(dest));
  })).then(() => {
    gutil.log('Waiting for copy to finish');
    return new Promise(res => setTimeout(res, 2000));
  });
});

gulp.task('component', () => {
  const cap = val => val.charAt(0).toUpperCase() + val.slice(1);

  const camelCaseToDashed = val => val.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();

  const name = yargs.argv.name;
  const parentPath = yargs.argv.parent || '';
  const destPath = path.join(resolveToComponents(), parentPath, name);
  const randomNamespace = `nw.${Math.random().toString(36).substring(7)}`;
  const namespace = yargs.argv.namespace || randomNamespace;
  const displayName = name.replace(/([A-Z]+)*([A-Z][a-z])/g, '$1 $2');

  if (namespace === randomNamespace) gutil.log(gutil.colors.red(`[component] ${name} requires a namespace to avoid collisions. Therefore adding a random namespace ${randomNamespace}`));

  return gulp.src(paths.blankTemplates)
    .pipe(template({
      name,
      namespace,
      upCaseName: cap(name),
      dashedName: camelCaseToDashed(name),
      displayName: capitalize(displayName),
    }))
    .pipe(rename(templatePath => {
      templatePath.basename = templatePath.basename.replace('temp', name);
    }))
    .pipe(gulp.dest(destPath));
});

gulp.task('default', ['serve']);
