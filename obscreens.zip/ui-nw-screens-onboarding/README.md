# Table of Contents

* [Walkthrough](#walkthrough)
    * [Build System](#build-system)
    * [Application Structure](#application-structure)
    * [Testing Setup](#testing-setup)
* [Getting Started](#getting-started)
    * [Dev setup](#dev-setup)
    * [Installing](#installing)
    * [Conventions](#Conventions)
    * [Running the App](#running-the-app)
        * [Gulp Tasks](#gulp-tasks)
        * [Testing](#testing)
		* [Generating Components](#generating-components)
    * [Dev workflow](#dev-workflow) 	
    * [Updating node dependencies](#updating-node-dependencies)	
	* [CI server](#ci-server) 	
* [Credits](#Credits)

# Walkthrough

## Build System

New world Components uses Gulp and Webpack together for its build system. Yes, you don't need Gulp if you're using Webpack. This is true if your build system is only responsible for file manipulation. However, ours is not.

`webpack` handles all file-related concerns:

* Transpiling from ES6 to ES5 with `babel`
* Loading HTML files as modules
* Transpiling stylesheets and appending them to the DOM
* Refreshing the browser and rebuilding on file changes
* Hot module replacement for transpiled stylesheets
* Bundling the app
* Loading all modules
* Doing all of the above for `*.spec.js` files as well

`gulp` is the orchestrator:

* Starting and calling Webpack
* Starting a development server (yes, Webpack can do this too)
* Generating boilerplate for the Angular app

## Application Structure

We use a componentized approach with `new world`. This will be the eventual standard (and particularly helpful, if using Angular's new router) as well as a great way to ensure a tasteful transition to Angular 2, when the time is ripe. Everything or mostly everything, as we'll explore (below) is a component. 

A component is a self-contained concern. It may be as small as a single feature or as large as a strictly-defined, ever present element of the UI (such as a header, sidebar, or footer). Also characteristic of a component is that it harnesses its own stylesheets, templates, controllers, routes, services, and specs. This encapsulation allows us the comfort of isolation and structural locality. 

Here's how it looks:

```
└─ src/app/
	   ├─ app.js # app entry file
	   ├─ app.html # app template
	   ├─ common/ # functionality pertinent to several components propagate into this directory
	   └─ components/ # where components live
	      ├─ components.js # components entry file
	      └─ home/ # home component
	         ├─ home.js # home entry file (routes, configurations, and declarations occur here)
	         ├─ home.component.js # home component definition
	         ├─ home.controller.js # home controller
	         ├─ home.service.js # home service
	         ├─ home.scss # home styles
	         ├─ home.html # home template
	         └─ home.spec.js # home specs (for entry, component, and controller)
```

More information about component design pattern can be found in following articles.

* [Angular component guide](https://docs.angularjs.org/guide/component)
* [Angular component style guide](https://github.com/toddmotto/angular-styleguide)
* [Component pattern for Angular 1.X](http://slides.com/tomastrajan/component-pattern-for-angular-js-1-x)

## Testing Setup

All tests are also written in ES6. We use Webpack to take care of the logistics of getting those files to run in the various browsers, just like with our client files. This is our testing stack:

* [Karma](https://karma-runner.github.io/1.0/index.html)
* [Mocha](https://mochajs.org/)
* [Chai BDD](http://chaijs.com/api/bdd/)
* [Webpack](https://webpack.github.io/)
* [Babel](https://babeljs.io/)

To run tests, type `npm run test` or `npm run test:watch` in the terminal. Read more about testing [below](#testing).

# Getting Started

## Dev setup

If you haven't setup any `new world` repos before you need to install `node 4.2.0` and several `global node_modules`. See instrcutions in [wiki page](http://dwgps0026/twiki/bin/view/NextGen/NewWorld_ReadMeDevSetup)

## Installing

* `checkout` this repo
* `npm run yarn` to install all project dependencies and update new-world dependencies to latest versions. You must run this command from project root

## Conventions

* [Angular style guide](https://github.com/toddmotto/angular-styleguide)
* [Airbnb style guide](https://github.com/airbnb/javascript)

Code will be tested aginst Airbnb style guide and will cause a build break if the code is not compliance with Airbnb rules.<br/> 
By running `npm run lint:fix` system will try to auto fix the issues. You can `run npm run lint` to make sure code is compliance with the rules. If you have any issues with linting we have documented a few issues that we came across in the [wiki page](http://dwgps0026/twiki/bin/view/NextGen/NewWorld_LintingTipsTricks)

## Running the App

* `New World` uses Gulp to build and launch the development environment. After you have installed all dependencies (`npm run yarn`), you may run the app. 
* `npm run dev` will bundle the app with `webpack`, launch a development server, and watch all files. The port will be displayed in the terminal.
* At the moment `new world` does not contain any mocks. Therefore you also need to run `grunt connect` or `grunt server-no-min` from [ui-framework-tools](https://stash.btfin.com/projects/PAN/repos/ui-framework-tools/browse) project
* You can access the new world application directly visiting the url: http://localhost:3000/#/app/onboarding/home
* Default API endpoint will be mock. To change the environment specify flag env `-- --env prod`. Available environment's are `jarvis, mock, local, dev1, dev2, dev3, dev4, uat1, uat2, sit1, sit3, demo, pilot and prod`. 
* If your environment is `jarvis` then you need to specify the endpoint as well. E.g.  `npm run dev -- --env jarvis --endpoint https://sup.jarvis.cloud.btfin-dev.com`
* To create a session with API endpoint, navigate to `#/login` and fill the form and submit it. 
 
### NPM run-script commands
```
$ npm run <cmd_from_list_below> [-- --<args>...]
```

```
dev                # Run the webpack-dev-server using gulp
dev:production     # Run the webpack-dev-server using gulp with production configuration

lint               # Run the linter in JS files
lint:fix           # Automatically fix some linting problems
lint:scss          # Run the linter in SCSS files

test               # Run unit tests once (to run in chrome, specify flag "--browsers Chrome")
test:watch         # Run and watch unit tests (to run in chrome, specify flag "--browsers Chrome")
test:coverage      # Run unit tests once and create coverage report (to generate lcov report only, specify flag "--lcovOnly")

pre-push           # Run quality gate checks before pushing
clean              # Clean the dist/, temp/, and coverage/, directories
build              # Build a development artifact to dist/
build:production   # Build a production artifact to dist/
sonar              # Analyzing the source with SonarQube Scanner and create a result report

yarn               # Install javascript dependencies (faster npm install)
yarn:after-add     # Clean internal dependencies from the yarn lock file

# Reserved for CI server
ci:sonar           # Analyzing the source with SonarQube Scanner and submits the results to Sonar server
ci:build           # Task run as part of the ci build process, analyse code for errors and run sonar
ci:publish         # Publish the artifacts to npm private repository
```
  
### Testing

To run the tests, run `npm run test` or you can run `npm run test:watch` so when the files get change test's will re-run.

`Karma` combined with Webpack runs all files matching `*.spec.js` inside the `src/app` folder. This allows us to keep test files local to the component--which keeps us in good faith with continuing to build our app modularly. The file `spec.bundle.js` is the bundle file for **all** our spec files that Karma will run.

Be sure to define your `*.spec.js` files within their corresponding component directory. You must name the spec file like so, `[name].spec.js`. `Mocha` is the testing suite and `Chai` is the assertion library. Further `Sinon` is the stub/mock library.

### Generating Components

Following a consistent directory structure between components offers us the certainty of predictability. We can take advantage of this certainty by creating a gulp task to automate the "instantiation" of our components. The component boilerplate task generates this:

```
└─ componentName/
   ├─ componentName.js # entry file where all its dependencies load
   ├─ componentName.component.js
   ├─ componentName.controller.js
   ├─ home.service.js # home service
   ├─ componentName.html
   ├─ componentName.scss # scoped to affect only its own template
   └─ componentName.spec.js  # contains passing demonstration tests
```

You may, of course, create these files manually, every time a new module is needed, but that gets quickly tedius.
To generate a component, run `gulp component --name componentName --namespace nw.namespace`.

The parameter following the `--name` flag is the name of the component to be created. Ensure that it is unique or it will overwrite the preexisting identically-named component. You need to specify a unique `--namespace` and format is `nw.module.submodule.*`

The component will be created, by default, inside `src/app/components`. To change this, apply the `--parent` flag, followed by a path relative to `src/app/components/`.

For example, running `gulp component --name signup --parent auth --namespace nw.namespace` will create a `signup` component at `src/app/components/auth/signup`.  

Running `gulp component --name footer --parent ../common --namespace nw.namespace` creates a `footer` component at `src/app/common/footer`.  

Because the argument to `--name` applies to the folder name **and** the actual component name, make sure to camelcase the component names.


### Dev workflow

By following the seven steps below, you will be able to deliver a feature without much of hassle.

* Make sure you have taken the latest code from remote
* Always create a new feature branch for your work. E.g. `US1021-dev`
* Run `npm run yarn` and this will ensure that your platform dependencies are up-to date
* Develop your new component using the scaffolding tool and this will ensure that across the platform we are following a same pattern
* `TDD` is easy with new world setup. All you need is, run `npm run test:watch` and tests will run when the source code updates
* Once you have developed the feature run `npm run lint:fix` and this will attempt to fix most of lint issues in your new code. Then you can run `npm run lint` and this will highlight any lint issues in your new code.
* To ensure code passes the tests, pre-configured linting rules and quality gates you should run `npm run pre-push` before pushing the code to `origin`

### Updating node dependencies

#### devDependencies

If you want to add/update devDependency you can run `yarn add **package** --dev` and this will install the devDependency and update the package.json.
Once the installation is completed you need to run `npm run yarn:after-add` and this will remove internal dependencies from the yarn lock file ensuring they are always up to date. 

#### dependencies

If you want to add/update dependency you can run `yarn add **package**` and this will install the dependency and update the package.json. 
Once the installation is completed you need to run `npm run yarn:after-add` and this will remove internal dependencies from the yarn lock file ensuring they are always up to date. 
Also you need to install the new dependency to `ui-nw-aggregator` as well.

### CI Server

After a successful build new world aggregator pipeline will be executed, producing the build artifacts. For this reason project dependencies <strong>should be in sync</strong> across the new world repos.

### Credits

this project scaffold using https://github.com/AngularClass/NG6-starter
