define(['MvcModel',
       'app/framework/services/dateService', 'underscore'],
    function (MvcModel, dateService, _) {
        'use strict';

        return MvcModel.extend({

            initialize: function () {
                this.set('sortBy', 'ascendingName');
            },

            init: function () {

                var closureDate = this.get('closureDate');
                var datedetail = this.get('datedetail');
                if (_.isDate(closureDate)) {
                    datedetail = closureDate;
                } else {
                    datedetail = dateService.today();
                }
                this.set('datedetail', datedetail);
            },

            dateMaxClosureValue: function (datedetail) {
                var closureDate = this.get('closureDate');
                if (!_.isUndefined(closureDate)) {
                    return datedetail <= closureDate;
                } else {
                    return true;
                }
            },

            dateMaxTodayValue: function (datedetail) {
                return datedetail <= dateService.today();
            },

            dateMinValue: function (datedetail) {
                var accountStartDate = this.get('migrationDate') || this.get('accountStartDate');
                if (_.isDate(accountStartDate) && _.isDate(datedetail)) {
                    return datedetail.dateOnly() >= accountStartDate.dateOnly();
                } else {
                    return true;
                }
            },

            validation: {
                'datedetail': {
                    priority: ['required', 'customFormat', 'customMinValue', 'customMaxClosureValue', 'customMaxTodayValue'],
                    blur: {
                        required: true,
                        customMaxClosureValue: 'dateMaxClosureValue',
                        customMaxTodayValue: 'dateMaxTodayValue',
                        customMinValue: 'dateMinValue'
                    },
                    submit: {
                        required: true
                    }
                }
            },

            dateDetailsDateString: function () {
                return dateService.formatDate(this.get('datedetail'), "YYYY-MM-dd");
            }
        });

    });
