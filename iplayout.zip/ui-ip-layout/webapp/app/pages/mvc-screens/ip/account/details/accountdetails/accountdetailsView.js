define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({

        hideContent: function () {
            this.$el.find('.js-screen-content').hide();
        }
    });
});
