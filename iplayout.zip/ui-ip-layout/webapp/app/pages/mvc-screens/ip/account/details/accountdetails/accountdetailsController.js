defineMvcController({
    name: 'accountdetails',
    parentPath: 'mvc-screens/ip/account/details',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'accountdetails',
    hashDefault: true,
    mvcComponents: ['tablev3'],
    screens: ['editdetails', 'clientdata', 'company', 'trust', 'smsf', 'superpensiondetails'],
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore', 'app/framework/services/Permissions']
}, function (config, MvcController, rootController, _, Permissions) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.report.view',
        targetId: 'a',
        requiredParams: ['a'],
        urlTemplate: '../api/accounts/v3_0/<%=a%>',
        INDIVIDUAL: 'individual',
        JOINT: 'joint',
        TRUST: 'trust',
        SMSF: 'smsf',
        SUPER: 'super',
        capitalGainTaxUrl: '../api/v1_0/static?category=capital_tax_tax',

        preRender: function () {
            var params = {};
            params.url = this.getUrl(rootController.getUrlParams(), this.urlTemplate);
            if (rootController.getUrlParams() && rootController.getUrlParams().a) {
                this.model.set('accountId', rootController.getUrlParams().a);
            }
            //Set the error message in prior so null message alert is not displayed
            this._setErrorMessage();
            params.success = _.bind(function (data) {
                if (data && data.data) {
                    data.data.accountantLearnMore = rootController.isIntermediary();
                    this.model.set('ajaxerrormessage', null);
                    this.model.formatData(data.data);
                    data.isSuperPensionAccount = this.checkAccountType(data.data);
                    this.model.set(data);
                }
            }, this);
            params.error = _.bind(function (jqXHR, textStatus, errorThrown) {
                this._setErrorMessage(errorThrown);
            }, this);
            this.model.deferred = this.ajaxGet(params);
            if (Permissions.ruleMatched('feature.global.gcmIntegration', '')) {
                this.model.set('companyTiltle', 'Corporate trustee');
            } else {
                this.model.set('companyTiltle', 'Company details');
            }
        },

        checkAccountType: function (account) {
            return account.accountType === 'SUPER' && account.superAccountSubType === 'pens';
        },

        _setErrorMessage: function (errorThrown) {
            if (errorThrown === 'timeout') {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0344'));
            }
        },

        postRender: function () {
            //if error, then display error message and hide the content
            if (this.model.get('ajaxerrormessage') !== null) {
                this.view.hideContent();
            } else {
                var modelData = this.model.get('data');
                if (modelData && modelData.accountType) {
                    var accountType = modelData.accountType.toLowerCase();
                    //Modifiying data and render children
                    this.modifyData(accountType, modelData);
                }
                if (this.model.get('data.linkedClients') !== null && !_.isUndefined(this.model.get('data.linkedClients')) && this.model.get('data.linkedClients').length > 0) {
                    if (this.children && this.children.clientdata) {
                        //Set Linked Clients data
                        this.children.clientdata.model.set('clientData', this.model.get('data.linkedClients'));
                        //Set Primary contact details
                        this.children.clientdata.model.set('primaryContactPerson', this.model.get('data.primaryContactPerson'));
                        this.children.clientdata.view.render();
                    }
                }
            }
            this._setDisclaimerMsg(this.model.get('data'));
        },

        _setDisclaimerMsg: function (account) {
            if (_.isObject(account) && account.accountType === 'SUPER') {
                if (account.superAccountSubType === 'pens') {
                    this.model.set('isAccountTypeSuperPension', true);
                } else {
                    this.model.set('isAccountTypeSuperAccumulation', true);
                }
            }
        },

        modifyData: function (accountType, modelData) {
            if (accountType === this.INDIVIDUAL || accountType === this.JOINT || accountType === this.SUPER) {
                if (this.children && this.children.clientdata) {
                    this.children.clientdata.model.set('accountType', accountType);
                    this.children.clientdata.model.set('clientData', modelData.owners);
                    //Set Primary contact details
                    this.children.clientdata.model.set('primaryContactPerson', this.model.get('data.primaryContactPerson'));
                    this.children.clientdata.view.render();
                }
            } else if (this.children[accountType]) {
                if (this.children[accountType].model.modifyModelData) {
                    this.children[accountType].model.modifyModelData(modelData);
                }
                //There is only single owner for LEGAL type accounts
                //So set the first item of owner data to the model
                this.children[accountType].model.set('data', modelData.owners[0]);
                this.children[accountType].view.render();
                //Render company information if the trustee data is available
                if (modelData.company) {
                    if (this.children && this.children.company) {
                        this.children.company.model.set('data', modelData.company);
                        this.children.company.view.render();
                    }
                }
                //Render beneficiaries information
                if (accountType === this.TRUST && this.children && this.children.beneficiaries) {
                    this.children.beneficiaries.setRows({
                        rowName: 'beneficiaries'
                    }, this.model.get('data'));
                    this.children.beneficiaries.renderComponentView();
                }

            }
        },

        openModal: function (paramName, paramValue, childName, listOfValues) {
            if (this.children && this.children.editdetails) {
                var modelData = {};
                modelData.editParam = paramName;
                modelData[paramName] = paramValue;
                modelData.childName = childName;
                modelData.lovs = listOfValues;
                modelData.modificationSeq = this.model.get('data.modificationSeq');
                this.children.editdetails.openModal(modelData);
            }
        },

        updateDetails: function (data, childName, paramName) {
            if (paramName === 'primaryContactPerson') {
                this.model.updatePrimaryContactPerson(data, childName);
            } else {
                this.model.set('data.cGTLMethodId', data.cGTLMethodId);
                this.model.set('data.cGTLMethod', data.cGTLMethod);
            }
            this.model.set('data.modificationSeq', data.modificationSeq);
            this.model.set('ajaxerrormessage', null);
            if (this.children && this.children.editdetails) {
                this.children.editdetails.closeModal();
            }
        },

        editTaxPreference: function () {
            var params = {};
            params.url = this.capitalGainTaxUrl;
            var CGTLMethodId = this.model.get('data').cGTLMethodId;
            if (!_.isNull(CGTLMethodId) && !_.isUndefined(CGTLMethodId)) {
                CGTLMethodId = CGTLMethodId.toLowerCase();
            }
            var capitalGainTax = 'capital_tax_tax';
            params.success = _.bind(function (data) {
                this.openModal('capitalGainTax', {
                    'CGTLMethodId': CGTLMethodId
                }, null, this._convertListOfValues({
                    'capitalGainTaxMethods': data.data.resultMap[capitalGainTax]
                }));
            }, this);
            params.error = _.bind(function (jqXHR, textStatus, errorThrown) {
                this._setErrorMessage(errorThrown);
            }, this);
            this.ajaxGet(params);
        },

        _convertListOfValues: function (data) {
            var convertedData = {};
            var row, obj;
            var convertedDataArray;
            for (var label in data) {
                convertedDataArray = [];
                obj = data[label];
                for (var j in obj) {
                    row = {};
                    row.label = obj[j].label;
                    row.value = obj[j].intlId.toLowerCase();
                    convertedDataArray.push(row);

                }
                convertedData[label] = convertedDataArray;
            }
            return convertedData;
        }
    });
});
