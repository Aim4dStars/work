define([
    'MvcView',
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        hideBeneficiariesLastUpdated: function () {
            this.$el.find('.js-beneficiaries-last-updated').hide();
        },

        showBeneficiariesLastUpdated: function () {
            this.$el.find('.js-beneficiaries-last-updated').show();
        },

        rootTemplate: {
            headerDownload: {
                items: [{
                    'label': 'PDF',
                    'action': 'buildPdfLink'
                }]
            }
        },

        hideSecondarynominationsTableHeader: function (table) {
            table.view.$el.find('.data-table-default>thead>tr').hide();
        },

        hideTableCaption: function () {
            this.$el.find('[data-component-name="secondarynominations"] tbody[aria-hidden=true]').hide();
        }
    });
});
