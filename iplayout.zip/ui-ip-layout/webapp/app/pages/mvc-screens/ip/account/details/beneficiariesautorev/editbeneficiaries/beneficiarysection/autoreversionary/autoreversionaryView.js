define([
    'app/pages/mvc-templates/modal/modalView'

], function (ModalView) {
    'use strict';

    return ModalView.extend({

        events: {
            'click .modal-close': 'cancelRequest',
        },

        cancelRequest: function () {
            this.controller.cancel();
        },

        showDeleting: function () {
            //show the spinner on the button
            this.controller.viewChildren.button.loading(true);
        }
    });
});
