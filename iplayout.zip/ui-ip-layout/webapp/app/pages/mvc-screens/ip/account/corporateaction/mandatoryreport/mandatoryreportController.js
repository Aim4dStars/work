defineMvcController({
    name: 'mandatoryreport',
    parentPath: 'mvc-screens/ip/account/corporateaction',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    viewComponents: ['button', 'icon'],
    mvcComponents: ['tablev3'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/mandatoryreport/mandatoryreportController'
}, function (config, MandatoryReportController) {
    'use strict';
    return MandatoryReportController.extend({
        config: config
    });

});
