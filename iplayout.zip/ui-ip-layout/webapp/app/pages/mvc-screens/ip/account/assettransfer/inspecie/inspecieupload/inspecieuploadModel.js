define(['MvcModel', 'underscore'],
    function (MvcModel, _) {
        'use strict';

        return MvcModel.extend({

            validation: {
                sponsorselector: {
                    blur: {
                        customRequired: function (value, fieldName) {
                            var sponsorselector = this.get(fieldName);
                            if (_.isObject(sponsorselector)) {
                                sponsorselector = sponsorselector.sponsorname;
                            }

                            var controller = this.controller;
                            if (controller.name !== 'inspecieupload') {
                                controller = this.controller.parentController;
                            }

                            var chessSponsors = controller.model.get('chessSponsors');
                            var found = _.find(chessSponsors, function (chessSponsor) {
                                return chessSponsor.sponsorname === sponsorselector;
                            });

                            return !_.isEmpty(found);
                        }
                    }
                },
                tailoredportfolios: {
                    blur: {
                        required: true
                    }
                },
                managedportfolios: {
                    blur: {
                        required: true
                    }
                },
                sourceFilter: {
                    submit: {
                        required: true
                    }
                },
                transferInto: {
                    submit: {
                        required: true
                    }
                },
                cbo: {
                    submit: {
                        required: true
                    }
                },
                listedSecurityAssetSource: {
                    submit: {
                        required: true
                    }
                },
                managedFundAssetSource: {
                    submit: {
                        required: true
                    }
                },
                otherAssetSource: {
                    submit: {
                        required: true
                    }
                },
            },

            getAssetSource: function () {
                var assetSource;
                var sourceFilter = this.get('sourceFilter');

                if (sourceFilter === 'listedSecurities') {
                    assetSource = this.get('listedSecurityAssetSource');
                } else if (sourceFilter === 'managedFunds') {
                    assetSource = this.get('managedFundAssetSource');
                } else if (sourceFilter === 'listedSecuritiesAndManagedFunds') {
                    assetSource = this.get('otherAssetSource');
                }
                return assetSource;
            },

            getAssetSourceForManualEntry: function () {
                var assetSource;
                var sourceFilter = this.get('sourceFilter');

                if (sourceFilter === 'listedSecurities') {
                    assetSource = this.get('listedSecurityAssetSource');
                    if (assetSource === 'assetsFromOtherPlatform') {
                        assetSource = 'listedSecurityChessSponsored';
                    }
                } else if (sourceFilter === 'managedFunds') {
                    assetSource = this.get('managedFundAssetSource');
                    if (assetSource === 'assetsFromOtherPlatform') {
                        assetSource = 'managedFunds';
                    }
                } else if (sourceFilter === 'listedSecuritiesAndManagedFunds') {
                    assetSource = this.get('otherAssetSource');
                }
                return assetSource;
            },

            getSponsorSelector: function () {
                var sponsorSelector = {};
                var sourceFilter = this.get('sourceFilter');
                var assetSource = this.getAssetSource();

                if (sourceFilter === 'listedSecurities') {
                    if (assetSource === 'listedSecurityChessSponsored') {
                        sponsorSelector = this.get('sponsorselector');
                    } else if (assetSource === 'assetsFromOtherPlatform') {
                        sponsorSelector = this.get('lssponsorselector');
                    }
                } else if (sourceFilter === 'listedSecuritiesAndManagedFunds') {
                    if (assetSource === 'assetsFromOtherPlatform') {
                        sponsorSelector = this.get('othersponsorselector');
                    }
                }
                return sponsorSelector;
            }
        });
    });
