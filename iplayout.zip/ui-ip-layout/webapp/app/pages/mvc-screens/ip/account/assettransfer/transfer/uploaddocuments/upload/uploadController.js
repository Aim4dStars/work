defineMvcController({
    name: 'upload',
    parentPath: 'mvc-screens/ip/account/assettransfer/transfer/uploaddocuments',
    viewHtml: true,
    viewJs: true,
    hashName: 'upload',
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    viewComponents: ['icon'],
    dependencies: ['jquery', 'underscore', 'rootController']
}, function (config, ModalController, $, _, rootController) {
    'use strict';

    return ModalController.extend({
        config: config,
        loading: false,
        requiredParams: ['a'],
        urlUploadTaxParcel: '../api/inspecietransfer/v2_0/accounts/<%=a%>/inspecie-transfer/<%=t%>/uploadTaxParcels',

        postRender: function () {
            var type = this.model.get('modal');
            if (type === 'upload') {
                if (window.FormData) {
                    this.view.hideFileUpload();
                } else {
                    this.view.showFileUpload();
                }
                this.view.showUploadModal();
            } else {
                this.view.showErrorModal();
            }
        },

        onBeforeCloseModal: function () {
            var $file = this.parentController.view.getModelUpload();
            $file.replaceWith($file = $file.clone(true));
            return true;
        },


        submit: function () {
            var params = {};
            var files = this.parentController.view.getModelUpload().get(0).files;
            if (window.FormData && _.isObject(files) && files.length !== 0) {
                var file = files[0];
                var attrs = {
                    "a": rootController.getUrlParams().a,
                    "t": this.model.get('transferId')
                };
                params.url = this.getUrl(attrs, this.urlUploadTaxParcel);
                var formData = new FormData();
                formData.append('upload-file', file);
                params.data = formData;
                params.processData = false;
                params.contentType = false;
                params.success = _.bind(function (data) {
                    var errors = data.data.warnings;
                    this.view.hideSpinner();
                    if (!_.isUndefined(errors) && errors.length > 0) {
                        this.parentController.model.set('errors', errors);
                        this.parentController.model.set('errorlength', errors.length);
                        this._handleSubmissionError(errors);
                    } else {
                        this._handleSubmissionSuccess(data);
                    }
                }, this);
                params.error = _.bind(function () {
                    this.view.hideSpinner();
                    rootController.model.set('ajax.error', true);
                    this.parentController.parentController.parentController.parentController.parentController.toggleAjaxError();
                    this.closeModal();
                }, this);

                this.view.showSpinner();
                this.ajaxPost(params);
            }
        },

        _handleSubmissionSuccess: function () {
            this.parentController.showSuccessMessage();
            this.closeModal();
        },

        _handleSubmissionError: function () {
            this.parentController.view.showFailureMessage();
            this.closeModal();
        }
    });
});
