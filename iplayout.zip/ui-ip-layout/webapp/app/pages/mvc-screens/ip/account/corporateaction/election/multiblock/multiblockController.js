defineMvcController({
    name: 'multiblock',
    parentPath: 'mvc-screens/ip/account/corporateaction/election',
    viewHtml: true,
    modelJs: false,
    viewJs: true,
    viewComponents: ['inputselect'],
    screens: [],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/multiblock/multiblockController'
}, function (config, MultiblockController) {
    'use strict';

    return MultiblockController.extend({
        config: config
    });
});
