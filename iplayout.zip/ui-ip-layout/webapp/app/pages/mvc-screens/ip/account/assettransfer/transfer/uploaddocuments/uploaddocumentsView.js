define([
    'MvcView',
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        showSuccessMessage: function () {
            this.$el.find('.successMessage').show();
            this.$el.find('.failureMessage').hide();
        },
        showFailureMessage: function () {
            this.$el.find('.failureMessage').show();
            this.$el.find('.successMessage').hide();
        },

        clickModelUpload: function () {
            this.$el.find('input[name=modelupload]').click();
        },

        getModelUpload: function () {
            var $file = this.$el.find('input[name=modelupload]');
            return $file;
        }
    });
});
