defineMvcController({
    name: 'slidingscalefee',
    parentPath: 'mvc-screens/ip/account/fees/manage/details/advicefee',
    viewHtml: true,
    modelJs: true,
    viewJs: true,
    viewComponents: ['fieldset'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        maxRows: 10,
        newTier: {
            lowerBound: '',
            upperBound: '',
            percentage: '',
            type: 'SlidingScaleFeeTier'
        },

        preRender: function () {
            this._setModelData();
            this._setModelBindings();
            this._addModelListeners();
        },

        postRender: function () {
            this._bindData();
        },

        _addModelListeners: function () {
            this.model.on('change:data', this._bindData, this);
        },

        _bindData: function () {
            this.model.setTierValidation();
            var data = this.model.get('data');
            var name = this.model.get('name');
            this.model.set(name + 'dispLowerBound0', 0);
            for (var i = 1; i < data.length; i++) {
                this.model.set(name + 'lowerBound' + i, this.model.get(name + 'upperBound' + (i - 1)));
                if (this.model.get(name + 'upperBound' + (i - 1)) !== "") {
                    this.model.set(name + 'dispLowerBound' + i, this.model.formatValue(this.model.get(name + 'upperBound' + (i - 1))));
                }
            }
            this.model.set('rows', data.length - 1);
        },

        _setModelData: function () {
            var data = this.parentController.model.get('data');
            if (data && data.feesComponent) {
                var name = this.parentController.model.get('name');
                var feesComponent = data.feesComponent;
                for (var j in feesComponent) {
                    if (feesComponent[j].type === 'SlidingScaleFee') {
                        var slidingscaleComponent = feesComponent[j];
                        var tiers = slidingscaleComponent.slidingScaleFeeTier;
                        this.model.set('name', name);
                        this.model.set(name + 'managedportfolios', slidingscaleComponent.managedPortfolio);
                        this.model.set(name + 'listedsecurities', slidingscaleComponent.share);
                        this.model.set(name + 'managedfunds', slidingscaleComponent.managedFund);
                        this.model.set(name + 'termdeposits', slidingscaleComponent.termDeposit);
                        this.model.set(name + 'cash', slidingscaleComponent.cash);
                        this.model.set('data', tiers);
                        this.model.set('rows', tiers.length - 1);
                    }
                }
            }
        },

        _setModelBindings: function () {
            for (var i = 0; i < this.maxRows; i++) {
                this.model.bindAttributeToOtherModel('data.' + i + '.lowerBound', this.model.get('name') + 'lowerBound' + i, this.model);
                this.model.bindAttributeToOtherModel('data.' + i + '.upperBound', this.model.get('name') + 'upperBound' + i, this.model);
                this.model.bindAttributeToOtherModel('data.' + i + '.percentage', this.model.get('name') + 'percentage' + i, this.model);
                this.model.updateValidation(i);
            }
            this.model.setTierValidation();

        },

        addRow: function (event) {
            var name = this.model.get('name');
            var rowIndex = parseFloat(event.currentTarget.name.replace(name + 'upperBound', ''));
            var lastRow = this.model.get('data').length - 1;
            var currentValue = Number(event.currentTarget.value);

            if (rowIndex === lastRow && (currentValue > this.model.get('data')[lastRow - 1].upperBound)) {
                this.newTier.lowerBound = currentValue;
                var data = this.model.get('data');
                data.push(this.newTier);
                // this.model.unset('data');
                this.model.set('data', data);
                this.view.render();
            }
        },

        deleteRow: function (event) {
            var data = this.model.get('data');

            var currentRowIndex = Number(event.currentTarget.parentElement.getAttribute('data-index'));

            if (currentRowIndex !== data.length - 1) {
                data[currentRowIndex + 1].lowerBound = data[currentRowIndex].lowerBound;
                data[currentRowIndex + 1].percentage = data[currentRowIndex].percentage;
            } else {
                data[currentRowIndex - 1].upperBound = null;
            }

            data.splice(currentRowIndex, 1);
            // this.model.unset('data');
            this.model.set('data', data);
            this.view.render();
        },

        getValues: function () {
            var name = this.parentController.model.get('name');
            var valid = false;
            var listedSecurities = this.model.get(name + 'listedsecurities');
            var managedFunds = this.model.get(name + 'managedfunds');
            var managedPortfolios = this.model.get(name + 'managedportfolios');
            var termDeposits = this.model.get(name + 'termdeposits');
            var cash = this.model.get(name + 'cash');
            if (this.validateAndSubmitForm(this.view.getSubmitEvent()) && this.model.validateForm(listedSecurities, managedFunds, managedPortfolios, termDeposits, cash)) {
                valid = true;
            }

            return {
                valid: valid,
                value: {
                    share: listedSecurities,
                    managedFund: managedFunds,
                    managedPortfolio: managedPortfolios,
                    cash: cash,
                    termDeposit: termDeposits,
                    slidingScaleFeeTier: this._getTierData(),
                    type: 'SlidingScaleFee',
                    label: 'Sliding scale fee component'
                }
            };
        },

        _getTierData: function () {
            var data = this.model.get('data');
            if (data) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].percentage === '') {
                        data[i].percentage = 0;
                    }
                }
                return data;
            }

        },

        deleteChildCell: function () {
            this.parentController.deleteChildCell(this.name);
        },

        validateCheckbox: function (event) {
            this.model._validateCheckboxes(event);
        },

        hidePercentageError: function () {
            this.view.hidePercentageError();
        },

        showPercentageError: function () {
            this.view.showPercentageError();
        },

        showCheckboxError: function () {
            this.view.showCheckboxError();
        },

        hideCheckboxError: function () {
            this.view.hideCheckboxError();
        }
    });
});
