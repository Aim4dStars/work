defineMvcController({
    name: 'inspecie',
    parentPath: 'mvc-screens/ip/account/assettransfer',
    hashName: 'inspecie',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    extend: 'MvcController',
    viewComponents: ['trainstop', 'inputradios', 'forminputautocomplete', 'button', 'tooltip', 'inputselect', 'messagealert'],
    screens: ['inspecieupload', 'transferform', 'providedocuments'],
    mvcComponents: ['inputautocomplete'],
    dependencies: ['app/framework/services/Permissions', 'rootController', 'app/framework/services/analyticsService']
}, function (config, MvcController, Permissions, rootController, analyticsService) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        hasPermission: 'account.transfer.inspecie.view',

        preRender: function () {
            var assettransferHelpUrl = this.getAssetTransferSupportUrl();
            this.model.set('assettransferHelpUrl', assettransferHelpUrl);
        },

        postRender: function () {
            var canViewSummaryBar = Permissions.ruleMatched('account.summary.bar.view', rootController.getUrlParams().a);
            if (!canViewSummaryBar) {
                return;
            }
            analyticsService.send({
                "pageName": "ng:account:assettransfer:inspecie",
                "pageType": "selfservice",
                "formName": "inspecie transfer",
                "pageStep": "start",
                "trackDedupe": true
            });
        },

        getAssetTransferSupportUrl: function () {
            if (Permissions.ruleMatched('feature.global.aemEnabled')) {
                if (Permissions.ruleMatched('account.asim.view', rootController.getUrlParams().a)) {
                    return rootController.getAsimBasePageUrl() + '/your-account/reports-and-transactions/asset-transfer.html';
                } else {
                    var path = '/content/secure/help-and-support/bt/en/' + rootController.getStaticPageRole() + '/clients/reports-and-transactions/asset-transfer.html';
                    return rootController.getCmsHost() + path;
                }
            } else {
                return '/ng/public/content/helpandsupport/static-templates/' + rootController.getStaticPageRole() + '/asset-transfer.html';
            }
        },

        openAssetTransferSupport: function () {
            var assettransferHelpUrl = this.model.get('assettransferHelpUrl');
            window.open(assettransferHelpUrl, 'Asset Transfer');
        },

    });

});
