define([
    'app/pages/mvc-templates/modal/modalView',
    'jquery',
    'underscore'
], function (ModalView, $, _) {
    'use strict';

    return ModalView.extend({
        showErrors: function (errors) {
            var $errorMessage = this.$el.find('.error-list [data-view-component="messagealert"]').remove();
            var $errorList = this.$el.find('.error-list');
            _.each(errors, function (error) {
                var $newErrorMessage = $errorMessage.clone();
                $newErrorMessage.find('.error-message-content').html(error.message);
                $newErrorMessage.appendTo($errorList);
            });
        },

        showWarnings: function (warnings) {
            var $warningMessage = this.$el.find('.warnings [data-view-component="messagealert"]').remove();
            var $warningList = this.$el.find('.warnings');
            _.each(warnings, function (warning) {
                var $newWarningMessage = $warningMessage.clone();
                $newWarningMessage.find('.warning-message-content').html(warning.message);
                $newWarningMessage.appendTo($warningList);
            });
        }
    });

});
