define([
    'MvcView',
    'jquery',
    'underscore'
], function (MvcView, $, _) {
    'use strict';

    return MvcView.extend({

        closeMenuAction: function () {
            $(document).trigger('click.closeOtherMenu');
        },

        getTargetRow: function (transferId) {
            var $messageAlert = this.$el.find("[data-id=" + transferId + "]");
            var $subTable = $messageAlert.closest('tr');
            var $parentTable = $($subTable[0]).prev(".expandable-row:visible");
            if (_.size($parentTable) === 0) {
                return;
            }
            return $parentTable[0];
        },

        isRowClosed: function (transferId) {
            var $messageAlert = this.$el.find("[data-id=" + transferId + "]");
            var $subTable = $messageAlert.closest('tr');
            return $($subTable[0]).is(':hidden');
        },

        showErrorMessage: function (transferId, errorlength) {
            var $errorAlert = this.$el.find(".error-message[data-id=" + transferId + "]");
            var $successAlert = this.$el.find(".success-message[data-id=" + transferId + "]");
            $errorAlert.show();
            $successAlert.hide();
            $errorAlert.find("[data-name=errorlength]").html(errorlength);
            $errorAlert.find('.view-errors').off('click');
        },

        showSuccessMessage: function (transferId) {
            var $errorAlert = this.$el.find(".error-message[data-id=" + transferId + "]");
            var $successAlert = this.$el.find(".success-message[data-id=" + transferId + "]");
            $errorAlert.hide();
            $successAlert.show();
        },

        hideErrorMessage: function (transferId) {
            var $messageAlert = this.$el.find("[data-id=" + transferId + "]");
            $messageAlert.hide();
        },

        getTransferId: function (ev) {
            var target = ev.target;
            var $parent = $(target).closest('[data-view-component="messagealert"]');
            var transferId = $parent.data('id');
            return transferId;
        }
    });
});
