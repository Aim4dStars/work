define([
    'MvcView',
    'jquery'
], function (MvcView, $) {
    'use strict';

    return MvcView.extend({
        transferIntoOptions: [
            {
                value: 'directHolding',
                label: 'Direct holding in this Panorama account'
            }, {
                value: 'managedPortfolio',
                label: 'Managed portfolio in this Panorama account'
            }
        ],
        hidePrimaryBoxArrow: function () {
            this.$el.find('.asset-section .box-primary').removeClass('linked');
        },

        showPrimaryBoxArrow: function () {
            this.$el.find('.asset-section .box-primary').addClass('linked');
        },

        getForm: function () {
            return this.$el.find('form');
        },

        showAssetSource: function (sourceFilter) {
            this.$el.find('.js-listed-security-asset-source').hide();
            this.$el.find('.js-managed-fund-asset-source').hide();
            this.$el.find('.js-other-asset-source').hide();

            if (sourceFilter === 'listedSecurities') {
                this.$el.find('.js-listed-security-asset-source').show();
            } else if (sourceFilter === 'managedFunds') {
                this.$el.find('.js-managed-fund-asset-source').show();
            } else if (sourceFilter === 'listedSecuritiesAndManagedFunds') {
                this.$el.find('.js-other-asset-source').show();
            }
        },

        resetAssetSourceView: function () {
            $('.view-lsassetsource li label').removeClass('selected');
            $('[name=listedSecurityAssetSource]').prop('checked', false);

            $('.view-mfassetsource li label').removeClass('selected');
            $('[name=managedFundAssetSource]').prop('checked', false);

            $('.view-otherassetsource li label').removeClass('selected');
            $('[name=otherAssetSource]').prop('checked', false);
        }
    });
});
