define([
    'MvcModel',
    'app/framework/helpers/format',
    'jquery',
    'underscore'
], function (MvcModel, format, $, _) {
    'use strict';

    return MvcModel.extend({
        settingsInformation: null,
        primaryContactPerson: null,
        SHAREHOLDER: 'Shareholder',
        dataFeedMap: {
            manual: 'No software connected.',
            received: ' feed connected',
            stop: ' feed has been stopped',
            awaiting: ' data feed activation has been requested'
        },

        formatData: function (data) {
            this._formatOwnerInfo(data);
            this._formatAdviserInfo(data);
            this._formatAccountantInfo(data);
            data.primaryContactPerson = this.primaryContactPerson;
            if (data.bsb !== null) {
                data.bsb = format.formatBSB(data.bsb);
            }
        },

        _formatOwnerInfo: function (data) {
            var linkedClients = [];
            var beneficiaries = [];
            this.settingsInformation = data.settings;
            for (var i in data.owners) {
                this._formatEmail(data.owners[i]);
                this._formatPhones(data.owners[i]);
                this._formatAddressList(data.owners[i]);

                //Linked Clients - NOT available for individual/joint account type
                if (data.owners[i].linkedClients) {
                    linkedClients = linkedClients.concat(this._formatLinkedClient(data.owners[i].linkedClients));
                }

                //Beneficiaries - Available for Trust account type
                if (data.owners[i].beneficiaries) {
                    beneficiaries = beneficiaries.concat(this._formatBeneficiaries(data.owners[i].beneficiaries));
                }

                //Set Trustee Information
                if (data.owners[i].company) {
                    data.company = this._formTrusteeData(data.owners[i].company);
                }

                this._modifyTaxOption(data.owners[i]);
                this._formatBusinessData(data.owners[i]);
                this._formatGST(data.owners[i]);
                this._formatTrustData(data.owners[i]);
                this._formatPersonAssociation(data.owners[i]);
                //nullify this value because it is not required for an owner, this information is required only for linked clients
                data.owners[i].personAssociation = null;
            }
            data.linkedClients = linkedClients;
            data.beneficiaries = beneficiaries;
            data.primaryContact = this.primaryContact;
        },

        _formTrusteeData: function (trusteeInfo) {
            this._modifyTaxOption(trusteeInfo);
            this._formatGST(trusteeInfo);
            this._formatBusinessData(trusteeInfo);
            this._formatAddressList(trusteeInfo);
            return trusteeInfo;
        },

        _formatLinkedClient: function (linkedClients) {
            var formattedLinkedClients = [];
            _.each(linkedClients, function (linkedClient) {
                this._formatPersonAssociation(linkedClient);
                //if the client has only Shareholder as a role, do not add the client to the linked client list
                if (!linkedClient.isShareholder) {
                    this._formatEmail(linkedClient);
                    this._formatPhones(linkedClient);
                    this._formatAddressList(linkedClient);
                    formattedLinkedClients.push(linkedClient);
                }
            }, this);
            return formattedLinkedClients;
        },

        _formatBeneficiaries: function (beneficiaries) {
            var beneficiaryList = [];
            for (var i in beneficiaries) {
                var beneficiary = beneficiaries[i];
                beneficiary.beneficiaryName = beneficiaries[i].title + ' ' + beneficiaries[i].firstName + ' ' + beneficiaries[i].lastName;
                beneficiary.beneficiaryAddresses = this._formatAddress(beneficiaries[i].addresses[0]);
                beneficiaryList.push(beneficiary);
            }
            return beneficiaryList;
        },

        _formatPersonAssociation: function (client) {
            var isShareholder;
            //Person roles, primary contact person is stored in settings
            for (var i in this.settingsInformation) {
                if (this.settingsInformation[i].clientKey.clientId === client.key.clientId) {
                    //Person association
                    var personRolesFinal = [];
                    if (this.settingsInformation[i].personRoles !== null) {
                        var personRoles = this.settingsInformation[i].personRoles;
                        isShareholder = true;
                        for (var j in personRoles) {
                            if (personRoles[j] !== this.SHAREHOLDER) {
                                personRolesFinal.push(personRoles[j]);
                                isShareholder = false;
                            }
                        }
                    }
                    client.personAssociation = personRolesFinal.join(', ');
                    client.personAssociation = $.trim(client.personAssociation);
                    if (this.settingsInformation[i].approver === true) {
                        //Append account approver text
                        if (client.personAssociation === '') {
                            client.personAssociation = "Account approver";
                        } else {
                            client.personAssociation = client.personAssociation + " and account approver";
                        }
                    }

                    client.isShareholder = isShareholder;
                    //Payment settings
                    client.paymentSetting = this.settingsInformation[i].permissions;
                    //Primary contact
                    if (this.settingsInformation[i].primaryContactPerson === true) {
                        client.primaryContactPerson = this.settingsInformation[i].primaryContactPerson;
                        this.primaryContact = client;
                        this.primaryContactPerson = client.title + " " + client.firstName + " " + client.lastName;
                    }
                    return;
                }
            }
        },

        _formatAdviserInfo: function (data) {
            if (data.adviser) {
                for (var i in data.settings) {
                    if (data.settings[i].adviser === true) {
                        data.adviser.permissions = this.settingsInformation[i].permissions;
                        return;
                    }
                }
            }
        },

        _formatAccountantInfo: function (data) {
            if (data.accountant) {
                if (data.accountant.externalAssetsFeedState === 'manual') {
                    data.accountant.accountingSoftware = this.dataFeedMap[data.accountant.externalAssetsFeedState];
                } else if (data.accountant.accountingSoftware) {
                    data.accountant.accountingSoftware = data.accountant.accountingSoftware.toLowerCase().toTitleCase() + this.dataFeedMap[data.accountant.externalAssetsFeedState];
                }
            }
        },

        _modifyTaxOption: function (data) {
            if (data.tfnProvided) {
                data.taxOptionReason = "Tax file number provided";
            } else if (data.exemptionReason === 'No exemption') {
                data.taxOptionReason = "Tax file number or exemption not provided";
            } else {
                data.taxOptionReason = "Exemption reason provided";
            }
        },

        _formatBusinessData: function (data) {
            if (data.acn !== null) {
                data.acn = format.formatACN(data.acn);
            }
            if (data.arsn !== null) {
                data.arsn = format.formatARSN(data.arsn);
            }
            if (data.abn !== null) {
                data.abn = format.formatABN(data.abn);
            }
        },

        _formatTrustData: function (data) {
            if (data.trustType !== null && !_.isUndefined(data.trustType)) {
                if (data.trustType.toLowerCase() !== 'government super fund') {
                    data.legEstFund = null;
                }
                if (data.trustType.toLowerCase() !== 'regulated trust') {
                    data.trustReguName = null;
                }
            }
        },

        _formatGST: function (data) {
            data.registrationForGstDisplay = "No";
            if (data.registrationForGst) {
                data.registrationForGstDisplay = "Yes";
            }
        },

        _formatAddressList: function (clientData) {
            var formattedAddress;
            for (var j in clientData.addresses) {
                formattedAddress = this._formatAddress(clientData.addresses[j]);
                if (clientData.addresses[j].domicile) {
                    clientData.residentialAddress = formattedAddress;
                    clientData.businessAddress = formattedAddress;
                }
                if (clientData.addresses[j].mailingAddress) {
                    clientData.postalAddress = formattedAddress;
                    clientData.registeredAddress = formattedAddress;
                }
            }
        },

        _formatAddress: function (address) {
            var formattedAddress = null;
            var addressLine1 = $.trim(this._setAddressLine1(address));
            var addressLine2 = $.trim(this._setAddressLine2(address));
            formattedAddress = $.trim(addressLine1 + ' ' + addressLine2) + ', ';

            if (address.suburb) {
                formattedAddress = formattedAddress + address.suburb + ', ';
            }

            if (address.country === 'Australia' && address.stateAbbr) {
                formattedAddress = formattedAddress + address.stateAbbr + ' ';
            } else if (address.state) {
                formattedAddress = formattedAddress + address.state + ' ';
            }

            if (address.postcode) {
                formattedAddress = formattedAddress + address.postcode + ', ';
            }

            if (address.country !== 'Australia') {
                formattedAddress = formattedAddress + address.country;
            }

            formattedAddress = $.trim(formattedAddress);

            //Removes the last comma if exists
            return formattedAddress.replace(/,$/, "");
        },

        _setAddressLine2: function (address) {
            var addressLine = "";
            if (address.unitNumber !== null) {
                addressLine = addressLine + address.unitNumber + '/';
            }
            if (address.streetNumber !== null) {
                addressLine = addressLine + address.streetNumber + ' ';
            }
            if (address.poBox !== null && address.poBoxPrefix !== null) {
                addressLine = addressLine + address.poBoxPrefix + ' ' + address.poBox + ' ';
            } else if (address.streetName !== null) {
                addressLine = addressLine + address.streetName + ' ';
            }
            if (address.streetType !== null) {
                addressLine = addressLine + address.streetType + ' ';
            }
            return addressLine;
        },

        _setAddressLine1: function (address) {
            var addressLine = "";
            if (address.building !== null) {
                addressLine = addressLine + address.building + ', ';
            }
            if (address.floor !== null) {
                addressLine = addressLine + 'Level ' + address.floor + ', ';
            }
            return addressLine;
        },

        _formatEmail: function (data) {
            if (!data) {
                return;
            }

            // emailList arrays have different name for adviser and investor
            var emailList = data.emails ? data.emails : data.email ? data.email : null;
            if (emailList) {
                var primaryEmail = null;
                var secondaryEmail = null;
                for (var i in emailList) {
                    if (emailList[i].email !== '') {
                        if (emailList[i].emailType === 'Primary') {
                            primaryEmail = {};
                            primaryEmail.email = emailList[i].email;
                            primaryEmail.preferred = emailList[i].preferred;
                            primaryEmail.modificationSeq = emailList[i].modificationSeq;
                            primaryEmail.emailKey = emailList[i].emailKey;
                            data.primaryEmail = primaryEmail;
                        } else {
                            secondaryEmail = {};
                            secondaryEmail.email = emailList[i].email;
                            secondaryEmail.preferred = emailList[i].preferred;
                            secondaryEmail.modificationSeq = emailList[i].modificationSeq;
                            secondaryEmail.emailKey = emailList[i].emailKey;
                            data.secondaryEmail = secondaryEmail;
                        }
                    }
                }
            }
        },

        _formatPhones: function (data) {
            if (!data) {
                return;
            }

            // phoneList arrays have different name for adviser and investor
            var phoneList = data.phones ? data.phones : data.phone ? data.phone : null;
            if (phoneList) {
                var primaryMobile = null;
                var secondaryMobile = null;
                var homeTelephone = null;
                var workTelephone = null;
                for (var i in phoneList) {
                    if (phoneList[i].phoneType === 'Primary') {
                        primaryMobile = {};
                        //no need to format the number, since it not updated dynamically
                        primaryMobile.number = phoneList[i].number;
                        primaryMobile.preferred = phoneList[i].preferred;
                        primaryMobile.modificationSeq = phoneList[i].modificationSeq;
                        primaryMobile.phoneKey = phoneList[i].phoneKey;
                        data.primaryMobile = primaryMobile;
                    } else if (phoneList[i].phoneType === 'Secondary') {
                        secondaryMobile = {};
                        secondaryMobile.number = phoneList[i].number;
                        secondaryMobile.preferred = phoneList[i].preferred;
                        secondaryMobile.modificationSeq = phoneList[i].modificationSeq;
                        secondaryMobile.phoneKey = phoneList[i].phoneKey;
                        data.secondaryMobile = secondaryMobile;
                    } else if (phoneList[i].phoneType === 'Home') {
                        homeTelephone = {};
                        homeTelephone.number = phoneList[i].number;
                        homeTelephone.preferred = phoneList[i].preferred;
                        homeTelephone.modificationSeq = phoneList[i].modificationSeq;
                        homeTelephone.phoneKey = phoneList[i].phoneKey;
                        data.homeTelephone = homeTelephone;
                    } else if (phoneList[i].phoneType === 'Work') {
                        workTelephone = {};
                        workTelephone.number = phoneList[i].number;
                        workTelephone.preferred = phoneList[i].preferred;
                        workTelephone.modificationSeq = phoneList[i].modificationSeq;
                        workTelephone.phoneKey = phoneList[i].phoneKey;
                        data.workTelephone = workTelephone;
                    }
                }
            }
        },

        updatePrimaryContactPerson: function (data, childName) {
            if (this.controller && this.controller.children && this.controller.children[childName]) {
                var clients = this.controller.children[childName].model.get('clientData');
                for (var i in clients) {
                    if (clients[i].key.clientId === data.primaryContact.key.clientId) {
                        clients[i].primaryContactPerson = true;
                        var primaryContactPersonName = clients[i].title + " " + clients[i].firstName + " " + clients[i].lastName;
                        this.controller.children[childName].model.set('primaryContactPerson', primaryContactPersonName);
                    } else {
                        clients[i].primaryContactPerson = false;
                    }
                }
            }
        }
    });

});
