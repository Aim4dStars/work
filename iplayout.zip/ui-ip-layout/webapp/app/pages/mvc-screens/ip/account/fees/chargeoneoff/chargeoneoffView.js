define([
    'MvcView',
], function (MvcView) {
    'use strict';

    return MvcView.extend({

        rootTemplate: {
            headerPanel: 'Fees',
            headerPrint: false,
            headerDownload: false,
            menuTabs: []
        },

        clearError: function () {
            this.$el.find('.view-messagealert').show();
            var $error = this.$el.find('.view-messagealert .message p');
            $error.html('');
        },

        showError: function (message) {
            var $error = this.$el.find('.view-messagealert .message p');
            $error.append(message + "</br>");
        },

        hideError: function () {
            this.$el.find('.view-messagealert').hide();
        }

    });

});
