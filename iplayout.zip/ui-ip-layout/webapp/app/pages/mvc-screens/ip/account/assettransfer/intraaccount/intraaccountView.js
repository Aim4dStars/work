define([
    'MvcView',
    'jquery'
], function (MvcView, $) {
    'use strict';

    return MvcView.extend({
        destinationFilterOption: [
            {
                value: 'managedPortfolios',
                label: 'All managed portfolios'
            }, {
                value: 'tailoredPortfolios',
                label: 'All tailored portfolios'
            }, {
                value: 'clientHoldings',
                label: 'All client holdings'
            }
        ],

        disableDirectDestination: function () {
            var container = this.$el.find(".view-destinationcontainer");
            $(container).find('input[value=directContainer]').prop('disabled', true);
        },

        enableDirectDestination: function () {
            var container = this.$el.find(".view-destinationcontainer");
            $(container).find('input[value=directContainer]').prop('disabled', false);
        },

        disableDirectSource: function () {
            var container = this.$el.find(".view-sourcecontainer");
            $(container).find('input[value=directContainer]').prop('disabled', true);
        },

        disablePortfolioSource: function () {
            var container = this.$el.find(".view-sourcecontainer");
            $(container).find('input[value=portfolioContainer]').prop('disabled', true);
        },

        getForm: function () {
            return this.$el.find('.assetselector');
        },

        scrollToAssetList: function () {
            this.setScrollIntoView({
                element: this.$el.find('.assetlist-container')
            });
        },

        scrollToAssetSelector: function () {
            this.setScrollIntoView({
                element: this.$el.find('.assetselector')
            });
        },

        truncateAssetName: function ($portfolioselector) {
            var annotationContents = $portfolioselector.find('.annotation').text();
            if (annotationContents.length > 0) {
                $portfolioselector.find('input').addClass('hasAnnotation');
            } else {
                $portfolioselector.find('input').removeClass('hasAnnotation');
            }
        },
    });
});
