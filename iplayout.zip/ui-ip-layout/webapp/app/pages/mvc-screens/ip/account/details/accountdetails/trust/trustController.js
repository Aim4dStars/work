defineMvcController({
    name: 'trust',
    parentPath: 'mvc-screens/ip/account/details/accountdetails',
    viewHtml: true,
    viewComponents: ['definitionlist'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config

    });
});
