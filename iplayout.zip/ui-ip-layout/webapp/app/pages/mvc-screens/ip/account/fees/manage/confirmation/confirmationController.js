defineMvcController({
    name: 'confirmation',
    parentPath: 'mvc-screens/ip/account/fees/manage',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    viewComponents: ['forminputtext', 'button', 'termsandconditions'],
    mvcComponents: ['tablev3'],
    screens: ['cancel'],
    hashName: 'confirmation',
    extend: 'MvcController',
    dependencies: ['jquery', 'rootController', 'underscore']
}, function (config, MvcController, $, rootController, _) {
    'use strict';

    return MvcController.extend({
        config: config,

        viewEvents: {
            'submit form': 'submit'
        },

        preRender: function () {
            if (!this.parentController.isPreviousStepValid(this.name)) {
                this.parentController.showLastValidStep();
            } else {
                rootController.confirmNavigation(true);
                var contributionFee = this.parentController.getContributionFees({
                    fees: this.parentController.model.get('request')
                });
                this.model.colateFees(this.parentController.model.get('request'), contributionFee);

            }
        },

        openModal1: function () {
            this.children.cancel.openModal();
        },

        postRender: function () {
            this.view.hideError();
            var data = this.model.get('data.fees');
            if (data) {
                this._populateAdviceFees(_.findWhere(data, {
                    type: 'Ongoing advice fee'
                }), 'ongoingadvicefee');
                this._populateAdviceFees(_.findWhere(data, {
                    type: 'Licensee advice fee'
                }), 'licenseeadvicefee');
            }
            var pmfData = this.model.get('data.pmf');
            if (pmfData) {
                this._populatePortfolioFees(pmfData);
            }
            var contributionFeeData = this.model.get('data.contributionFees');
            if (contributionFeeData && (contributionFeeData.oneoffFees.length > 0 || contributionFeeData.regularFees.length > 0)) {
                this._populateContributionSection(contributionFeeData);
            }
        },

        _populateAdviceFees: function (adviceFees, feeType) {
            var child = feeType;
            if (adviceFees && adviceFees.feesComponent) {
                var feesComponent = adviceFees.feesComponent;
                for (var j in feesComponent) {
                    if (feesComponent[j].type === 'PercentageFee') {
                        child = child + 'percentagefee';
                        if (this.children[child]) {
                            this.children[child].setRows({
                                rowName: 'percentageData'
                            }, this._formatPercentageData(feesComponent[j]));
                            this.children[child].populateAndRenderData();
                        }
                    } else if (feesComponent[j].type === 'SlidingScaleFee') {
                        child = child + 'slidingscalefee';
                        if (this.children[child]) {
                            this.children[child].setRows({
                                rowName: 'slidingScaleData'
                            }, this._formatSlidingScaleData(feesComponent[j].slidingScaleFeeTier));
                            this.children[child].populateAndRenderData();
                        }
                    }
                }
            }
        },

        _populatePortfolioFees: function (fees) {
            if (_.isObject(this.children.pmfpercent)) {
                this.children.pmfpercent.setRows({
                    rowName: 'pmfPercentData'
                }, fees.percentageComponent);
                this.children.pmfpercent.populateAndRenderData();
            }
            _.each(fees.slidingScaleComponent, _.bind(function (slidingComponent, index) {
                this._populateSlidingPmfFees(slidingComponent, index);
            }, this));
        },

        _populateSlidingPmfFees: function (slidingComponent, index) {
            var sliding = this.children['pmfsliding' + index];
            var detailedSliding = this.children['pmfslidingdetail' + index];

            if (_.isObject(sliding)) {
                sliding.setRows({
                    rowName: 'pmfSlidingData'
                }, this._formatSlidingScaleData(slidingComponent.slidingScaleFeeTier));
                sliding.populateAndRenderData();
            }

            if (_.isObject(detailedSliding)) {
                var detailData = [{
                    investmentName: slidingComponent.investmentName,
                    apirCode: slidingComponent.apirCode,
                    code: slidingComponent.code
                }];
                detailedSliding.setRows({
                    rowName: 'pmfSlidingData'
                }, detailData);
                detailedSliding.populateAndRenderData();
            }
        },

        _populateContributionSection: function (contributionFees) {
            if (contributionFees.oneoffFees.length > 0 && this.children.oneofftable) {
                this.children.oneofftable.setRows({}, contributionFees.oneoffFees);
                this.children.oneofftable.populateAndRenderData();
                this.model.set('oneoffFees', contributionFees.oneoffFees);
            }
            if (contributionFees.regularFees.length > 0 && this.children.regulartable) {
                this.children.regulartable.setRows({}, contributionFees.regularFees);
                this.children.regulartable.populateAndRenderData();
                this.model.set('regularFees', contributionFees.regularFees);
            }
        },

        _formatPercentageData: function (component) {
            return this.parentController.parentController.formatPercentageData(component);
        },

        _formatSlidingScaleData: function (tiers) {
            return this.parentController.parentController.formatSlidingScaleData(tiers);
        },

        submit: function (event) {
            var validationResult = this.validateAndSubmitForm(event);
            if (validationResult) {
                if (!this.viewChildren.next.isLoading()) {
                    rootController.confirmNavigation(false);
                    this.parentController.formSuccess(this.name);
                }
            } else {
                if (!this.model.get('disclaimer')) {
                    this.viewChildren.termsandconditions.turnintoTooltip();
                    this.parentController.formFail(this.name);
                }
            }
        },

        openModal: function () {
            rootController.confirmNavigation(false);
            this.children.cancel.openModal();
        },

        gotoView: function () {
            rootController.confirmNavigation(false);
            window.history.back();
        },


        generatePdf: function () {
            rootController.confirmNavigation(false);
            var feeObj = this._buildFeeObj(this.parentController.model.get('request'));
            var dto = JSON.stringify(feeObj);

            var url = '../reportpdf/feeScheduleAuthorisationForm?account-id=' + rootController.getUrlParams().a + '&feeScheduleTransactionDto=' + dto;
            window.open(url);
            rootController.confirmNavigation(true);
        },

        _buildFeeObj: function (feesRequest) {
            var fees = {};
            _.each(feesRequest, function (obj) {
                if (obj.type === 'Ongoing advice fee') {
                    fees.onGoingFees = this._convertFeeTypes(obj.feesComponent);
                } else if (obj && obj.type === 'Licensee advice fee') {
                    fees.licenseeFees = this._convertFeeTypes(obj.feesComponent);
                } else if (obj && obj.type === 'Portfolio management fee') {
                    fees.portfolioFees = obj.feesComponent;
                } else if (obj && obj.type === 'Contribution fee') {
                    fees.contributionFees = obj.feesComponent;
                }
            }, this);
            return fees;
        },

        _convertFeeTypes: function (components) {
            var feeType = {};
            _.each(components, function (component) {
                if (component.type === 'DollarFee') {
                    feeType.dollarFee = component;
                } else if (component.type === 'PercentageFee') {
                    feeType.percentageFee = component;
                } else if (component.type === 'SlidingScaleFee') {
                    feeType.slidingScaleFee = component;
                }
            });
            return feeType;
        }


    });
});
