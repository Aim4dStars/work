define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            headerDownload: {
                items: [{
                    'label': 'PDF',
                    'action': 'buildPdfLink'
                }, {
                    'label': 'CSV',
                    'action': 'buildCsvLink'
                }]
            }
        }
    });
});
