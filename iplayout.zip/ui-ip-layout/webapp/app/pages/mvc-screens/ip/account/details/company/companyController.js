defineMvcController({
    name: 'company',
    parentPath: 'mvc-screens/ip/account/details',
    viewHtml: true,
    viewComponents: ['definitionlist'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config

    });
});
