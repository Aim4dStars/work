defineMvcController({
    name: 'clientdata',
    parentPath: 'mvc-screens/ip/account/details/accountdetails',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['definitionlist', 'icon'],
    extend: 'MvcController',
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        editPrimaryContact: function () {
            this.parentController.openModal('primaryContactPerson', this.model.get('clientData'), this.name);
        }
    });
});
