define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/participationreport/participationreportView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/participationreport/_participationreport.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (ParticipationReportView, _participationreportTemplate, componentXml, Handlebars) {
    'use strict';

    return ParticipationReportView.extend({
        preRender: function () {
            Handlebars.registerPartial('participationreport', componentXml.encode(_participationreportTemplate));
        }
    });

});
