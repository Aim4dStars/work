define([
    'underscore', 'jquery', 'rootController'
], function (_, $, rootController) {
    'use strict';

    return {
        url: {
            rolloverReceived: '../api/rollover/v1_0/account/<%=a%>/rollover-received'
        },

        getReceivedRollover: function (controller, params) {
            var deferred = $.Deferred();

            controller.ajaxGet({
                url: controller.getUrl(rootController.getUrlParams(), this.url.rolloverReceived),
                data: params,
                success: function (data) {
                    if (data) {
                        deferred.resolve(data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },
    };
});
