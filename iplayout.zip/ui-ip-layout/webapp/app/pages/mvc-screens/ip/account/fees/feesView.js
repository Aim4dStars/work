define([
    'MvcView',
    'handlebars'
], function (MvcView, Handlebars) {
    'use strict';

    return MvcView.extend({

        rootTemplate: {
            menuTabs: [{
                label: 'Advice fees',
                url: '#ng/account/fees',
                child: 'schedule,manage,chargeoneoff,taxinvoices',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.report.view',
                    tree: 'a'
                }
            }, {
                label: 'Administration & investment fees',
                url: '#ng/account/fees/administration',
                child: 'administration',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.report.view',
                    tree: 'a'
                }
            }]
        },
        preRender: function () {
            Handlebars.registerHelper('fixedTOTwo', function (number) {
                number = Math.ceil(parseFloat(number * 100).toFixed(13)) / 100;
                return parseFloat(number).toFixed(2);
            });
        },
        hideContent: function () {
            this.$el.find('.screen-content').hide();
        }

    });

});
