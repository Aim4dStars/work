defineMvcController({
    name: 'transfer',
    parentPath: 'mvc-screens/ip/account/assettransfer',
    viewHtml: true,
    viewJs: true,
    hashName: 'transfer',
    hashDefault: false,
    viewComponents: ['inputselect', 'snapshot', 'inputcheckbox'],
    mvcComponents: ['inputautocomplete'],
    screens: ['timeline', 'transferform', 'uploaddocuments'],
    extend: 'MvcController',
    dependencies: ['app/framework/services/Permissions', 'rootController', 'jquery', 'underscore', 'text!app/pages/mvc-screens/ip/account/assettransfer/transfer/transferform/chessSponsors.json', 'app/pages/mvc-screens/ip/services/accountService']
}, function (config, MvcController, Permissions, rootController, $, _, chessSponsorsJSON, accountService) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.inspecie.transfer.submit',
        targetId: 'a',
        requiredParams: ['a'],
        valuationServiceUrl: '../api/portfolio/v3_0/<%=a%>/valuation',
        availableAssetsServiceUrl: '../api/v1_0/accounts/<%=a%>/available-assets',
        chessSponsorsUrl: 'app/pages/mvc-screens/ip/account/assettransfer/transfer/transferform/chessSponsors.json',
        autoHideSpinner: false,

        preRender: function () {
            this.model.set('pageState', 'wizard');
            var assettransferHelpUrl = this.getAssetTransferSupportUrl();
            this.model.set('assettransferHelpUrl', assettransferHelpUrl);
            this.model.set('accountId', rootController.getUrlParams().a);
        },

        getAssetTransferSupportUrl: function () {
            if (Permissions.ruleMatched('feature.global.aemEnabled')) {
                if (Permissions.ruleMatched('account.asim.view', rootController.getUrlParams().a)) {
                    return rootController.getAsimBasePageUrl() + '/your-account/reports-and-transactions/asset-transfer.html';
                } else {
                    var path = '/content/secure/help-and-support/bt/en/' + rootController.getStaticPageRole() + '/clients/reports-and-transactions/asset-transfer.html';
                    return rootController.getCmsHost() + path;
                }
            } else {
                return '/ng/public/content/helpandsupport/static-templates/' + rootController.getStaticPageRole() + '/asset-transfer.html';
            }
        },

        postRender: function () {
            this.model.on({
                'change:assetType': this.changeAssetType,
                'change:transferInfo': this.changeTransferInfo,
                'change:managedPortfolio': this.changeManagedPortfolio,
                'change:tailoredPortfolio': this.changeTailoredPortfolio,
                'change:cbo': this.changeCBO,
                'change:pageState': this.changePageState,
                'change:showClientHoldingsOnly': this.updateManagedPortfolios,
                'change:showTailoredClientHoldingsOnly': this.updateTailoredPortfolios
            }, this);

            // Temporarily use the chess sponsor data from a local dependency.
            this.populateChessSponsors($.parseJSON(chessSponsorsJSON));

            this.hideAssetSelector();
            this.viewChildren.continuebtn.disable();

            // Populate accountId for link to asset status page
            this.model.set('accountId', rootController.getUrlParams().a);

            this.children.uploaddocuments.hide();

            $.when(this.fetchAvailableAssets(), this.fetchPortfolios(), this.fetchAccountData() /*,this.fetchChessSponsors()*/ )
                .done(_.bind(this.populate, this));
        },

        fetchAvailableAssets: function () {
            var url = this.getUrl(rootController.getUrlParams(), this.availableAssetsServiceUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    this.model.set('availableAssets', data.data.resultList);
                }, this)
            };

            return this.ajaxGet(params);
        },

        fetchPortfolios: function () {
            var url = this.getUrl(rootController.getUrlParams(), this.valuationServiceUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    var managedPortfolioData = _.find(data.data.categories, function (d) {
                        return d.categoryName === 'Managed portfolios';
                    });
                    if (!_.isUndefined(managedPortfolioData)) {
                        this.model.set('heldManagedPortfolios', managedPortfolioData.investments);
                    }

                    var cashData = _.find(data.data.categories, function (d) {
                        return d.categoryName === 'Cash';
                    });
                    if (!_.isUndefined(cashData)) {
                        this.model.set('heldCash', cashData.investments);
                    }

                    //for tailored portfolios
                    var tailoredPortfolioData = _.find(data.data.categories, function (d) {
                        return d.categoryName === 'Tailored portfolios';
                    });

                    if (!_.isUndefined(tailoredPortfolioData)) {
                        this.model.set('heldTailoredPortfolios', tailoredPortfolioData.investments);
                    }
                }, this)
            };

            return this.ajaxGet(params);
        },

        fetchAccountData: function () {
            return accountService.getAccount(this)
                .done(_.bind(function (account) {
                    this.model.set('accountName', account.accountName);
                    this.model.set('accountNumber', account.accountNumber);
                }, this));
        },

        populate: function () {
            var heldManagedPortfolios = this.model.get('heldManagedPortfolios');
            var availableAssets = this.model.get('availableAssets');
            var heldTailoredPortfolios = this.model.get('heldTailoredPortfolios');

            var managedPortfolios = this._filterByAssetType(availableAssets, heldManagedPortfolios, "Managed portfolio");
            managedPortfolios = this._filterPortfolios(managedPortfolios);
            this.model.set('managedPortfolios', managedPortfolios);

            var tailoredPortfolios = this._filterByAssetType(availableAssets, heldTailoredPortfolios, "Tailored portfolio");
            tailoredPortfolios = this._filterPortfolios(tailoredPortfolios);
            this.model.set('tailoredPortfolios', tailoredPortfolios);

            this.renderPortfolios("managedPortfolios", "managedportfolios", managedPortfolios);
            this.renderPortfolios("tailoredPortfolios", "tailoredportfolios", tailoredPortfolios);

            this.view.hideSpinner();
        },

        _filterByAssetType: function (availableAssets, heldPortfolios, assetType) {
            var portfolios = _.filter(availableAssets, function (asset) {
                return asset.assetType === assetType;
            });
            _.each(portfolios, function (asset) {
                var heldPortfolio = _.find(heldPortfolios, function (portfolio) {
                    return portfolio.assetId === asset.assetId;
                });

                if (heldPortfolio) {
                    asset.balance = heldPortfolio.balance;
                    asset.subAccountId = heldPortfolio.subAccountId;
                    asset.incomePreference = heldPortfolio.incomePreference;
                }
            });
            portfolios = _.sortBy(portfolios, function (portfolio) {
                return portfolio.assetName;
            });

            return portfolios;

        },

        _filterPortfolios: function (portfolios) {
            portfolios = _.filter(portfolios, function (portfolio) {
                var isNull = _.isNull(portfolio.status);
                var isOpen = portfolio.status === "Open";
                var isEmpty = _.isEmpty(portfolio.status);
                return isNull || isOpen || isEmpty;
            });
            return portfolios;
        },

        renderPortfolios: function (type, child, portfolios) {
            var menuConfig = {};
            menuConfig[type] = {
                items: portfolios
            };

            this.children[child].renderMenuData(menuConfig);
        },

        updateManagedPortfolios: function () {
            var managedPortfolios = this.updatePortfolio("showClientHoldingsOnly", "managedPortfolios");
            this.renderPortfolios("managedPortfolios", "managedportfolios", managedPortfolios);
        },

        updateTailoredPortfolios: function () {
            var tailoredPortfolios = this.updatePortfolio("showTailoredClientHoldingsOnly", "tailoredPortfolios");
            this.renderPortfolios("tailoredPortfolios", "tailoredportfolios", tailoredPortfolios);
        },

        updatePortfolio: function (selector, assetName) {
            var filterOption = this.model.get(selector);
            var portfolios = this.model.get(assetName);
            if (filterOption === 'holdings') {
                portfolios = _.filter(portfolios, function (portfolio) {
                    return portfolio.balance > 0;
                });
            }
            return portfolios;
        },

        hideAssetSelector: function () {
            this.view.hideTransferInfo();
            this.view.hideManagedPortfolio();
            this.view.hideTailoredPortfolio();
            this.view.hideCBO();
            this.view.hideTable();
        },

        changeAssetType: function () {
            this.model.set({
                'transferInfo': 'select',
                'managedPortfolio': '',
                'tailoredPortfolio': '',
                'cbo': 'select'
            });
            this.children.managedportfolios.view.clearListOptions();

            var assetType = this.model.get('assetType');
            var options;
            if (assetType === 'brokersponsored' || assetType === 'issuersponsored' || assetType === 'listedsecuritycustodian') {
                options = [{
                    label: 'Select',
                    value: 'select'
                }, {
                    label: 'Listed securities',
                    value: 'listedsecurities'
                }, {
                    label: 'Managed portfolios',
                    value: 'managedportfolios'
                }];

                if (Permissions.ruleMatched('feature.global.dealerGroupModels')) {
                    options.push({
                        label: 'Tailored portfolios',
                        value: 'tailoredportfolios'
                    });
                }
                this.viewChildren.transferinfo.setOptions(options);
                this.view.showTransferInfo();

            } else if (assetType === 'managedfunds') {
                options = [{
                    label: 'Select',
                    value: 'select'
                }, {
                    label: 'Managed funds',
                    value: 'managedfunds'
                }, {
                    label: 'Managed portfolios',
                    value: 'managedportfolios'
                }];
                if (Permissions.ruleMatched('feature.global.dealerGroupModels')) {
                    options.push({
                        label: 'Tailored portfolios',
                        value: 'tailoredportfolios'
                    });
                }
                this.viewChildren.transferinfo.setOptions(options);
                this.view.showTransferInfo();

            } else {
                this.view.hideTransferInfo();
            }
        },

        changeTransferInfo: function () {
            this.model.set({
                'managedPortfolio': '',
                'tailoredPortfolio': '',
                'cbo': 'select'
            });
            this.children.managedportfolios.view.clearListOptions();

            var transferInfo = this.model.get('transferInfo');

            this.view.hidePMMessage();
            this.view.hideCBO();
            this.view.hideManagedPortfolio();
            this.view.hideTailoredPortfolio();

            if (transferInfo === 'listedsecurities' || transferInfo === 'managedfunds') {
                this.view.showCBO();
            } else if (transferInfo === 'managedportfolios') {
                this.showPMMessage(rootController.getCmsEntry('Err.IP-0543'));
                this.view.showManagedPortfolio();
            } else if (transferInfo === 'tailoredportfolios') {
                this.showPMMessage(rootController.getCmsEntry('Err.IP-0597'));
                this.view.showTailoredPortfolio();
            }
        },

        changeManagedPortfolio: function () {
            this.changePortfolio("managedPortfolio");
        },

        changeTailoredPortfolio: function () {
            this.changePortfolio("tailoredPortfolio");
        },

        showPMMessage: function (message) {
            this.viewChildren.pmmessage.viewData.message = message;
            this.viewChildren.pmmessage.render();
            this.view.showPMMessage();
        },

        changePortfolio: function (assetType) {
            this.model.set({
                'cbo': 'select'
            });

            var portfolio = this.model.get(assetType);
            if (portfolio) {
                this.view.showCBO();
            } else {
                this.view.hideCBO();
            }
        },

        completeTransferForm: function () {
            var cbo = this.model.get('cbo');
            this.viewChildren.cbo.setSelectedOption();
            if (cbo === 'yes' || cbo === 'no') {
                this.model.set('pageState', 'table');
                this.changePageState();
            } else {
                this.model.set('pageState', 'wizard');
            }
        },

        back: function () {
            this.model.set('pageState', 'wizard');
            this.changePageState();
            this.clearTransferForm();
            this.view.setScrollIntoView({
                element: this.view.$el.find('.mvc-transfer')
            });
        },
        getDestAssetId: function () {
            var destAssetId = null;
            var transferInfo = this.model.get('transferInfo');
            if (transferInfo === 'managedportfolios' || transferInfo === 'tailoredportfolios') {

                var portfolioModel = 'managedPortfolio';
                if (transferInfo === 'tailoredportfolios') {
                    portfolioModel = 'tailoredPortfolio';
                }

                var matchingPortfolio = this.getMatchingPortfolio();
                if (_.isNull(matchingPortfolio) || _.isUndefined(matchingPortfolio)) {
                    var portfolio = this.model.get(portfolioModel);
                    destAssetId = portfolio.assetId;
                }
            }

            return destAssetId;
        },
        getContainerId: function () {
            var heldCash = this.model.get('heldCash');
            var containerId = heldCash[0].subAccountId;

            var matchingPortfolio = this.getMatchingPortfolio();
            if (!_.isNull(matchingPortfolio) && !_.isUndefined(matchingPortfolio) && !_.isUndefined(matchingPortfolio.subAccountId)) {
                containerId = matchingPortfolio.subAccountId;
            }

            return containerId;
        },

        getMatchingPortfolio: function () {
            var matchingPortfolio;
            var transferInfo = this.model.get('transferInfo');
            if (transferInfo === 'managedportfolios' || transferInfo === 'tailoredportfolios') {
                var portfolioModel = 'managedPortfolio';
                var heldPortfolioModel = 'heldManagedPortfolios';

                if (transferInfo === 'tailoredportfolios') {
                    portfolioModel = 'tailoredPortfolio';
                    heldPortfolioModel = 'heldTailoredPortfolios';
                }
                var portfolio = this.model.get(portfolioModel);
                if (!_.isUndefined(portfolio)) {
                    var heldPortfolios = this.model.get(heldPortfolioModel);
                    matchingPortfolio = _.find(heldPortfolios, function (_portfolio) {
                        return _portfolio.assetId === portfolio.assetId;
                    });
                    if (!_.isUndefined(matchingPortfolio)) {
                        return matchingPortfolio;
                    }
                }
            }
        },

        changePageState: function () {
            var pageState = this.model.get('pageState');
            this.children.timeline.model.set('screenState', pageState);
            if (pageState === 'table') {
                this.view.showTable();
                this.view.hidePMMessage();
                var transferform = this.children.transferform;
                var containerId = this.getContainerId();

                transferform.model.set({
                    'accountName': this.model.get('accountName'),
                    'accountNumber': this.model.get('accountNumber'),
                    'managedPortfolio': this.model.get('managedPortfolio'),
                    'tailoredPortfolio': this.model.get('tailoredPortfolio'),
                    'cbo': this.model.get('cbo'),
                    'assetType': this.model.get('assetType'),
                    'transferInfo': this.model.get('transferInfo'),
                    'containerId': containerId
                });

                var destAssetId = this.getDestAssetId();
                transferform.model.set('destAssetId', destAssetId);

                transferform.removeChildren();
                transferform.view.removeComponents(this.view.el);
                transferform.view.render();

                rootController.confirmNavigation(true);
            } else {
                this.view.hideTable();
                rootController.confirmNavigation(false);
            }
            if (pageState !== 'addDocuments') {
                this.children.uploaddocuments.hide();
            }
        },

        changeCBO: function () {
            var cbo = this.model.get('cbo');
            if (cbo === 'yes' || cbo === 'no') {
                this.viewChildren.continuebtn.enable();
            } else {
                this.viewChildren.continuebtn.disable();
            }
        },

        clearTransferForm: function () {
            this.model.set('cbo', 'select');
            this.model.unset('managedPortfolio');
            this.model.unset('tailoredPortfolio');
            this.model.unset('transferInfo');
            this.model.set('assetType', 'select');
            this.model.set('showClientHoldingsOnly', 'all');

            this.view.hideCBO();
            this.view.hideTransferInfo();
            this.view.hideManagedPortfolio();
            this.view.hideTailoredPortfolio();
        },

        showUploadDocuments: function () {
            this.view.hideTransferForm();
            this.children.uploaddocuments.show();
        },

        fetchChessSponsors: function () {
            var url = this.getUrl(rootController.getUrlParams(), this.chessSponsorsUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    this.populateChessSponsors(data);
                }, this)
            };
            return this.ajaxGet(params);
        },

        populateChessSponsors: function (chessSponsors) {
            this.model.set('chessSponsors', chessSponsors);
        },

        openAssetTransferSupport: function () {
            var assettransferHelpUrl = this.model.get('assettransferHelpUrl');
            window.open(assettransferHelpUrl, 'Asset Transfer');
        },

        removeDocumentsState: function () {
            this.view.removeDocumentsState();
        },

        addDocumentsState: function () {
            this.view.addDocumentsState();
        }
    });
});
