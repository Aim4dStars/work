define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/baseelectionform/baseelectionformView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/multiblock/_multiblock.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (SuperView, _multiblockTemplate, componentXml, Handlebars) {
    'use strict';

    return SuperView.extend({
        formSelector: ".multiblock-form",

        preRender: function () {
            Handlebars.registerPartial('multiblock', componentXml.encode(_multiblockTemplate));
        }
    });

});
