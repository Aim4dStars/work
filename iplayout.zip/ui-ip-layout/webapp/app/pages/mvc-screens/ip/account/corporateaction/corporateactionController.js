defineMvcController({
    name: 'corporateaction',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    hashName: 'corporateaction',
    mvcComponents: ['chart', 'tablev3'],
    viewComponents: ['menuaction', 'messagedisclaimer'],
    screens: ['election', 'participationreport', 'mandatoryreport', 'mvc-screens/ip/tracking/corporateaction/modelelection', 'mvc-screens/ip/tracking/corporateaction/modelparticipationreport'],
    dependencies: ['rootController', 'app/pages/mvc-screens/ip/tracking/corporateactions/corporateactionUtils', 'libs/panorama-bridge/require-panoramaBridge'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/corporateactionController'
}, function (config, CorporateActionController, rootController, utils, panoramaBridge) {
    'use strict';

    return CorporateActionController.extend({
        config: config,
        hasPermission: 'account.asim.view',
        requiredParams: ['a'],
        targetId: 'a',

        goBackToAccountCorporateAction: function () {
            var params = rootController.getUrlParams();
            var mandatory = this.model.get('mandatory');
            var paths = {
                "mandatory": "#/app/adviser/account/<%=a%>/corporate-actions/mandatory",
                "voluntary": "#/app/adviser/account/<%=a%>/corporate-actions/voluntary"
            };
            paths.mandatory = this.getUrl(params, paths.mandatory);
            paths.voluntary = this.getUrl(params, paths.voluntary);

            if (mandatory) {
                panoramaBridge.notifyHashChange(paths.mandatory, true);
            } else {
                panoramaBridge.notifyHashChange(paths.voluntary, true);
            }
        }
    });
});
