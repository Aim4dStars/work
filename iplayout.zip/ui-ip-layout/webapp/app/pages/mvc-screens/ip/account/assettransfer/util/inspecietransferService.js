define([
    'underscore', 'jquery', 'rootController'
], function (_, $, rootController) {
    'use strict';

    function isValidResponse(data) {
        return _.isObject(data) && _.isObject(data.data);
    }

    function getErrors(data) {
        return _.filter(data.data.warnings, function (warning) {
            return warning.errorType === 'error';
        });
    }

    return {
        url: {
            inspecietransferServiceURL: '../api/inspecietransfer/v3_0/accounts/<%=a%>/inspecie-transfer',
            oldinspecietransferServiceURL: '../api/inspecietransfer/v2_0/accounts/<%=a%>/inspecie-transfer'
        },

        submitTransferRequest: function (controller, params, useOldUrlVersion) {
            var deferred = $.Deferred();

            var url = this.url.inspecietransferServiceURL;
            var data = {
                'transferData': JSON.stringify(params)
            };

            if (useOldUrlVersion) {
                url = this.url.oldinspecietransferServiceURL;
                data = {
                    'transferDetails': JSON.stringify(params)
                };
            }

            url = controller.getUrl(rootController.getUrlParams(), url);
            controller.ajaxPost({
                url: url,
                data: data,
                success: function (data) {
                    if (isValidResponse(data)) {
                        var errors = getErrors(data);
                        if (_.isArray(errors) && errors.length > 0) {
                            deferred.reject(data);
                        }
                        deferred.resolve(data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },
    };
});
