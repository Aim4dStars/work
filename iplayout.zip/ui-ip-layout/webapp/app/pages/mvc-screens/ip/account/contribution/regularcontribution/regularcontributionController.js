defineMvcController({
    name: 'regularcontribution',
    parentPath: 'mvc-screens/ip/account/contribution',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'regularcontribution',
    extend: 'app/pages/mvc-screens/ip/account/movemoney/depositsv2/details/detailsController',
    screens: ['confirmation'],
    viewComponents: ['forminputselect', 'forminputtext', 'forminputdate', 'button', 'forminputcheckbox', 'messagealert'],
    mvcComponents: ['inputautocomplete'],
    dependencies: ['underscore', 'jquery', 'app/pages/mvc-screens/ip/services/depositAccountsService', 'app/pages/mvc-screens/ip/services/accountService', 'rootController', 'app/framework/services/Permissions', 'app/framework/helpers/timezone', 'moment', 'app/framework/services/dateService']
}, function (config, Super, _, $, depositAccountsService, accountService, rootController, Permissions, timezone, moment, dateService) {
    'use strict';

    var MAX_AGE_FOR_SPOUSE_CONTRIBUTION = 70;

    return Super.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        hasPermission: 'account.super.contribution.view',

        preRender: function () {
            this.model.set('repeatdeposit', 'repeat');
            this.model.set('contributionType', 'personal');
            this.model.on('change:contributionType', this.onContributionTypeChange, this);
            this.model.set('helpUrl', rootController.getHelpPageUrl());

            Super.prototype.preRender.apply(this);
        },

        postRender: function () {
            var accountId = rootController.getUrlParams().a;
            var pensionView = Permissions.ruleMatched('account.super.pension.view', accountId);
            if (pensionView && !_.isUndefined(this.viewChildren.previousscreen)) {
                this.viewChildren.previousscreen.viewData.href = "#/app/adviser/account/" + accountId + "/contribution/rollover-contribution";
                this.viewChildren.previousscreen.render();
            }
            Super.prototype.postRender.apply(this, arguments);
            this.parentController.model.unset('messageConfig');
            this.hideGraceMessage();
        },

        showLinkedAccountValidation: function () {
            if (this.model) {
                this.model.set('showGenericError', false);
                this.view.showLinkedAccountValidation();

            } else {
                this.parentController.showOneOffLinkedAccountValidation();

            }

            return true;
        },

        showGraceMessage: function () {
            this.viewChildren.gracemessage.show();
        },

        hideGraceMessage: function () {
            this.viewChildren.gracemessage.hide();
        },

        fetchData: function () {
            $.when(depositAccountsService.fetchPayeeList(this), accountService.getAccount(this))
                .done(_.bind(this.populateScreen, this));
        },

        populateScreen: function (payeeList, account) {
            var toEditSavedContribution = this.parentController.model.get('toEditSavedContribution');
            this.model.set('account', account);
            this.model.set('payeeList', payeeList);
            if (!_.isUndefined(toEditSavedContribution)) {
                this.prePopulateForm(toEditSavedContribution, payeeList);
            }
            this.onContributionTypeChange();
            this.initializePayeeDropdown(payeeList);
            if (this._getPrePensionCommencement(account)) {
                this.viewChildren.save.hide();
                this.viewChildren.prepensionmessage.show();
                this.view.hideDepositDate();
            }
            this.view.hideSpinner();
        },

        prePopulateForm: function (toEditSavedContribution, payeeList) {
            this.setContributionType(toEditSavedContribution);
            this.setContributionAccount(toEditSavedContribution, payeeList);
            this.setContributionFrequency(toEditSavedContribution);
            this.setContributionAmount(toEditSavedContribution);
            this.setStartDate(toEditSavedContribution);
            this.setEndDate(toEditSavedContribution);
            this.setErrorMessages();
        },

        setContributionAccount: function (toEditSavedContribution, payeeList) {
            var isContributionAccountLinked = _.find(payeeList, function (payee) {
                var bsbCode = _.clone(payee.code.replace('-', ''));
                return _.isEqual(+payee.accountId, +toEditSavedContribution.fromPayDto.accountId) && _.isEqual(+bsbCode, +toEditSavedContribution.fromPayDto.code);
            });

            if (!_.isUndefined(isContributionAccountLinked)) {
                isContributionAccountLinked.groupsConfiguration = {
                    'view_value': isContributionAccountLinked.accountName + ' - ' + isContributionAccountLinked.code + ' ' + isContributionAccountLinked.accountId
                };
                this.model.set('payeelist', isContributionAccountLinked);
            }
        },

        setContributionType: function (toEditSavedContribution) {
            this.model.set('contributionType', toEditSavedContribution.contributionType.toLowerCase());
        },

        setContributionFrequency: function (toEditSavedContribution) {
            this.model.set('depositfrequency', toEditSavedContribution.frequency);
        },

        setContributionAmount: function (toEditSavedContribution) {
            this.model.set('amount', toEditSavedContribution.amount);
        },

        setStartDate: function (toEditSavedContribution) {
            this.model.set('depositdate', timezone.convertTimezone(new Date(toEditSavedContribution.startDate), 'AEDST').date);
        },

        setEndDate: function (toEditSavedContribution) {
            var isEndDate = _.isDate(toEditSavedContribution.endDate) || !_.isEmpty(toEditSavedContribution.endDate);
            if (toEditSavedContribution.endRepeatNumber) {
                this.model.set('endrepeats', 'setNumber');
                this.model.set('repeatnumber', parseInt(toEditSavedContribution.endRepeatNumber, 10));
            } else if (_.isEmpty(toEditSavedContribution.endRepeatNumber) && isEndDate) {
                this.model.set('endrepeats', 'setDate');
                this.model.set('repeatenddate', timezone.convertTimezone(new Date(toEditSavedContribution.endDate), 'AEDST').date);
            } else {
                this.model.set('endrepeats', 'noDate');
            }
        },

        setErrorMessages: function () {
            var errors = this.parentController.model.get('confirmationError');
            if (!_.isEmpty(errors)) {
                this.viewChildren.errormessage.show();
                this.view.setErrorMessage(errors);
            }
        },

        onContributionTypeChange: function () {
            var contributionType = this.model.get('contributionType');
            var account = this.model.get('account');
            var age = accountService.getAge(account.owners);

            if (contributionType === 'spouse') {
                if (age >= MAX_AGE_FOR_SPOUSE_CONTRIBUTION) {
                    this.viewChildren.spouseagealert.show();
                    this.model.set('showForm', false);
                    this.viewChildren.spousehelpmessage.hide();
                } else {
                    this.viewChildren.spouseagealert.hide();
                    this.model.set('showForm', true);
                    this.viewChildren.spousehelpmessage.show();
                }
                this.viewChildren.cgtexpemptmessage.hide();
            } else if (contributionType === 'cgt') {
                this.viewChildren.cgtexpemptmessage.show();
                this.viewChildren.spouseagealert.hide();
                this.model.set('showForm', false);
                this.viewChildren.spousehelpmessage.hide();
            } else {
                this.viewChildren.spouseagealert.hide();
                this.model.set('showForm', true);
                this.viewChildren.spousehelpmessage.hide();
                this.viewChildren.cgtexpemptmessage.hide();
            }
        },

        getDataForSubmission: function () {
            var toEditSavedContribution = this.parentController.model.get('toEditSavedContribution');
            var data = Super.prototype.getDataForSubmission.call(this);
            data['depositType'] = this.model.get('contributionType');
            data['isRecurring'] = true;
            if (toEditSavedContribution) {
                data['key'] = toEditSavedContribution.key;
                data['transactionSeq'] = toEditSavedContribution.transactionSeq;
            }
            return data;
        },

        confirmContribution: function () {
            var $form = this.view.getForm();
            var event = {
                currentTarget: $form
            };
            this.confirmDeposit(event);
        },

        saveContribution: function () {
            var $form = this.view.getForm();
            var event = {
                currentTarget: $form
            };
            this.saveDeposit(event);
        },

        _getPrePensionCommencement: function (account) {
            var now = timezone.convertTimezone(dateService.now(), 'AEDST');
            now = moment(now.date);
            if (account.superAccountSubType === 'pens' && _.isObject(account.pensionDetails) && (_.isNull(account.pensionDetails.commencementDate) || now.diff(account.pensionDetails.commencementDate) < 0)) {
                return true;
            }
            return false;
        },

        showReceipt: function (response, type, action) {
            var payeeList = this.model.get('payeelist');
            response.toPayeeDto = this.parentController._getToPayeeDto(payeeList);
            this.parentController.model.set({
                submitResponse: response,
                type: type,
                action: action
            });
            this.parentController.children.contributionreceipt.show({
                updateLocationHash: true,
                preserveQueryStringParams: true
            });
        },

        showSavedContribution: function (response) {
            this.showReceipt(response, 'regularcontribution', 'save');
        }
    });
});
