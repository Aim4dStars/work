define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/statusfilter/statusfilterView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/statusfilter/_statusfilter.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (StatusfilterView, _statusfilterTemplate, componentXml, Handlebars) {
    'use strict';

    return StatusfilterView.extend({

        preRender: function () {
            Handlebars.registerPartial('statusfilter', componentXml.encode(_statusfilterTemplate));
        }
    });

});
