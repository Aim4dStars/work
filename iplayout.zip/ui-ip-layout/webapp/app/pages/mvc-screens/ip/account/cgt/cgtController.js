defineMvcController({
    name: 'cgt',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    screens: ['realised', 'unrealised'],
    hashName: 'cgt',
    extend: 'MvcController',
    dependencies: []
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.report.view',

        preRender: function () {
            this.model.set('clientId', this.parentController.model.get('clientId'));
            this.model.set('accountId', this.parentController.model.get('accountId'));
        }

    });

});
