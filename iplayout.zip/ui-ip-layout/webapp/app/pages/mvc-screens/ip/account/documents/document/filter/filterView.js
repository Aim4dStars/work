define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({

        getFilterForm: function () {
            return this.$el.find('form');
        }
    });
});
