defineMvcController({
    name: 'assettransfer',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    screens: ['transfer', 'status', 'individualstatus', 'intraaccount', 'transferreceipt', 'inspecie'],
    hashName: 'assettransfer',
    extend: 'MvcController',
    viewChildren: ['messagealert'],
    dependencies: ['app/framework/services/Permissions', 'rootController', 'app/framework/services/optionsService']
}, function (config, MvcController, Permissions, rootController, optionsService) {
    'use strict';

    return MvcController.extend({
        config: config,
        requiredParams: ['a'],
        accountOptionsParam: 'a',

        postRender: function () {
            var canSubmit = Permissions.ruleMatched('account.inspecie.transfer.submit', rootController.getUrlParams().a);
            var isBlocked = !Permissions.ruleMatched('account.summary.bar.view', rootController.getUrlParams().a);
            var accountLabel = optionsService.getOption('assettransfer.menu.description', 'a');

            if ((!isBlocked && canSubmit) && accountLabel === 'Intra account transfers') {
                this.children.transfer.hashDefault = false;
                this.children.status.hashDefault = false;
                this.children.intraaccount.hashDefault = true;
            }
        },

        getAssetTransferSupportUrl: function () {
            return this.children.transfer.getAssetTransferSupportUrl();
        },

        insertSubHeadings: function (investments) {
            return this.view.insertSubHeadings(investments);
        }
    });
});
