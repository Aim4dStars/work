define([
    'app/pages/mvc-templates/modal/modalView'
], function (ModalView) {
    'use strict';

    return ModalView.extend({

        showFileUpload: function () {
            this.$el.find('.hasFormData').hide();
            this.$el.find('.noFormData').show();
        },

        hideFileUpload: function () {
            this.$el.find('.hasFormData').show();
            this.$el.find('.noFormData').hide();
        },

        showErrorModal: function () {
            this.$el.find('.errorModal').show();
            this.$el.find('.uploadModal').hide();
        },

        showUploadModal: function () {
            this.$el.find('.uploadModal').show();
            this.$el.find('.errorModal').hide();
        }

    });

});
