define(['MvcModel',
       'app/framework/services/dateService',
       'underscore'],
    function (MvcModel, dateService, _) {
        'use strict';

        return MvcModel.extend({

            initialize: function () {
                this.set({
                    'sortBy': 'ascendingName'
                });
            },

            init: function () {
                var closureDate = this.get('closureDate');
                var accountStartDate = this.get('migrationDate') || this.get('accountStartDate');
                var todayDate = dateService.today();
                var financialYearStartDate;
                if (_.isDate(closureDate)) {
                    this.set('enddate', closureDate);
                    financialYearStartDate = new Date(closureDate).startOfFinancialYear();
                } else {
                    this.set('enddate', todayDate);
                    financialYearStartDate = new Date(todayDate).startOfFinancialYear();
                }
                if (_.isDate(accountStartDate)) {
                    if (accountStartDate < financialYearStartDate) {
                        this.set('startdate', financialYearStartDate);
                    } else {
                        this.set('startdate', accountStartDate);
                    }
                }
            },

            startDateMinDateRange: function (startDate) {
                var endDate = this.get('enddate');
                return startDate <= endDate;
            },

            endDateMinDateRange: function (endDate) {
                var startDate = this.get('startdate');
                return startDate <= endDate;
            },

            customMinValue: function (minValue) {
                var accountStartDate = this.get('migrationDate') || this.get('accountStartDate');
                return minValue >= accountStartDate;
            },

            customMaxClosureValue: function (endDate) {
                var closureDate = this.get('closureDate');
                return _.isDate(closureDate) ? endDate <= closureDate : true;
            },

            customMaxTodayValue: function (endDate) {
                return endDate <= dateService.today();
            },

            validation: {
                'startdate': {
                    priority: ['required', 'customFormat', 'customDateRange', 'customMinValue'],
                    blur: {
                        required: true,
                        customDateRange: 'startDateMinDateRange',
                        customMinValue: 'customMinValue'
                    },
                    submit: {
                        required: true
                    }
                },
                'enddate': {
                    priority: ['required', 'customFormat', 'customDateRange', 'customMaxClosureValue', 'customMaxTodayValue'],
                    blur: {
                        required: true,
                        customDateRange: 'endDateMinDateRange',
                        customMaxClosureValue: 'customMaxClosureValue',
                        customMaxTodayValue: 'customMaxTodayValue'
                    },
                    submit: {
                        required: true
                    }
                }
            },

            startDateString: function () {
                return dateService.formatDate(this.get('startdate'), "YYYY-MM-dd");
            },

            endDateString: function () {
                return dateService.formatDate(this.get('enddate'), "YYYY-MM-dd");
            }
        });

    });
