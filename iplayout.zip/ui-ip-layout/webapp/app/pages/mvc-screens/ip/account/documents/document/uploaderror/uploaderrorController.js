defineMvcController({
    name: 'uploaderror',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['button', 'messagealert'],
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',

}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config

    });

});
