defineMvcController({
    name: 'assetlist',
    parentPath: 'mvc-screens/ip/account/assettransfer/intraaccount',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    extend: 'MvcController',
    mvcComponents: ['menuactioninput', 'tableoptions', 'tablev3', 'section'],
    dependencies: ['jquery', 'underscore', 'rootController', 'app/pages/mvc-screens/ip/account/assettransfer/util/valuationService',
     'app/pages/mvc-screens/ip/tracking/_mixins/selectAllCheckboxMixin', 'app/framework/helpers/format', 'app/pages/mvc-screens/ip/account/assettransfer/util/utils']
}, function (config, MvcController, $, _, rootController, valuationService, selectAllCheckboxMixin, format, util) {
    'use strict';

    var assetlistController = MvcController.extend({
        config: config,
        pendingMFArray: [],

        postRender: function () {
            this.children.assetlistsection.updateSort = _.bind(this.updateSort, this);
        },

        setConfirmNavigation: function () {
            this.model.on('change', function () {
                rootController.confirmNavigation(true);
            }, this);
        },

        applyToAll: function (quantityObj) {
            this.resetSectionView(false);
            var selectedAssets = this.model.get('selectedIds_selectall');
            _.each(selectedAssets, function (selectedRowCode) {
                var quantityEle = this.getQuantityElement(selectedRowCode);
                if (!_.isUndefined(quantityEle)) {
                    if (quantityObj.option === 'percentage') {
                        this.setPercentageForElement(quantityObj, quantityEle);
                    } else {
                        this.setDollarForElement(quantityObj, quantityEle);
                    }
                }
            }, this);
        },

        setPercentageForElement: function (quantityObj, quantityEle) {
            var asset = quantityEle.viewData.asset;
            var transferAmount = 0;
            if (!_.isUndefined(asset)) {
                if (valuationService.isConvertToUnits(asset.investmentAsset)) {
                    transferAmount = this.model.convertToUnits(asset, 'percentage', quantityObj.value);
                    quantityEle.setOption("units", transferAmount);
                } else {
                    transferAmount = this.model.convertToDollar(asset, 'percentage', quantityObj.value);
                    quantityEle.setOption("dollars", transferAmount);
                }
            }
        },

        setDollarForElement: function (quantityObj, quantityEle) {
            var asset = quantityEle.viewData.asset;
            var totalSelectedHolding = this.parentController.model.get('selectedHolding');
            totalSelectedHolding = util.convertToNumber(totalSelectedHolding);
            if (!_.isUndefined(asset) && totalSelectedHolding !== 0) {
                var portfolioPercent = asset.investmentAsset.availableMarketValue / totalSelectedHolding;
                var transferAmount = portfolioPercent * quantityObj.value;
                if (valuationService.isConvertToUnits(asset.investmentAsset)) {
                    transferAmount = this.model.convertToUnits(asset, 'dollars', transferAmount);
                    quantityEle.setOption("units", transferAmount);
                } else {
                    quantityEle.setOption("dollars", transferAmount.toFixed(2));
                }
            }
        },

        toggleAllAssetQuantity: function (enableQuantity) {
            var selectedAssets = this.model.get('selectedIds_selectall');
            _.each(selectedAssets, function (selectedRowCode) {
                var quantityEle = this.getQuantityElement(selectedRowCode);
                if (enableQuantity) {
                    quantityEle.enable();
                } else {
                    quantityEle.disable();
                }
            }, this);
        },

        customAllCheckboxChanged: function (isChecked) {
            var assetlistData = this.model.get('assetlistData');
            _.each(assetlistData, function (asset) {
                var pendingAsset = _.find(this.pendingMFArray, function (assetId) {
                    return assetId === asset.assetId;
                });
                if (_.isUndefined(pendingAsset)) {
                    this.customCheckboxChanged(asset.assetId, isChecked);
                }
            }, this);
        },

        customCheckboxChanged: function (assetId, isChecked) {
            var quantityEle = this.getQuantityElement(assetId);
            if (!isChecked) {
                this.parentController.updateClosePortfolio();
            }
            this.changeQuantityState(quantityEle, isChecked, assetId);
            this.view.toggleRowState(quantityEle, isChecked);
        },

        changeQuantityState: function (quantityEle, isChecked, assetId) {
            if (!_.isUndefined(quantityEle)) {
                var assetlisttable = this.children.assetlistsection.children.assetlisttable;
                if (isChecked) {
                    quantityEle.enable();
                    var quantityObj = quantityEle.getState();
                    this.updateQuantity(quantityEle.viewData.asset, quantityObj.value, quantityObj.option);
                } else {
                    assetlisttable.model.set('transferamount_' + assetId, format.formatMoney(0, 2, '$'));
                    this.updateAssetTransferAmount();
                    quantityEle.disable();
                }
            }
        },

        dataChanged: function () {
            this.parentController.model.set('screenState', this.parentController.SCREEN_STATE.PREVIEW);
        },

        updateQuantity: function (asset, value, option) {
            if (!_.isUndefined(asset)) {
                var transferAmount = 0,
                    showMaxError = false;
                if (option === 'units') {
                    transferAmount = (value / asset.investmentAsset.availableQuantityHolding) * asset.investmentAsset.availableMarketValue;
                    if (value > asset.investmentAsset.availableQuantityHolding) {
                        showMaxError = 'units';
                    }
                } else if (option === 'dollars') {
                    if (value > asset.investmentAsset.availableMarketValue) {
                        showMaxError = 'dollars';
                    }
                    transferAmount = value;
                } else if (option === 'percentage') {
                    transferAmount = (value * asset.investmentAsset.availableMarketValue) / 100;
                }
                this.updateTableValues(asset, value, option, showMaxError, transferAmount);
            }
        },

        updateTableValues: function (asset, value, option, showMaxError, transferAmount) {
            var quantityObj = {
                option: option,
                value: value
            };
            var maxErrorMessage = rootController.getCmsEntry('Err.IP-0498');
            if (valuationService.isCash(asset.investmentAsset)) {
                maxErrorMessage = rootController.getCmsEntry('Err.IP-0077');
            }
            if (showMaxError) {
                this.view.showMaxError(asset.assetId, maxErrorMessage, showMaxError, value);
            } else {
                this.view.hideMaxError(asset.assetId);
            }
            this.model.set(option, value);
            var isCheckboxChecked = this.isCheckboxChecked(asset);
            if (!this.model.validateAttribute(option, 'blur').valid || showMaxError || !isCheckboxChecked) {
                transferAmount = 0;
            }
            var assetlisttable = this.children.assetlistsection.children.assetlisttable;
            assetlisttable.model.set('quantityamount_' + asset.assetId, quantityObj);
            assetlisttable.model.set('transferamount_' + asset.assetId, format.formatMoney(transferAmount, 2, '$'));
            this.updateAssetTransferAmount();
        },

        updateAssetTransferAmount: function () {
            var assetlistData = this.model.get('assetlistData');
            var assetlisttable = this.children.assetlistsection.children.assetlisttable;
            var totalTransferAmount = 0;
            _.each(assetlistData, function (transfer) {
                var amount = assetlisttable.model.get('transferamount_' + transfer.assetId);
                if (!_.isUndefined(amount)) {
                    totalTransferAmount += util.convertToNumber(amount);
                }
            }, this);
            var totalHoldings = this.parentController.model.get('selectedHolding');
            totalHoldings = util.convertToNumber(totalHoldings);
            var remainingTransferAmount = totalHoldings - totalTransferAmount;

            this.children.assetlistsection.model.set('totalTransferAmount', format.formatMoney(totalTransferAmount, 2, '$'));
            assetlisttable.model.set('totalTransferAmount', format.formatMoney(totalTransferAmount, 2, '$'));
            assetlisttable.model.set('remainingTransferAmount', format.formatMoney(remainingTransferAmount, 2, '$'));
            this.updateTotalTransferAmount();
        },

        updateTotalTransferAmount: function () {
            var assetAmount = this.children.assetlistsection.model.get('totalTransferAmount');
            var cashAmount = this.children.cashtablesection.model.get('transferamount_cash');
            assetAmount = util.convertToNumber(assetAmount);
            cashAmount = util.convertToNumber(cashAmount);
            var showCashTable = this.parentController.model.get('showCashTable');
            if (!_.isNumber(cashAmount) || _.isNaN(cashAmount) || !showCashTable) {
                cashAmount = 0;
            }
            if (!_.isNumber(assetAmount) || _.isNaN(assetAmount)) {
                cashAmount = 0;
            }
            var totalTransferAmount = assetAmount + cashAmount;
            this.model.set('totaltransfervalue', format.formatMoney(totalTransferAmount, 2, '$'));
            this.viewChildren.totaltransfervalue.render();
        },

        disablePendingMF: function () {
            _.each(this.pendingMFArray, function (assetId) {
                this.customCheckboxChanged(assetId, false);
            }, this);
        },

        populateAssetList: function (investments, disablePendingMF) {
            this.pendingMFArray = [];
            this.resetData(investments);
            if (disablePendingMF) {
                investments = this.getInvestmentsWithErrors(investments);
            }
            this.model.set('assetlistData', investments);
            this.populateAssetlistTable();
            this.setTableBindings();
            this.selectAllAssets();
            if (this.pendingMFArray.length > 0) {
                this.disablePendingMF();
            }
            this.view.hideSpinner();
        },

        selectAllAssets: function () {
            this.children.assetlistsection.children.assetlisttable.model.unset('selectall');
            this.children.assetlistsection.children.assetlisttable.model.set('selectall', true);
        },

        populateCashTable: function (cashData) {
            var cashtable = this.children.cashtablesection.children.cashtable;
            this.resetCashModelValues();
            cashtable.model.validation['cashquantity'] = this.model.validation['cashquantity'];
            cashtable.model.validation['cashquantity'].change.customMaxValue = _.bind(this.cashMaxValue, this);
            cashtable.model.on('change:cashquantity', _.bind(this.dataChanged, this));
            cashtable.removeViewChildren();
            cashtable.setRows({}, cashData);
            cashtable.renderComponentView();

            cashtable.model.on({
                'change:cashquantity': this.updateCashTransferAmount
            }, this);
            this.model.set('cashData', cashData);
            cashtable.model.set('transferamount_cash', format.formatMoney(0, 2, '$'));
            this.children.cashtablesection.model.set('transferamount_cash', format.formatMoney(0, 2, '$'));
        },

        getInvestmentsWithErrors: function (investments) {
            _.each(investments, function (investment) {
                var asset = investment.investmentAsset;
                if (valuationService.isManagedFund(asset) && asset.hasPending) {
                    investment.showPendingMFError = true;
                    this.pendingMFArray.push(investment.assetId);
                }
            }, this);
            return investments;
        },

        resetCashModelValues: function () {
            var cashtable = this.children.cashtablesection.children.cashtable;
            if (!_.isUndefined(cashtable)) {
                cashtable.model.set('transferamount_cash', '$0.00');
                cashtable.model.set('cashquantity', '');
            }
        },

        cashMaxValue: function (value) {
            var cashAsset = this.parentController.model.get('cashAsset');
            if (value > cashAsset.investments[0].availableBalance) {
                return false;
            }
            return true;
        },

        updateCashTransferAmount: function () {
            var cashtable = this.children.cashtablesection.children.cashtable;
            var cashAmount = cashtable.model.get('cashquantity');
            if (!cashtable.model.validateAttribute('cashquantity', 'blur').valid) {
                cashAmount = 0;
            }
            cashtable.model.set('transferamount_cash', format.formatMoney(cashAmount, 2, '$'));
            this.children.cashtablesection.model.set('transferamount_cash', format.formatMoney(cashAmount, 2, '$'));
            this.updateTotalTransferAmount();
        },

        resetData: function (investments) {
            this.resetSectionView(false);
            var assetlisttable = this.children.assetlistsection.children.assetlisttable;
            assetlisttable.model.unset('totalTransferAmount');
            assetlisttable.model.unset('remainingTransferAmount');
            assetlisttable.model.unset('showPendingMFError');
            _.each(investments, function (investment) {
                assetlisttable.model.unset('quantityamount_' + investment.assetId);
                assetlisttable.model.unset('transferamount_' + investment.assetId);
            });
            this.updateTotalTransferAmount();
            this.children.assetlistsection.children.tableoptions.model.set('sortBy', 'groupByAssetType');
        },

        resetSectionView: function (expand) {
            if (expand && !this.children.assetlistsection.view.isExpanded()) {
                this.children.assetlistsection.view.expand();
            } else if (!expand && this.children.assetlistsection.view.isExpanded()) {
                this.children.assetlistsection.view.collapse();
            }
            if (this.children.cashtablesection && this.children.cashtablesection.view.isExpanded()) {
                this.children.cashtablesection.view.collapse();
            }
        },

        populateAssetlistTable: function () {
            var assetlistData = this.model.get('assetlistData');
            var sortBy = this.children.assetlistsection.children.tableoptions.model.get('sortBy');
            assetlistData = this.model.sort(assetlistData, sortBy);

            if (sortBy === 'groupByAssetType') {
                assetlistData = this.parentController.insertSubHeadings(assetlistData);
            }
            var assetlisttable = this.children.assetlistsection.children.assetlisttable;
            assetlisttable.removeChildren();
            assetlisttable.removeViewChildren();
            assetlisttable.setRows({}, assetlistData);
            assetlisttable.renderComponentView();
            if (sortBy === 'groupByAssetType') {
                this.view.addColSpanForHeadings();
            }
            this.children.assetlistsection.model.set('totalTransferAmount', format.formatMoney(0, 2, '$'));
        },

        setTableBindings: function () {
            var assetlistData = this.model.get('assetlistData');
            _.each(assetlistData, function (asset) {
                if (!_.isUndefined(asset.assetId)) {
                    var quantityEle = this.getQuantityElement(asset.assetId);
                    if (!_.isUndefined(quantityEle)) {
                        this.setQuantityBinding(asset, quantityEle);
                        this.setQuantityValues(asset, quantityEle);
                    }
                }
            }, this);
            this.children.assetlistsection.children.assetlisttable.model.set('transferamount_', '$0.00');
        },

        setQuantityBinding: function (asset, quantity) {
            var conversionFun = "convertQuantity" + asset.assetId;
            var updateFun = "updateQuantity" + asset.assetId;

            quantity.viewData.conversion = conversionFun;
            quantity.viewData.callback = updateFun;

            quantity.viewData.asset = asset;

            quantity.model.validation['units'] = $.extend(true, {}, this.model.validation['units']);
            quantity.model.validation['percentage'] = this.model.validation['percentage'];
            quantity.model.validation['dollars'] = this.model.validation['dollars'];

            var percentageItemIndex = this.getMenuActionItem('percentage', quantity);

            if (valuationService.isConvertToUnits(asset.investmentAsset)) {
                var dollarItemIndex = this.getMenuActionItem('dollars', quantity);
                if (!_.isUndefined(dollarItemIndex)) {
                    dollarItemIndex['auto_conversion'] = "units";
                }
                if (!_.isUndefined(percentageItemIndex)) {
                    percentageItemIndex['auto_conversion'] = "units";
                }
            } else {
                if (!_.isUndefined(percentageItemIndex)) {
                    percentageItemIndex['auto_conversion'] = "dollars";
                }
            }
            var assetlisttable = this.children.assetlistsection.children.assetlisttable;

            assetlisttable[conversionFun] = _.bind(this.model.convertQuantity, this.model, asset);
            assetlisttable[updateFun] = _.bind(this.updateQuantity, this, asset);
            assetlisttable.model.on('change:transferamount_' + asset.assetId, _.bind(this.dataChanged, this));
        },

        setQuantityValues: function (asset, quantityEle) {
            var quantityObj = this.children.assetlistsection.children.assetlisttable.model.get('quantityamount_' + asset.assetId);
            if (valuationService.isConvertToUnits(asset.investmentAsset)) {
                if (!_.isUndefined(quantityObj)) {
                    quantityEle.setOption(quantityObj.option, quantityObj.value);
                } else {
                    quantityEle.setOption('units', '');
                }
            } else {
                quantityEle.hideItem('Units');
                if (!_.isUndefined(quantityObj)) {
                    quantityEle.setOption(quantityObj.option, quantityObj.value);
                } else {
                    quantityEle.setOption('dollars', '');
                }
            }
        },

        getMenuActionItem: function (itemName, quantity) {
            return _.find(quantity.viewData.items, function (item) {
                return item.name === itemName;
            });
        },

        getQuantityElement: function (assetId) {
            var quantityList = this.children.assetlistsection.children.assetlisttable.children;
            var foundClass = this.view.getClassName(assetId);

            if (!_.isUndefined(foundClass)) {
                foundClass = foundClass.substring(4);
                return quantityList[foundClass];
            }
        },

        setSelectedCheckboxes: function () {
            var assetlistData = this.model.get('assetlistData');
            var selectedAssets = this.model.get('selectedIds_selectall_copy');
            _.each(assetlistData, function (assetObj) {
                var checkboxValue = true;
                if (selectedAssets.indexOf(assetObj.assetId) === -1) {
                    checkboxValue = false;
                }
                this.children.assetlistsection.children.assetlisttable.model.set('selectall_' + assetObj.assetId, checkboxValue);
                this.customCheckboxChanged(assetObj.assetId, checkboxValue);
            }, this);
        },

        updateSort: function () {
            this.parentController.isClosePortfolioChanging = true;
            var selectedAssets = _.union(this.model.get('selectedIds_selectall'), []);
            this.model.set('selectedIds_selectall_copy', selectedAssets);

            this.populateAssetlistTable();
            this.setTableBindings();
            this.setSelectedCheckboxes();
            var closePortfolio = this.parentController.model.get('closeportfolio');
            if (closePortfolio) {
                this.toggleAllAssetQuantity(false);
            }
            this.parentController.isClosePortfolioChanging = false;
        },

        getFilteredTableList: function () {
            var assetlistData = this.model.get('assetlistData');
            assetlistData = _.filter(assetlistData, function (assetObj) {
                if (this.pendingMFArray.indexOf(assetObj.assetId) !== -1) {
                    return false;
                }
                return true;
            }, this);
            var transfers = {
                list: assetlistData,
                attributeName: 'assetId'
            };
            return transfers;
        },

        isCheckboxChecked: function (asset) {
            var selectedIds = _.union(this.model.get('selectedIds_selectall_copy'), this.model.get('selectedIds_selectall'));
            var isCheckboxChecked = _.find(selectedIds, function (assetId) {
                return assetId === asset.assetId;
            });
            return isCheckboxChecked;
        },

        getAssetData: function () {
            var assetlistData = this.model.get('assetlistData');
            var transferAssets = [];
            _.each(assetlistData, function (asset) {
                var assetObj;
                var assetlisttable = this.children.assetlistsection.children.assetlisttable;
                var quantityObj = assetlisttable.model.get('quantityamount_' + asset.assetId);
                var transferAmount = assetlisttable.model.get('transferamount_' + asset.assetId);
                if (util.convertToNumber(transferAmount) > 0) {
                    assetObj = this.model.getAssetObj(asset, transferAmount, quantityObj);
                    transferAssets.push(assetObj);
                }
            }, this);

            if (this.parentController.model.get('showCashTable')) {
                var cashquantity = this.children.cashtablesection.children.cashtable.model.get('cashquantity');
                if (cashquantity > 0) {
                    var cashData = this.model.get('cashData');
                    var cashAsset = this.model.getCashAsset(cashData[0], cashquantity);
                    transferAssets.push(cashAsset);
                }
            }
            return {
                totalTransferAmount: this.children.assetlistsection.children.assetlisttable.model.get('totalTransferAmount'),
                transferAssets: transferAssets
            };
        },

        isValid: function () {
            var assetlistData = this.model.get('assetlistData');
            var valid = true;
            _.each(assetlistData, function (asset) {
                var quantityEle = this.getQuantityElement(asset.assetId);
                var quantityObj = quantityEle.getState();
                if (_.isUndefined(quantityEle)) {
                    return;
                }
                if (!quantityEle.model.validateAttribute(quantityObj.option, 'submit').valid) {
                    valid = false;
                }
            }, this);

            if (this.parentController.model.get('showCashTable')) {
                if (!this.children.cashtablesection.children.cashtable.model.validateAttribute('cashquantity', 'submit').valid) {
                    valid = false;
                }
            }
            if ($(".validation-container.custom-invalid").length > 0) {
                valid = false;
            }
            return valid;
        },

        showVettingResponse: function (vettingData) {
            this.model.removeVettErrors();
            var assetlistData = this.model.get('assetlistData');
            var selectedAssets = this.model.get('selectedIds_selectall');
            this.hasAssetVettingError = false;
            var warnings = this.model.removeExcessQuantityError(vettingData.warnings);
            _.each(warnings, function (error) {
                if (_.isNull(error.domain)) {
                    return;
                }
                this.hasAssetVettingError = true;
                var messageObj = {
                    "message": error['message']
                };
                var foundAsset = _.find(assetlistData, function (_asset) {
                    return error.domain === _asset.assetId;
                });
                if (foundAsset && foundAsset.isCashTransfer) {
                    this.showCashVetting(foundAsset, error, messageObj);
                }
                if (_.isUndefined(foundAsset)) {
                    return;
                }
                if (error.errorType === 'error') {
                    foundAsset.vettErrors.push(messageObj);
                } else {
                    foundAsset.vettWarnings.push(messageObj);
                }
            }, this);
            this.model.set('assetlistData', assetlistData);
            this.model.set('selectedIds_selectall', selectedAssets);
            this.resetSectionView(this.hasAssetVettingError);
            this.updateSort();
            this.disablePendingMF();
        },

        showCashVetting: function (asset, error, messageObj) {
            var cashData = this.model.get('cashData');
            cashData[0].vettErrors = [];
            cashData[0].vettWarnings = [];
            if (error.errorType === 'error') {
                cashData[0].vettErrors.push(messageObj);
            } else {
                cashData[0].vettWarnings.push(messageObj);
            }
            this.populateCashTable(cashData);
            if (error.errorType !== 'error') {
                this.children.cashtablesection.children.cashtable.model.set('cashquantity', asset.quantity);
            }
        }
    });
    _.extend(assetlistController.prototype, selectAllCheckboxMixin);
    return assetlistController;
});
