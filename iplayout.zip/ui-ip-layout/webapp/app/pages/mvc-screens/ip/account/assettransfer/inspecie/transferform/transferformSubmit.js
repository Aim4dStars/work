define([
    'underscore', 'jquery', 'rootController',
    'app/pages/mvc-screens/ip/account/assettransfer/util/inspecietransferService', 'app/framework/router'
], function (_, $, rootController, inspecietransferService, router) {
    'use strict';

    return {

        submitForm: function () {
            if (!this.isValid()) {
                return;
            }
            if (this.isAssetCodeValidationRequired()) {
                $.when(this.validateAssetCode()).done(_.bind(function () {
                    if (this.isAssetCodeValid) {
                        this.submitTranserDetails();
                    } else {
                        this.view.hideSpinner();
                    }
                }, this));
            } else {
                this.view.showSpinner();
                this.submitTranserDetails();
            }
        },

        isValid: function () {
            this.children[this.assetTables[0]].removeNonFilledRows();
            var assetSource = this.model.get('assetSource');
            var isForm2Valid = true;

            if (assetSource === 'assetsFromOtherPlatform') {
                this.children[this.assetTables[1]].removeNonFilledRows();
                var form2 = this.children[this.assetTables[1]].getForm();
                isForm2Valid = this.children[this.assetTables[1]].validateAndSubmitForm(null, form2);
            }

            var form1 = this.children[this.assetTables[0]].getForm();
            var isForm1Valid = this.children[this.assetTables[0]].validateAndSubmitForm(null, form1);

            if (!isForm1Valid || !isForm2Valid) {
                return false;
            }
            return true;
        },

        isAssetCodeValidationRequired: function () {
            var managedPortfolio = this.model.get('managedPortfolio');
            var tailoredPortfolio = this.model.get('tailoredPortfolio');
            if (!_.isEmpty(managedPortfolio) || !_.isEmpty(tailoredPortfolio)) {
                return true;
            }
            return false;
        },

        validateAssetCode: function () {
            this.isAssetCodeValid = true;
            var assetCodes = this.getAssetCodes();
            var url = this.universalAssetListURL + "?asset-codes=" + JSON.stringify(assetCodes);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    this.vettAssetCodeError(data.data.resultList);
                }, this)
            };
            this.view.showSpinner();
            return this.ajaxGet(params);
        },

        getAssetCodes: function () {
            var assetSource = this.model.get('assetSource');
            var assetCodes = this.children[this.assetTables[0]].model.getAsxCodes();

            if (assetSource === 'managedFunds') {
                assetCodes = this.children[this.assetTables[0]].model.getApirCodes();
            } else if (assetSource === 'assetsFromOtherPlatform') {
                var apirCodes = this.children[this.assetTables[1]].model.getApirCodes();
                assetCodes = _.union(assetCodes, apirCodes);
            }

            this.model.set('assetCodeArary', assetCodes);
            assetCodes = _.map(assetCodes, function (asset) {
                return _.isString(asset.value) ? asset.value.toUpperCase() : asset.value;
            });
            return assetCodes;
        },

        vettAssetCodeError: function (assetList) {
            this.model.set("universalAAL", assetList);
            _.each(this.model.get("assetCodeArary"), function (code) {
                var newAsset = _.find(assetList, function (asset) {
                    code.value = _.isString(code.value) ? code.value.toUpperCase() : code.value;
                    return code.value === asset.assetCode;
                });
                this.children[this.assetTables[0]].hideAssetCodeError(code.key);
                if (_.isUndefined(newAsset)) {
                    this.children[this.assetTables[0]].showAssetCodeError(code.key);
                    this.isAssetCodeValid = false;
                }
            }, this);
        },

        submitTranserDetails: function () {
            this.viewChildren.uierror.hide();
            this.viewChildren.uiwarning.hide();

            var transferData = this.getTransferData();
            transferData.action = "validate";
            inspecietransferService.submitTransferRequest(this, transferData)
                .done(_.bind(function (data) {
                    var hasErrors = this.handleVettingError(data);
                    this.handleVettingWarning(data);
                    this.parentController.model.set('transferType', transferData.transferType);
                    if (!hasErrors) {
                        this.handleVettingResponse(data);
                    }
                    this.view.hideSpinner();
                }, this))
                .fail(_.bind(function (data) {
                    this.handleVettingError(data);
                    this.handleVettingWarning(data);
                    this.view.hideSpinner();
                }, this));
        },

        handleVettingError: function (data) {
            var hasErrors = false;
            if (!_.isUndefined(data.data)) {
                var uiErrors = data.data.warnings;

                // Filter to errors
                uiErrors = _.filter(uiErrors, function (response) {
                    return response['errorType'] === 'error';
                });

                uiErrors = _.map(uiErrors, function (error) {
                    return error.message;
                });
                if (!_.isEmpty(uiErrors)) {
                    this.view.setUIErrors(uiErrors);

                    this.viewChildren.uierror.show();
                    this.view.setScrollIntoView({
                        element: this.viewChildren.uierror.$el
                    });
                    hasErrors = true;
                } else {
                    this.viewChildren.uierror.hide();
                }
            }
            return hasErrors;
        },

        handleVettingWarning: function (data) {
            if (!_.isUndefined(data.data) && !this.doHideWarnings) {
                var uiWarnings = data.data.warnings;

                // Filter to warnings
                uiWarnings = _.filter(uiWarnings, function (response) {
                    return response['errorType'] === 'warning';
                });

                // Do not show the pending container status warning
                uiWarnings = _.filter(uiWarnings, function (warn) {
                    return warn['errorId'] !== this.PENDING_CONTAINER_STATUS_CODE;
                }, this);

                uiWarnings = _.map(uiWarnings, function (warning) {
                    return warning.message;
                });

                if (!_.isEmpty(uiWarnings)) {
                    this.view.setUIWarnings(uiWarnings);

                    this.viewChildren.uiwarning.show();
                    this.view.setScrollIntoView({
                        element: this.viewChildren.uiwarning.$el
                    });
                } else {
                    this.viewChildren.uiwarning.hide();
                }
            }
        },

        handleVettingResponse: function (data) {
            // Store the state warning message
            this.model.set('submitwarnings', _.map(data.data.warnings, function (warn) {
                return {
                    "errorId": warn.errorId,
                    "domain": warn.domain,
                    "reason": warn.reason,
                    "message": warn.message,
                    "errorType": warn.errorType
                };
            }));
            this.viewChildren.submit.show();
            this.viewChildren.termsandconditions.show();
            this.viewChildren.preview.hide();
        },

        getTransferData: function () {
            var assetSource = this.model.get('assetSource');
            var sponsorDetails = this.children[this.assetTables[0]].getSponsorDetailsDto();
            var transferAssets = this.children[this.assetTables[0]].getTransferAssets(sponsorDetails);

            if (assetSource === 'assetsFromOtherPlatform') {
                sponsorDetails = this.children[this.assetTables[1]].getSponsorDetailsDto();
                transferAssets = _.union(transferAssets, this.children[this.assetTables[1]].getTransferAssets(sponsorDetails));
            }
            var transferData = this.model.getTransferDataDTO();
            transferData.transferType = this.transferTypes[assetSource];
            transferData.transferAssets = transferAssets;

            if (_.isUndefined(this.model.get('containerId'))) {
                transferData['targetAssetId'] = this.model.get('destAssetId');
            }

            if (!_.isUndefined(this.model.get('incomepreference'))) {
                transferData['incomePreference'] = this.model.get('incomepreference');
            }

            var excludedAssets = this.model.get('excludedAssets');
            transferData['transferPreferences'] = _.map(excludedAssets, function (asset) {
                return {
                    issuerKey: asset.issuerId,
                    preference: asset.preference,
                    action: asset.action
                };
            });

            return transferData;
        },

        submitOrder: function () {
            if (!this.model.get('termsandconditions')) {
                this.viewChildren.termsandconditions.turnintoTooltip();
                return;
            }

            var transferData = this.getTransferData();
            transferData['warnings'] = this.model.get('submitwarnings');
            transferData['action'] = 'submit';
            rootController.confirmNavigation(false);
            inspecietransferService.submitTransferRequest(this, transferData)
                .done(_.bind(function (data) {
                    this.parentController.model.set({
                        transferId: data.data.key.transferId,
                        transferType: data.data.transferType,
                        cbo: this.model.get('cbo')
                    });
                    router.appRouter.navigate('#ng/account/assettransfer/inspecie/providedocuments' + rootController.getUrlParamString(), {
                        trigger: true,
                        replace: true
                    });
                    this.view.hideSpinner();
                }, this));

            this.view.showSpinner();
        }
    };
});
