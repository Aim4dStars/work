defineMvcController({
    name: 'contributionstatus',
    parentPath: 'mvc-screens/ip/account/contribution',
    viewHtml: true,
    viewJs: true,
    hashName: 'contributionstatus',
    hashDefault: true,
    extend: 'MvcController',
    mvcComponents: ['tableoptions', 'tablev3'],
    screens: ['cancel', 'regularconfirmation', 'oneoffconfirmation'],
    dependencies: ['app/framework/services/Permissions',
        'rootController',
        'app/pages/mvc-screens/ip/services/superContributionService',
        'underscore',
        'app/pages/mvc-screens/ip/services/accountService',
        'jquery',
        'app/framework/router',
        'app/pages/mvc-screens/ip/services/depositService',
        'app/pages/mvc-screens/ip/account/contribution/contributionstatus/formvalidationModel'
    ]
}, function (config, MvcController, Permissions, rootController, superContributionService, _, accountService, $, router, depositService, FormValidationModel) {
    'use strict';

    var AGE_LIMIT = 75;

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        hasPermission: 'account.super.contribution.view',
        autoHideSpinner: false,

        preRender: function () {
            this.model.set('accountId', rootController.getUrlParams().a);
            $.when(this.parentController.parentController.getAccountPromise())
                .done(_.bind(function (account) {
                    this.model.set('age', accountService.getAge(account.owners));
                    if (this.model.get('age') < AGE_LIMIT) {
                        this.model.set('editable', true);
                    }
                }, this));
        },

        postRender: function () {
            this.viewChildren.agelimitmessage.hide();
            this.parentController.model.unset('toEditSavedContribution');
            this.fetchTransactions();
            this.displayInfoMessage();
        },

        fetchTransactions: function () {
            $.when(superContributionService.fetchContributions(this), superContributionService.fetchSavedContribution(this))
                .done(_.bind(this.populateScreen, this));
        },

        populateScreen: function (scheduleTransactions, savedTransactions) {
            var age = this.model.get('age');
            if (age >= AGE_LIMIT) {
                this.viewChildren.agelimitmessage.show();
                this.children.regularoptions.hide();
                this.children.oneoffoptions.hide();
            }

            this.model.set('savedTransactions', savedTransactions);
            this.model.set('scheduleTransactions', scheduleTransactions);
            scheduleTransactions = _.union(scheduleTransactions, savedTransactions);
            var regularContributions = superContributionService.getRegularContributions(scheduleTransactions);
            this.children.regularpayment.setRows({}, regularContributions);
            this.children.regularpayment.renderComponentView();

            var oneOffContributions = superContributionService.getOneOffContributions(scheduleTransactions);
            this.children.oneoffpayment.setRows({}, oneOffContributions);
            this.children.oneoffpayment.renderComponentView();

            this.view.hideSpinner();
        },

        endDeposit: function (transactionId, metaType, frequency) {
            if (metaType.toLowerCase() === 'incoming payment') {
                metaType = "deposit";
            }

            this.children.cancel.openModal({
                transactionId: transactionId,
                transactionType: metaType,
                frequency: frequency.toLowerCase()
            });
        },

        cancelContribution: function (depositId, type) {
            // Cancel saved contribution
            var toEditSavedContribution = this.findSavedContribution(depositId);
            this.children.cancel.openModal({
                toEditSavedContribution: toEditSavedContribution,
                status: 'savedContribution',
                type: type
            });
        },

        showCancelFailure: function () {
            this.showTopInfoMessage('Ins-IP-0206', 'error');
        },

        showTopInfoMessage: function (messageCode, messageType) {
            var messageConfig = {
                messageCode: messageCode,
                messageType: messageType,
                viewChildren: 'topinfomessage'
            };
            this.parentController.model.set('messageConfig', messageConfig);
            this.displayInfoMessage();
        },

        editDetails: function (depositId, type) {
            this.parentController.model.unset('confirmationError');
            var toEditSavedContribution = this.findSavedContribution(depositId);
            this.parentController.model.set('toEditSavedContribution', toEditSavedContribution);
            this.navigateByType(type);
        },

        findSavedContribution: function (depositId) {
            var savedTransactions = this.model.get('savedTransactions');
            return _.find(savedTransactions, function (savedTransaction) {
                return _.isEqual(savedTransaction.key.depositId, depositId);
            });
        },

        navigateByType: function (type) {
            var urlParams = rootController.getUrlParams();
            if (_.isEqual(type, 'regular')) {
                var urlRegular = '#ng/account/contribution/regularcontribution?a=' + urlParams.a;
                router.appRouter.navigate(urlRegular, {
                    trigger: true,
                    replace: false
                });
            } else if (_.isEqual(type, 'oneoff')) {
                var urlOneOff = '#ng/account/contribution/oneoffcontribution?a=' + urlParams.a;
                router.appRouter.navigate(urlOneOff, {
                    trigger: true,
                    replace: false
                });
            }
        },

        getDataForSubmission: function (toEditSavedContribution, type) {
            return {
                'amount': toEditSavedContribution.amount,
                'transactionDate': toEditSavedContribution.transactionDate,
                'description': toEditSavedContribution.description ? toEditSavedContribution.description : '',
                'frequency': toEditSavedContribution.frequency,
                'endRepeatNumber': toEditSavedContribution.endRepeatNumber ? toEditSavedContribution.endRepeatNumber : '',
                'fromPayDto': {
                    'accountId': toEditSavedContribution.fromPayDto.accountId,
                    'accountName': toEditSavedContribution.fromPayDto.accountName,
                    'code': toEditSavedContribution.fromPayDto.code,
                    'nickname': toEditSavedContribution.fromPayDto.nickname,
                    'payeeType': toEditSavedContribution.fromPayDto.payeeType
                },
                'endRepeat': toEditSavedContribution.endRepeat,
                'repeatEndDate': toEditSavedContribution.repeatEndDate ? toEditSavedContribution.repeatEndDate : '',
                'depositType': toEditSavedContribution.contributionType ? toEditSavedContribution.contributionType.toLowerCase() : '',
                'isRecurring': _.isEqual(type, 'regular'),
                'key': toEditSavedContribution.key,
                'transactionSeq': toEditSavedContribution.transactionSeq
            };
        },

        reviewAndSubmit: function (depositId, type) {
            this.model.set('type', type);
            var toEditSavedContribution = this.findSavedContribution(depositId);
            this.parentController.model.set('toEditSavedContribution', toEditSavedContribution);
            var data = this.getDataForSubmission(toEditSavedContribution, type);
            var validationResult = this.getValidationState(toEditSavedContribution);
            if (validationResult) {
                $.when(depositService.confirmDeposit(this, data), accountService.getAccount(this))
                    .done(_.bind(this.onSubmitSuccess, this))
                    .fail(_.bind(this.onSubmitFailure, this));
            } else {
                var errors = [{
                    message: rootController.getCmsEntry('Err.IP-0906')
                }];
                this.parentController.model.set('confirmationError', errors);
                this.navigateByType(type);
            }
        },

        getValidationState: function (toEditSavedContribution) {
            var validate = {
                age: true,
                linkedAccount: true,
                startDate: true
            };
            var formValidation = new FormValidationModel();
            formValidation.set('type', this.model.get('type'));
            formValidation.set('contributionType', toEditSavedContribution.contributionType);
            validate.age = this.checkAgeLimit(formValidation, validate);
            validate.linkedAccount = this.checkLinkedAccount(formValidation, validate, toEditSavedContribution);
            validate.startDate = this.checkStartDate(formValidation, validate, toEditSavedContribution);

            return validate.age && validate.linkedAccount && validate.startDate;
        },

        checkAgeLimit: function (formValidation, validate) {
            formValidation.set('age', this.model.get('age'));
            validate.age = formValidation.validateAttribute('age', 'submit').valid;
            return validate.age;
        },

        checkLinkedAccount: function (formValidation, validate, toEditSavedContribution) {
            formValidation.set('payer', toEditSavedContribution.payer);
            validate.linkedAccount = formValidation.validateAttribute('payer', 'submit').valid;
            return validate.linkedAccount;
        },

        checkStartDate: function (formValidation, validate, toEditSavedContribution) {
            formValidation.set('depositDate', toEditSavedContribution.startDate);
            validate.startDate = formValidation.validateAttribute('depositDate', 'submit').valid;
            return validate.startDate;
        },

        onSubmitSuccess: function (data, account) {
            var type = this.model.get('type');
            this.model.set('account', account);
            if (_.isEqual(type, 'regular')) {
                var isEndDate = _.isDate(data.repeatEndDate) || !_.isEmpty(data.repeatEndDate);
                data.endRepeat = isEndDate ? null : 'noDate';
                this.children.regularconfirmation.openModal(data);
            } else {
                this.children.oneoffconfirmation.openModal(data);
            }
        },

        onSubmitFailure: function (data) {
            if (!_.isEmpty(data)) {
                var type = this.model.get('type');
                this.parentController.model.set('confirmationError', data);
                this.navigateByType(type);
            }
        },

        showReceipt: function (response, action) {
            var accountDetails = this.parentController.model.get('accountDetails');
            if (response) {
                response.toPayeeDto = this._getToPayeeDto(accountDetails);
                if (!_.isEqual(response.frequency.toLowerCase(), 'once')) {
                    response.isRecurring = true;
                }
                this.parentController.model.set({
                    'submitResponse': response,
                    'action': action
                });
            }
            this.parentController.children.contributionreceipt.show({
                updateLocationHash: true,
                preserveQueryStringParams: true
            });
        },

        _getToPayeeDto: function (accountDetails) {
            return {
                moneyAccountName: accountDetails.accountName,
                moneyAccountId: accountDetails.accountNumber,
                moneyAccountBsb: accountDetails.bsb ? accountDetails.bsb.replace('-', '') : ''
            };
        },

        unsetModelValue: function () {
            this.parentController.model.unset('toEditSavedContribution');
        },

        displayInfoMessage: function () {
            this.hideAllMessages();
            var messageConfig = this.parentController.model.get('messageConfig');
            if (messageConfig) {
                var viewChildrenName = messageConfig.viewChildren;
                var messages = _.isNull(messageConfig.messageCode) ? messageConfig.messages : rootController.getCmsEntry(messageConfig.messageCode);
                this.viewChildren[viewChildrenName].viewData.type = messageConfig.messageType;
                this.viewChildren[viewChildrenName].viewData.html = this.getInfoMessage(messages);
                var requiredViewData = this.setViewData(messageConfig.messageType);
                _.extend(this.viewChildren[viewChildrenName].viewData, requiredViewData);
                this.viewChildren[viewChildrenName].show();
                this.viewChildren[viewChildrenName].render();
            }
        },

        getInfoMessage: function (messages) {
            if (_.isArray(messages)) {
                var infoMessages = [];
                _.each(messages, function (val) {
                    infoMessages.push("<p>" + val.message + "</p><br/>");
                });
                return infoMessages.join().replace(/,/g, '');
            } else {
                return "<p>" + messages + "</p>";
            }
        },

        setViewData: function (messageType) {
            switch (messageType) {
            case 'success':
                return {
                    className: "success",
                    imageName: "icon-message-success"
                };
            case 'error':
                return {
                    className: 'alert',
                    imageName: 'icon-message-error'
                };
            default:
                return {
                    className: null,
                    imageName: null
                };
            }
        },

        hideAllMessages: function () {
            this.viewChildren.topinfomessage.hide();
            this.viewChildren.bottominfomessage.hide();
            this.viewChildren.bottomoneoffinfomessage.hide();
        }
    });
});
