define(['MvcView', 'jquery', 'underscore'],
    function (MvcView, $, _) {
        'use strict';

        return MvcView.extend({
            rootTemplate: {
                headerPanel: 'Asset transfers',
                headerDownload: {
                    items: []
                },
            },
            postRender: function () {
                this.$el.find('.showTermsAndConditionsHyperlink').on('click', _.bind(this.showTerms, this));
            },
            showAssetCodeError: function (element) {
                var validationContainer = $(".parent-" + element).closest(".validation-container");
                validationContainer.addClass("custom-invalid");
                validationContainer.find(".error-asset-code").show();
            },
            hideAssetCodeError: function (element) {
                var validationContainer = $(".parent-" + element).closest(".validation-container");
                validationContainer.removeClass("custom-invalid");
                validationContainer.find(".error-asset-code").hide();
            },
            setUIErrors: function (messages) {
                var $uiErrorMessageContainer = this.$el.find('.view-uierror .message');

                $uiErrorMessageContainer.find('p').not(':eq(0)').remove();
                _.each(messages, function (message) {
                    $uiErrorMessageContainer.append('<p>' + message + '</p>');
                });
            },
            setUIWarnings: function (messages) {
                var $uiWarningMessageContainer = this.$el.find('.view-uiwarning .message');

                $uiWarningMessageContainer.find('p').not(':eq(0)').remove();
                _.each(messages, function (message) {
                    $uiWarningMessageContainer.append('<p>' + message + '</p>');
                });
            },
            showTerms: function (e) {
                //Prevent the showTerms link from triggering the checkbox on click
                e.preventDefault();
                e.stopPropagation();

                //show the terms and conditions modal
                this.controller.children.terms.openModal();
            },
            hideManagedPortfolio: function () {
                this.$el.find('.snapshot-container .snapshot:eq(3) .data-wrapper').hide();
            },

            hideManagedPortfolioTooltip: function () {
                this.$el.find('.managedPortfolioNewTooltip').hide();
            },

            showManagedPortfolioTooltip: function () {
                this.$el.find('.managedPortfolioNewTooltip').show();
            },
            getTransferFormContainer: function () {
                return this.$el.find('.transferFormContainer');
            },
            updateDynamicDisabledFields: function () {
                $('.dynamicDisable').each(function (index) {
                    if (index >= 1) {
                        $(this).find('input').prop('disabled', 'disabled').addClass("ui-state-disabled");
                    } else {
                        $(this).find('input').prop('disabled', null).removeClass("ui-state-disabled");
                    }
                });
            },

            getAllClientRowsForIndexinglds: function (isMF) {
                var pidFieldList = this.$el.find((isMF) ? '.mfquantity' : '.quantity');
                var pidIndexList = [];
                _.each(pidFieldList, function (pidField) {
                    pidIndexList.push(pidField.attributes.assetindex.value);
                }, this);
                return pidIndexList;
            },

            toggleAddButtonContainer: function (hideButton) {
                var elem = this.$el.find('.add-button-container');
                if (hideButton) {
                    elem.hide();
                } else {
                    elem.show();
                }
            }
        });
    });
