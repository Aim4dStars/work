define([
    'MvcModel'
], function (MvcModel) {
    'use strict';

    return MvcModel.extend({

        validation: {

            'disclaimer': {
                blur: {
                    required: true
                }
            }
        }
    });

});
