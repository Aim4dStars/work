defineMvcController({
    name: 'pensioncommencement',
    parentPath: 'mvc-screens/ip/account/details',
    viewHtml: true,
    viewJs: true,
    hashName: 'pensioncommencement',
    defaultHash: true,
    extend: 'MvcController',
    screens: ['accountdetails', 'pensionpayments', 'beneficiaries'],
    dependencies: ['rootController', 'jquery', 'underscore', 'app/pages/mvc-screens/ip/services/accountService', 'app/framework/services/dateService', 'app/framework/helpers/format', 'app/pages/mvc-screens/ip/account/_mixins/super/superBeneficiariesControllerMixin', 'app/framework/router', 'app/framework/services/applicationCache', 'app/framework/services/Permissions'],
}, function (config, MvcController, rootController, $, _, accountService, dateService, format, beneficiariesMixin, router, AppCache, Permissions) {
    'use strict';

    var controller = MvcController.extend({
        config: config,
        autoHideSpinner: false,
        // US18965 requirement for UI to show insufficient balance message
        minStartBalance: 5000,
        accountBalanceUrl: '../api/v1_0/accounts/<%=a%>/balance',
        commencePensionUrl: '../api/v1_0/accounts/<%=a%>/super/commence-pension',
        AUTO_REVERSIONARY: 'auto reversionary',
        DATE_OF_DEATH_ERROR_CODE: 'btfg$chk_dod_pens_comm',


        viewEvents: {
            'submit form': 'submitPensionCommencement'
        },

        preRender: function () {
            this.model.set('accountId', rootController.getUrlParams().a);
            this.model.unset('pensioncommencementerrormessage');
            this.model.unset('dateofdeatherrormessage');
        },

        postRender: function () {
            var beneficiariesController = this.parentController.children.beneficiariesautorev;

            $.when(
                accountService.getAccount(this, true),
                this._fetchAccountBalance(),
                beneficiariesController.fetchBeneficiaries(),
                beneficiariesController.fetchNominationTypes(),
                beneficiariesController.fetchRelationshipTypes(),
                beneficiariesController.fetchGender())
                .then(_.bind(function (account, accountBalance, beneficiaryDetails, nominationTypes, relationshipTypes, genders) {
                        this._populateAccountDetails(account, accountBalance);
                        this._populatePensionPayments(account);
                        this._populateBeneficiaries(beneficiaryDetails.beneficiaries, nominationTypes, relationshipTypes, genders);
                        this.view.hideSpinner();
                    }, this),
                    _.bind(function () {
                        this.model.set('ajaxerrormessage', true);
                        this.view.hideSpinner();
                    }, this));
        },

        submitPensionCommencement: function (event) {
            var validationResult = this.validateAndSubmitForm(event);

            if (validationResult) {
                if (!this.model.get('termsandconditions')) {
                    this.viewChildren.termsandconditions.turnintoTooltip();
                } else {
                    rootController.confirmNavigation(false);
                    this._commencePension();
                }
            }
        },

        _commencePension: function () {
            this.model.set('pensioncommencementerrormessage', false);
            this.model.set('dateofdeatherrormessage', false);
            this.model.set('ajaxerrormessage', false);
            this.view.showSpinner();

            var params = {
                contentType: 'application/json',
                url: this.getUrl(rootController.getUrlParams(), this.commencePensionUrl),
                data: JSON.stringify({}),
                success: _.bind(function (data) {
                    if (_.isObject(data) && _.isObject(data.data) && data.data.transactionStatus === 'saved') {
                        this.navigateToAccountOverview();
                    } else {
                        this.model.set(this._checkForDateOfDeathError(data), true);
                        this.view.scrollToTableTop();
                        this.view.hideSpinner();
                    }
                }, this),
                error: _.bind(function () {
                    this.model.set('ajaxerrormessage', true);
                    this.view.hideSpinner();
                }, this)
            };
            this.ajaxPost(params);
        },

        _checkForDateOfDeathError: function (data) {
            var isDateOfDeathErrorPresent;
            if (_.isObject(data) && _.isObject(data.data) && !_.isEmpty(data.data.errors)) {
                isDateOfDeathErrorPresent = _.find(data.data.errors, function (errorItem) {
                    return errorItem.errorId === this.DATE_OF_DEATH_ERROR_CODE;
                }, this);
            }
            return !_.isEmpty(isDateOfDeathErrorPresent) ? 'dateofdeatherrormessage' : 'pensioncommencementerrormessage';
        },

        navigateToAccountOverview: function () {
            var accountId = this.model.get('accountId');

            // remove cached results to reload account and permissions from server
            accountService.flushCachedAccount(accountId);
            Permissions.clearAccountCache(accountId);

            // set flag for oneoff message
            AppCache.set('pensioncommenced', true);

            // must change href to navigate to account overview to avoid temporarily blanking out hamburger menu
            // ie. cannot use appRouter.navigate()
            this._gotoUrl(this.getUrl(rootController.getUrlParams(), '#ng/account/overview?a=<%=a%>'));
        },

        _gotoUrl: function (url) {
            window.location.href = url;
        },

        _fetchAccountBalance: function () {
            var deferred = $.Deferred();
            var params = {};

            params.url = this.getUrl(rootController.getUrlParams(), this.accountBalanceUrl);
            params.success = _.bind(function (data) {
                deferred.resolve(data.data);
            }, this);
            params.error = _.bind(function () {
                deferred.reject();
            }, this);

            this.ajaxGet(params);
            return deferred.promise();
        },

        _populateAccountDetails: function (account, accountBalance) {
            var child = this.children.accountdetails;
            var model = child.model;
            var valuationDate = new Date();
            var pensionDetails = account.pensionDetails;
            var portfolioValue = (accountBalance && accountBalance.portfolioValue) ? accountBalance.portfolioValue : 0;
            var taxablePercentage = portfolioValue === 0 ? '-' : format.formatPercent(account.taxAndPreservationDetails.nonTaxablePercentage / 100, 2, '%');

            model.set({
                'portfolioValue': portfolioValue,
                'valuationDate': format.formatDate(valuationDate, {
                    'convertTimezone': true,
                    'format': 'dd MMM YYYY',
                    'type': 'date'
                }),
                'nonTaxablePercentage': taxablePercentage,
                'actualRolloverCount': pensionDetails.actualRolloverCount,
                'estimatedRolloverCount': pensionDetails.estimatedRolloverCount,
                'moreRolloverExpectedHtml': pensionDetails.actualRolloverCount + ' of ' + pensionDetails.estimatedRolloverCount
            });

            if (portfolioValue < this.minStartBalance) {
                this.model.set('insufficientstartbalancemessage', true);
            }

            child.view.render();
        },

        _populatePensionPayments: function (account) {
            var child = this.children.pensionpayments;
            var model = child.model;
            var pensionDetails = account.pensionDetails;
            var linkedAccounts = account.linkedAccounts;
            var paymentAmount = this._getPaymentAmount(pensionDetails);

            model.set({
                'paymentAmount': paymentAmount,
                'pensionType': pensionDetails.pensionType,
                'paymentType': pensionDetails.paymentType,
                'indexationMethodInfo': this._getIndexationMethodInfo(pensionDetails),
                'frequency': pensionDetails.paymentFrequency,
                'firstPaymentDate': format.formatDate(pensionDetails.firstPaymentDate, {
                    'convertTimezone': true,
                    'format': 'dd MMM YYYY',
                    'type': 'date'
                }),
                'showMinPaymentWarning': this._showMinPaymentWarningFlag(pensionDetails.paymentType),
                'daysOfFirstPaymentDateFromToday': pensionDetails.daysToFirstPayment
            });

            if (!_.isUndefined(linkedAccounts)) {
                var pensionAccount = _.find(linkedAccounts, function (account) {
                    return account.pensionPayment === true;
                }, this);

                if (pensionAccount) {
                    model.set({
                        'accountName': pensionAccount.name,
                        'bsb': format.formatBSB(pensionAccount.bsb),
                        'accountNumber': pensionAccount.accountNumber
                    });
                }
            }

            child.view.render();
        },

        _showMinPaymentWarningFlag: function (paymentType) {
            var today = dateService.localDateFromIsoString(dateService.today());
            var minPaymentWarningFirstDate = dateService.localDateFromIsoString(today.getFullYear() + '-05-31');
            var minPaymentWarningDateAfterLastDate = dateService.localDateFromIsoString(today.getFullYear() + '-07-01');

            return paymentType === 'Minimum amount' && minPaymentWarningFirstDate.getTime() <= today.getTime() && today.getTime() <= minPaymentWarningDateAfterLastDate.getTime() - 1;
        },

        _getPaymentAmount: function (pensionDetails) {
            switch (pensionDetails.paymentType) {
            case 'Specific amount':
                return format.formatMoney(pensionDetails.paymentAmount, 2, '$');

            case 'Minimum amount':
                return 'Minimum';

            case 'Maximum amount':
                return 'Maximum';

            default:
                return pensionDetails.paymentType;
            }
        },

        _getIndexationMethodInfo: function (pensionDetails) {
            if (pensionDetails.paymentType !== 'Specific amount' || _.isUndefined(pensionDetails.indexationType) || _.isNull(pensionDetails.indexationType)) {
                return '';
            }

            switch (pensionDetails.indexationType.toUpperCase()) {
            case 'CPI':
                return '(Indexed to CPI)';

            case 'PERCENTAGE':
                return '(Indexed by ' + format.formatPercent(this._getIndexationAmount(pensionDetails) / 100, 2, '%') + ')';

            case 'DOLLAR':
                return '(Indexed by ' + format.formatMoney(this._getIndexationAmount(pensionDetails), 2, '$') + ')';

            default:
                return '(No indexation)';
            }
        },

        _getIndexationAmount: function (pensionDetails) {
            return pensionDetails.indexationAmount ? pensionDetails.indexationAmount : 0;
        },

        _populateBeneficiaries: function (beneficiaries, nominationTypes, relationshipTypes, genders) {
            var child = this.children.beneficiaries;
            var model = child.model;

            beneficiariesMixin._prepareRelationshipTypes(relationshipTypes);
            beneficiariesMixin._prepareBeneficiaries(beneficiaries, nominationTypes, relationshipTypes, genders, false);

            _.each(beneficiaries, function (beneficiary) {
                if (beneficiary.allocationPercent) {
                    beneficiary.allocationPercent = beneficiary.allocationPercent / 100;
                }
            });
            model.set('beneficiaries', this._formatBeneficiariesData(beneficiaries));
            child.view.render();
        },

        _formatBeneficiariesData: function (beneficiaries) {
            var beneficiariesList = [];
            var beneficiariesGroups = _.groupBy(beneficiaries, function (beneficiary) {
                if (beneficiary.nominationTypeLabel.toLowerCase() === this.AUTO_REVERSIONARY) {
                    beneficiary.showSectionHeader = true;
                    return 'primaryNomination';
                } else {
                    return 'secondaryNominations';
                }
            }, this);
            if (!_.isUndefined(beneficiariesGroups.primaryNomination) && beneficiaries.length) {
                if (_.isUndefined(beneficiariesGroups.secondaryNominations)) {
                    beneficiariesGroups.primaryNomination[0].showSecondaryEmptystateMsg = true;
                    beneficiariesList = beneficiariesGroups.primaryNomination;
                } else {
                    beneficiariesList = _.union(beneficiariesGroups.primaryNomination, beneficiariesGroups.secondaryNominations);
                }
            } else {
                beneficiariesList = beneficiaries;
            }
            return beneficiariesList;
        },

        _getLabelForType: function (list, predicate) {
            var result = _.findWhere(list, predicate);

            if (result) {
                return result.label;
            }

            return '';
        },

        _getBeneficiaryName: function (beneficiary) {
            return ((beneficiary.firstName || '') + ' ' + (beneficiary.lastName || '')).trim();
        },

        _getSubInfoLabel: function (labels) {
            return _.reduce(labels, function (str, item) {
                    if (item && item.trim() !== '') {
                        if (str.length === 0) {
                            return item;
                        }

                        return str + ', ' + item;
                    }

                    return str;
                },
                '');
        }
    });

    _.extend(controller.prototype, beneficiariesMixin);

    return controller;
});
