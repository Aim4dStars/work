defineMvcController({
    name: 'uploadfile',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie/inspecieupload',
    viewHtml: true,
    viewJs: true,
    extend: 'MvcController',
    hashDefault: false,
    dependencies: ['app/framework/router', 'underscore', 'rootController', 'app/pages/mvc-screens/ip/services/inspecieUploadService',
        'app/pages/mvc-screens/ip/account/assettransfer/util/inspecietransferService']
}, function (config, MvcController, router, _, rootController, inspecieUploadService, inspecietransferService) {
    'use strict';

    return MvcController.extend({
        config: config,
        PENDING_CONTAINER_STATUS_CODE: 'btfg$mdf_mp_cont_status',

        uploadAssetDetails: function () {
            this.view.triggerFileUpload();
        },

        onFileSelected: function () {
            this.parentController.model.set('showUploadErrorMessage', false);

            var files = this.view.getFiles();
            if (_.isObject(files) && files.length > 0 && !this.fileUploading) {
                var file = files[0];
                var transferData = this.parentController.getTransferData();
                var sponsorSelector = {};
                if (_.isFunction(this.parentController.getSponsorSelector)) {
                    sponsorSelector = this.parentController.getSponsorSelector();
                }

                this.fileUploading = true;
                inspecieUploadService.uploadFile(this, file, transferData, sponsorSelector.sponsorname, sponsorSelector.sponsorpid)

                .done(_.bind(this.onUploadSuccess, this))
                    .fail(_.bind(this.onUploadFailure, this));

                this.parentController.showUploadStatus();
            }
        },

        onUploadSuccess: function (vettingResponse, warnings) {
            this.fileUploading = false;
            this.model.set('vettingResponse', vettingResponse);
            var transferInto = this.parentController.getTransferInto();
            var successData = {
                'assetSource': this.parentController.getAssetSource(),
                'warnings': this.filterWarnings(warnings),
                'transferInto': transferInto.transferInto,
                'managedportfolios': transferInto.managedportfolios,
                'tailoredportfolios': transferInto.tailoredportfolios
            };
            this.parentController.model.set('successData', successData);
            this.parentController.setUploadSuccess(successData);
        },

        filterWarnings: function (warnings) {
            // Do not show the pending container status warning - only relevant within Avaloq smartclient
            return _.filter(warnings, function (warning) {
                return warning['errorId'] !== this.PENDING_CONTAINER_STATUS_CODE;
            }, this);
        },

        onUploadFailure: function (errors) {
            this.fileUploading = false;

            this.parentController.setUploadFailure(errors);
        },

        submit: function () {
            var vettingResponse = this.model.get('vettingResponse');

            vettingResponse.action = "submit";
            this.parentController.setUploadInProgress();
            var useOldUrlVersion = false;
            var transferData = this.parentController.getTransferData();
            if (!_.isUndefined(transferData.transferId)) {
                useOldUrlVersion = true;
            }
            inspecietransferService.submitTransferRequest(this, vettingResponse, useOldUrlVersion)
                .done(_.bind(function (data) {
                    this.parentController.hideUploadStatus();
                    rootController.confirmNavigation(false);
                    this.parentController.submitCallback(data);

                }, this))
                .fail(_.bind(function (data) {
                    var errors = _.filter(data.data.warnings, function (warning) {
                        return warning.errorType === 'error';
                    });
                    this.onUploadFailure(errors);
                }, this));
        },

        setFileUploading: function (flag) {
            this.fileUploading = flag;
        }

    });
});
