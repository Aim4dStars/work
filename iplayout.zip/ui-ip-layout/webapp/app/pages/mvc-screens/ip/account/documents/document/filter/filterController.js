defineMvcController({
    name: 'filter',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    modelJs: true,
    viewJs: true,
    extend: 'MvcController',
    viewComponents: ['forminputcheckbox', 'forminputtext', 'forminputselect', 'inputcheckbox', 'forminputdaterange'],
    mvcComponents: ['inputautocomplete'],
    dependencies: ['underscore', 'rootController', 'app/framework/services/optionsService']
}, function (config, MvcController, _, rootController, optionsService) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            this.model.set('filtersObject', this.parentController.parentController.model.filterMap);
        },

        postRender: function () {
            this.setLOVs();
            if (optionsService.getOption('adviser.documents.filter.scheme', 'a') === 'challenger') {
                this.model.on('change:formuploadedRole', this._updateDocType, this);
            } else {
                this.model.on('change:formdocumentType', this._updateDocSubType, this);
                this.model.on('change:formdocumentSubType', this._updateDocSubSubType, this);
            }
            this._setDefaults();
        },

        _updateDocType: function () {
            var uploadRole = this.model.get('formuploadedRole');
            var documentTypes = this.parentController.parentController.model['documentTypes' + uploadRole];
            if (documentTypes) {
                this.viewChildren.formdocumenttype.setOptions(documentTypes);
                this.viewChildren.formdoctypecomp.show();
            } else {
                this.viewChildren.formdoctypecomp.hide();
            }
            this.model.set('formdocumentType', 'any');
        },

        _updateDocSubType: function () {
            var docType = this.model.get('formdocumentType');
            var documentSubTypes = this.parentController.parentController.model['documentSubTypes' + docType];
            if (documentSubTypes) {
                this.viewChildren.formdocumentsubtype.setOptions(documentSubTypes);
                this._showDocSubType();
            } else {
                this._hideDocSubType();
            }
            this.model.set('formdocumentSubType', 'any');
        },

        _updateDocSubSubType: function () {
            var documentSubTypes = this.model.get('formdocumentSubType');
            if (documentSubTypes) {
                var documentSubSubTypes = this.parentController.parentController.model['documentSubTypes2' + documentSubTypes.replace(/\s/g, '')];
                if (documentSubSubTypes) {
                    this.viewChildren.formdocumentsubtype2.setOptions(documentSubSubTypes);
                    this._showDocSubSubType();
                } else {
                    this._hideDocSubSubType();
                }
                this.model.set('formdocumentSubType2', 'any');
            }

        },

        setLOVs: function () {
            var anyObject = {
                label: 'Any',
                value: 'any'
            };
            var documentTypes = _.reject(_.clone(this.parentController.parentController.model.documentTypes), function (documentType) {
                return documentType.hideOnFilter;
            });
            var uploadedBys = this.parentController.parentController.model.uploadedBys;
            if (optionsService.getOption('adviser.documents.filter.scheme', 'a') === 'challenger') {
                uploadedBys = this.parentController.parentController.model.uploadedBysChallenger;
            }
            var financialYears = _.clone(this.parentController.parentController.model.get('financialYears'));
            if (documentTypes) {
                documentTypes.unshift(anyObject);
                this.viewChildren.formdocumenttype.setOptions(documentTypes);
            }
            if (uploadedBys) {
                this.viewChildren.formuploadedrole.setOptions(uploadedBys);
            }
            if (financialYears && this.viewChildren.formfinancialyear) {
                financialYears.unshift(anyObject);
                this.viewChildren.formfinancialyear.setOptions(financialYears);
            }
        },

        _hideDocSubType: function () {
            this.viewChildren.formdocsubtypecomp.hide();
        },

        _showDocSubType: function () {
            this.viewChildren.formdocsubtypecomp.show();
        },

        _hideDocSubSubType: function () {
            this.viewChildren.formdocsubsubtypecomp.hide();
        },

        _showDocSubSubType: function () {
            this.viewChildren.formdocsubsubtypecomp.show();
        },

        getValues: function () {
            var values = {};
            _.each(this.model.attributes, function (val, key) {
                if (/^form/.test(key)) {
                    values[key] = val;
                }
            }, this);
            return values;
        },

        setValues: function (values) {
            _.each(values, function (value, key) {
                this.model.set(key, value);
            }, this);
        },

        _setDefaults: function () {
            //&type=SMSF&subtype=SMSF Fund Administration&subsubtype=MSTDOCS
            var params = rootController.getUrlParams();

            this._setDefaultFilterDate('formstartUploadedDate', new Date(params.sd));
            this._setDefaultFilterDate('formendUploadedDate', new Date(params.ed));

            var documentType = params.type;
            var documentSubType = params.subtype || '';
            var documentSubSubType = params.subsubtype;
            var documentModel = this.parentController.parentController.model;

            if (this._isValidAttribute(documentModel.documentTypes, documentType)) {
                this.model.set('formdocumentType', documentType);
                var documentSubTypes = documentModel['documentSubTypes' + documentType];
                var documentSubSubTypes = documentModel['documentSubTypes2' + documentSubType.replace(/\s/g, '')];

                if (this._isValidAttribute(documentSubTypes, documentSubType)) {
                    this.model.set('formdocumentSubType', documentSubType);
                    this.viewChildren.formdocumentsubtype.setOptions(documentSubTypes);
                    this._showDocSubType();
                }

                if (this._isValidAttribute(documentSubSubTypes, documentSubSubType)) {
                    this.model.set('formdocumentSubType2', documentSubSubType);
                    this.viewChildren.formdocumentsubtype2.setOptions(documentSubSubTypes);
                    this._showDocSubSubType();
                }
            }
        },

        _setDefaultFilterDate: function (modelAttribute, dateValue) {
            if (_.isDate(dateValue) && String(dateValue) !== 'Invalid Date') {
                var validated = this.model.validateValue(dateValue, modelAttribute);
                if (_.isObject(validated) && validated.valid) {
                    this.model.set(modelAttribute, dateValue);
                }
            }
        },

        _isValidAttribute: function (list, value) {
            return _.findWhere(list, {
                value: value
            });
        },

        validateFilterForm: function () {
            return this.validateAndSubmitForm(null, this.view.getFilterForm());
        }
    });
});
