defineMvcController({
    name: 'unrealised',
    parentPath: 'mvc-screens/ip/account/cgt',
    viewHtml: true,
    modelJs: true,
    viewJs: true,
    hashDefault: true,
    viewComponents: ['search', 'forminputdate', 'messagedisclaimer'],
    mvcComponents: ['tableoptions', 'section'],
    screens: ['unrealisedportfolio', 'unrealisedsecurity'],
    hashName: 'unrealised',
    extend: 'app/pages/mvc-screens/ip/account/cgt/cgtBaseController',
    dependencies: ['rootController', 'underscore']
}, function (config, CgtBaseController, rootController, _) {
    'use strict';

    return CgtBaseController.extend({
        config: config,
        viewByChildren: ['unrealisedportfolio', 'unrealisedsecurity'],
        defaultViewBy: 'unrealisedportfolio',
        defaultTotalColumns: [20, 7, 7, 7],
        showParcelsTotalColumns: [22, 7, 6, 6],
        showTaxDetailsTotalColumns: [24, 6, 6, 24],

        getFetchParams: function () {
            var datedetail = this.model.get('datedetail');
            if (_.isUndefined(datedetail)) {
                this.model.init();
            }
            return "effective-date=" + encodeURIComponent(this.model.dateDetailsDateString());
        },

        buildPdfLink: function () {
            var url = '../reportpdf/unrealisedCapitalGainsTaxReportV2';
            url += '?account-id=' + rootController.getUrlParams().a;
            url += '&effective-date=' + encodeURIComponent(this.model.dateDetailsDateString());
            url += '&order-by=' + this.getOrderBy();

            window.open(url, '_report');
        },

        buildCsvLink: function () {

            var url = '../reportcsv/unrealisedCapitalGainsTaxCsvReport';
            url += '?account-id=' + rootController.getUrlParams().a;
            url += '&effective-date=' + encodeURIComponent(this.model.dateDetailsDateString());

            window.open(url, '_report');
        }
    });

});
