defineMvcController({
    name: 'chargeoneoff',
    parentPath: 'mvc-screens/ip/account/fees',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['forminputtext', 'button'],
    screens: ['details', 'confirmation'],
    hashName: 'chargeoneoff',
    extend: 'app/pages/mvc-templates/formwizard/formwizardController',
    dependencies: ['underscore', 'rootController', 'app/framework/services/Permissions', 'app/framework/services/dateService', 'app/framework/helpers/format']
}, function (config, MvcController, _, rootController, Permissions, dateService, format) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.fee.advice.update',
        targetId: 'a',
        requiredParams: ['a'],
        childForms: [],
        forms: [],
        lastStep: null,
        currentChild: 'details',
        urlAdviseFees: '../api/v1_0/fees/accounts/<%=a%>/advicefees',

        preRender: function () {
            if (Permissions.ruleMatched('account.fee.block.view', rootController.getUrlParams().a)) {
                this.childForms = ['details', 'confirmation'];
            }
            this.model.set('accountId', rootController.getUrlParams().a);
        },

        postRender: function () {
            this.parentController._hideErrorMessage();
            this.initForms();
        },

        submitMultiStepForm: function () {
            var params = {
                url: this.getUrl(rootController.getUrlParams(), this.urlAdviseFees),
                data: {
                    'feesAmount': this.model.get('feesAmount'),
                    'description': this.model.get('description')
                },
                success: _.bind(function (data) {
                    this.parentController._hideErrorMessage();
                    if (data.data && !this.isError(data.data.warnings)) {
                        this.model.set('submitDate', data.data.submitDate);
                        this.model.set('feesAmount', data.data.feesAmount);
                        this.model.set('description', data.data.description);
                        var message = format.formatMoney(data.data.feesAmount, 2, '$') + ' one-off advice fee successfully charged';
                        if (_.isString(data.data.description)) {
                            message += " for: " + data.data.description;
                        }
                        message += ' (';
                        message += format.formatDate(dateService.now(), {
                            'includeTimezoneLabel': true,
                            'convertTimezone': true,
                            'format': 'dd MMM YYYY h:nna/p',
                            'type': 'date'
                        });
                        message += ')';

                        this.parentController.model.set('successMessage', message);
                        this.parentController.show({
                            updateLocationHash: true,
                            preserveQueryStringParams: true
                        });


                    } else {
                        this.checkError(data);
                    }
                    this._unloadSpinner();
                }, this),
                error: _.bind(function (jqXHR, textStatus, errorThrown) {
                    this.parentController._setErrorMessage(errorThrown);
                    this.parentController._showErrorMessage();
                    this.view.hideError();
                    this._unloadSpinner();
                }, this),
            };
            this._loadSpinner();
            this.ajaxPost(params);
        },

        _unloadSpinner: function () {
            if (this.children && this.children.confirmation && this.children.confirmation.view) {
                this.children.confirmation.view.unloadSpinner();
            }
        },

        _loadSpinner: function () {
            if (this.children && this.children.confirmation && this.children.confirmation.view) {
                this.children.confirmation.view.loadSpinner();
            }
        },

        isError: function (errorList) {
            var result = false;
            if (errorList) {
                for (var el in errorList) {
                    if (errorList[el].errorType === 'error') {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        },

        checkError: function (data) {
            this.view.clearError();
            for (var i = 0; i < data.data.warnings.length; i++) {
                if (data.data.warnings[i]['errorType'] !== 'error') {
                    continue;
                }
                var code;
                //conversion of error id to cms code
                switch (data.data.warnings[i]['message']) {
                case 'btfg$fee_cap_aggr_exceed':
                    code = 'Err.IP-0086';
                    this.view.showError(rootController.getCmsEntry(code));
                    break;
                case 'btfg$fee_insuff_cash':
                    code = 'Err.IP-0077';
                    this.view.showError(rootController.getCmsEntry(code));
                    break;
                default:
                    code = 'Err.IP-0344';
                    this.view.showError(rootController.getCmsEntry(code));
                    //this.view.showError(data.data.warnings[i]['message']);
                }
            }
        },

        absFeeAmount: function (value) {
            if (value < 0) {
                return value * -1;
            }
            return value;
        },

        navigateToChild: function (targetChildName) {
            if (this.children && this.children[targetChildName]) {
                this.children[targetChildName].show({
                    updateLocationHash: true,
                    preserveQueryStringParams: true
                });
            }
        },

        cancelForm: function () {
            this.closeModal();
            if (this.currentChild && this.children && this.children[this.currentChild]) {
                this.children[this.currentChild].cancelFornm();
            }
        },

        omnitureEventTrigger: function (controller, step) {
            if (step === 'complete') {
                window.org.bt.EventChannel.trigger('account.fees.complete', {
                    url: window.location.href,
                    hash: window.location.hash,
                    pageType: 'payment',
                    transactionType: 'one-off advice fee',
                    formName: 'charge one-off advice fee',
                    pageStep: step,
                    transactionAmount: controller.model.get('absFeesAmount')
                });
            } else {
                window.org.bt.EventChannel.trigger('account.fees.start', {
                    url: window.location.href,
                    hash: window.location.hash,
                    pageType: 'payment',
                    transactionType: 'one-off advice fee',
                    formName: 'charge one-off advice fee',
                    pageStep: step
                });
            }
        }

    });

});
