defineMvcController({
    name: 'statusfilter',
    parentPath: 'mvc-screens/ip/account/corporateaction/election',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['forminputautocomplete', 'forminputselect'],
    mvcComponents: ['inputautocomplete'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/statusfilter/statusfilterController'
}, function (config, StatusfilterController) {
    'use strict';

    return StatusfilterController.extend({
        config: config
    });
});
