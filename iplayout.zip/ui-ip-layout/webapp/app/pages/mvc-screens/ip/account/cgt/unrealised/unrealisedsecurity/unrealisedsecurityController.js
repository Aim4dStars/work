defineMvcController({
    name: 'unrealisedsecurity',
    parentPath: 'mvc-screens/ip/account/cgt/unrealised',
    viewHtml: true,
    modelJs: false,
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['inputdate'],
    hashName: 'unrealisedsecurity',
    extend: 'app/pages/mvc-screens/ip/account/cgt/cgtBaseViewByController',
    dependencies: []
}, function (config, CgtViewByBaseController) {
    'use strict';

    return CgtViewByBaseController.extend({
        config: config,
        urlTemplate: '../api/v1_0/accounts/<%=a%>/unrealised-cgtBySecurity',
        taxColumns: [6, 8, 9],
        showQuantity: true,
        detailSort: 'ascendingPortfolioName',
        repeatingAssetProperty: 'parentInvCode',
        totalColspan: 5,
        title: 'unrealised'
    });

});
