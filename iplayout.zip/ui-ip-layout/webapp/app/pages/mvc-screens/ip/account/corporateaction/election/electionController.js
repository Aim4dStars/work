defineMvcController({
    name: 'election',
    parentPath: 'mvc-screens/ip/account/corporateaction',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['snapshot', 'inputdate', 'tooltip', 'button', 'messagealert'],
    hashName: 'election',
    hashDefault: true,
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/electionController',
    screens: ['statusfilter', 'terms', 'multiblock', 'rightsexercise', 'baseelectionform', 'buyback', 'baseelectiontable', 'mvc-screens/ip/tracking/corporateaction/election/bulkelection', 'mvc-screens/ip/tracking/corporateaction/election/modelelectiontable'],
}, function (config, ElectionController) {
    'use strict';

    return ElectionController.extend({
        config: config
    });

});
