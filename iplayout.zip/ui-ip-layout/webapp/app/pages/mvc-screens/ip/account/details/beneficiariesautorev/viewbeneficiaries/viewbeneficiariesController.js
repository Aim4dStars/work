defineMvcController({
    name: 'viewbeneficiaries',
    parentPath: 'mvc-screens/ip/account/details/beneficiariesautorev',
    viewHtml: true,
    viewJs: true,
    hashName: 'viewbeneficiaries',
    defaultHash: true,
    viewComponents: ['button', 'messagealert'],
    mvcComponents: ['tablev3'],
    dependencies: ['underscore', 'jquery', 'app/framework/helpers/format', 'rootController'],
    extend: 'MvcController',
}, function (config, MvcController, _, $, formatHelper, rootController) {
    'use strict';

    return MvcController.extend({
        config: config,
        autoHideSpinner: false,
        viewEvents: {
            'click .js-fullname-link': '_setSelectedFullname'
        },

        secondarynominationsTableHeader: 'SECONDARY NOMINATIONS',
        primarynominationsTableHeader: 'PRIMARY NOMINATION',

        preRender: function () {
            var nominationTables = [{
                'tableName': 'primarynominations',
            }, {
                'tableName': 'secondarynominations',
            }];
            this.model.set('nominationTables', nominationTables);
        },

        postRender: function () {
            this._hideMessage('ajaxerror');
            this.view.hideBeneficiariesLastUpdated();
            delete this.parentController.clickedFullname;
            this._loadData();
            this._checkForOneTimeSuccessMsg();
        },

        _checkForOneTimeSuccessMsg: function () {
            this.model.set('isBeneficiariesSaved', this.parentController.model.get('isBeneficiariesSaved'));
            this.parentController.model.unset('isBeneficiariesSaved');
        },

        _setSelectedFullname: function (event) {
            var $el = $(event.currentTarget);
            this.parentController.model.set('selectedFullname', $el.html());
        },

        _loadData: function () {
            $.when(
                this.parentController.fetchBeneficiaries(),
                this.parentController.fetchNominationTypes(),
                this.parentController.fetchRelationshipTypes(),
                this.parentController.fetchGender()
            ).then(_.bind(function (beneficiaryDetails, nominationTypes, relationshipTypes, genders) {
                    var table = this.children;
                    this._prepareRelationshipTypes(relationshipTypes);
                    this._setupBeneficiarieslastUpdated(beneficiaryDetails.beneficiariesLastUpdatedTime);
                    this._prepareBeneficiaries(beneficiaryDetails.beneficiaries, nominationTypes, relationshipTypes, genders);
                    var beneficiariesNominationTablesData = this.parentController._formatBeneficiaryData(beneficiaryDetails.beneficiaries);
                    this._renderBeneficiariesTableData(table.primarynominations, table.secondarynominations, beneficiariesNominationTablesData, beneficiaryDetails.totalAllocationPercent);
                    this.view.hideSpinner();
                }, this),
                _.bind(function () {
                    this._showMessage('ajaxerror');
                    this.view.hideSpinner();
                }, this));
        },

        _renderBeneficiariesTableData: function (primarynominationsTable, secondarynominationsTable, beneficiariesNominationTablesData, totalAllocationPercent) {
            var emptyStateMsg;
            if (!this.parentController.model.get('isprimaryNominationAvailable')) {
                emptyStateMsg = this._checkForEmptyStateMsg(false);
                secondarynominationsTable.setRows({
                    rowName: 'beneficiaries',
                }, beneficiariesNominationTablesData.nominations);
                secondarynominationsTable.model.set({
                    'emptyStateMsg': emptyStateMsg,
                    'totalAllocationPercent': totalAllocationPercent
                });
                secondarynominationsTable.renderComponentView();
                primarynominationsTable.view.hide();
                this.view.hideTableCaption();
            } else {
                emptyStateMsg = this._checkForEmptyStateMsg(true);
                secondarynominationsTable.setRows({
                    rowName: 'secondaryNominations',
                }, beneficiariesNominationTablesData.secondaryNominations);
                secondarynominationsTable.model.set({
                    'tableHeader': this.secondarynominationsTableHeader,
                    'emptyStateMsg': emptyStateMsg,
                    'footerLabel': 'secondary',
                    'totalAllocationPercent': formatHelper.formatMoney(beneficiariesNominationTablesData.secondaryNominations.totalAllocationPercent)
                });
                primarynominationsTable.setRows({
                    rowName: 'primaryNominations',
                }, beneficiariesNominationTablesData.primaryNomination);
                primarynominationsTable.model.set({
                    'tableHeader': this.primarynominationsTableHeader,
                    'totalAllocationPercent': beneficiariesNominationTablesData.primaryNomination.totalAllocationPercent
                });
                primarynominationsTable.renderComponentView();
                secondarynominationsTable.renderComponentView();
                this.view.hideSecondarynominationsTableHeader(secondarynominationsTable);
            }
        },

        _checkForEmptyStateMsg: function (isprimaryNominationAvailable) {
            return isprimaryNominationAvailable ? rootController.getCmsEntry('Ins-IP-0236') : rootController.getCmsEntry('Ins-IP-0150');
        },

        _prepareRelationshipTypes: function (relationshipTypes) {
            _.each(relationshipTypes, function (relationshipType) {
                relationshipType.label = this.toSentenceCase(relationshipType.label);
            }, this);
        },

        toSentenceCase: function (normalStr) {
            if ((normalStr === null) || (normalStr === '')) {
                return normalStr;
            }

            return normalStr.charAt(0).toUpperCase() + normalStr.substr(1).toLowerCase();
        },

        _prepareBeneficiaries: function (beneficiaries, nominationTypes, relationshipTypes, genders) {
            _.each(beneficiaries, function (beneficiary) {
                var beneficiaryName = this._getBeneficiaryName(beneficiary);

                beneficiary.nominationTypeLabel = this._getLabelForType(nominationTypes, {
                    intlId: beneficiary.nominationType
                });
                beneficiary.relationshipTypeLabel = this._getLabelForType(relationshipTypes, {
                    intlId: beneficiary.relationshipType
                });
                beneficiary.genderLabel = this._getLabelForType(genders, {
                    intlId: beneficiary.gender
                });

                if (beneficiaryName === '') {
                    beneficiary.fullName = beneficiary.relationshipTypeLabel;
                    beneficiary.subInfo = this._getSubInfoLabel([beneficiary.dateOfBirth,
                        beneficiary.genderLabel]);
                } else {
                    beneficiary.fullName = beneficiaryName;
                    beneficiary.subInfo = this._getSubInfoLabel([beneficiary.dateOfBirth,
                        beneficiary.genderLabel, beneficiary.relationshipTypeLabel]);
                }

                beneficiary.email = this._getAsDashIfEmpty(beneficiary.email);
                beneficiary.phoneNumber = this._formatTelephone(beneficiary.phoneNumber);
            }, this);
        },

        _getLabelForType: function (list, predicate) {
            var result = _.findWhere(list, predicate);

            if (result) {
                return result.label;
            }

            return '';
        },

        _getBeneficiaryName: function (beneficiary) {
            return ((beneficiary.firstName || '') + ' ' + (beneficiary.lastName || '')).trim();
        },

        _getSubInfoLabel: function (labels) {
            return _.reduce(labels, function (str, item) {
                    if (item && item.trim() !== '') {
                        if (str.length === 0) {
                            return item;
                        }

                        return str + ', ' + item;
                    }

                    return str;
                },
                '');
        },

        _formatTelephone: function (str) {
            var formatted = formatHelper.formatTelephone(str);
            return this._getAsDashIfEmpty(formatted);
        },

        _getAsDashIfEmpty: function (str) {
            return (str && !_.isEmpty(str.trim())) ? str.trim() : '-';
        },

        _setupBeneficiarieslastUpdated: function (date) {
            if (!_.isUndefined(date) && !_.isNull(date)) {
                this.model.set('beneficiariesLastUpdatedDate', formatHelper.formatDate(date, {
                    'convertTimezone': true,
                    'format': 'dd MMM YYYY',
                    'type': 'date'
                }));

                this.view.showBeneficiariesLastUpdated();
            }
        },

        _showMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].hide();
            }
        },

        buildPdfLink: function () {
            window.open('../reportpdf/beneficiaryDetailsPdfReport?account-id=' + rootController.getUrlParams().a, '_report');
        },

    });
});
