define([
    'MvcView', 'jquery', 'underscore', 'app/framework/services/Permissions', 'app/framework/services/optionsService'
], function (MvcView, $, _, Permissions, optionsService) {
    'use strict';

    return MvcView.extend({
        preRender: function () {
            // Change title and show no tabs if super/pension account
            var assetTransferLabel = optionsService.getOption('assettransfer.menu.description', 'a');
            if (assetTransferLabel === 'Intra account transfers') {
                this.rootTemplate = {
                    headerPanel: assetTransferLabel,
                    menuTabs: []
                };
            } else {
                this.rootTemplate = {
                    headerPanel: 'Asset transfers',
                    menuTabs: [{
                        label: 'Transfer status',
                        url: '#ng/account/assettransfer/status',
                        child: 'status',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.transfer.status.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'In specie transfers',
                        url: '#ng/account/assettransfer/inspecie',
                        child: 'inspecie',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.transfer.inspecie.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Intra account transfers',
                        url: '#ng/account/assettransfer/intraaccount',
                        child: 'intraaccount,transferreceipt',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.transfer.intraaccount.view',
                            tree: 'a'
                        }
                    }]
                };
            }
        },

        insertSubHeadings: function (investments) {
            var rval = [];
            investments = $.extend(true, [], investments);
            var lastAssetType;
            for (var i = investments.length - 1; i >= 0; i--) {
                var asset = investments[i];
                var assetType = asset.categoryName;
                if (!_.isEmpty(lastAssetType) && assetType !== lastAssetType) {
                    rval.push({
                        heading: lastAssetType
                    });
                }
                rval.push(asset);
                lastAssetType = assetType;
            }

            if (!_.isEmpty(lastAssetType)) {
                rval.push({
                    heading: lastAssetType
                });
            }

            rval.reverse();

            var startCashRows, newrval = rval;
            _.each(rval, function (row, index) {
                if (!_.isUndefined(row.heading) && row.heading.toLowerCase() === 'cash') {
                    startCashRows = index;
                }
            });
            if (!_.isUndefined(startCashRows)) {
                var cashRows = rval.slice(startCashRows, 2);
                rval.splice(startCashRows, 2);
                newrval = _.union(newrval, cashRows);
            }
            return newrval;
        }
    });
});
