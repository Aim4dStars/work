define(['MvcModel', 'underscore'],
    function (MvcModel, _) {
        'use strict';
        return MvcModel.extend({

            validateFeesComponent: function () {
                if (this.get('termdeposits') && this.get('termdeposits') > '0.00' ||
                    this.get('cash') && this.get('cash') > '0.00' ||
                    this.get('managedportfolios') && this.get('managedportfolios') > '0.00' ||
                    this.get('managedfunds') && this.get('managedfunds') > '0.00' ||
                    this.get('listedsecurities') && this.get('listedsecurities') > '0.00') {
                    this.controller.hidePercentageError();
                    return true;
                } else {
                    this.controller.showPercentageError();
                    return false;
                }
            },

            _updatePercentageValidation: function (child) {
                this.validation[child] = _.extend({}, this.validationTypes.percent);
                this.validation[child].blur = _.omit(this.validation[child].blur, 'customFormat');
                this.validation[child].blur.required = false;
                this.validation[child].blur.minValue = 0;
            }

        });
    });
