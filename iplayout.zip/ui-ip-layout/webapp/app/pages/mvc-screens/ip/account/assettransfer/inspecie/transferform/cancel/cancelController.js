defineMvcController({
    name: 'cancel',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie/transferform',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    hashName: 'cancel',
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['app/framework/services/analyticsService'],
}, function (config, ModalController, analyticsService) {
    'use strict';

    return ModalController.extend({
        config: config,

        postRender: function () {
            if (!this.model.get('removeall')) {
                if (this.parentController.name === 'transferform') {
                    analyticsService.send({
                        "pageName": "ng:account:assettransfer:inspecie",
                        "pageType": "selfservice",
                        "formName": "inspecie transfer",
                        "dialogTitle": "confirm cancellation"
                    });
                } else {
                    analyticsService.send({
                        "pageName": "ng:account:assettransfer:intraaccount",
                        "pageType": "selfservice",
                        "formName": "intraaccount transfer",
                        "dialogTitle": "confirm cancellation"
                    });
                }
            }
        },

        submit: function () {
            if (this.model.get('removeall')) {
                this.parentController.resetRowList();
            } else {
                this.parentController.back(true);
            }
            this.closeModal();
        },

    });
});
