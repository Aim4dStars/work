define(['MvcModel', 'underscore', 'jquery'],
    function (MvcModel, _, $) {
        'use strict';

        return MvcModel.extend({
            getAssetListData: function () {
                var assetlistData = $.extend(true, {}, this.get('transferData'));
                assetlistData.transferAssets = _.map(assetlistData.transferAssets, function (asset) {
                    return {
                        "asset": {
                            "assetId": asset.asset.assetId,
                            "assetCode": asset.asset.assetCode,
                            "assetName": asset.asset.assetName,
                            "assetType": asset.categoryName,
                            "type": this.getAssetType(asset.categoryName)
                        },
                        "amount": asset.asset.amount,
                        "quantity": asset.quantity,
                        "isCashTransfer": asset.isCashTransfer,
                        "vettWarnings": this.filterWarnings(asset.vettWarnings),
                    };
                }, this);

                return assetlistData;
            },

            filterWarnings: function (vettWarnings) {
                var warnings = _.map(vettWarnings, function (warnings) {
                    return warnings.message;
                });
                return warnings;
            },

            getPdfData: function (assetlistData) {
                return {
                    "targetAssetId": assetlistData.targetAssetId,
                    "targetContainerId": assetlistData.targetContainerId,
                    "sourceContainerId": assetlistData.sourceContainerId,
                    "transferPreferences": assetlistData.transferPreferences,
                    "isFullClose": assetlistData.isFullClose,
                    "transferAssets": assetlistData.transferAssets,
                    "transferType": "Internal transfer",
                    "sourceAccountKey": {
                        "accountId": this.get('accountId')
                    },
                    "targetAccountKey": {
                        "accountId": this.get('accountId')
                    },
                    "action": "validate",
                    "key": assetlistData.key,
                    "orderType": "Intra account transfer",
                    "warnings": assetlistData.warnings
                };
            },

            getAssetType: function (categoryName) {
                if (categoryName === 'Listed securities') {
                    return 'ShareAsset';
                } else if (categoryName === 'Managed funds') {
                    return 'ManagedFundAsset';
                } else if (categoryName === 'Managed portfolios') {
                    return 'ManagedPortfolioAsset';
                }
                return 'Asset';
            }

        });
    });
