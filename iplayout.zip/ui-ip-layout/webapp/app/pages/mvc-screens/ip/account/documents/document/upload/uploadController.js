defineMvcController({
    name: 'upload',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    viewComponents: ['forminputselect', 'inputcheckbox', 'button', 'messagealert'],
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['underscore', 'rootController']
}, function (config, ModalController, _, rootController) {
    'use strict';

    return ModalController.extend({
        config: config,
        restUrlTemplate: '../upload',
        MAX_FILE_SIZE: 20971520,
        viewEvents: {
            'submit form': 'submit'
        },

        postRender: function () {
            this._setLovs();
            this._validateFile();
            this.model.on('change:documentType', this._updateDocSubType, this);
            this.model.on('change:documentSubType', this._updateDocSubSubType, this);
        },

        _updateDocSubType: function () {
            var docType = this.model.get('documentType');
            var documentSubTypes = _.clone(this.parentController.model['documentSubTypes' + docType]);
            if (documentSubTypes) {
                this.viewChildren.documentsubtype.setOptions(documentSubTypes);
                this._showDocSubType();
            } else {
                this._hideDocSubType();
            }
            this.model.set('documentSubType', 'any');
        },

        _updateDocSubSubType: function () {
            var documentSubTypes = this.model.get('documentSubType');
            var documentSubSubTypes = this.parentController.model['documentSubTypes2' + documentSubTypes.replace(/\s/g, '')];
            if (documentSubSubTypes) {
                this.viewChildren.documentsubtype2.setOptions(documentSubSubTypes);
                this._showDocSubSubType();
            } else {
                this._hideDocSubSubType();
            }
            this.model.set('documentSubType2', 'any');
        },

        _hideDocSubType: function () {
            if (this.viewChildren.formdocsubtypecomp) {
                this.viewChildren.formdocsubtypecomp.hide();
            }
        },

        _showDocSubType: function () {
            this.viewChildren.formdocsubtypecomp.show();
        },

        _hideDocSubSubType: function () {
            this.viewChildren.formdocsubsubtypecomp.hide();
        },

        _showDocSubSubType: function () {
            this.viewChildren.formdocsubsubtypecomp.show();
        },

        _setLovs: function () {
            var documentTypes = _.clone(this.parentController.model.documentTypes);
            documentTypes = _.reject(documentTypes, function (documentType) {
                return documentType.hideOnUpload;
            });
            var financialYears = _.clone(this.parentController.model.get('financialYears'));
            if (documentTypes && this.viewChildren.documenttype) {
                documentTypes.unshift({
                    label: 'Select',
                    value: ''
                });
                this.viewChildren.documenttype.setOptions(documentTypes);
            }
            if (financialYears) {
                financialYears.unshift({
                    label: 'Select',
                    value: 'any'
                });
                this.viewChildren.financialyear.setOptions(financialYears);
            }
        },

        _validateFile: function () {
            var file = this.model.get('file');
            var result = true;
            this._hideAllMessage();
            //fileSize should be greater then 20Mb
            if (file.size > this.MAX_FILE_SIZE) {
                this._showErrorMessage('sizeerror');
                result = false;
            }
            if (file.name.length > 200) {
                this._showErrorMessage('nameerror');
                result = false;
            }
            var fileExt = file.name.substr(file.name.lastIndexOf('.') + 1).toLowerCase();
            var allowedFiles = ['doc', 'docx', 'pdf', 'jpg', 'msg', 'png', 'ppt', 'pptx', 'tif', 'xls', 'xlsx', 'csv'];
            if (allowedFiles.indexOf(fileExt) === -1) {
                this._showErrorMessage('formaterror');
                result = false;
            }

            if (result) {
                this.view.hideUploadButton();
                this.view.showContent();
            } else {
                this.view.uploadNewDocument();
            }
        },

        submit: function (event) {
            if (this.validateAndSubmitForm(event) && !this.viewChildren.uploadsubmit.isLoading()) {
                this._loadSpinner();
                var params = {};
                params.url = this.restUrlTemplate;
                params.data = this._getFormData();
                params.processData = false;
                params.contentType = false;
                params.success = _.bind(function (data) {
                    if (this._isError(data.data.warnings)) {
                        this._handleSubmissionError(data.data.warnings);
                    } else {
                        this.closeModal();
                        this.parentController.fetchDocuments();
                        this.parentController.showSuccessMessage('uploadsuccess');
                    }
                }, this);
                params.error = _.bind(function (jqXHR) {
                    this._unloadSpinner();
                    if (jqXHR.status === 403) {
                        this._showErrorMessage('viruserror');
                        this.view.uploadNewDocument();
                    } else {
                        this._showErrorMessage('ajaxerror');
                    }
                }, this);
                this.ajaxPost(params);
            }
        },

        _handleSubmissionError: function (warningList) {
            this._unloadSpinner();
            this._hideAllMessage();
            this.view.clearError();
            _.each(warningList, function (warning) {
                if (warning.errorType === 'error') {
                    this.view.updateError(rootController.getCmsEntry(warning.message));
                }
            }, this);
            this.view.uploadNewDocument();
            this._showErrorMessage();
        },

        _isError: function (errorList) {
            var result = false;
            if (errorList) {
                for (var i = 0, len = errorList.length; i < len; i++) {
                    if (errorList[i].errorType === 'error') {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        },

        _getFormData: function () {
            var formData = new FormData();
            var attributes = ['documentName', 'financialYear', 'audit', 'status', 'documentType', 'documentSubType', 'documentSubType2'];
            _.each(attributes, function (attribute) {
                var value = this.model.get(attribute);
                if (attribute === 'audit') {
                    value = value ? true : false;
                } else if (attribute === 'status') {
                    value = value === this.parentController.DOCUMENT_STATUS.DRAFT ? this.parentController.DOCUMENT_STATUS.DRAFT : this.parentController.DOCUMENT_STATUS.FINAL;
                }
                this._appendAttribute(formData, attribute, value);
            }, this);

            formData.append('docupload', this.model.get('file'));
            formData.append('key.accountId',  rootController.getUrlParams().a);

            if (this.model.get('key')) {
                formData.append('key.documentId', this.model.get('key').documentId);
            }
            return formData;
        },

        _appendAttribute: function (formData, attribute, value) {
            if (!value) {
                value = this.model.get(attribute);
            }
            if (!_.isNull(value) && !_.isUndefined(value) && value !== 'any') {
                formData.append(attribute, value);
            }
        },

        _showErrorMessage: function (messageType) {
            messageType = messageType ? messageType : 'error';
            if (this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideAllMessage: function () {
            _.each(['ajaxerror', 'sizeerror', 'nameerror', 'formaterror', 'viruserror', 'error'], function (messageType) {
                if (this.viewChildren[messageType]) {
                    this.viewChildren[messageType].hide();
                }
            }, this);
        },

        updateModal: function (fileObject) {
            this.model.set(fileObject);
            this.view.updateDocumentInfo(fileObject.documentName);
            this._validateFile();
        },

        _loadSpinner: function () {
            this.viewChildren.uploadsubmit.loading(true);
            this.viewChildren.cancel.disable();
        },

        _unloadSpinner: function () {
            this.viewChildren.uploadsubmit.loading(false);
            this.viewChildren.cancel.enable();
        }

    });

});
