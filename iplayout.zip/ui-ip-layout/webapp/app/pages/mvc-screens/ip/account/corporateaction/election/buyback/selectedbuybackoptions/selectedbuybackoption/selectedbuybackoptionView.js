define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/buyback/selectedbuybackoptions/selectedbuybackoption/selectedbuybackoptionView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/buyback/selectedbuybackoptions/selectedbuybackoption/_selectedbuybackoption.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (SelectedBuybackOptionView, _selectedbuybackoptionTemplate, componentXml, Handlebars) {
    'use strict';

    return SelectedBuybackOptionView.extend({

        preRender: function () {
            Handlebars.registerPartial('selectedbuybackoption', componentXml.encode(_selectedbuybackoptionTemplate));
        }
    });

});
