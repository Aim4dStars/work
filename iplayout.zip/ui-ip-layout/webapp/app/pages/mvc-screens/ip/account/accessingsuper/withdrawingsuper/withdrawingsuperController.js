defineMvcController({
    name: 'withdrawingsuper',
    hashName: 'withdrawingsuper',
    hashDefault: true,
    parentPath: 'mvc-screens/ip/account/accessingsuper',
    viewHtml: true,
    viewJs: false,
    screens: ['oneoffwithdrawal', 'cancelsavedwithdrawal', 'submitsavedwithdrawal'],
    dependencies: ['app/pages/mvc-screens/ip/services/accountService', 'underscore', 'jquery', 'app/pages/mvc-screens/ip/account/accessingsuper/accessingsuperServices'],
    viewComponents: ['snapshot', 'messagedisclaimer', 'messagealert'],
    extend: 'MvcController'
}, function (config, MvcController, accountService, _, $, accessingsuperServices) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.super.withdrawal.view',
        targetId: 'a',
        requiredParams: ['a'],
        autoHideSpinner: false,

        postRender: function () {
            this.model.set('showGenericError', false);
            this._hideAllMessages();
            this.model.unset('savedWithdrawals');
            this._populateWithdrawals();
            this._showUnrecoverableErrorMessage();
        },

        showSuccessMessage: function () {
            var messageType = this.parentController.model.get('showSuccessMessage');
            this.showSuccessfulSavedMessage(messageType, false);
            this.parentController.model.unset('showSuccessMessage');
        },

        _showUnrecoverableErrorMessage: function () {
            var unrecoverableErrorType = this.parentController.getNonRecoverableErrorType();
            this.model.set('unrecoverableOneoffWithdrawalPaymentMessageVisible', unrecoverableErrorType === 'oneoffWithdrawal');
            this.parentController.unsetNonRecoverableErrorType();
        },

        _populateWithdrawals: function () {
            $.when(this._fetchSavedWithdrawalsDetails(), accessingsuperServices._fetchAccountData(this))
                .done(_.bind(function () {
                    this.checkForUnrestrictedNonPreservedAmount();
                }, this))
                .fail(_.bind(function () {
                    this.model.set('showGenericError', true);
                }, this))
                .always(_.bind(function () {
                    this.view.hideSpinner();
                }, this));
        },

        _fetchSavedWithdrawalsDetails: function () {
            var deferred = $.Deferred();
            accessingsuperServices.fetchSavedWithdrawalDetails(this)
                .done(_.bind(function (savedWithdrawals) {
                    this.model.set('savedWithdrawals', savedWithdrawals);
                    this.reRenderChildren('oneoffwithdrawal');
                    deferred.resolve();
                }, this))
                .fail(_.bind(function () {
                    this.model.set('showGenericError', true);
                    deferred.reject();
                }, this));

            return deferred.promise();
        },

        reRenderChildren: function (screenChild) {
            if (!_.isUndefined(this.children[screenChild])) {
                this.children[screenChild].removeChildren();
                this.children[screenChild].removeViewChildren();
                this.children[screenChild].view.render();
            }
        },

        extendModelProperties: function (controller) {
            _.extend(controller.model, this.model);
        },

        showSuccessfulSavedMessage: function (messageType, refreshData) {
            this._hideAllMessages();
            if (refreshData) {
                this.model.unset('savedWithdrawals');

                this.view.showSpinner();
                $.when(this._fetchSavedWithdrawalsDetails())
                    .always(_.bind(function () {
                        this.view.hideSpinner();
                    }, this));
            }
            this.viewChildren[messageType].show();
        },

        _hideAllMessages: function () {
            _.each(['oneoffwithdrawalsuccessmessage', 'cancelsavedoneoffwithdrawalmessage', 'saveoneoffwithdrawalsuccessmessage'], function (message) {
                if (!_.isUndefined(this.viewChildren[message])) {
                    this.viewChildren[message].hide();
                }
            }, this);
        },

        checkForUnrestrictedNonPreservedAmount: function () {
            var unrestrictedNonPreservedAmount = this.model.get('unrestrictedNonPreservedAmount');

            this.model.set('showUnrestrictedNonPreservedMsg', !_.isUndefined(unrestrictedNonPreservedAmount) && unrestrictedNonPreservedAmount > 0);
        }
    });
});
