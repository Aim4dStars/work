defineMvcController({
    name: 'realisedportfolio',
    parentPath: 'mvc-screens/ip/account/cgt/realised',
    viewHtml: true,
    modelJs: false,
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['inputdate'],
    hashName: 'realisedportfolio',
    hashDefault: true,
    extend: 'app/pages/mvc-screens/ip/account/cgt/cgtBaseViewByController',
    dependencies: ['rootController']
}, function (config, CgtViewByBaseController) {
    'use strict';

    return CgtViewByBaseController.extend({
        config: config,
        urlTemplate: '../api/v1_0/accounts/<%=a%>/realised-cgt',
        taxColumns: [5, 7, 8],
        detailSort: 'ascendingSecurityName',
        repeatingAssetProperty: 'securityCode',
        totalColspan: 4,
        title: 'realised'
    });

});
