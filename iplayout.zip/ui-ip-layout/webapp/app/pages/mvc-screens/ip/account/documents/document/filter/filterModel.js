define([
    'MvcModel'
], function (MvcModel) {
    'use strict';

    return MvcModel.extend({
        defaults: {
            formstartUploadedDate: '',
            formendUploadedDate: '',
            formdocumentType: 'any',
            formfinancialYear: 'any',
            formaudit: false,
            formstatus: false,
            formuploadedRole: 'any',
            formdocumentSubType: 'any',
            formdocumentSubType2: 'any'
        },

        initialize: function () {
            this.on('change:formaudit', function () {
                if (this.get("formaudit") === null) {
                    this.set("formaudit", false);
                }
            });
            this.on('change:formstatus', function () {
                if (this.get("formstatus") === null) {
                    this.set("formstatus", false);
                }
            });
        },

        validation: {
            formstartUploadedDate: {
                blur: {
                    required: false,
                    maxValue: new Date()
                }
            },
            formendUploadedDate: {
                blur: {
                    required: false,
                    maxValue: new Date()
                }
            }
        }
    });

});
