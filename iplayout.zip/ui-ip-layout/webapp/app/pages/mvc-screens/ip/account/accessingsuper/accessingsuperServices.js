define([
    'rootController',
    'underscore',
    'jquery',
    'app/pages/mvc-screens/ip/services/accountService',
    'app/framework/services/dateService',
    'app/framework/router'
], function (rootController, _, $, accountService, dateService, router) {
    'use strict';

    return {

        fetchPayeeAccountsUriTemplate: '../api/movemoney/v2_0/accounts/<%=a%>/payments/payees',
        fetchSavedWithdrawalUrl: '../api/movemoney/v2_0/accounts/<%=a%>/payments/savedPayments',
        confirmWithdrawalUriTemplate: '../api/movemoney/v2_0/accounts/<%=a%>/payments/confirmPayment',
        saveWithdrawalUriTemplate: '../api/movemoney/v2_0/accounts/<%=a%>/payments/savePayment',
        submitWithdrawalUriTemplate: '../api/movemoney/v2_0/accounts/<%=a%>/payments/submitPayment',
        availableCashUriTemplate: '../api/portfolio/v3_0/<%=a%>/available-cash',
        cancelSavedwithdrawalUrl: '../api/movemoney/v2_0/accounts/<%=a%>/payments/cancelSavedPayment',
        withdrawingSuperUriTemplate: '#ng/account/accessingsuper/withdrawingsuper?a=<%=a%>',

        // mapper for translating Avaloq error to UI error. Non-recoverable means that the error may result in lost data.
        errorMap: [
            {
                sourceErrorId: 'reject_reason',
                targetErrorId: 'Err.IP-0909',
                nonRecoverable: true
            },
            {
                sourceErrorId: 'btfg$insuf_fund_min_pay_tax',
                targetErrorId: 'Err.IP-0908',
                nonRecoverable: false
            },
            {
                sourceErrorId: 'btfg$chk_tax_buc_list_status',
                targetErrorId: 'Err.IP-0916',
                nonRecoverable: false
            }
        ],

        mapErrors: function (errors) {
            if (!_.isUndefined(errors)) {
                _.each(errors, function (error) {
                    var mappedError = _.find(this.errorMap, function (errorItem) {
                        return errorItem.sourceErrorId === error.errorId;
                    });

                    if (!_.isUndefined(mappedError)) {
                        error.errorId = mappedError.targetErrorId;
                        error.message = rootController.getCmsEntry(mappedError.targetErrorId);
                        error.nonRecoverable = mappedError.nonRecoverable;
                    }
                }, this);
            }

            return errors;
        },

        /**
         * Asynchronously fetches the payee accounts from the server, filtering the results if required.
         *
         * This functions returns a promise that will be resolved with the {PaymentDto} accounts once the data has be retrieved and filtered.
         *
         * @param {MvcController} controller - The controller which is invoking the call
         * @param {Array[String]} payeeType - (optional) The array of payeeType with which to filter the payee accounts, e.g. ['LINKED']
         * @return {$.Deferred.promise} - a promise which is resolved with the (filtered) payee accounts.
         */

        _fetchPaymentAccounts: function (controller) {
            return this.fetchPayeeAccounts(controller, ['LINKED'])
                .done(_.bind(function (paymentAccounts) {
                    controller.model.set('paymentAccounts', this._processPaymentAccounts(paymentAccounts));
                }, this));
        },

        _processPaymentAccounts: function (paymentAccounts) {
            var processedAccounts = [];
            _.each(paymentAccounts, function (account) {
                var processedAccount = account.toPayeeDto;
                processedAccount.fromAccount = account.fromPayDto;
                processedAccounts.push(processedAccount);
            });
            return processedAccounts;
        },


        fetchPayeeAccounts: function (controller, payeeTypes) {
            var deferred = $.Deferred();
            var params = {
                url: controller.getUrl(rootController.getUrlParams(), this.fetchPayeeAccountsUriTemplate),
                success: _.bind(function (response) {
                    var payees = response.data.resultList;
                    if (_.isUndefined(payeeTypes)) {
                        deferred.resolve(payees);
                    } else {
                        deferred.resolve(this._filterPayeeAccountsByTypes(payees, payeeTypes));
                    }
                }, this)
            };
            controller.ajaxGet(params);
            return deferred.promise();
        },

        _filterPayeeAccountsByTypes: function (payees, payeeTypes) {
            return _.filter(payees, function (payee) {
                if (_.contains(payeeTypes, payee.toPayeeDto.payeeType)) {
                    return true;
                }
            });
        },

        _navigateToWithdrawingSuperDetails: function (controller) {
            var uri = controller.getUrl(rootController.getUrlParams(), this.withdrawingSuperUriTemplate);
            router.appRouter.navigate(uri, {
                trigger: true,
                replace: false
            });
        },
        /**
         * Builds a super withdrawal object that is suitable for submission to the api service.
         *
         * @param {PayeeDto} toAccount - The account to which the payment will be made.
         * @param {PayeeDto} fromAccount - The account from which the payment will be made.
         * @param {number} amount - The amount of the withdrawal.
         * @param {String} pensionPaymentType - The pension payment type e.g Minimum amount, Maximum amount.
         * @param {String} startDate - The date from which to sart the withdrawal.
         * @param {String} description - The description of the withdrawal.
         
         * @param {String} transactionId - The id of the transaction, this is used to update a withdrawal.
         * @return {WithdrawalDto} - the withdrawal object.
         */
        buildWithdrawal: function (toAccount, fromAccount, amount, pensionPaymentType, startDate, description, indexationType, indexation, frequency, withdrawalType, transactionId) {
            return {
                'toPayeeDto': toAccount,
                'fromPayDto': fromAccount,
                'amount': amount,
                'pensionPaymentType': pensionPaymentType,
                'transactionDate': startDate,
                'description': description,
                'frequency': frequency,
                'isRecurring': frequency ? true : false,
                'indexationType': indexationType,
                'indexationAmount': indexation,
                'withdrawalType': withdrawalType,
                'transactionId': transactionId
            };
        },

        buildLumpSumWithdrawal: function (controller) {
            return this.buildWithdrawal(controller.model.get('toAccount'),
                controller.model.get('fromAccount'),
                controller.model.get('amount'),
                'Specific amount',
                controller.model.get('startdate'),
                controller.model.get('description'),
                null,
                null,
                null,
                'Lump sum withdrawal');
        },


        confirmWithdrawal: function (controller, withdrawal) {
            return this._postRequest(controller, this.confirmWithdrawalUriTemplate, withdrawal);
        },

        submitWithdrawal: function (controller, withdrawal) {
            return this._postRequest(controller, this.submitWithdrawalUriTemplate, withdrawal);
        },

        _getPaymentAccounts: function (controller, payeeBsb) {
            return this.fetchPayeeAccounts(controller, ['LINKED'])
                .done(_.bind(function (paymentAccounts) {
                    _.filter(paymentAccounts, function (account) {
                        return _.isEqual(account.toPayeeDto.code, payeeBsb);
                    }, this);
                }, this))
                .fail(_.bind(function () {
                    controller.parentController.model.set('showGenericError', true);
                    controller.view.hideSpinner();
                }, this));
        },

        reviewSavedWithdrawal: function (controller, rowData, saveTypeAction) {
            var withdrawal;
            this._getPaymentAccounts(controller, rowData.payeeBsb)
                .done(_.bind(function (withdrawalAccounts) {
                    withdrawal = this.buildreviewSavedWithdrawalData(saveTypeAction, rowData, withdrawalAccounts[0]);
                    withdrawal.paymentAction = saveTypeAction;
                    withdrawal.transSeqNo = rowData.transSeqNo;
                    withdrawal.receiptNumber = rowData.recieptNumber;
                    withdrawal.stordPosId = rowData.stordPosId;
                    this.confirmWithdrawal(controller, withdrawal)
                        .done(_.bind(function (data) {
                            if (_.isUndefined(data) || !_.isEmpty(data.errors)) {
                                this.navigateToEditScreen(controller, saveTypeAction, data.errors, rowData);
                            } else {
                                withdrawal.indexationType = data.indexationType;
                                controller.parentController.children.submitsavedwithdrawal.openModal({
                                    'withdrawal': withdrawal
                                });
                            }
                        }, this))
                        .always(_.bind(function () {
                            controller.view.hideSpinner();
                        }, this))
                        .fail(_.bind(function () {
                            controller.parentController.model.set('showGenericError', true);
                        }, this));
                }, this));
        },

        navigateToEditScreen: function (controller, saveTypeAction, errors, withdrawalData) {
            var parentControllerModel = controller.parentController.parentController.model;
            parentControllerModel.set('dataValidationErrors', errors);
            var url = '#ng/account/accessingsuper/editoneoffwithdrawal?a=' + rootController.getUrlParams().a;
            this.setSelectedRowData(controller, withdrawalData, 'modifyoneoff');
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },

        buildreviewSavedWithdrawalData: function (saveTypeAction, data, paymentAccounts) {
            return this.buildWithdrawal(paymentAccounts.toPayeeDto,
                paymentAccounts.fromPayDto,
                data.netAmount,
                'Specific amount',
                dateService.firstBusinessDay(),
                data.description,
                null,
                null,
                null,
                data.orderType);
        },

        buildSaveWithdrawal: function (data, receiptNumber, transSeqNo, stordPosId, saveTypeAction) {
            data.receiptNumber = receiptNumber;
            data.transSeqNo = transSeqNo;
            data.stordPosId = stordPosId;
            data.transactionId = stordPosId;
            switch (saveTypeAction) {
            case 'saveoneoff':
                data.receiptNumber = undefined;
                data.transSeqNo = undefined;
                data.transactionId = undefined;
                break;
            case 'modifyoneoff':
                data.transactionId = undefined;
                break;
            }
        },

        saveWithdrawal: function (controller, withdrawal) {
            var deferred = $.Deferred();
            var url = controller.getUrl(rootController.getUrlParams(), this.saveWithdrawalUriTemplate);
            var params = {
                url: url,
                data: JSON.stringify(withdrawal),
                contentType: 'application/json',
                success: _.bind(function (data) {
                    if (_.isUndefined(data) || !_.isEmpty(data.error) || _.isUndefined(data.data)) {
                        controller.model.set('showGenericError', true);
                        deferred.reject();
                    } else {
                        deferred.resolve(data.data);
                    }
                }, controller),
                error: _.bind(function () {
                    deferred.reject();
                }, controller)
            };
            controller.ajaxPost(params);
            return deferred.promise();
        },

        _postRequest: function (controller, uriTemplate, data) {
            var deferred = $.Deferred();
            var params = {
                url: controller.getUrl(rootController.getUrlParams(), uriTemplate),
                data: JSON.stringify(data),
                contentType: "application/json",
                success: function (response) {
                    deferred.resolve(response.data);
                },
                error: function () {
                    deferred.reject();
                }
            };
            controller.ajaxPost(params);
            return deferred.promise();
        },

        fetchSavedWithdrawalDetails: function (controller) {
            var deferred = $.Deferred(),
                url = controller.getUrl(rootController.getUrlParams(), this.fetchSavedWithdrawalUrl),
                params = {
                    url: url,
                    success: _.bind(function (data) {
                        if (_.isUndefined(data) || _.isUndefined(data.data) || _.isUndefined(data.data.resultList)) {
                            controller.parentController.model.set('showGenericError', true);
                            deferred.reject();
                        } else {
                            deferred.resolve(data.data.resultList);
                        }
                    }),
                    error: function () {
                        deferred.reject();
                    }
                };
            controller.ajaxGet(params);
            return deferred.promise();
        },

        filterOneOffWithdrawals: function (withdrawals) {
            return _.filter(withdrawals, function (withdrawal) {
                return _.isEmpty(withdrawal.frequency) || _.isEqual(withdrawal.frequency.toLowerCase(), 'once');
            }, this);
        },

        setSelectedRowData: function (controller, data, action) {
            controller.parentController.parentController.model.set({
                'selectedwithdrawalData': data,
                'saveTypeAction': action
            });
        },

        getSelectedRowData: function (controller, attr) {
            return controller.parentController.model.get(attr);
        },

        unsetRowData: function (controller, attr) {
            controller.parentController.model.unset(attr);
        },

        /**
         * Asynchronously fetches the available cash data from the current account from the server. The account id is taken from the url paramas.
         *
         * This functions returns a promise that will be resolved with the {AvailableCashDto} once is has be retrieved.
         *
         * @param {MvcController} controller - The controller which is invoking the call
         * @return {$.Deferred.promise} - a promise which is resolved with the {AvailableCashDto}.
         */
        fetchAvailableCashData: function (controller) {
            var deferred = $.Deferred();
            var params = {
                url: controller.getUrl(rootController.getUrlParams(), this.availableCashUriTemplate),
                success: _.bind(function (response) {
                    deferred.resolve(response.data);
                }, this)
            };
            controller.ajaxGet(params);
            return deferred.promise();
        },

        cancelSavedWithdrawal: function (controller, withdrawal) {
            var deferred = $.Deferred();
            var url = controller.getUrl(rootController.getUrlParams(), this.cancelSavedwithdrawalUrl);
            var params = {
                url: url,
                data: JSON.stringify(withdrawal),
                contentType: 'application/json',
                success: _.bind(function (data) {
                    if (_.isUndefined(data) || !_.isEmpty(data.error) || _.isUndefined(data.data)) {
                        controller.model.set('showGenericError', true);
                        deferred.reject();
                    } else {
                        deferred.resolve(data.data);
                    }
                }),
                error: function () {
                    deferred.reject();
                }
            };
            controller.ajaxPost(params);
            return deferred.promise();
        },

        _displayMessageAlert: function (messageAlert, messages) {
            var messageText = '';
            _.each(messages, function (message) {
                messageText += message + "<br/>";
            });
            messageAlert.viewData.html = messageText;
            messageAlert.render();
            messageAlert.show();
        },

        _fetchAccountData: function (controller) {
            return accountService.getAccount(controller)
                .done(_.bind(function (account) {
                    if (account.taxAndPreservationDetails) {
                        controller.model.set({
                            'taxablePercentage': account.taxAndPreservationDetails.taxablePercentage,
                            'unrestrictedNonPreservedAmount': account.taxAndPreservationDetails.unrestrictedNonPreservedAmount
                        });
                    }
                }, controller));
        }

    };
});
