define([
    'underscore', 'jquery', 'rootController'
], function (_, $, rootController) {
    'use strict';

    return {
        url: {
            valuationServiceUrl: '../api/portfolio/v3_0/<%=a%>/valuation'
        },
        CATEGORY_NAME: {
            'CASH': 'Cash',
            'MANAGED_PORTFOLIO': 'Managed portfolios',
            'MANAGED_FUND': 'Managed funds',
            'TERM_DEPOSIT': 'Term deposits',
            'SHARE': 'Listed securities',
            'TAILORED_PORTFOLIO': 'Tailored portfolios'
        },

        ASSET_TYPE: {
            'SHARE': 'SHARE',
            'MANAGED_FUND': 'MANAGED_FUND',
            'CASH': 'CASH'
        },

        getValuationData: function (controller, loadFromCache) {
            var deferred = $.Deferred();
            var valuationServiceUrl = this.url.valuationServiceUrl;
            if (loadFromCache) {
                valuationServiceUrl += "?use-cache=true";
            }

            controller.ajaxGet({
                url: controller.getUrl(rootController.getUrlParams(), valuationServiceUrl),
                success: function (data) {
                    if (data.data) {
                        deferred.resolve(data.data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },


        filterCashAsset: function (valuation) {
            return _.find(valuation.categories, function (category) {
                return category.categoryName === this.CATEGORY_NAME.CASH;
            }, this);
        },

        filterManagedPortfolio: function (valuation) {
            return _.find(valuation.categories, function (category) {
                return category.categoryName === this.CATEGORY_NAME.MANAGED_PORTFOLIO;
            }, this);
        },

        filterTailoredPortfolio: function (valuation) {
            return _.find(valuation.categories, function (category) {
                return category.categoryName === this.CATEGORY_NAME.TAILORED_PORTFOLIO;
            }, this);
        },

        filterDirectContainerInvestments: function (valuation) {
            return _.filter(valuation.categories, function (category) {
                var isMF = category.categoryName === this.CATEGORY_NAME.MANAGED_FUND;
                var isLS = category.categoryName === this.CATEGORY_NAME.SHARE;
                return isMF || isLS;
            }, this);
        },

        mergeDirectContainerInvestments: function (directContainerInvestments) {
            var allInvestments = [];
            _.each(directContainerInvestments, function (investments) {
                _.each(investments.investments, function (investment) {
                    var asset = investment.investmentAsset;
                    asset.availableQuantityHolding = asset.availableQuantity;
                    if (this.isManagedFund(asset)) {
                        asset.availableQuantityHolding = investment.availableBalance;
                        asset.availableMarketValue = investment.availableBalance;
                    } else {
                        asset.availableMarketValue = parseFloat((asset.availableQuantity * asset.unitPrice).toFixed(2));
                    }

                    if (asset.availableQuantityHolding > 0 && !asset.prepaymentAsset) {
                        investment.assetId = asset.assetId;
                        allInvestments.push(investment);
                    }
                }, this);
            }, this);

            return allInvestments;
        },

        getTotalHolding: function (investments) {
            var totalHolding = 0;
            _.each(investments, function (investment) {
                totalHolding += investment.investmentAsset.availableMarketValue;
            }, this);

            return totalHolding;
        },

        filterByHolding: function (investments) {
            investments = _.filter(investments, function (investment) {
                return investment.availableBalance > 0;
            });

            _.each(investments, function (investment) {
                investment.investmentAssets = _.map(investment.investmentAssets, function (asset) {
                    if (this.isCash(asset)) {
                        return _.extend(asset, {
                            'availableMarketValue': asset.availableQuantityToTransfer,
                            'availableQuantityHolding': asset.availableQuantityToTransfer
                        });
                    } else if (this.isManagedFund(asset)) {
                        return _.extend(asset, {
                            'availableMarketValue': asset.marketValue,
                            'availableQuantityHolding': asset.marketValue
                        });
                    } else {
                        return _.extend(asset, {
                            'availableMarketValue': parseFloat((asset.availableQuantity * asset.unitPrice).toFixed(2)),
                            'availableQuantityHolding': asset.availableQuantity
                        });
                    }
                }, this);
            }, this);

            return investments;
        },

        isCash: function (asset) {
            return asset.assetType === this.ASSET_TYPE.CASH;
        },

        isShare: function (asset) {
            return asset.assetType === this.ASSET_TYPE.SHARE;
        },

        isManagedFund: function (asset) {
            return asset.assetType === this.ASSET_TYPE.MANAGED_FUND;
        },

        isConvertToUnits: function (asset) {
            var isMF = asset.assetType === this.ASSET_TYPE.MANAGED_FUND;
            var isCash = asset.assetType === this.ASSET_TYPE.CASH;
            return !(isMF || isCash);
        },

        getCashAsset: function (investments) {
            return _.find(investments, function (investment) {
                return investment.categoryName === this.ASSET_TYPE.CASH;
            }, this);
        },

        removeCash: function (investments) {
            return _.filter(investments, function (investment) {
                return investment.categoryName !== this.ASSET_TYPE.CASH;
            }, this);
        },

        filterByAssetType: function (investments) {
            return _.filter(investments, function (asset) {
                return asset.investmentAsset.availableQuantityHolding > 0 && !asset.investmentAsset.prepaymentAsset;
            }, this);
        },

        getCategoryName: function (asset) {
            if (this.isManagedFund(asset)) {
                return 'Managed funds';
            } else if (this.isCash(asset)) {
                return 'CASH';
            } else {
                return 'Listed securities';
            }
        },

        addAssetType: function (assetType, portfolios) {
            return _.map(portfolios, function (portfolio) {
                return _.extend(portfolio, {
                    assetType: assetType
                });
            });
        },

        getContainerId: function (selectedPortfolio, heldPortfolios) {
            var containerId = null;
            var matchingPortfolio = this.getMatchingPortfolio(selectedPortfolio, heldPortfolios);
            if (!_.isNull(matchingPortfolio) && !_.isUndefined(matchingPortfolio) && !_.isUndefined(matchingPortfolio.subAccountId)) {
                containerId = matchingPortfolio.subAccountId;
            }

            return containerId;
        },

        getMatchingPortfolio: function (selectedPortfolio, heldPortfolios) {
            var matchingPortfolio;
            matchingPortfolio = _.find(heldPortfolios, function (_portfolio) {
                return _portfolio.assetId === selectedPortfolio.assetId;
            });
            if (!_.isUndefined(matchingPortfolio)) {
                return matchingPortfolio;
            }
        },
    };
});
