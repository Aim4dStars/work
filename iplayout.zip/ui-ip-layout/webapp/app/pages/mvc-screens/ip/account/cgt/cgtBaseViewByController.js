defineMvcController({
    name: 'cgtviewbybase',
    viewHtml: false,
    modelJs: false,
    extend: 'MvcController',
    dependencies: ['rootController', 'jquery', 'underscore', 'app/framework/helpers/format', 'app/framework/handlebars/format']
}, function (config, MvcController, rootController, $, _, format, Format) {
    'use strict';

    return MvcController.extend({
        config: config,
        autoHideSpinner: false,
        showQuantity: false,
        requiredParams: ['a'],

        fetchData: function () {
            $.when(this.parentController.parentController.parentController.getAccountPromise())
                .done(_.bind(function (account) {
                    var migrationDetails = account.migrationDetails,
                        migrationDate, startDateErrMsg;
                    if (migrationDetails && migrationDetails.migrationDate) {
                        migrationDate = migrationDetails.migrationDate;
                        startDateErrMsg = 'Err.IP-0925';
                    }
                    this.parentController.parentController.view.show();

                    this.parentController.model.set('closureDate', account.closureDate);
                    this.parentController.model.set('accountStartDate', account.openDate);
                    this.parentController.model.set('migrationDate', migrationDate);

                    var url = this.getUrl(rootController.getUrlParams());
                    url += "?" + this.parentController.getFetchParams();

                    if (!_.isUndefined(this.view)) {
                        this.view.showSpinner();
                    }

                    this.ajaxGet({
                        url: url,
                        success: _.bind(function (data) {
                            this.model.unset('cgtGroupDtoList');
                            this.model.set('cgtGroupDtoList', data.data.cgtGroupDtoList);

                            this.initializeTableOptions(data.data.cgtGroupDtoList);

                            this.model.set('groupBy', data.data.key.groupBy);
                            this.populateScreen();
                            this.setAccountErrorMessages(migrationDate || account.openDate, account.closureDate, startDateErrMsg);
                        }, this)
                    });
                }, this))
                .fail(_.bind(function () {
                    this.parentController.parentController.view.hide();
                }, this));
        },

        setAccountErrorMessages: function (accountStartDate, closureDate, startDateErrMsg) {
            var startErrorMessage = rootController.getCmsEntry(startDateErrMsg || 'Err.IP-0309', [Format(accountStartDate, 'date')]);
            this.parentController.parentController.view.setAccountStartDateErrorMessage(startErrorMessage);

            var closeErrorMessage = rootController.getCmsEntry('Err.IP-0310', [Format(closureDate, 'date')]);
            this.parentController.parentController.view.setAccountEndDateErrorMessage(closeErrorMessage);
        },

        initializeTableOptions: function (cgtGroupDtoList) {

            if (_.isEmpty(cgtGroupDtoList)) {
                this.parentController.children.tableoptions.disable();
            } else {
                this.parentController.children.tableoptions.enable();
            }

            var showParcels = this.parentController.model.get('showParcels');

            if (!_.isUndefined(showParcels)) {
                this.parentController.children.tableoptions.viewChildren.showtaxdetails.enable();
            } else {
                this.parentController.children.tableoptions.viewChildren.showtaxdetails.disable();
            }
        },

        populateScreen: function () {
            var cgtGroupDtoList = this.model.get('cgtGroupDtoList');
            if (_.isEmpty(cgtGroupDtoList)) {

                this.showNoDataMessage();

                var overallTotals = this.calculateTotals(cgtGroupDtoList);
                this.setTotalGrossGain(overallTotals);

            } else {

                var groupBy = this.model.get('groupBy');
                var sortBy = this.parentController.model.get('sortBy');

                var showParcels = this.parentController.model.get('showParcels');
                var showTaxDetails = this.parentController.model.get('showTaxDetails');
                if (groupBy === 'SECURITY') {
                    this.populateSecurityView(cgtGroupDtoList, sortBy, showParcels, showTaxDetails);
                } else {
                    this.populateAssetTypeView(cgtGroupDtoList, sortBy, showParcels, showTaxDetails);
                }

                this.hideNoDataMessage();
            }
            this.view.hideSpinner();
        },


        secondarySortAssetList: function (assetList, assetTotals, sortBy, modelEntry) {
            var secondarysortedlist = []; //used for managed funds and for listed securities
            var aggregatedSecuritiesList = [];

            // Sort managed funds at asset level, not group level
            if (!_.isEmpty(assetList)) {
                _.each(assetList, function (asset, i) {
                    assetList[i].cgtSecurities = assetList[i].cgtSecurities;
                });
                aggregatedSecuritiesList = this.aggregateManagedFunds(assetList);
                var flatAssetList = _.flatten(_.map(assetList, function (asset, key) {
                    return assetList[key].cgtSecurities;
                }));

                //push the sorted results to a structure to consume
                for (var i in aggregatedSecuritiesList) {
                    if (!aggregatedSecuritiesList.hasOwnProperty(i)) {
                        continue;
                    }

                    var aggregatedSecurity = aggregatedSecuritiesList[i];
                    var childList = _.where(flatAssetList, {
                        securityCode: aggregatedSecurity.securityCode
                    });
                    childList = this.sort(childList, sortBy);

                    var zsx = _.where(assetList, {
                        groupCode: aggregatedSecurity.key
                    })[0];
                    zsx.cgtSecurities = childList;
                    secondarysortedlist.push(zsx);
                }

                secondarysortedlist[0].aggregatedcgtSecurities = aggregatedSecuritiesList;
                assetList = secondarysortedlist;
                this.model.set(modelEntry, assetList);
                assetTotals = this.calculateTotals(assetList);
            }

            return {
                assetList: assetList,
                assetTotals: assetTotals
            };
        },

        populateAssetTypeView: function (cgtGroupDtoList, sortBy, showParcels, showTaxDetails) {
            var investments = this.getInvestments(cgtGroupDtoList);

            var managedFundList = investments.managedFunds;
            var listedSecuritiesList = investments.listedSecurities;
            var managedPortfolioList = investments.managedPortfolios;
            var tailoredPortfolioList = investments.tailoredPortfolios;

            var managedFundTotals;
            var listedSecuritiesTotals;
            var managedPortfolioTotals;
            var tailoredPortfolioTotals;

            var mfData = this.secondarySortAssetList(managedFundList, managedFundTotals, sortBy, 'managedFundList');
            var lsData = this.secondarySortAssetList(listedSecuritiesList, listedSecuritiesTotals, sortBy, 'listedSecuritiesList');

            if (!_.isEmpty(managedPortfolioList)) {
                managedPortfolioList = this.sort(managedPortfolioList, sortBy, true);
                this.model.set('managedPortfolioList', managedPortfolioList);
                managedPortfolioTotals = this.calculateTotals(managedPortfolioList);
            }

            if (!_.isEmpty(tailoredPortfolioList)) {
                tailoredPortfolioList = this.sort(tailoredPortfolioList, sortBy, true);
                this.model.set('tailoredPortfolioList', tailoredPortfolioList);
                tailoredPortfolioTotals = this.calculateTotals(tailoredPortfolioList);
            }

            var overallTotals = this.calculateTotals(cgtGroupDtoList);
            this.setTotalGrossGain(overallTotals);
            this.clearView();
            this.view.render();
            this.setFooterTotal(overallTotals);

            this.discernParcelContainersDisplay(mfData.assetList, mfData.assetTotals, lsData.assetList, lsData.assetTotals, managedPortfolioList, managedPortfolioTotals, tailoredPortfolioList, tailoredPortfolioTotals, showParcels, showTaxDetails);
        },

        discernParcelContainersDisplay: function (managedFundList, managedFundTotals, listedSecuritiesList, listedSecuritiesTotals, managedPortfolioList, managedPortfolioTotals, tailoredPortfolioList, tailoredPortfolioTotals, showParcels, showTaxDetails) {

            this.hideSectionsIfEmpty(managedFundList, listedSecuritiesList, managedPortfolioList, tailoredPortfolioList);

            if (showParcels) {
                if (!_.isEmpty(managedFundList)) {
                    this.showParcels(managedFundList, managedFundTotals, showTaxDetails, 'managedfund');
                }
                if (!_.isEmpty(listedSecuritiesList)) {
                    this.showParcels(listedSecuritiesList, listedSecuritiesTotals, showTaxDetails, 'listedsecurities');
                }
                if (!_.isEmpty(managedPortfolioList)) {
                    this.showParcels(managedPortfolioList, managedPortfolioTotals, showTaxDetails, 'managedportfolio');
                }
                if (!_.isEmpty(tailoredPortfolioList)) {
                    this.showParcels(tailoredPortfolioList, tailoredPortfolioTotals, showTaxDetails, 'tailoredportfolio');
                }
            } else {
                if (!_.isEmpty(managedFundList)) {
                    this.showResults(managedFundList, managedFundTotals, 'managedfund');
                }
                if (!_.isEmpty(listedSecuritiesList)) {
                    this.showResults(listedSecuritiesList, listedSecuritiesTotals, 'listedsecurities');
                }
                if (!_.isEmpty(managedPortfolioList)) {
                    this.showResults(managedPortfolioList, managedPortfolioTotals, 'managedportfolio');
                }
                if (!_.isEmpty(tailoredPortfolioList)) {
                    this.showResults(tailoredPortfolioList, tailoredPortfolioTotals, 'tailoredportfolio');
                }

                this.parentController.children.tableoptions.disableFilters([this.parentController.children.tableoptions.viewChildren.showtaxdetails]);
            }
        },

        hideSectionsIfEmpty: function (mfList, lsList, mpList, tpList) {

            if (_.isEmpty(mfList)) {
                this.model.set('managedfundsection', false);
                this.model.set('detailmanagedfund', false);
            }

            if (_.isEmpty(lsList)) {
                this.model.set('listedsecuritiessection', false);
                this.model.set('detaillistedsecurities', false);
            }

            if (_.isEmpty(mpList)) {
                this.model.set('managedportfoliosection', false);
                this.model.set('detailmanagedportfolio', false);
            }

            if (_.isEmpty(tpList)) {
                this.model.set('tailoredportfoliosection', false);
                this.model.set('detailtailoredportfolio', false);
            }

        },

        populateSecurityView: function (cgtGroupDtoList, sortBy, showParcels, showTaxDetails) {
            cgtGroupDtoList = this.sort(cgtGroupDtoList, sortBy, true);

            var isRealised = (this.title === 'realised');
            _.each(cgtGroupDtoList, function (investment) {
                var orders = investment.cgtSecurities;

                //fix for securities sorting
                _.each(orders, function (order) {
                    order.parentInvCode = order.parentInvCode || order.securityCode;
                    order.parentInvName = order.parentInvName || order.securityName;
                });

                if (isRealised) {
                    orders = _(orders).chain().sortBy('securityName').sortBy('taxDate').reverse().sortBy('date').reverse().sortBy('parentInvName').value();
                } else {
                    orders = _(orders).chain().reverse().sortBy('taxDate').sortBy('parentInvName').value();
                }

                investment.cgtSecurities = orders;
            }, this);
            //fix for securities...?
            this.model.set('cgtGroupDtoList', cgtGroupDtoList);

            this.clearView();
            this.view.render();

            var totals = this.calculateTotals(cgtGroupDtoList);
            this.setTotalGrossGain(totals);

            if (showParcels) {
                this.showParcels(cgtGroupDtoList, totals, showTaxDetails, 'security');
            } else {
                this.showResults(cgtGroupDtoList, totals, 'security');

                this.parentController.children.tableoptions.disableFilters([this.parentController.children.tableoptions.viewChildren.showtaxdetails]);
            }
        },

        clearView: function () {
            this.removeChildren();
            this.view.removeComponents(this.view.el);
        },

        setTotalGrossGain: function (totals) {
            var headerDesc;
            if (totals.grossGain >= 0) {
                headerDesc = this.title + ' gain';
            } else {
                headerDesc = this.title + ' loss';
            }

            this.parentController.model.set({
                'totalGrossGain': format.formatMoney(totals.grossGain, 2, '$'),
                'totalCostBaseGain': format.formatMoney(totals.costBaseGain, 2, '$'),
                'headerDesc': headerDesc
            });
        },

        calculateTotals: function (cgtGroupDtoList) {
            var totals = {
                amount: 0,
                costBase: 0,
                taxAmount: 0,
                indexedCostBase: 0,
                reducedCostBase: 0,
                grossGain: null,
                costBaseGain: null
            };

            totals = _.reduce(cgtGroupDtoList, function (total, cgtGroupDto) {
                total.amount += cgtGroupDto.amount;
                total.taxAmount += cgtGroupDto.taxAmount;
                total.costBase += cgtGroupDto.costBase;
                total.indexedCostBase += cgtGroupDto.indexedCostBase;
                total.reducedCostBase += cgtGroupDto.reducedCostBase;
                if (cgtGroupDto.grossGain !== null) {
                    if (total.grossGain !== null) {
                        total.grossGain += cgtGroupDto.grossGain;
                    } else {
                        total.grossGain = cgtGroupDto.grossGain;
                    }
                }
                if (cgtGroupDto.costBaseGain !== null) {
                    if (total.costBaseGain !== null) {
                        total.costBaseGain += cgtGroupDto.costBaseGain;
                    } else {
                        total.costBaseGain = cgtGroupDto.costBaseGain;
                    }
                }
                return total;
            }, totals);

            return totals;
        },

        showParcels: function (cgtGroupDtoList, totals, showTaxDetails, type) {

            var sectionName = 'detailedcgt';
            var sectionVisible = true;

            var groupBy = this.model.get('groupBy');
            var isSecurity = (groupBy === 'SECURITY');

            if (type === 'managedfund') {
                sectionVisible = this.controlManagedFundDisplay(cgtGroupDtoList, 'parcels');
                sectionName = 'detailmanagedfund';

            } else if (type === 'listedsecurities') {
                sectionVisible = this.controlListedSecuritiesDisplay(cgtGroupDtoList, 'parcels');
                sectionName = 'detaillistedsecurities';

            } else if (type === 'managedportfolio') {
                sectionVisible = this.controlManagedPortfolioDisplay(cgtGroupDtoList, 'parcels');
                sectionName = 'detailmanagedportfolio';

            } else if (type === 'tailoredportfolio') {
                sectionVisible = this.controlTailoredPortfolioDisplay(cgtGroupDtoList, 'parcels');
                sectionName = 'detailtailoredportfolio';

            } else {
                $('.mvc-cgtresults').hide();
                $('#detailedcgt').show();
            }

            if (sectionVisible) {
                // Perform underlying asset sorting for Managed Portfolios
                if (type === 'managedportfolio' && !isSecurity) {
                    _.each(cgtGroupDtoList, function (cgtGroupDto) {
                        cgtGroupDto.cgtSecurities = this.sort(cgtGroupDto.cgtSecurities, 'ascendingSecurityName', true);
                    }, this);
                }

                // Perform underlying asset sorting for Tailored Portfolios
                if (type === 'tailoredportfolio' && !isSecurity) {
                    _.each(cgtGroupDtoList, function (cgtGroupDto) {
                        cgtGroupDto.cgtSecurities = this.sort(cgtGroupDto.cgtSecurities, 'ascendingSecurityName', true);
                    }, this);

                }

                this.removeRepeatingAssetProperties(cgtGroupDtoList);

                var isParcels = !_.isUndefined(this.parentController.model.get('showParcels'));

                _.each(cgtGroupDtoList, function (cgtGroupDto, index) {

                    var detailedCgtSection = this.children[sectionName + index];

                    var footerConfig = this.generateFooter(cgtGroupDto,
                        totals,
                        this.showQuantity,
                        showTaxDetails,
                        index === (cgtGroupDtoList.length - 1),
                        type);

                    if (!isSecurity && isParcels) {
                        if (index !== 0) {
                            detailedCgtSection.viewData.title = false;
                            detailedCgtSection.viewData.label = false;
                        }
                    }

                    detailedCgtSection.setRows({
                        rowName: 'cgtSecurities',
                        tableFooterConfig: footerConfig
                    }, cgtGroupDto);

                    var $cgtContainer = $(".cgt-container");
                    $cgtContainer.removeClass().addClass('cgt-container');

                    if (showTaxDetails) {
                        $cgtContainer.addClass('show-parcels-and-tax');
                        detailedCgtSection.view.showColumns(this.taxColumns);
                    } else {
                        $cgtContainer.addClass('show-parcels');
                        detailedCgtSection.view.hideColumns(this.taxColumns);
                    }

                    detailedCgtSection.renderComponentView();

                }, this);
            }
        },

        showResults: function (cgtGroupDtoList, totals, type) {

            var section = this.children['cgtresults'];
            var sectionVisible = true;

            if (type === 'managedfund') {
                sectionVisible = this.controlManagedFundDisplay(cgtGroupDtoList, 'results');
                section = this.children['managedfundresults'];

            } else if (type === 'listedsecurities') {
                sectionVisible = this.controlListedSecuritiesDisplay(cgtGroupDtoList, 'results');
                section = this.children['listedsecuritiesresults'];

            } else if (type === 'managedportfolio') {
                sectionVisible = this.controlManagedPortfolioDisplay(cgtGroupDtoList, 'results');
                section = this.children['managedportfolioresults'];

            } else if (type === 'tailoredportfolio') {
                sectionVisible = this.controlTailoredPortfolioDisplay(cgtGroupDtoList, 'results');
                section = this.children['tailoredportfolioresults'];

            } else {
                $('#detailedcgt').hide();
                $('.mvc-cgtresults').show();
            }

            if (sectionVisible) {
                if (!_.isUndefined(section)) {
                    if (type === 'managedfund' || type === 'listedsecurities') {
                        section.setRows({
                            rowName: 'aggregatedcgtSecurities',
                        }, cgtGroupDtoList[0]);
                    } else {
                        section.setRows({
                            rowName: 'cgtGroupDtoList',
                        }, cgtGroupDtoList);
                    }

                    section.model.set({
                        'totalAmount': format.formatMoney(totals.amount, 2, '$'),
                        'totalCostBase': format.formatMoney(totals.costBase, 2, '$'),
                        'totalGrossGain': totals.grossGain,
                        'totalCostBaseGain': totals.costBaseGain
                    });

                    section.renderComponentView();
                }
                $(".cgt-container").removeClass().addClass('cgt-container summary');
            }
        },

        sort: function (orders, sortBy, isPrimary) {

            if (_.isArray(orders) && !_.isEmpty(orders)) {
                var nameField = 'groupName';
                var securityType = _.sortBy(orders, 'securityType')[0].securityType;
                var isManagedFund = securityType === 'MANAGED_FUND';
                var isListedSecurity = securityType === 'SHARE' || securityType === 'OPTION';
                var isRealised = (this.title === 'realised');
                var groupBy = this.model.get('groupBy');
                var isSecurity = (groupBy === 'SECURITY');

                isPrimary = isPrimary || isSecurity;

                if (isManagedFund || isListedSecurity) {
                    nameField = 'securityName';
                }

                if (isSecurity && isPrimary) {
                    nameField = 'groupName';
                }

                var safeNameField = function (order) {
                    if (order[nameField] === null) {
                        return '';
                    }
                    return order[nameField].toLowerCase();
                };

                switch (sortBy) {
                case 'ascendingName':
                    if (isPrimary) {
                        orders = _.sortBy(orders, safeNameField);
                    } else if (isRealised) {
                        orders = _(orders).chain().sortBy(safeNameField).reverse().sortBy('taxDate').reverse().sortBy('date').reverse().value();
                    } else {
                        orders = _(orders).chain().sortBy(safeNameField).sortBy('taxDate').value();
                    }
                    break;
                case 'descendingName':
                    if (isPrimary) {
                        orders = _.sortBy(orders, safeNameField).reverse();
                    } else if (isRealised) {
                        orders = _(orders).chain().sortBy(safeNameField).sortBy('taxDate').reverse().sortBy('date').reverse().value();
                    } else {
                        orders = _(orders).chain().sortBy(safeNameField).reverse().sortBy('taxDate').value();
                    }
                    break;
                case 'ascendingGainLosses':
                    if (isPrimary) {
                        orders = _.sortBy(orders, 'grossGain');
                    } else if (isRealised) {
                        orders = _(orders).chain().sortBy('grossGain').reverse().sortBy('taxDate').reverse().sortBy('date').reverse().value();
                    } else {
                        orders = _(orders).chain().sortBy('grossGain').reverse().sortBy('taxDate').value();
                    }
                    break;
                case 'descendingGainLosses':
                    if (isPrimary) {
                        orders = _.sortBy(orders, 'grossGain').reverse();
                    } else if (isRealised) {
                        orders = _(orders).chain().sortBy('grossGain').sortBy('taxDate').reverse().sortBy('date').reverse().value();
                    } else {
                        orders = _(orders).chain().sortBy('grossGain').sortBy('taxDate').value();
                    }
                    break;
                case 'ascendingPortfolioName':
                    if (isPrimary) {
                        orders = _.sortBy(orders, safeNameField).reverse();
                    } else if (isRealised) {
                        orders = _(orders).chain().sortBy('grossGain').reverse().sortBy('taxDate').reverse().sortBy('date').reverse().value();
                    } else {
                        orders = _(orders).chain().sortBy('grossGain').reverse().sortBy('taxDate').value();
                    }
                    break;
                case 'ascendingSecurityName':
                    if (isPrimary) {
                        if (isRealised) {
                            orders = _(orders).chain().sortBy(safeNameField).sortBy('taxDate').reverse().sortBy('date').reverse().sortBy(safeNameField).value();
                        } else {
                            orders = _(orders).chain().reverse().sortBy('taxDate').sortBy(safeNameField).value();
                        }
                    } else if (isRealised) {
                        orders = _(orders).chain().sortBy(safeNameField).sortBy('taxDate').reverse().sortBy('date').reverse().sortBy(safeNameField).value();
                    } else {
                        orders = _(orders).chain().sortBy(safeNameField).reverse().sortBy('taxDate').sortBy(safeNameField).value();
                    }

                    break;
                default:
                    orders = _.sortBy(orders, safeNameField);
                    break;
                }
                return orders;
            }
            return orders;
        },

        _compare: function (x, y) {
            if (x === y) {
                return 0;
            }
            if (_.isUndefined(y)) {
                return 1;
            }
            if (_.isUndefined(x)) {
                return -1;
            }
            if (isNaN(x) && isNaN(y)) {
                return x.toLowerCase() > y.toLowerCase() ? 1 : -1;
            } else {
                return x > y ? 1 : -1;
            }
        },

        removeRepeatingAssetProperties: function (cgtGroupDtoList) {
            _.each(cgtGroupDtoList, function (cgtGroupDto) {
                var lastsecurityCode = '';
                _.each(cgtGroupDto.cgtSecurities, function (assetRow) {
                    if (assetRow[this.repeatingAssetProperty] !== lastsecurityCode) {
                        assetRow.hideName = false;
                        lastsecurityCode = assetRow[this.repeatingAssetProperty];
                    } else {
                        // Override style to not show line
                        assetRow.hideName = true;
                        assetRow.class = 'no-row-line';
                    }
                }, this);
            }, this);
        },

        generateFooter: function (asset, grandTotals, showQuantity, showTaxCostDetails, showGrandTotal, sectionType) {
            var footers = [];
            var idx = 0;
            var groupBy = this.model.get('groupBy');
            var isSecurity = (groupBy === 'SECURITY');
            var totalSuffix = 'securities';

            if (!isSecurity) {
                if (sectionType === 'managedfund') {
                    totalSuffix = 'managed funds';

                } else if (sectionType === 'listedsecurities') {
                    totalSuffix = 'listed securities';

                } else if (sectionType === 'managedportfolio') {
                    totalSuffix = 'managed portfolios';

                } else if (sectionType === 'tailoredportfolio') {
                    totalSuffix = 'tailored portfolios';
                }
            }

            var colspan = this.totalColspan - (this.showQuantity ? 1 : 0);

            if (sectionType !== 'managedfund' && sectionType !== 'listedsecurities') {
                footers[0] = {
                    type: 'total',
                    cell: [{
                        html: 'Total',
                        colspan: colspan
                    }]
                };

                if (showQuantity) {
                    this._addFooterCell(footers[0].cell, ++idx, asset.quantity, false);
                }

                this._addFooterCell(footers[0].cell, ++idx, asset.amount, true);
                if (showTaxCostDetails) {
                    this._addFooterCell(footers[0].cell, ++idx, asset.taxAmount, true);
                }
                this._addFooterCell(footers[0].cell, ++idx, asset.costBase, true);
                if (showTaxCostDetails) {

                    this._addFooterCell(footers[0].cell, ++idx, asset.indexedCostBase, true);
                    this._addFooterCell(footers[0].cell, ++idx, asset.reducedCostBase, true);
                }
                if (showTaxCostDetails) {
                    this._addGrossGainFooterCell(footers[0].cell, ++idx, asset.grossGain, true);
                } else {
                    this._addGrossGainFooterCell(footers[0].cell, ++idx, asset.costBaseGain, true);
                }
            }
            if (showGrandTotal) {
                idx = 0;
                footers[1] = {
                    type: 'grand-total',
                    cell: [{
                        html: '<span>Total ' + totalSuffix + '</span>',
                        colspan: colspan,
                        format: 'number'
                    }]
                };

                if (showQuantity) {
                    this._addFooterCell(footers[1].cell, ++idx, '', false);
                }

                this._addFooterCell(footers[1].cell, ++idx, grandTotals.amount, true);

                if (showTaxCostDetails) {
                    this._addFooterCell(footers[1].cell, ++idx, grandTotals.taxAmount, true);
                }

                this._addFooterCell(footers[1].cell, ++idx, grandTotals.costBase, true);

                if (showTaxCostDetails) {
                    this._addFooterCell(footers[1].cell, ++idx, '', false);
                    this._addFooterCell(footers[1].cell, ++idx, '', false);
                }


                if (showTaxCostDetails) {
                    this._addGrossGainFooterCell(footers[1].cell, ++idx, grandTotals.grossGain, true);
                } else {
                    this._addGrossGainFooterCell(footers[1].cell, ++idx, grandTotals.costBaseGain, true);
                }
            }

            return footers;
        },

        _addFooterCell: function (obj, idx, value, formatCell) {
            if (formatCell) {
                obj[idx] = {
                    html: format.formatMoney(value, 2, '$'),
                    align: 'right',
                    format: 'number'
                };
            } else {
                obj[idx] = {
                    html: value + '',
                    align: 'right',
                    format: 'number'
                };
            }
        },

        _addGrossGainFooterCell: function (obj, idx, value, formatCell) {
            var footerVal = null;
            if (value !== null) {
                footerVal = format.formatMoney(value, 2, '$');
            } else {
                footerVal = "-";
            }
            if (formatCell) {
                obj[idx] = {
                    html: footerVal,
                    align: 'right',
                    format: 'number'
                };
            } else {
                obj[idx] = {
                    html: value + '',
                    align: 'right',
                    format: 'number'
                };
            }
        },

        // Split list of all cgtgroupdtos into asset types
        getInvestments: function (dtoList) {

            var managedFundList = [];
            var listedSecuritiesList = [];
            var managedPortfolioList = [];
            var tailoredPortfolioList = [];

            for (var i = 0; i < dtoList.length; i++) {

                if ('MANAGED_FUND' === dtoList[i].groupId) {
                    managedFundList.push(dtoList[i]);

                } else if ('SHARE' === dtoList[i].groupId || 'OPTION' === dtoList[i].groupId) {
                    listedSecuritiesList.push(dtoList[i]);

                } else {
                    // GroupId is a portfolio id - further separation uses the tye of portfolio
                    if ('MANAGED_PORTFOLIO' === dtoList[i].groupType) {
                        managedPortfolioList.push(dtoList[i]);
                    }
                    if ('TAILORED_PORTFOLIO' === dtoList[i].groupType) {
                        tailoredPortfolioList.push(dtoList[i]);
                    }
                }
            }

            var investments = {
                managedFunds: managedFundList,
                listedSecurities: listedSecuritiesList,
                managedPortfolios: managedPortfolioList,
                tailoredPortfolios: tailoredPortfolioList
            };

            return investments;
        },

        showNoDataMessage: function () {

            this.model.set('data-contents', false);
            this.model.set('messagealert', true);
        },

        hideNoDataMessage: function () {

            this.model.set('messagealert', false);
            this.model.set('data-contents', true);
        },

        controlManagedFundDisplay: function (managedFundList, detailLevel) {

            if (!_.isEmpty(managedFundList)) {
                if (detailLevel === 'parcels') {
                    this.model.set('managedfundsection', false);
                    this.model.set('detailmanagedfund', true);
                } else {
                    this.model.set('detailmanagedfund', false);
                    this.model.set('managedfundsection', true);
                }
                return true;
            }
            return false;
        },

        controlListedSecuritiesDisplay: function (listedSecurityList, detailLevel) {

            if (!_.isEmpty(listedSecurityList)) {
                if (detailLevel === 'parcels') {
                    this.model.set('listedsecuritiessection', false);
                    this.model.set('detaillistedsecurities', true);
                } else {
                    this.model.set('detaillistedsecurities', false);
                    this.model.set('listedsecuritiessection', true);
                }
                return true;
            }
            return false;
        },

        controlManagedPortfolioDisplay: function (managedPortfolioList, detailLevel) {

            if (!_.isEmpty(managedPortfolioList)) {
                if (detailLevel === 'parcels') {
                    this.model.set('managedportfoliosection', false);
                    this.model.set('detailmanagedportfolio', true);
                } else {
                    this.model.set('detailmanagedportfolio', false);
                    this.model.set('managedportfoliosection', true);
                }
                return true;
            }
            return false;
        },

        controlTailoredPortfolioDisplay: function (tailoredPortfolioList, detailLevel) {

            if (!_.isEmpty(tailoredPortfolioList)) {
                if (detailLevel === 'parcels') {
                    this.model.set('tailoredportfoliosection', false);
                    this.model.set('detailtailoredportfolio', true);
                } else {
                    this.model.set('detailtailoredportfolio', false);
                    this.model.set('tailoredportfoliosection', true);
                }
                return true;
            }
            return false;
        },

        setFooterTotal: function (totals) {
            var totalCostBaseGain = totals.costBaseGain === null ? 0 : totals.costBaseGain;
            var totalGrossGain = totals.grossGain === null ? 0 : totals.grossGain;
            this.model.set('totalAmount', totals.amount);
            this.model.set('totalCostBase', totals.costBase);
            this.model.set('totalCostBaseGain', totalCostBaseGain);
            this.model.set('totalGrossGain', totalGrossGain);
            if (this.viewChildren.totalassettypes) {

                var showParcels = this.parentController.model.get('showParcels');
                var showTaxDetails = this.parentController.model.get('showTaxDetails');

                //set footer columns
                var tehcells = this.viewChildren.totalassettypes.viewData.body.cell;
                for (var i in tehcells) {
                    if (!_.isUndefined(showParcels) && !_.isUndefined(showTaxDetails)) {
                        tehcells[i]['grid_width'] = this.parentController.showTaxDetailsTotalColumns[i];
                    } else if (!_.isUndefined(showParcels)) {
                        tehcells[i]['grid_width'] = this.parentController.showParcelsTotalColumns[i];
                    } else {
                        tehcells[i]['grid_width'] = this.parentController.defaultTotalColumns[i];
                    }
                }

                this.viewChildren.totalassettypes.render();
            }
        },

        aggregateManagedFunds: function (managedFundList) {
            var that = this;
            var sortedaggregatedFundList = [];
            if (!_.isEmpty(managedFundList)) {
                var aggregatedFundList = [];
                var managedFundAssetList = _.flatten(_.map(managedFundList, function (obj, key) {
                    return managedFundList[key].cgtSecurities;

                }));

                if (!_.isEmpty(managedFundAssetList)) {
                    var currentAsset = _.clone(managedFundAssetList[0]);

                    if (managedFundAssetList.length > 1) {

                        for (var i = 1; i < managedFundAssetList.length; i++) {
                            if (currentAsset.securityCode === managedFundAssetList[i].securityCode) {

                                currentAsset.amount = currentAsset.amount + managedFundAssetList[i].amount;
                                currentAsset.costBase = currentAsset.costBase + managedFundAssetList[i].costBase;
                                currentAsset.costGain = currentAsset.costGain + managedFundAssetList[i].costGain;
                                currentAsset.costBaseGain = currentAsset.costBaseGain + managedFundAssetList[i].costBaseGain;
                                if (managedFundAssetList[i].grossGain !== null) {
                                    currentAsset.grossGain = currentAsset.grossGain + managedFundAssetList[i].grossGain;
                                }

                            } else {

                                aggregatedFundList.push(currentAsset);
                                currentAsset = _.clone(managedFundAssetList[i]);
                            }
                        }
                    }

                    // push final asset
                    aggregatedFundList.push(currentAsset);
                }

                var sortBy = that.parentController.model.get('sortBy');
                sortedaggregatedFundList = that.sort(aggregatedFundList, sortBy, true);
            }
            return sortedaggregatedFundList;
        }
    });
});
