define([
    'MvcView',
    'underscore'
], function (MvcView, _) {
    'use strict';

    return MvcView.extend({
        scrollToTableTop: function () {
            var selectors = [
                'div[data-component-name="dateofdeatherror"]'
            ];
            var elementSelector = _.find(selectors, function (selector) {
                return this.$el.find(selector).length > 0;
            }, this);

            this.setScrollIntoView({
                element: this.$el.find(elementSelector)
            });
        }
    });
});
