define([
    'MvcModel'
], function (MvcModel) {
    'use strict';

    return MvcModel.extend({
        validation: {
            documentType: {
                blur: {
                    required: true
                }
            }
        },

        defaults: {
            documentType: null,
            documentSubType: null,
            documentSubType2: null,
            financialYear: null,
            audit: null,
            status: null
        }
    });

});
