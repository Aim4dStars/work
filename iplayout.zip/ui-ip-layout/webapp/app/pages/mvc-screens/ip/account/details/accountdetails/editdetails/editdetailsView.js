define([
    'app/pages/mvc-templates/modal/modalView'
], function (ModalView) {
    'use strict';
    return ModalView.extend({
        loadSpinner: function () {
            this.controller.viewChildren.update.loading(true);
            this.controller.viewChildren.cancel.disable();
        },

        unloadSpinner: function () {
            if (this.controller.viewChildren && this.controller.viewChildren.update) {
                this.controller.viewChildren.update.loading(false);
                this.controller.viewChildren.cancel.enable();
            }
        }
    });
});
