define(['MvcModel'],
    function (MvcModel) {
        'use strict';

        return MvcModel.extend({
            getTransferDataDTO: function () {
                var isCBO = this.get("cbo") === "yes";
                return {
                    "targetContainerId": this.get("containerId"),
                    "key": {
                        "accountId": this.get("accountId"),
                        "transferId": null
                    },
                    "isCBO": isCBO,
                    "sourceAccountKey": {
                        "accountId": this.get("accountId")
                    },
                    "targetAccountKey": {
                        "accountId": this.get("accountId")
                    },
                    "orderType": "In specie account transfer",
                };
            }
        });
    });
