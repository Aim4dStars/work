defineMvcController({
    name: 'delete',
    parentPath: 'mvc-screens/ip/account/details/beneficiariesautorev/editbeneficiaries/beneficiarysection',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['spinner', 'button', 'messagealert'],
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['underscore']
}, function (config, ModalController, _) {
    'use strict';

    return ModalController.extend({
        config: config,

        preRender: function () {
            if (this.model.get('showAutoReversionaryDeletePopup')) {
                var namesOfBeneficiariesToBeRemoved = this.parentController._filterNamesOfBeneficiaries(0, this.parentController.getAllSectionModelData());
                this.model.set('namesOfBeneficiariesToBeRemoved', namesOfBeneficiariesToBeRemoved);
            }
        },

        postRender: function () {
            this.getNameOfBeneficiaryToBeRemoved(this.model.get('rowIndex'));
        },

        getNameOfBeneficiaryToBeRemoved: function (rowIndex) {
            var beneficiary = this.parentController.getAllSectionModelData('beneficiaries')[rowIndex];
            if (_.isObject(beneficiary) && beneficiary.displayName) {
                this.model.set('nameOfBeneficiaryToBeRemoved', beneficiary.displayName);
            }
        },

        deleteForm: function () {
            this.view.showDeleting();
            var rowIndex = Number(this.model.get('rowIndex'));
            this.parentController.removeRow(rowIndex);
            this.closeModal();
        }
    });

});
