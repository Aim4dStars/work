defineMvcController({
    name: 'intraaccount',
    parentPath: 'mvc-screens/ip/account/assettransfer',
    hashName: 'intraaccount',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    extend: 'MvcController',
    viewComponents: ['termsandconditions', 'forminputautocomplete'],
    screens: ['assetlist', 'mvc-screens/ip/account/investmentorders/ordercapture/modelpreferences', 'mvc-screens/ip/account/assettransfer/transfer/transferform/cancel', 'terms'],
    mvcComponents: ['inputautocomplete', 'menuactioninput'],
    dependencies: ['rootController', 'underscore', 'jquery', 'app/pages/mvc-screens/ip/account/assettransfer/util/valuationService',
     'app/pages/mvc-screens/ip/account/assettransfer/util/tradableassetsService', 'app/pages/mvc-screens/ip/account/assettransfer/util/tradableinvestmentoptionsService',
     'app/pages/mvc-screens/ip/account/investmentorders/ordercapture/ordercapturePreferences', 'app/pages/mvc-screens/ip/account/assettransfer/intraaccount/modelPreferencesHelper',
     'app/pages/mvc-screens/ip/account/assettransfer/intraaccount/intraaccountSubmit', 'app/framework/services/optionsService', 'app/framework/helpers/format',
     'app/framework/services/Permissions', 'app/framework/services/analyticsService']
}, function (config, MvcController, rootController, _, $, valuationService, tradableassetsService, investmentoptionsService, ordercapturePreferences, modelPreferencesHelper, intraaccountSubmit, optionsService, format, Permissions, analyticsService) {
    'use strict';

    var intraaccountController = MvcController.extend({
        config: config,
        filterOptionsSource: [],
        targetId: 'a',
        requiredParams: ['a'],
        accountOptionsParam: 'a',
        isSourceMPFilter: false,
        autoHideSpinner: false,
        destinationPortfolioError: false,
        hasPermission: 'account.transfer.intraaccount.view',
        viewEvents: {
            'blur .mvc-quantityall input': 'applyToAll',
            'click .view-closeportfolio input': 'closePorfolioCheckboxChanged',
            'click .terms-and-conditions': 'openTermsAndConditions'
        },

        postRender: function () {
            var canViewSummaryBar = Permissions.ruleMatched('account.summary.bar.view', rootController.getUrlParams().a);
            if (!canViewSummaryBar) {
                this.view.hideSpinner();
                return;
            }
            this.model.on({
                'change:sourceContainer': this.sourceContainerChanged,
                'change:destinationContainer': this.destinationContainerChanged,
                'change:sourceportfoliosfilter': this.sourceFilterChanged,
                'change:destinationportfoliosfilter': this.destinationFilterChanged,
                'change:sourceportfolio': this.sourcePortfolioChanged,
                'change:destinationportfolio': this.destinationPortfolioChanged,
                'change:screenState': this.screenStateChanged,
                'change:closeportfolio': this.closePortfolioChanged,
                'change:incomepreference': this.incomePreferenceChanged
            }, this);

            this.model.set({
                'hasHoldings': true,
                'screenState': this.SCREEN_STATE.PREVIEW,
                'showCashTable': true,
                'accountId': rootController.getUrlParams().a
            });

            this.children.quantityall.model['getDollarsAllMaxValue'] = _.bind(this.model.getDollarsAllMaxValue, this.model);
            this.fetchScreenData();

            analyticsService.send({
                "pageName": "ng:account:assettransfer:intraaccount ",
                "pageType": "selfservice",
                "formName": "intraaccount transfer",
                "pageStep": "start",
                "trackDedupe": true
            });
        },

        fetchScreenData: function () {
            $.when(this.fetchValuationData(), tradableassetsService.getTradableAssets(this, tradableassetsService.assetTypeFilter.portfolios), investmentoptionsService.getInvestmentOptions(this))
                .done(_.bind(function (valuationData, tradablePortfolios, investmentOptions) {
                    this.populateDestinationPortfolio(tradablePortfolios);
                    this.model.set('investmentOptions', investmentOptions);
                    this.model.on('change', function () {
                        rootController.confirmNavigation(true);
                    }, this);
                    this.view.hideSpinner();
                }, this));
        },

        closePorfolioCheckboxChanged: function (event) {
            this.model.set('screenState', this.SCREEN_STATE.PREVIEW);
            var $checkbox = $(event.target);
            var isChecked = $checkbox.is(':checked');
            if (isChecked) {
                this.closePortoflioSelected = true;
            } else {
                this.closePortoflioSelected = false;
                this.viewChildren.portfolionotclosedwarning.show();
            }
        },

        closePortfolioChanged: function () {
            var closePortoflio = this.model.get('closeportfolio');
            if (closePortoflio) {
                this.isClosePortfolioChanging = true;
                this.children.assetlist.selectAllAssets();
                this.children.quantityall.setOption('percentage', 100);
                this.children.quantityall.disable();
                this.children.assetlist.toggleAllAssetQuantity(false);
                this.applyToAll();
                this.isClosePortfolioChanging = false;
                this.viewChildren.portfolionotclosedwarning.hide();
            } else {
                this.children.quantityall.enable();
                this.children.assetlist.toggleAllAssetQuantity(true);
            }
        },

        updateClosePortfolio: function () {
            var closePortfolio = this.model.get('closeportfolio');
            if (closePortfolio && !this.isClosePortfolioChanging) {
                this.model.set('closeportfolio', false);
                this.viewChildren.portfolionotclosedwarning.show();
            }
        },

        sourceContainerChanged: function () {
            var sourceContainer = this.model.get('sourceContainer');
            var selectedHolding = 0;
            this.resetSourcePortfolio();
            this.resetDestinationPortfolio();
            this.children.assetlist.resetCashModelValues();
            if (sourceContainer === 'directContainer') {
                selectedHolding = this.model.get('totalDirectHolding');
                this.view.disableDirectDestination();
                this.model.set('showSourcePortfolioSelector', false);
                this.model.set('destinationContainer', 'portfolioContainer');
            } else {
                this.view.enableDirectDestination();
                this.model.set('showSourcePortfolioSelector', true);
            }
            this.model.set('selectedHolding', format.formatMoney(selectedHolding, 2, '$'));
            this.populateAssetList(sourceContainer);
        },

        resetSourcePortfolio: function () {
            this.children.sourceportfolio.view.clearListOptions();
            if (this.filterOptionsSource.length > 0) {
                this.model.set('sourceportfoliosfilter', this.filterOptionsSource[0].value);
            }
        },

        resetDestinationPortfolio: function () {
            this.model.set('screenState', this.SCREEN_STATE.PREVIEW);
            this.model.set('showPreferences', false);
            this.model.set('showIncomePreference', false);
            this.model.set('destinationportfolio', '');
            this.model.set('destinationportfoliosfilter', 'managedPortfolios');
            this.viewChildren.previewemptystate.hide();
            var sourcePortfolio = this.model.get('sourceportfolio');
            if (!_.isNull(sourcePortfolio) && !_.isUndefined(sourcePortfolio)) {
                this.removePortfolio(sourcePortfolio);
            } else {
                var managedPortfolios = this.model.get('managedPortfolios');
                var tailoredPortfolios = this.model.get('tailoredPortfolios');
                this.model.set('updatedManagedPortfolios', managedPortfolios);
                this.model.set('updatedTailoredPortfolios', tailoredPortfolios);
                this.renderPortfolioSelector('managedPortfolios', 'destinationportfolio', managedPortfolios);
            }
        },

        removePortfolio: function (sourcePortfolio) {
            if (tradableassetsService.isManagedPortfolio(sourcePortfolio)) {
                var managedPortfolios = this.model.get('managedPortfolios');
                if (!_.isUndefined(managedPortfolios)) {
                    managedPortfolios = tradableassetsService.removePortfolio(sourcePortfolio, managedPortfolios);
                }
                this.model.set('updatedManagedPortfolios', managedPortfolios);
                this.renderPortfolioSelector('managedPortfolios', 'destinationportfolio', managedPortfolios);
            } else if (tradableassetsService.isTailoredPortfolio(sourcePortfolio)) {
                var tailoredPortfolios = this.model.get('tailoredPortfolios');
                if (!_.isUndefined(tailoredPortfolios)) {
                    tailoredPortfolios = tradableassetsService.removePortfolio(sourcePortfolio, tailoredPortfolios);
                }
                this.model.set('updatedTailoredPortfolios', tailoredPortfolios);
            }
        },

        destinationContainerChanged: function () {
            var destinationContainer = this.model.get('destinationContainer');
            this.model.set('screenState', this.SCREEN_STATE.PREVIEW);
            this.viewChildren.previewemptystate.hide();
            if (destinationContainer === 'portfolioContainer') {
                this.populateCashTable();
                this.model.set('showDestinationPortfolioSelector', true);
            } else {
                this.model.set('showCashTable', false);
                this.children.assetlist.updateTotalTransferAmount();
                this.resetDestinationPortfolio();
                this.model.set('showDestinationPortfolioSelector', false);
            }
        },

        fetchValuationData: function () {
            var deferred = $.Deferred();
            valuationService.getValuationData(this)
                .done(_.bind(function (valuationData) {
                    this.populatePortfolio(valuationData);
                    this.populateIncomePreferenceOption(valuationData);
                    deferred.resolve();
                }, this));

            return deferred.promise();
        },

        populateIncomePreferenceOption: function (valuation) {
            var cashInvestment = valuationService.filterCashAsset(valuation).investments;
            var cashName = "";
            if (_.size(cashInvestment) > 0) {
                cashName = cashInvestment[0].name;
            }
            var options = [{
                label: 'Transfer to ' + cashName,
                value: 'transfer'
            }, {
                label: 'Reinvest into model',
                value: 'reinvest'
            }];
            this.model.set('cashName', cashName);
            this.viewChildren.incomepreference.setOptions(options);
        },

        incomePreferenceChanged: function () {
            this.model.set('screenState', this.SCREEN_STATE.PREVIEW);
            var incomePreference = this.model.get('incomepreference');
            if (incomePreference === 'transfer') {
                this.viewChildren.transfercashtooltip.showTooltip();
            }
        },

        populateAssetList: function (sourceContainer, investments) {
            this.closePortoflioSelected = false;
            this.model.set('closeportfolio', false);
            this.viewChildren.previewerror.hide();
            this.viewChildren.previewwarning.hide();
            this.children.quantityall.setOption('percentage', '');
            if (sourceContainer === 'directContainer') {
                var disablePendingMF = true;
                investments = this.model.get('heldDirectAssets');
                this.populateCashTable();
                this.children.assetlist.populateAssetList(investments, disablePendingMF);
            } else {
                this.children.assetlist.populateAssetList(investments);
            }
        },

        populateCashTable: function () {
            var cashAsset = this.model.get('cashAsset');
            if (!_.isUndefined(cashAsset)) {
                this.model.set('showCashTable', true);
                this.children.assetlist.populateCashTable(cashAsset.investments);
            }
        },

        populatePortfolio: function (valuationData) {
            this.filterOptionsSource = [];
            this.isSourceMPFilter = false;
            var managedPortfolioData = valuationService.filterManagedPortfolio(valuationData);
            if (!_.isUndefined(managedPortfolioData)) {
                var MPFilterObj = {
                    label: 'All managed portfolios',
                    value: 'managedPortfolios'
                };
                this.model.set('allHeldManagedPortfolios', managedPortfolioData.investments);
                managedPortfolioData = this.getSourcePorfolioData(managedPortfolioData, "Managed portfolio", 'heldManagedPortfolios', MPFilterObj);
            }

            var tailoredPortfolioData = valuationService.filterTailoredPortfolio(valuationData);
            if (!_.isUndefined(tailoredPortfolioData)) {
                var TPFilterObj = {
                    label: 'All tailored portfolios',
                    value: 'tailoredPortfolios'
                };
                this.model.set('allHeldTailoredPortfolios', tailoredPortfolioData.investments);
                tailoredPortfolioData = this.getSourcePorfolioData(tailoredPortfolioData, "Tailored portfolio", 'heldTailoredPortfolios', TPFilterObj);
            }

            var cashAsset = valuationService.filterCashAsset(valuationData);

            var investments = valuationService.filterDirectContainerInvestments(valuationData);
            investments = valuationService.mergeDirectContainerInvestments(investments);
            var totalDirectHolding = valuationService.getTotalHolding(investments);
            this.model.set('totalDirectHolding', totalDirectHolding);
            this.model.set('cashAsset', cashAsset);
            this.model.set('destinationContainer', 'portfolioContainer');
            this.setDefaultSourceContainer(investments, managedPortfolioData, tailoredPortfolioData);
        },

        getSourcePorfolioData: function (portfolioData, assetType, portfolioModelName, filterObj) {
            portfolioData = valuationService.filterByHolding(portfolioData.investments);
            if (_.isArray(portfolioData) && portfolioData.length > 0) {
                portfolioData = valuationService.addAssetType(assetType, portfolioData);
                this.model.set(portfolioModelName, portfolioData);
                this.addFilterOption(filterObj);
                if (portfolioModelName === 'heldManagedPortfolios') {
                    this.model.set('sourceportfoliosfilter', 'managedPortfolios');
                    this.isSourceMPFilter = true;
                } else if (portfolioModelName === 'heldTailoredPortfolios' && !this.isSourceMPFilter) {
                    this.model.set('sourceportfoliosfilter', 'tailoredPortfolios');
                }
            }

            return portfolioData;
        },

        setDefaultSourceContainer: function (investments, managedPortfolioData, tailoredPortfolioData) {
            var hasHoldings = false;
            var managedPortfolioEmpty = _.isUndefined(managedPortfolioData) || managedPortfolioData.length === 0;
            var tailoredPortfolioEmpty = _.isUndefined(tailoredPortfolioData) || tailoredPortfolioData.length === 0;
            var isSourcePortfolioContainer = false;
            var defaultContainer = '';
            if (!managedPortfolioEmpty || !tailoredPortfolioEmpty) {
                defaultContainer = 'portfolioContainer';
                hasHoldings = true;
                isSourcePortfolioContainer = true;
            } else {
                this.view.disablePortfolioSource();
            }

            if (_.isArray(investments) && investments.length > 0) {
                this.model.set('heldDirectAssets', investments);
                hasHoldings = true;
                if (!isSourcePortfolioContainer) {
                    defaultContainer = 'directContainer';
                }
            } else {
                this.view.disableDirectSource();
            }
            this.model.set('hasHoldings', hasHoldings);
            this.model.set('defaultContainer', defaultContainer);
            this.model.set('sourceContainer', defaultContainer);
            this.children.assetlist.setConfirmNavigation();
            this.children.assetlist.updateTotalTransferAmount();
        },

        addFilterOption: function (filterObj) {
            this.filterOptionsSource.push(filterObj);
            this.viewChildren.sourceportfoliosfilter.setOptions(this.filterOptionsSource);
        },

        sourceFilterChanged: function () {
            var filterOption = this.model.get('sourceportfoliosfilter');
            this.children.sourceportfolio.view.clearListOptions();
            if (filterOption === 'managedPortfolios') {
                var managedPortfolioData = this.model.get('heldManagedPortfolios');
                this.renderPortfolioSelector('managedPortfolios', 'sourceportfolio', managedPortfolioData);
            } else {
                var tailoredPortfolioData = this.model.get('heldTailoredPortfolios');
                this.renderPortfolioSelector('tailoredPortfolios', 'sourceportfolio', tailoredPortfolioData);
            }
        },

        destinationFilterChanged: function () {
            var filterOption = this.model.get('destinationportfoliosfilter');
            this.children.destinationportfolio.view.clearListOptions();
            if (filterOption === 'managedPortfolios') {
                var managedPortfolioData = this.model.get('updatedManagedPortfolios');
                this.renderPortfolioSelector('managedPortfolios', 'destinationportfolio', managedPortfolioData);
            } else if (filterOption === 'tailoredPortfolios') {
                var tailoredPortfolioData = this.model.get('updatedTailoredPortfolios');
                this.renderPortfolioSelector('tailoredPortfolios', 'destinationportfolio', tailoredPortfolioData);
            } else {
                var menuConfig = {
                    managedPortfolios: {
                        items: this.getClientHoldings('managedPortfolios')
                    },
                    tailoredPortfolios: {
                        items: this.getClientHoldings('tailoredPortfolios')
                    }
                };
                this.children.destinationportfolio.renderMenuData(menuConfig);
            }
        },

        getClientHoldings: function (portfolioName) {
            var portfolios = this.model.get('updatedManagedPortfolios');
            if (portfolioName === 'tailoredPortfolios') {
                portfolios = this.model.get('updatedTailoredPortfolios');
            }
            return _.filter(portfolios, function (portfolio) {
                return portfolio.availableBalance > 0;
            });
        },

        renderPortfolioSelector: function (type, child, portfolios) {
            var menuConfig = {};
            menuConfig[type] = {
                items: portfolios
            };

            this.children[child].renderMenuData(menuConfig);
        },

        sourcePortfolioChanged: function () {
            this.view.truncateAssetName(this.viewChildren.sourceportfolio.$el);
            this.viewChildren.portfolionotclosedwarning.hide();
            var sourcePortfolio = this.model.get('sourceportfolio');
            if (this.model.get('sourceContainer') !== 'directContainer') {
                this.model.set('selectedHolding', format.formatMoney(0, 2, '$'));
            }
            var investments;
            var isSourcePortfolioDefined = !_.isNull(sourcePortfolio) && !_.isUndefined(sourcePortfolio);
            if (isSourcePortfolioDefined) {
                this.viewChildren.portfolionotclosedwarning.show();
                this.model.set('selectedHolding', format.formatMoney(sourcePortfolio.availableBalance, 2, '$'));
                investments = this.model.structureInvestments(sourcePortfolio.investmentAssets);
                investments = valuationService.filterByAssetType(investments);
            }
            this.resetDestinationPortfolio();
            this.populateAssetList('portfolioContainer', investments);
        },

        destinationPortfolioChanged: function () {
            this.view.truncateAssetName(this.viewChildren.destinationportfolio.$el);
            this.model.set('screenState', this.SCREEN_STATE.PREVIEW);
            this.viewChildren.previewemptystate.hide();
            var destinationPortfolio = this.model.get('destinationportfolio');
            this.hideDestinationErrorMessage();
            this.model.set('showPreferences', false);
            this.model.set('showIncomePreference', false);
            if (!_.isEmpty(destinationPortfolio) && _.isObject(destinationPortfolio)) {
                this.checkPreferencePermission(destinationPortfolio);
                if (tradableassetsService.isSuspended(destinationPortfolio.asset)) {
                    this.showDestinationErrorMessage();
                } else {
                    var isTP = tradableassetsService.isTailoredPortfolio(destinationPortfolio.asset);
                    this.showMinAmountWarningMessage(destinationPortfolio, isTP);
                }
            }
        },

        checkPreferencePermission: function (portfolio) {
            var hasPermission = false;
            var hasIncomePermission = false;
            if (tradableassetsService.isManagedPortfolio(portfolio.asset)) {
                hasPermission = Permissions.ruleMatched('modelportfolio.preference.edit', rootController.getUrlParams().a);
                hasIncomePermission = Permissions.ruleMatched('modelportfolio.incomepreference.view', rootController.getUrlParams().a);
            } else if (tradableassetsService.isTailoredPortfolio(portfolio.asset)) {
                hasPermission = Permissions.ruleMatched('modelportfolio.tailored.preference.edit', rootController.getUrlParams().a);
                hasIncomePermission = Permissions.ruleMatched('modelportfolio.tailored.incomepreference.view', rootController.getUrlParams().a);
            }
            if (hasPermission) {
                this.model.set('showPreferences', true);
                this.getPreferences(portfolio);
            }

            if (hasIncomePermission) {
                this.model.set('showIncomePreference', true);
                this.setIncomePreference(portfolio);
            }
        },

        setIncomePreference: function (portfolio) {
            var incomePreference = 'reinvest';
            if (portfolio.availableBalance > 0) {
                incomePreference = portfolio.incomePreference;
                if (_.isString(incomePreference)) {
                    incomePreference = incomePreference.toLowerCase();
                }
            }
            if (incomePreference === 'transfer') {
                this.viewChildren.transfercashtooltip.showTooltip();
            }
            this.model.set('incomepreference', incomePreference);
        },

        populateDestinationPortfolio: function (tradablePortfolios) {
            var managedPortfolioData = tradableassetsService.filterManagedPortfolio(tradablePortfolios);
            var tailoredPortfolioData = tradableassetsService.filterTailoredPortfolio(tradablePortfolios);

            managedPortfolioData = tradableassetsService.addDataToPortfolio(managedPortfolioData, this.model.get('allHeldManagedPortfolios'));
            managedPortfolioData = tradableassetsService.filterByStatus(managedPortfolioData);
            tailoredPortfolioData = tradableassetsService.addDataToPortfolio(tailoredPortfolioData, this.model.get('allHeldTailoredPortfolios'));
            tailoredPortfolioData = tradableassetsService.filterByStatus(tailoredPortfolioData);

            if (tailoredPortfolioData.length > 0) {
                this.viewChildren.destinationportfoliosfilter.setOptions(this.view.destinationFilterOption);
            }
            this.model.set({
                'managedPortfolios': managedPortfolioData,
                'updatedManagedPortfolios': managedPortfolioData,
                'tailoredPortfolios': tailoredPortfolioData,
                'updatedTailoredPortfolios': tailoredPortfolioData
            });
            this.renderPortfolioSelector('managedPortfolios', 'destinationportfolio', managedPortfolioData);
        },

        insertSubHeadings: function (assetlistData, groupBy) {
            return this.parentController.insertSubHeadings(assetlistData, groupBy);
        },

        applyToAll: function () {
            this.viewChildren.previewemptystate.hide();
            var quantityObj = this.children.quantityall.getState();
            if (!this.children.quantityall.model.validateAttribute(quantityObj.option, 'blur').valid) {
                return;
            }
            this.children.assetlist.applyToAll(quantityObj);
        },

        openTermsAndConditions: function () {
            this.children.terms.openModal({});
        }

    });

    _.extend(intraaccountController.prototype, ordercapturePreferences, modelPreferencesHelper, intraaccountSubmit);
    return intraaccountController;
});
