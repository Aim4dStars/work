define([
    'app/pages/mvc-templates/modal/modalView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/terms/_terms.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (ModalView, _termsTemplate, componentXml, Handlebars) {
    'use strict';

    return ModalView.extend({

        preRender: function () {
            Handlebars.registerPartial('terms', componentXml.encode(_termsTemplate));
        }
    });

});
