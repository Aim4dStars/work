define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/rightsexercise/rightsexerciseModel'
],
    function (RightsExerciseModel) {
        'use strict';

        return RightsExerciseModel.extend({});
    });
