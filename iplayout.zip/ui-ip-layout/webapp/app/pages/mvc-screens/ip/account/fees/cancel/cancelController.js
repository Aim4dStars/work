defineMvcController({
    name: 'cancel',
    parentPath: 'mvc-screens/ip/account/fees',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal'
}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config,

        cancelForm: function () {
            this.closeModal();
            this.parentController.cancelForm();
        }
    });
});
