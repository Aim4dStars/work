define(['MvcView', 'jquery'],
    function (MvcView, $) {
        'use strict';

        return MvcView.extend({
            updateDynamicDisabledFields: function () {
                var $otherRows = this.$el.find('.mvc-assets tbody tr:not(:first-child) .js-disable-other-rows');

                $otherRows.find('input')
                    .prop('disabled', 'disabled')
                    .addClass("ui-state-disabled");
                $otherRows.find('.error').remove();
                $otherRows.removeClass('validation-container');
            },

            showAssetCodeError: function (element) {
                var validationContainer = $(".parent-" + element).closest(".validation-container");
                validationContainer.addClass("custom-invalid");
                validationContainer.find(".error-asset-code").show();
            },

            hideAssetCodeError: function (element) {
                var validationContainer = $(".parent-" + element).closest(".validation-container");
                validationContainer.removeClass("custom-invalid");
                validationContainer.find(".error-asset-code").hide();
            },

            getForm: function () {
                return this.$el.find('form');
            }
        });
    });
