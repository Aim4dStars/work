defineMvcController({
    name: 'smsf',
    parentPath: 'mvc-screens/ip/account/details/accountdetails',
    viewHtml: true,
    dependencies: ['underscore'],
    viewComponents: ['definitionlist'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config

    });
});
