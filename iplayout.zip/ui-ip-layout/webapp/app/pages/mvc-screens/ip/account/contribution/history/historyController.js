defineMvcController({
    name: 'history',
    parentPath: 'mvc-screens/ip/account/contribution',
    viewHtml: true,
    viewJs: true,
    hashName: 'history',
    hashDefault: false,
    viewComponents: ['inputselect', 'button', 'tooltip'],
    mvcComponents: ['search', 'section', 'tablev3'],
    screens: ['financialyear'],
    dependencies: ['rootController', 'underscore', 'jquery', 'app/framework/handlebars/format', 'app/framework/helpers/format', 'app/framework/services/Permissions'],
    extend: 'MvcController'
}, function (config, MvcController, rootController, _, $, format, formatHelper, Permissions) {
    'use strict';

    return MvcController.extend({
        config: config,
        autoHideSpinner: false,
        contCapsUrl: '../api/v1_0/accounts/<%=a%>/super/contributioncaps?date=<%=sc%>',
        contHistoryUrl: '../api/v1_0/accounts/<%=a%>/super/contributionhistory?date=<%=sc%>',
        financialYearUrl: '../api/v1_0/accounts/<%=a%>/availablefinancialyears',
        defaultFinancialYear: "",

        preRender: function () {
            this.model.set('lastContributionVisible', false);
            this.model.set('responseDateVisible', false);

            // only show 'Make contribution' link to super accumulation and non-commenced pension accounts
            this.model.set('makeContributionLinkVisible', Permissions.ruleMatched('account.super.contributions.menu.view', rootController.getUrlParams().a) || Permissions.ruleMatched('account.super.pension.commencement.view', rootController.getUrlParams().a));
        },

        postRender: function () {
            this._hideMessage('ajaxerror');
            this._fetchInitialData();
        },

        _fetchInitialData: function () {
            this.view.showSpinner();
            $.when(this._fetchFinancialYearData())
                .done(_.bind(function () {
                    this._search();
                }, this))
                .fail(_.bind(function () {
                    this._showMessage('ajaxerror');
                    this.view.hideSpinner();
                }, this));
        },


        _fetchScreenData: function () {
            $.when(this._loadHistoryData(), this._loadCapsData())
                .done(_.bind(function (historyData, capsData) {
                    this._processSummaryData(historyData, capsData);
                    this._processDetailData(historyData.data);
                }, this))
                .fail(_.bind(function () {
                    this._showMessage('ajaxerror');
                }, this))
                .always(_.bind(function () {
                    this.view.hideSpinner();
                }, this));
        },


        _loadHistoryData: function () {
            var deferred = $.Deferred();
            var dateCriteriaValue = this.children.searchfinancialyear.model.get('financialYear') || this.defaultFinancialYear;
            var url = this.getUrl({
                'a': rootController.getUrlParams().a,
                'sc': dateCriteriaValue
            }, this.contHistoryUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    deferred.resolve(data);
                }, this),
                error: function () {
                    deferred.reject();
                }
            };
            this.ajaxGet(params);
            return deferred.promise();
        },

        _loadCapsData: function () {
            var deferred = $.Deferred();
            var dateCriteriaValue = this.children.searchfinancialyear.model.get('financialYear') || this.defaultFinancialYear;
            var url = this.getUrl({
                'a': rootController.getUrlParams().a,
                'sc': dateCriteriaValue
            }, this.contCapsUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    deferred.resolve(data);
                }, this),
                error: function () {
                    deferred.reject();
                }
            };
            this.ajaxGet(params);
            return deferred.promise();
        },

        _fetchFinancialYearData: function () {
            var deferred = $.Deferred();
            var params = {};
            params.url = this.getUrl(rootController.getUrlParams(), this.financialYearUrl);
            params.success = _.bind(function (data) {
                if (data && data.data && data.data.resultList && data.data.resultList.length) {
                    var options = [];
                    _.each(data.data.resultList, function (yearData) {
                        options.push({
                            label: 'FY ' + yearData.displayText,
                            value: yearData.startDate
                        });
                    });
                    // first selectable item has a special name
                    var currentFinancialYear = options[0];
                    currentFinancialYear.label = 'Current FY';

                    var params = rootController.getUrlParams();
                    var filtered;
                    if (params.sc) {
                        filtered = _.where(options, {
                            value: params.sc
                        });
                    }
                    this.defaultFinancialYear = (!_.isEmpty(filtered) ? filtered[0] : currentFinancialYear).value;
                    this.model.set('currentFinancialYear', this.defaultFinancialYear);
                    this.children.searchfinancialyear.children.financialyear.setOptions(options);
                    this.children.searchfinancialyear.children.financialyear.model.set('financialYear', this.defaultFinancialYear);
                    deferred.resolve();
                }
            }, this);
            params.error = function () {
                deferred.reject();
            };

            this.ajaxGet(params);
            return deferred.promise();
        },

        _processSummaryData: function (historyResponse, capsResponse) {
            if (_.isObject(historyResponse) && _.isObject(historyResponse.data)) {
                var summaryData = historyResponse.data.contributionSummary;
                var selectedFinancialYear = this.children.searchfinancialyear.model.get('financialYear');

                if (historyResponse.lastUpdatedTime && this._showHideLastUpdatedTime(selectedFinancialYear)) {
                    this.model.set('responseDateVisible', true);
                    this.model.set('responseDate', this._formatDate(historyResponse.lastUpdatedTime));
                }

                if (summaryData && this._showHideLastUpdatedTime(selectedFinancialYear) && _.isNumber(summaryData.lastContributionAmount)) {
                    this.model.set('lastContributionVisible', true);
                    this.model.set('lastContributionAmount', format(summaryData.lastContributionAmount, 'dollar', true));
                    this.model.set('lastContributionTime', this._formatDate(summaryData.lastContributionTime));
                    this.model.set('lastContributionUrl', this._getLastContributionUrl(summaryData));
                }

                var capsData = {};
                if (_.isObject(capsResponse) && _.isObject(capsResponse.data) && _.isArray(capsResponse.data.resultList)) {
                    var capsClass = _.pluck(capsResponse.data.resultList[0].contributionCaps, "contributionClassification");
                    var capsAmount = _.pluck(capsResponse.data.resultList[0].contributionCaps, "amount");
                    capsData = _.object(capsClass, capsAmount);

                    //>>>> TODO: remove me when more caps are to be rendered.
                    //  Initially only use the caps 'concessional' value.
                    capsData = {
                        'conc': capsData['conc']
                    };
                    //<<<<
                }
                if (!summaryData || !_.isObject(summaryData)) {
                    summaryData = {};
                    summaryData.contributionSummaryClassifications = capsResponse.data.resultList[0].contributionCaps;
                    summaryData.totalContributions = 0;
                }

                summaryData.contributionSummaryClassifications = _.compact(_.map(summaryData.contributionSummaryClassifications, function (data) {

                    // Only show 'Other' row if there is an amount for the value;
                    if (data.contributionClassificationLabel === 'other' && !(data.total || data.total === 0)) {
                        return;
                    }
                    if (!data.total) {
                        data.total = 0;
                    }

                    // apply contribution caps;
                    data.capAmount = capsData[data.contributionClassification] || '-';
                    data.availableBalance = _.isNumber(data.capAmount) ? data.capAmount - data.total : data.capAmount;
                    return data;
                }));
                this._getSelectedFinancialYearLabel();
                this.children.summarytable.setRows({
                    rowName: 'contributionSummaryClassifications'
                }, summaryData);
            }
            this.children.summarytable.renderComponentView();
        },

        _processDetailData: function (data) {
            var table = this.children.contributiondetails;
            if (!_.isUndefined(data.contributionSummary) && !_.isNull(data.contributionSummary)) {
                table.model.set('totalContributions', data.contributionSummary.totalContributions);
            }
            table.setRows('rowName', data.contributionByClassifications);
            table.renderComponentView();
        },

        _getLastContributionUrl: function (data) {
            if (_.isObject(data)) {
                var params = rootController.getUrlParams();
                var transactionDate = this._formatDate(data.lastContributionTime, 'YYYY-MM-dd');
                return '#ng/account/transactions/history?a=' + params.a + '&sd=' + transactionDate + '&ed=' + transactionDate + '&filter=contribution';
            }
        },

        _search: function () {
            this.view.showSpinner();
            this._fetchScreenData();
        },

        _showHideLastUpdatedTime: function (year) {
            var currentFinancialYear = this.model.get('currentFinancialYear');
            var selectedFinancialYear = _.isUndefined(year) ? currentFinancialYear : year;
            if (currentFinancialYear !== selectedFinancialYear) {
                this.model.set('responseDateVisible', false);
                this.model.set('lastContributionVisible', false);
                return false;
            }
            return true;
        },

        _getSelectedFinancialYearLabel: function () {
            var selectedFinancialYearLabel = this.view.$el.find('.mvc-financialyear .ui-inputselect-status').text();
            this.model.set('selectedFinancialYearLabel', selectedFinancialYearLabel);
        },

        _formatDate: function (date, format) {
            return formatHelper.formatDate(date, {
                convertTimezone: true,
                format: format || 'dd MMM YYYY',
                type: 'date'
            });
        },

        buildPdfLink: function () {
            var url = '../reportpdf/contributionHistoryPdfReport';
            url += '?account-id=' + rootController.getUrlParams().a;
            url += '&date=' + (this.children.searchfinancialyear.model.get('financialYear') || this.defaultFinancialYear);

            window.open(url, '_report');
        },

        _showMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].hide();
            }
        },

    });

});
