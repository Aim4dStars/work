defineMvcController({
    name: 'uploadstatus',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie/inspecieupload',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    viewComponents: ['icon', 'spinner'],
    dependencies: ['app/framework/services/analyticsService']
}, function (config, ModalController, analyticsService) {
    'use strict';

    return ModalController.extend({
        config: config,

        viewEvents: {
            'click .terms-and-conditions': 'openTermsAndConditions'
        },

        postRender: function () {
            if (this.model.get('showError')) {
                this.setErrors(this.model.get('errors'));

                analyticsService.send({
                    "pageName": " ng:account:assettransfer:inspecie",
                    "pageType": "selfservice",
                    "formName": "inspecie transfer",
                    "dialogTitle": "there are errors with your asset transfer upload"
                });
            } else {
                this.setInProgress();

                analyticsService.send({
                    "pageName": "ng:account:assettransfer:inspecie",
                    "pageType": "selfservice",
                    "formName": "inspecie transfer",
                    "dialogTitle": "asset verified"
                });
            }
        },

        setInProgress: function () {
            this.model.set({
                'showInProgress': true,
                'showError': false,
                'showSuccess': false
            });
            this.viewChildren.spinner.spinnerOn();
        },

        setErrors: function (errors) {
            this.view.showErrors(errors);
            this.model.set({
                'showInProgress': false,
                'showError': true,
                'showSuccess': false,
                'numberOfErrors': errors.length
            });
        },

        setSuccess: function (successData) {
            this.view.showWarnings(successData.warnings);
            this.model.set({
                'showInProgress': false,
                'showError': false,
                'showSuccess': true,
                'managedPortfolio': successData.managedportfolios,
                'tailoredPortfolio': successData.tailoredportfolios
            });

            this.setAssetSourceLabel(successData.assetSource);
            this.showTransferIntoLabel(successData.transferInto);
        },

        setAssetSourceLabel: function (assetSource) {
            var label;
            if (assetSource === 'listedSecurityChessSponsored') {
                label = 'Listed securities - CHESS sponsored';
            } else if (assetSource === 'listedSecuritiesIssuerSponsored' || assetSource === 'LS_ISSUER_SPONSORED') {
                label = 'Listed securities - issuer sponsored';
            } else if (assetSource === 'managedFunds' || assetSource === 'MANAGED_FUND') {
                label = 'Managed funds - held with fund manager';
            } else if (assetSource === 'assetsFromOtherPlatform' || assetSource === 'LS_OTHER') {
                label = 'Assets from any other platform';
            } else if (assetSource === 'LS_BROKER_SPONSORED') {
                label = 'Listed securities - Broker sponsored';
            }

            this.model.set('assetSourceLabel', label);
        },

        showTransferIntoLabel: function (transferInto) {
            var label = transferInto;
            if (transferInto === 'directHolding') {
                label = 'Direct holding in this Panorama account';
            }
            if (transferInto === 'managedPortfolio') {
                var managedPortfolio = this.model.get('managedPortfolio');
                label = managedPortfolio.assetCode + ' ' + managedPortfolio.assetName;
            }
            if (transferInto === 'tailoredPortfolio') {
                var tailoredPortfolio = this.model.get('tailoredPortfolio');
                label = tailoredPortfolio.assetCode + ' ' + tailoredPortfolio.assetName;
            }

            this.model.set('transferIntoLabel', label);
        },

        submit: function () {
            var agree = this.model.get('agree');
            if (agree !== 'agreed') {
                this.viewChildren.termsandconditions.turnintoTooltip();
            } else {
                this.parentController.submit();
            }
        },

        cancel: function () {
            this.closeModal();
        },

        openTermsAndConditions: function (ev) {
            ev.preventDefault();
            this.model.set('showTerms', true);
        },

        closeTermsAndConditions: function () {
            this.model.unset('showTerms');
        },

        onBeforeCloseModal: function () {
            var screenState = this.model.get('showTerms');
            if (screenState) {
                this.model.unset('showTerms');
                return false;
            }
            this.parentController.setFileUploading(false);
            return true;
        },
    });
});
