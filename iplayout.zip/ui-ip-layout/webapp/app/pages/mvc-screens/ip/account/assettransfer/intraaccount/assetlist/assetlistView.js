define([
    'MvcView',
    'jquery',
    'underscore'
], function (MvcView, $, _) {
    'use strict';

    return MvcView.extend({

        addColSpanForHeadings: function () {
            var rows = $('.mvc-assetlisttable table tr');
            $.each(rows, function (ind, row) {
                var columns = $(row).find('td');
                if (_.isObject(columns) && columns.length > 3) {
                    var assetCodeColumn = columns[0];
                    if ($(assetCodeColumn).find('.sub-heading-two').length > 0) {
                        $(assetCodeColumn).attr('colspan', 3);
                        $(columns[1]).remove();
                        $(columns[2]).remove();
                    }
                }
            });
        },

        toggleRowState: function (quantityEle, isChecked) {
            if (!_.isUndefined(quantityEle)) {
                var name = quantityEle.name;
                var className = ".mvc-" + name;
                var row = $(className).closest("tr");
                if (isChecked) {
                    $(row).removeClass("disabled");
                } else {
                    $(row).addClass("disabled");
                }
            }
        },

        getClassName: function (assetId) {
            var element = $("[data-index=" + assetId + "]");
            var eleClasses = $(element).attr("class");
            if (!_.isUndefined(eleClasses)) {
                eleClasses = eleClasses.trim().split(" ");
                return _.find(eleClasses, function (classe) {
                    return classe.indexOf("mvc-quantity") !== -1;
                });
            }
        },

        showMaxError: function (assetId, errorMessage, modelName, modelValue) {
            var validationContainer = this.getValidationContainer(assetId);
            $(validationContainer).addClass("custom-invalid");
            this.model.set(modelName, modelValue);
            if (this.model.validateAttribute(modelName, 'change').valid) {
                if ($(validationContainer).find('.max-error').length === 0) {
                    $(validationContainer).append("<div class='max-error'>" + errorMessage + "</div>");
                } else {
                    $(validationContainer).find('.max-error').show();
                }
            } else {
                $(validationContainer).find('.max-error').hide();
            }
        },

        hideMaxError: function (assetId) {
            var validationContainer = this.getValidationContainer(assetId);
            $(validationContainer).removeClass("custom-invalid");
            $(validationContainer).find('.max-error').hide();
        },

        getValidationContainer: function (assetId) {
            var element = $("[data-index=" + assetId + "]");
            var column = $(element).closest('td');
            return $(column).find(".validation-container");
        }
    });
});
