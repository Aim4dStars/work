defineMvcController({
    name: 'deductionnotice',
    parentPath: 'mvc-screens/ip/account/contribution/personaltax',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'deductionnotice',
    extend: 'MvcController',
    viewComponents: ['button', 'tooltip', 'snapshot', 'menuaction', 'messagedisclaimer', 'messagealert'],
    mvcComponents: ['search', 'tablev3'],
    dependencies: ['underscore', 'jquery', 'rootController', 'app/framework/handlebars/format', 'app/framework/router']
}, function (config, MvcController, _, $, rootController, format, router) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        hasPermission: 'account.super.personaltaxdeductionnotice.update',
        noticeUrl: '../api/superpersonaltaxdeduction/v1_0/accounts/<%=a%>/notices?date=<%=sc%>',

        preRender: function () {

            this.model.on('change:amount', _.bind(this.formatAmount, this));

            var data = this.parentController.model.get('data') || {};
            this.model.set({
                docId: data.docId,
                originalDocId: data.originalDocId,
                financialYear: data.financialYear,
                financialYearPeriod: data.financialYearPeriod,
                totalContributions: data.totalContributions,
                totalNotifiedAmount: data.totalNotifiedAmount,
                amountAvailableForNewNotices: data.amountAvailableForNewNotices,
                amountAvailableBeforeReachingCap: data.amountAvailableBeforeReachingCap,
                originalAmount: data.originalAmount,
                formattedAmount: format(data.totalNotifiedAmount, 'dollar', true),
                unalterableNoticeAmount: data.unalterableNoticeAmount,
            });

            if (data.docId) {
                this.model.validation.amount.blur.minValue = data.unalterableNoticeAmount || 0;
                this.model.set('isClaimOrCanVaryNotice', data.originalAmount > data.unalterableNoticeAmount);
            } else {
                this.model.validation.amount.blur.minValue = 0;
                this.model.set('isClaimOrCanVaryNotice', true);
            }

            var params = this.getUrlParams();
            this.model.set('contributionHistoryUrl', "#ng/account/contribution/history?a=" + params.a + (params.sc ? '&sc=' + params.sc : ''));
        },

        postRender: function () {
            this._hideAllMessage();
        },

        formatAmount: function (event, amount) {
            var totalNotifiedAmount = this.model.get('totalNotifiedAmount');
            var originalAmount = this.model.get('originalAmount');

            totalNotifiedAmount = _.isFinite(Number(totalNotifiedAmount)) ? Number(totalNotifiedAmount) : 0;
            originalAmount = _.isFinite(Number(originalAmount)) ? Number(originalAmount) : 0;
            amount = !_.isNull(amount) && _.isFinite(Number(amount)) ? Number(amount) : originalAmount;
            amount = totalNotifiedAmount - (originalAmount - amount);

            this.model.set('formattedAmount', format(amount, 'dollar', true));

            this.toggleExceedConcessionalCapMessage();
            this.showConfirmationWhenModelDirty();
        },

        toggleExceedConcessionalCapMessage: function () {
            if (!this.model.get('docId') && Number(this.model.get('amount')) > 0 &&
                Number(this.model.get('amount')) <= this.model.get('amountAvailableForNewNotices') &&
                Number(this.model.get('amount')) > this.model.get('amountAvailableBeforeReachingCap')
            ) {
                this.viewChildren.exceedconcessionalcapmessage.show();
            } else {
                this.viewChildren.exceedconcessionalcapmessage.hide();
            }
        },

        showConfirmationWhenModelDirty: function () {
            if (this.model.get('amount')) {
                rootController.confirmNavigation(true);
            } else {
                rootController.confirmNavigation(false);
            }
        },

        submitNotice: function () {
            if (!this.model.get('agree')) {
                this.viewChildren.termsandconditions.turnintoTooltip();
            } else {
                if (!this.validateForm(this.view.$el, 'blur')) {
                    return;
                }

                var url = this.getUrl(this.getUrlParams(), this.noticeUrl);

                var data = {
                    'amount': this.model.get('amount')
                };
                var originalDocId = this.model.get('originalDocId'),
                    docId = _.isEmpty(originalDocId) ? this.model.get('docId') : originalDocId;
                if (docId) {
                    data.docId = docId;
                }

                var params = {
                    contentType: 'application/json',
                    url: url,
                    data: JSON.stringify(data),
                    success: _.bind(function (data) {
                        if (data.data.transactionStatus === 'saved') {
                            this.navigateToViewDeductions();
                        } else {
                            this._showMessage('unsuccessfulsubmiterror');
                            this.view.hideSpinner();
                        }
                    }, this),
                    error: _.bind(function (jqXHR, textStatus, errorThrown) {
                        this.showAjaxErrorMessage(errorThrown);
                        this.view.hideSpinner();
                    }, this)
                };
                this._hideAllMessage();
                this.view.showSpinner();
                this.ajaxPost(params);
            }
        },

        generateTaxDeductionPDF: function () {
            if (this.validateForm(this.view.$el, 'blur')) {
                var url = '../reportpdf/personalTaxDeductionPdfReport?account-id=' + rootController.getUrlParams().a + '&am=' + this.model.get('amount') + '&date=' + this.model.get('financialYear');

                if (this.model.get('docId')) {
                    url += '&di=' + this.model.get('docId');
                }

                window.open(url);
            }
        },

        showAjaxErrorMessage: function (errorThrown) {
            if (errorThrown === 'timeout') {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0344'));
            }
            this._showMessage('ajaxerror');
        },

        _showMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].hide();
            }
        },

        _hideAllMessage: function () {
            _.each(['ajaxerror', 'unsuccessfulsubmiterror'], function (message) {
                this._hideMessage(message);
            }, this);
        },

        navigateToViewDeductions: function () {
            // show onetime success message
            this.parentController.model.set({
                'noticeSubmitted': true,
                'docId': this.model.get('docId')
            });
            rootController.confirmNavigation(false);

            var urlParams = rootController.getUrlParams();
            var url = '#ng/account/contribution/personaltax/viewdeduction?a=' + urlParams.a;
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },

        getUrlParams: function () {
            return {
                'a': rootController.getUrlParams().a,
                'sc': this.model.get('financialYear')
            };
        }

    });
});
