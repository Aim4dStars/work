defineMvcController({
    name: 'transferreceipt',
    parentPath: 'mvc-screens/ip/account/assettransfer',
    modelJs: true,
    viewHtml: true,
    viewJs: true,
    hashName: 'transferreceipt',
    screens: [],
    mvcComponents: ['tablev3'],
    extend: 'MvcController',
    dependencies: ['jquery', 'underscore', 'rootController', 'app/pages/mvc-screens/ip/account/assettransfer/util/utils',
    'app/framework/handlebars/format', 'app/framework/helpers/format', 'app/pages/mvc-screens/ip/services/accountService']
}, function (config, MvcController, $, _, rootController, util, format, formatHelper, accountService) {
    'use strict';

    return MvcController.extend({
        config: config,
        accountPromise: null,

        preRender: function () {
            this.model.set('accountId', rootController.getUrlParams().a);
        },

        postRender: function () {
            this.fetchAccountDetails();
            this.model.set('submitDateTime', format(new Date(), 'dateTime'));
            var transferData = rootController.model.get('transferreceiptData');
            if (!_.isUndefined(transferData)) {
                this.model.set('transferData', transferData);
                this.populateTransferTable(transferData.transferAssets);
                this.setWarningMessage();
            }
        },

        fetchAccountDetails: function () {
            accountService.getAccount(this)
                .done(_.bind(function (account) {
                    this.model.set('account', account);
                }, this));
        },

        populateTransferTable: function (transferAssets) {
            transferAssets = _.filter(transferAssets, function (asset) {
                return !asset.isCashTransfer;
            });
            transferAssets = _.sortBy(transferAssets, function (asset) {
                return asset.categoryName;
            });
            transferAssets = this.parentController.insertSubHeadings(transferAssets);
            transferAssets.push({
                heading: 'Transfer summary'
            });
            this.children.transferreceipt.setRows({}, transferAssets);
            this.children.transferreceipt.renderComponentView();
            this.setFooterValues();

        },

        setFooterValues: function () {
            var transferData = this.model.get('transferData');
            var cashAmount = 0;
            var cashData = _.find(transferData.transferAssets, function (asset) {
                return asset.isCashTransfer;
            });
            if (!_.isUndefined(cashData)) {
                cashAmount = cashData.quantity;
            }
            var totalTransferAmountWithCash = util.convertToNumber(transferData.totalTransferAmount) + cashAmount;
            this.children.transferreceipt.model.set('cashAssetName', transferData.cashAssetName);
            this.children.transferreceipt.model.set('totalTransferAmount', transferData.totalTransferAmount);
            this.children.transferreceipt.model.set('cashAmount', formatHelper.formatMoney(cashAmount, 2, '$'));
            this.children.transferreceipt.model.set('totalTransferAmountWithCash', formatHelper.formatMoney(totalTransferAmountWithCash, 2, '$'));
        },

        setWarningMessage: function () {
            var transferData = this.model.get('transferData');
            var isWarning = _.find(transferData.transferAssets, function (asset) {
                return asset.vettWarnings && asset.vettWarnings.length > 0;
            });
            if (_.isUndefined(isWarning)) {
                this.viewChildren.warnings.hide();
            }
            if (transferData.warnings && transferData.warnings.length > 0) {
                this.viewChildren.warnings.viewData.warnings = transferData.warnings;
                this.viewChildren.warnings.show();
                this.viewChildren.warnings.render();
            }
        },

        downloadButtonClick: function () {
            var assetlistData = this.model.getAssetListData();
            var pdfData = this.model.getPdfData(assetlistData);
            var url = '../reportpdf/intraAccountTransferReport?account-id=' + rootController.getUrlParams().a;
            url = url + "&holdingvalue=" + this.model.get('transferData').selectedHolding;
            if (this.model.get('transferData').showPreferences) {
                url = url + "&preference=" + this.model.get('transferData').preferenceLabel;
            }
            if (this.model.get('transferData').showIncomePreference) {
                url = url + "&incomePreference=" + this.model.get('transferData').incomePreferenceLabel;
            }
            var destAcc = this.model.get('transferData').dest;
            if (!_.isUndefined(destAcc)) {
                url = url + "&destAssetCode=" + destAcc.assetCode;
                url = url + "&destAssetName=" + destAcc.assetName;
            }
            var sourceAcc = this.model.get('transferData').source;
            if (!_.isUndefined(sourceAcc)) {
                url = url + "&sourceAssetCode=" + sourceAcc.assetCode;
                url = url + "&sourceAssetName=" + sourceAcc.assetName;
            }
            var cashAssetName = this.model.get('transferData').cashAssetName;
            if (!_.isUndefined(cashAssetName)) {
                url = url + "&cashAssetName=" + cashAssetName;
            }

            //creating form to submit the data to server
            var reportForm = document.createElement('form');
            reportForm.action = url;
            reportForm.method = 'POST';
            reportForm.target = '_blank';
            var input = document.createElement('textarea');
            input.name = 'transferData';
            input.value = JSON.stringify(pdfData);
            reportForm.appendChild(input);
            reportForm.style.display = 'none';
            document.body.appendChild(reportForm);
            reportForm.submit();
            document.body.removeChild(reportForm);
        }

    });
});
