define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        events: {
            'click .btn-delete': 'deleteChildCell'
        },

        deleteChildCell: function () {
            this.controller.deleteChildCell();
        },

        getSubmitEvent: function () {
            return {
                'currentTarget': this.$el.find('.dollar-form')
            };
        }

    });

});
