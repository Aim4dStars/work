define([
    'MvcView',
    'jquery',
    'underscore'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            headerPanel: 'Capital gains',
            menuTabs: [{
                label: 'Unrealised',
                url: '#ng/account/cgt/unrealised/unrealisedportfolio',
                child: 'unrealised',
                bindHrefParam: 'a,c'
            }, {
                label: 'Realised',
                url: '#ng/account/cgt/realised/realisedportfolio',
                child: 'realised',
                bindHrefParam: 'a,c'
            }]
        },

        setAccountStartDateErrorMessage: function (message) {
            this.$el.find('[class*="-custom-min-value"]').text(message);
        },

        setAccountEndDateErrorMessage: function (message) {
            this.$el.find('[class*="-custom-max-closure-value"]').text(message);
        }
    });
});
