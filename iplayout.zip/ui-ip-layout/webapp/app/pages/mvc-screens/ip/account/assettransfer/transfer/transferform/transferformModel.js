define(['MvcModel',
       'app/framework/services/dateService',
       'underscore',
  'app/framework/helpers/format'],
    function (MvcModel, dateService, _, format) {
        'use strict';

        return MvcModel.extend({

            matchAsxCode: function (asxCode) {
                var managedPortfolio = this.get('managedPortfolio');
                var tailoredPortfolio = this.get('tailoredPortfolio');
                if (!_.isEmpty(managedPortfolio) || !_.isEmpty(tailoredPortfolio)) {
                    return true;
                }

                var match = this.controller.matchASXCodeToAsset(asxCode);
                return !_.isNull(match);
            },

            duplicateAsxCode: function (asxCode) {
                var matches = _.filter(this.attributes, function (value, key) {
                    return key.indexOf('asxcode') !== -1 && value.toUpperCase() === asxCode.toUpperCase();
                });
                if (_.isEmpty(matches)) {
                    return true;
                }
                return matches.length <= 1;
            },

            duplicateApirCode: function (apirCode) {
                var matches = [];
                if (_.isUndefined(apirCode)) {
                    return true;
                }
                matches = _.filter(this.attributes, function (value, key) {
                    return key.indexOf('apircode') !== -1 && value.toUpperCase() === apirCode.toUpperCase();
                });

                if (_.isEmpty(matches)) {
                    return true;
                }
                return matches.length <= 1;
            },

            convertQuantityForView: function (value) {
                if (!_.isUndefined(value) && _.isNumber(value)) {
                    return format.formatMoney(value, 0);
                } else {
                    return value;
                }
            },

            convertQuantityForModel: function (value) {
                var convertForModel = _.bind(this.validationTypes.quantity.convertForModel, this);
                var rval = convertForModel(value);
                if (_.isNumber(rval)) {
                    rval = this.truncate(rval);
                }
                return rval;
            },

            convertMFQuantityForView: function (value) {
                if (!_.isUndefined(value) && _.isNumber(value)) {
                    var fmtVal = value;
                    return fmtVal;
                } else {
                    return value;
                }
            },

            convertMFQuantityForModel: function (value) {
                var convertForModel = _.bind(this.validationTypes.quantity.convertForModel, this);
                var rval = convertForModel(value);
                return rval;
            },

            truncate: function (x) {
                return x < 0 ? Math.ceil(x) : Math.floor(x);
            },

            validation: {
                'asxcode': {
                    priority: ['required', 'minLength', 'maxLength', 'custom', 'customMatch'],

                    type: 'alphaNumeric',
                    blur: {
                        required: true,
                        custom: 'duplicateAsxCode',
                        minLength: 3,
                        customMatch: 'matchAsxCode',
                        maxLength: 6
                    },
                    submit: {
                        required: true
                    }
                },
                'quantity': {
                    type: 'numeric',
                    priority: ['minValue', 'maxValue'],
                    change: {
                        minValue: 1,
                        maxValue: 999999999999
                    },
                    blur: {
                        required: true
                    },
                    convertForModel: function (value) {
                        return this.convertQuantityForModel(value);
                    },
                    convertForView: function (value) {
                        return this.convertQuantityForView(value);
                    }
                },
                'mfquantity': {
                    type: 'numeric',
                    priority: ['minValue', 'maxValue', 'regexp'],
                    change: {
                        minValue: 1,
                        maxValue: 999999999999,
                        regexp: /^(?!0\d|$)\d*(\.\d{0,8})?$/,
                    },
                    blur: {
                        required: true
                    },
                    convertForModel: function (value) {
                        return this.convertMFQuantityForModel(value);
                    },
                    convertForView: function (value) {
                        return this.convertMFQuantityForView(value);
                    }
                },
                'chess': {
                    type: 'numeric',
                    blur: {
                        regexp: /^[0-9]{4,6}$/,
                        required: true
                    }
                },
                'sponsorselector': {
                    blur: {
                        required: true
                    }
                },
                'hin': {
                    blur: {
                        regexp: /^X[0-9]{10}$/,
                        required: true
                    }
                },
                'hinaccount': {
                    blur: {
                        required: true
                    }
                },
                'srn': {
                    blur: {
                        required: true
                    }
                },
                'apircode': {

                    type: 'name',
                    priority: ['required', 'custom', 'regexp', 'customMatch'],

                    blur: {
                        regexp: /^[A-Z]{3}[0-9]{4}[A-Z]{2}$/,
                        custom: 'duplicateApirCode',
                        required: true,
                        customMatch: 'matchAsxCode'
                    }
                },
                'account': {
                    type: 'name',
                    blur: {
                        required: true
                    }
                },
                'custodian': {
                    type: 'name'
                },
                'sponsorname': {
                    blur: {
                        required: true
                    }
                },
            }
        });
    });
