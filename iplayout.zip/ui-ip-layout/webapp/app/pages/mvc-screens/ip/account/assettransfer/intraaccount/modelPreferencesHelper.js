define([
    'underscore', 'jquery'
], function (_, $) {
    'use strict';

    return {
        getPreferences: function (asset) {
            this.unsetModelPreferences();
            this.model.unset('selectedAsset');
            this.model.set('selectedAsset', asset);
            this.model.unset('excludedAssets', []);
            this.viewChildren.preferencespinner.spinnerOn();
            $.when(this.getModelPreferences(asset.subAccountId))
                .done(_.bind(this.getModelPreferencesComplete, this));
        },

        getModelPreferencesComplete: function (excludedAssets, subAccountId) {
            this.viewChildren.preferencespinner.spinnerOff();

            var selectedAsset = this.model.get('selectedAsset');
            if (!_.isObject(selectedAsset) || selectedAsset.subAccountId !== subAccountId) {
                this.setNotSetModelPrefernces();
                return;
            }

            selectedAsset.excludedAssets = excludedAssets;
            this.model.unset('selectedAsset');
            this.model.set('selectedAsset', selectedAsset);

            this.updateModelPreferencesLabel(excludedAssets);
        },

        updateModelPreferencesLabel: function (excludedAssets) {
            if (!_.isEmpty(excludedAssets)) {
                var anyChanged = _.any(excludedAssets, function (exclusion) {
                    return !_.isUndefined(exclusion.action);
                });
                if (anyChanged) {
                    this.setModifiedModelPrefernces();
                } else {
                    this.setAppliedModelPrefernces();
                }
            } else {
                this.setNotSetModelPrefernces();
            }
        },

        editPreferences: function (event) {
            var selectedAsset = this.model.get('selectedAsset');
            var excludedAssets = selectedAsset.excludedAssets || [];
            var applyCallback = _.bind(this.applyExclusions, this);

            this.children.modelpreferences.openModal({
                asset: selectedAsset,
                excludedAssets: excludedAssets,
                applyCallback: applyCallback
            }, {
                $restoreFocusToEl: event
            });
        },

        applyExclusions: function (excludedAssets) {
            this.model.set('excludedAssets', excludedAssets);

            var activeExcludedAssets = _.filter(excludedAssets, function (excludedAsset) {
                return excludedAsset.action !== 'remove';
            });

            this.updateModelPreferencesLabel(activeExcludedAssets);
        },

        unsetModelPreferences: function () {
            this.model.set({
                'showPreferencesNotSet': false,
                'showPreferencesApplied': false,
                'showPreferencesModified': false
            });
        },

        setAppliedModelPrefernces: function () {
            this.model.set({
                'showPreferencesNotSet': false,
                'showPreferencesApplied': true,
                'showPreferencesModified': false
            });
        },

        setNotSetModelPrefernces: function () {
            this.model.set({
                'showPreferencesNotSet': true,
                'showPreferencesApplied': false,
                'showPreferencesModified': false
            });
        },

        setModifiedModelPrefernces: function () {
            this.model.set({
                'showPreferencesNotSet': false,
                'showPreferencesApplied': false,
                'showPreferencesModified': true
            });
        },

        getPreferenceValue: function () {
            if (this.model.get('showPreferencesApplied')) {
                return 'Applied';
            } else if (this.model.get('showPreferencesModified')) {
                return 'Modified';
            } else {
                return 'Not set';
            }
        },
    };
});
