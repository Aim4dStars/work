defineMvcController({
    name: 'cancel',
    parentPath: 'mvc-screens/ip/account/contribution/contributionstatus',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: [
        'app/pages/mvc-screens/ip/services/depositService',
        'app/framework/router',
        'rootController',
        'underscore'
    ]
}, function (config, ModalController, depositService, router, rootController, _) {
    'use strict';

    return ModalController.extend({
        config: config,

        endDepositSubmit: function () {
            var status = this.model.get('status');
            this.parentController.view.showSpinner();
            if (_.isEqual(status, 'savedContribution')) {
                this.cancelSavedContribution();
            } else {
                this.cancelSubmittedContribution();
            }
        },

        cancelSubmittedContribution: function () {
            var transactionId = this.model.get('transactionId');
            var transactionType = this.model.get('transactionType');

            depositService.cancelDeposit(this, transactionId, transactionType)
                .done(_.bind(this.onSubmitSuccess, this))
                .fail(_.bind(this.onSubmitFailure, this));
        },

        cancelSavedContribution: function () {
            var toEditSavedContribution = this.model.get('toEditSavedContribution');
            toEditSavedContribution.type = this.model.get('type');
            if (!_.isUndefined(this.viewChildren.endcontribution)) {
                this.viewChildren.endcontribution.loading(true);
            }
            depositService.cancelSavedDeposit(this, toEditSavedContribution)
                .done(_.bind(this.onSubmitSuccess, this))
                .fail(_.bind(this.onSubmitFailure, this));
        },

        onSubmitSuccess: function () {
            var status = this.model.get('status');
            var response = this.getDataByContributionStatus(status);
            this.parentController.fetchTransactions();
            this.parentController.showReceipt(response, 'cancel');
            this.closeModal();
        },

        onSubmitFailure: function () {
            this.parentController.showCancelFailure();
            this.closeModal();
            this.parentController.view.hideSpinner();
        },

        getDataByContributionStatus: function (status) {
            if (_.isEqual(status, 'savedContribution')) {
                var toEditSavedContribution = this.model.get('toEditSavedContribution');
                toEditSavedContribution.endRepeat = _.isNull(toEditSavedContribution.repeatEndDate) ? 'noDate' : null;
                return this.model.get('toEditSavedContribution');
            } else {
                var transactionId = this.model.get('transactionId');
                var scheduleTransactions = this.parentController.model.get('scheduleTransactions');
                return this.filterScheduledTransaction(scheduleTransactions, transactionId);
            }
        },

        filterScheduledTransaction: function (scheduleTransactions, transactionId) {
            var filteredScheduledTransaction = _.find(scheduleTransactions, function (scheduleTransaction) {
                return _.isEqual(scheduleTransaction.stordPosId, transactionId);
            });

            if (filteredScheduledTransaction) {
                return this.getDataForSubmission(filteredScheduledTransaction);
            }
        },

        getDataForSubmission: function (scheduledTransaction) {
            return {
                'fromPayDto': {
                    'accountId': scheduledTransaction.payerAccount,
                    'accountName': scheduledTransaction.payer,
                    'code': scheduledTransaction.payerBsb
                },
                'amount': scheduledTransaction.netAmount,
                'frequency': scheduledTransaction.frequency,
                'depositType': scheduledTransaction.contributionType,
                'transactionDate': scheduledTransaction.nextPaymentDate,
                'description': scheduledTransaction.description ? scheduledTransaction.description : '',
                'repeatEndDate': scheduledTransaction.lastPayment,
                'endRepeat': _.isNull(scheduledTransaction.lastPayment) ? 'noDate' : null
            };
        },

        cancel: function () {
            this.closeModal();
        }
    });
});
