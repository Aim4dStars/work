defineMvcController({
    name: 'selectedbuybackoptions',
    parentPath: 'mvc-screens/ip/account/corporateaction/election/buyback',
    viewHtml: true,
    modelJs: false,
    viewJs: true,
    viewComponents: ['inputselect'],
    screens: ['selectedbuybackoption'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/buyback/selectedbuybackoptions/selectedbuybackoptionsController'
}, function (config, SelectedBuybackOptionsController) {
    'use strict';

    return SelectedBuybackOptionsController.extend({
        config: config
    });
});
