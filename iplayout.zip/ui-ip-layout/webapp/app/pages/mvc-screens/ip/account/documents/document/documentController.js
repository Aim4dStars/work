// Document child screen is created, as it can be reused for fund establishment screen. Public method hideUploadSearchBar can be used to hide upload and search bar
defineMvcController({
    name: 'document',
    parentPath: 'mvc-screens/ip/account/documents',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    screens: ['upload', 'filter', 'search', 'editdetails', 'delete', 'uploaderror', 'downloaderror'],
    viewComponents: ['menuaction', 'messagealert', 'inputcheckbox', 'button', 'inputtext', 'messagedisclaimer', 'tray'],
    mvcComponents: ['tablev3', 'tableoptions', 'search'],
    extend: 'MvcController',
    dependencies: ['rootController', 'jquery', 'underscore', 'app/framework/helpers/format', 'app/framework/helpers/url']
}, function (config, MvcController, rootController, $, _, format, url) {
    'use strict';

    return MvcController.extend({
        config: config,
        autoHideSpinner: false,
        urlTemplate: '../api/v1_0/accounts/<%=a%>/documents',
        updateUrlTemplate: '../api/v1_0/documents/<%=documentId%>/update',
        downloadAllUrl: '../api/v1_0/documents/download',
        additionalServicesUrl: '../api/v1_0/accounts/<%=a%>/subscriptions',
        rowLimit: 'row_limit',
        DOCUMENT_STATUS: {
            DRAFT: 'Draft',
            FINAL: 'Final'
        },
        MAX_DOWNLOAD_COUNT: 20,
        MAX_DOWNLOAD_SIZE: 41943040,
        chainedTriggered: false,
        serviceInfoMessageMapping: {
            fa: 'Ins-IP-0081'
        },

        preRender: function () {
            this.model.filterDocumentType(rootController.getUrlParams().a);
            this._setPrivateHelpMessage();
        },

        _setPrivateHelpMessage: function () {
            var activeRole = rootController.getActiveRole();
            var messageId;
            if (activeRole) {
                if (!rootController.isIntermediary()) {
                    messageId = 'Help-IP-0143';
                } else if (activeRole.role === 'Accountant' || activeRole.role === 'Accountant Assistant') {
                    messageId = 'Help-IP-0142';
                } else {
                    messageId = 'Help-IP-0141';
                }
                this.model.set('privateMessage', rootController.getCmsEntry(messageId));
            }
        },

        postRender: function () {
            this.maxResults = this.defaultMaxResults = parseInt(this.children.documentstable.viewData[this.rowLimit], 10);
            this._fetchAdditionalServices();
            this.fetchDocuments();
            this._addModelListners();
        },

        _addModelListners: function () {
            this.model.on('change:docupload', _.bind(this._fileSelected, this));
        },

        filterDocuments: function () {
            if (this.children.tableoptions.children.filter.validateFilterForm()) {
                return this.fetchDocuments();
            } else {
                var deferred = $.Deferred();
                deferred.resolve(null, {
                    togglePanel: false
                });
                return deferred.promise();
            }
        },

        fetchDocuments: function () {
            this._hideSuccessMessage();
            if (!_.isObject(this.children.search)) {
                log.error('this.children.search does not exist');
                this.view.hideSpinner();
                return;
            }
            if (!_.isObject(this.children.tableoptions)) {
                log.error('this.children.tableoptions does not exist');
                this.view.hideSpinner();
                return;
            }
            var searchAttributes = this.children.search.getAttributes();
            if (!searchAttributes) {
                this.view.hideSpinner();
                return;
            }
            var tableOptionsAttributes = this.children.tableoptions.getAttributes();

            this.startIndex = 0;
            this.maxResults = this.defaultMaxResults;
            var deferred = $.Deferred();
            var params = this._getDocumentRequestObj(tableOptionsAttributes, searchAttributes, deferred);
            params.success = _.bind(function (data) {
                if (data && data.data) {
                    deferred.resolve();
                    this._populateTable(data);
                }
                this.view.hideSpinner();
            }, this);
            this.view.showSpinner();
            this.ajaxGet(params);
            return deferred.promise();
        },

        _getDocumentRequestObj: function (tableOptionsAttributes, searchAttributes, deferred) {
            var params = {};
            params.url = this.getUrl(rootController.getUrlParams(), this.urlTemplate);
            params.data = {
                filter: JSON.stringify(this.model.getFilters(tableOptionsAttributes)),
                sortby: tableOptionsAttributes.sortBy,
                query: (searchAttributes && _.isString(searchAttributes.documentName)) ? searchAttributes.documentName.trim() : '',
                paging: JSON.stringify({
                    'startIndex': this.startIndex,
                    'maxResults': this.defaultMaxResults
                })
            };
            params.error = _.bind(function (jqXHR, textStatus, errorThrown) {
                deferred.reject();
                this.showErrorMessage(errorThrown);
                this.view.hideSpinner();
            }, this);
            return params;
        },

        _populateTable: function (data) {
            var table = this.children.documentstable;
            if (table) {
                this._removeTabelModelListners();
                var tableOptionsAttributes = this.children.tableoptions.getAttributes();
                var filterLegend = this.model.getFilterLegend(tableOptionsAttributes);
                this.children.tableoptions.setFilterLegend(filterLegend);
                this.model.formatData(data.data.resultList);
                table.model.set(this.model.getFlags(data.data.resultList));
                table.setRows({
                    rowName: 'resultList'
                }, data.data);
                table.renderComponentView();
                //paging object is used after delete and audit flag
                this.model.set('paging', data.paging);
                this._updatePagination(data.paging);
                //Reset select all
                this._resetSelectAll();
                this._addTabelModelListners();
            }
        },

        _removeTabelModelListners: function () {
            var table = this.children.documentstable;
            table.model.off('change');
        },

        _addTabelModelListners: function () {
            var table = this.children.documentstable;
            table.model.on('change', this._updateFlags, this);
        },

        showMoreRecords: function () {
            this._hideSuccessMessage();
            this.startIndex += this.defaultMaxResults;
            this.maxResults += this.defaultMaxResults;
            var deferred = $.Deferred();
            var searchAttributes = this.children.search.getAttributes();
            var tableOptionsAttributes = this.children.tableoptions.getAttributes();

            var params = this._getDocumentRequestObj(tableOptionsAttributes, searchAttributes, deferred);

            params.success = _.bind(function (data) {
                var table = this.children.documentstable;
                if (table) {
                    this.model.formatData(data.data.resultList);
                    this._removeTabelModelListners();
                    table.model.set(this.model.getFlags(data.data.resultList));
                    deferred.resolve(data.data.resultList);
                    this._addTabelModelListners();
                    if (data.data.resultList.length > 0) {
                        this._resetSelectAll();
                        this._updatePagination(data.paging);
                    }
                }
                this.view.hideSpinner();
            }, this);

            this.view.showSpinner();
            this.ajaxGet(params);
            return deferred.promise();
        },

        _updatePagination: function (paging) {
            var paginationObj = {};
            if (paging) {
                paginationObj.total = paging.size;
                paginationObj.end = parseInt(this.children.documentstable.model.get('rows').length, 10);
            }
            this.children.tableoptions.setPaginationLegend(paginationObj);
        },

        _resetSelectAll: function () {
            var selectall = this.children.documentstable.model.get('selectall');
            if (selectall) {
                this._setSelectAll(null);
            }
        },

        _setSelectAll: function (value) {
            this.children.documentstable.model.set('selectall', value);
        },

        //update facility
        _updateFlags: function (event) {
            var name = Object.keys(event.changed)[0];
            if (name && name.indexOf('_') > 0) {
                var nameId = name.split('_');
                if (nameId[0] === 'audit') {
                    this._updateAuditFlag(nameId[1], event.changed[name] ? true : false);
                } else if (nameId[0] === 'select') {
                    this._toggleSelectAll(event.changed[name] ? true : false);
                }
            } else if (name === 'selectall') {
                this._toggleSelect();
            }
        },

        _updateAuditFlag: function (documentId, value) {
            var property = {};
            this._disableFlag('audit' + documentId);
            property.audit = value;
            $.when(this.updateProperties(documentId.toUpperCase(), property))
                .done(_.bind(function (data) {
                    if (data && data.key && data.key.documentId) {
                        //check filters and update table data
                        this._applyFilters(data, 'audit');
                        //enable flag
                        this._enableFlag('audit' + data.key.documentId.toLowerCase());
                    }
                }, this))
                .fail(_.bind(function (errorThrown) {
                    this.showErrorMessage(errorThrown);
                }, this));
        },

        _enableFlag: function (childrenName) {
            var table = this.children.documentstable;
            if (table.viewChildren[childrenName]) {
                table.viewChildren[childrenName].enable();
            }
        },

        _disableFlag: function (childrenName) {
            var table = this.children.documentstable;
            if (table.viewChildren[childrenName]) {
                table.viewChildren[childrenName].disable();
            }
        },

        _updateChangeToken: function (data) {
            var documents = this.children.documentstable.model.get('rows');
            var document = this.model.getDocument(documents, data.key.documentId);
            document.changeToken = data.changeToken;
        },

        //refresh documents on flag updates
        _applyFilters: function (data, propertyName) {
            var documentId = data.key.documentId;
            var tableOptionsAttributes = this.children.tableoptions.getAttributes();
            var flagStatus = tableOptionsAttributes.filters['form' + propertyName] ? true : false;
            if (flagStatus) {
                this.deleteDocument(documentId);
            } else {
                this._updateChangeToken(data);
            }
        },

        updateProperties: function (documentId, properties) {
            var deferred = $.Deferred();
            var params = {};
            _.extend(properties, {
                'changeToken': this._getDocument(documentId).changeToken,
                'key.accountId': rootController.getUrlParams().a
            });

            params.data = properties;
            params.success = _.bind(function (data) {
                deferred.resolve(data.data);
            }, this);

            params.error = _.bind(function (qXHR, textStatus, errorThrown) {
                deferred.reject(errorThrown);
            }, this);
            params.url = this.getUrl({
                documentId: documentId
            }, this.updateUrlTemplate);

            this.ajaxPost(params);
            return deferred.promise();
        },

        _getTableAttributeValue: function (name) {
            var table = this.children.documentstable;
            if (table) {
                return table.model.get(name) ? true : false;
            }
        },

        //upload functionality
        chooseFile: function (documentId, $element) {
            this._hideSuccessMessage();
            if (window.FormData) {
                if (documentId) {
                    this.model.set('documentId', documentId);
                    this.$restoreFocusToEl = $element;
                } else {
                    this.$restoreFocusToEl = null;
                }
                this.model.unset('docupload', {
                    silent: true
                });
                this.view.clickFilePicker();
            } else {
                //IE9 browser not support error modal
                this.children.uploaderror.openModal();
            }
        },

        _fileSelected: function () {
            var documentId = this.model.get('documentId');
            var fileObject = {};
            if (documentId) {
                var document = this._getDocument(documentId);
                _.extend(fileObject, document, {
                    previousName: document.documentName
                });
                this.model.unset('documentId');
            }

            var file = this.view.getFileInput();
            if (file) {
                _.extend(fileObject, {
                    file: file,
                    documentName: file.name,
                    size: format.formatDocumentSize(file.size),
                });
            }
            if (this.children.upload.displayed) {
                this.children.upload.updateModal(fileObject);
            } else {
                this.children.upload.openModal(fileObject, {
                    $restoreFocusToEl: this.$restoreFocusToEl
                });
            }
        },

        _getDocument: function (documentId) {
            var documents = this._getDocuments();
            var document = _.clone(this.model.getDocument(documents, documentId));
            if (document) {
                document.audit = this._getTableAttributeValue('audit_' + documentId.toLowerCase());
                document.size = format.formatDocumentSize(document.size);
                return document;
            }
        },

        _getDocuments: function () {
            var documents = this.children.documentstable.model.get('rows');
            return documents;
        },

        editDocument: function (docId, action, $element) {
            this._hideSuccessMessage();
            var document = this._getDocument(docId);
            if (this.children[action] && document) {
                this.children[action].openModal(document, {
                    $restoreFocusToEl: $element
                });
            }
        },

        deleteDocument: function (documentId) {
            this._removeTabelModelListners();
            var documentsTable = this.children.documentstable;
            var documents = documentsTable.model.get('rows');
            var modifiedDocumnts = _.reject(documents, function (document) {
                return document.key.documentId === documentId;
            });
            var paging = this.model.get('paging');
            paging.size--;
            if (modifiedDocumnts.length === 0 && paging.size > 0) {
                this.filterDocuments();
            } else {
                documentsTable.setRows({}, modifiedDocumnts);
                this.startIndex--;
                this.maxResults--;
                documentsTable.viewData[this.rowLimit] = this.maxResults;
                documentsTable.removeViewChildren();
                documentsTable.renderComponentView();
                documentsTable.viewData[this.rowLimit] = this.defaultMaxResults;
            }
            this._toggleSelectAll(true);
            this._updatePagination(paging);
            this._addTabelModelListners();
        },

        _hideSuccessMessage: function () {
            if (this.viewChildren.uploadsuccess) {
                this.viewChildren.uploadsuccess.hide();
            }
            if (this.viewChildren.deletesuccess) {
                this.viewChildren.deletesuccess.hide();
            }
            if (this.viewChildren.downloadcountwarning) {
                this.viewChildren.downloadcountwarning.hide();
            }
        },

        showSuccessMessage: function (showSuccessMessage) {
            if (this.viewChildren[showSuccessMessage]) {
                this.viewChildren[showSuccessMessage].show();
            }
        },

        showErrorMessage: function (exception, context) {
            context = context ? context : this;
            if (exception === 'timeout') {
                context.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                context.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0344'));
            }
            if (context.viewChildren.ajaxerror) {
                context.viewChildren.ajaxerror.show();
            }
        },

        hideUploadSearchBar: function () {
            this.view.hideUploadSearchBar();
        },

        _showHideToggleTray: function () {
            var selectedDocumentsLength = _.size(this._getSelectedDocumentAttributes().documentIds);
            //condition to check if length is < 0 then hide tray is there in setLabelAndDisplayTray function of the tray component
            this.viewChildren.tray.setLabelAndDisplayTray(selectedDocumentsLength, selectedDocumentsLength + ' documents selected');
        },

        _toggleSelect: function () {
            var selectAllVal = this.children.documentstable.model.get('selectall');
            var documents = this._getDocuments();
            var table = this.children.documentstable;
            this._removeTabelModelListners();
            _.each(documents, function (document) {
                table.model.set('select_' + document.key.documentId.toLowerCase(), selectAllVal);
            }, this);
            this._addTabelModelListners();
            this._showHideToggleTray();
        },

        _toggleSelectAll: function (currentDocumentSelected) {
            var selectAllVal = this.children.documentstable.model.get('selectall') ? true : false;
            this._removeTabelModelListners();
            //uncheck select all, if checked and currentDocumentSelected is unchecked
            if (selectAllVal && !currentDocumentSelected) {
                this._setSelectAll(null);
            } else {
                if (currentDocumentSelected) {
                    //check if all documents are selected
                    var selectedDocumentAttributes = this._getSelectedDocumentAttributes();
                    if (selectedDocumentAttributes.documentIds.length === selectedDocumentAttributes.allDocumentsCount) {
                        this._setSelectAll(selectedDocumentAttributes.allDocumentsCount === 0 ? null : 'true');
                    }
                }
            }
            this._addTabelModelListners();
            this._showHideToggleTray();
        },

        downloadAll: function () {
            var downloadAttributes = this._getSelectedDocumentAttributes();
            if (this._isValidDownloadAll(downloadAttributes.documentIds.length, downloadAttributes.selectedDocumentSize)) {
                if (downloadAttributes.documentIds.length > 0) {
                    window.location.href = url.setParam(this.downloadAllUrl, 'documentid', encodeURIComponent(downloadAttributes.documentIds.toString()));
                }
            } else {
                this.children.downloaderror.openModal({
                    selectCount: downloadAttributes.documentIds.length,
                    selectedDocumentSize: downloadAttributes.selectedDocumentSize,
                    formattedSelectedDocumentSize: format.formatDocumentSize(downloadAttributes.selectedDocumentSize, null, 2),
                    selectMaxCount: this.MAX_DOWNLOAD_COUNT,
                    selectMaxSize: this.MAX_DOWNLOAD_SIZE
                });
            }
        },

        _getSelectedDocumentAttributes: function () {
            var documents = this._getDocuments();
            var selectedDocAttributes = {
                documentIds: [],
                selectedDocumentSize: 0
            };
            _.each(documents, function (document) {
                if (this._getTableAttributeValue('select_' + document.key.documentId.toLowerCase())) {
                    selectedDocAttributes.documentIds.push(document.key.documentId);
                    selectedDocAttributes.selectedDocumentSize += document.size;
                }
            }, this);
            selectedDocAttributes.allDocumentsCount = documents.length;
            return selectedDocAttributes;
        },

        _isValidDownloadAll: function (selectCount, selectedDocumentSize) {
            return (selectCount > this.MAX_DOWNLOAD_COUNT || selectedDocumentSize > this.MAX_DOWNLOAD_SIZE) ? false : true;
        },

        _fetchAdditionalServices: function () {
            var params = {};
            params.url = this.getUrl(rootController.getUrlParams(), this.additionalServicesUrl);
            params.success = _.bind(function (data) {
                this._setServicesInfoMessage(data.data.resultList);
            }, this);
            params.error = _.bind(function (jqXHR, textStatus, errorThrown) {
                log('Error fetching additional services');
                this.showErrorMessage(errorThrown);
            }, this);
            this.ajaxGet(params);
        },

        _setServicesInfoMessage: function (services) {
            _.each(services, function (service) {
                if (service && this._serviceInProgress(service)) {
                    var serviceType = service.serviceType.toLowerCase();
                    var servicesMessageId = this.serviceInfoMessageMapping[serviceType];
                    if (servicesMessageId) {
                        this.model.set(serviceType + 'ServiceMessage', rootController.getCmsEntry(servicesMessageId));
                    }
                }
            }, this);
        },

        _serviceInProgress: function (service) {
            if (_.isString(service.status)) {
                var status = service.status.toLowerCase();
                return status !== 'done' && status !== 'unsubscribed';
            }
        }

    });

});
