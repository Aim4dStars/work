defineMvcController({
    name: 'baseelectiontable',
    parentPath: 'mvc-screens/ip/account/corporateaction/election',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    mvcComponents: ['tablev3'],
    viewComponents: ['button', 'tooltip', 'icon', 'termsandconditions'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/baseelectiontable/baseelectiontableController'
}, function (config, BaseElectiontableController) {
    'use strict';

    return BaseElectiontableController.extend({
        config: config
    });

});
