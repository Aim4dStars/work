defineMvcController({
    name: 'superpensiondetails',
    parentPath: 'mvc-screens/ip/account/details/accountdetails',
    hashName: 'superpensiondetails',
    hashDefault: true,
    viewHtml: true,
    mvcComponents: ['tablev3', 'section'],
    viewComponents: ['button', 'messagealert'],
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore', 'app/framework/handlebars/format']
}, function (config, MvcController, rootController, _, format) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            var pensionDetails = this.parentController.model.get('data').pensionDetails;
            this.model.set({
                'data': pensionDetails,
                'isPensionReviewInProgress': pensionDetails.pensionReviewInProgress
            });
            this._checkPensionCommencement(pensionDetails);
        },

        postRender: function () {
            if (this.model.get('hasPensionCommenced')) {
                this._populatePensionDetails();
            }
        },

        _checkPensionCommencement: function (data) {
            this.model.set({
                // commencement value exists only when pension has commenced
                'hasPensionCommenced': !_.isNull(data.commencementValue),
                'isPensionCommencementPending': data.commencementPending === true
            });
        },

        _populatePensionDetails: function () {
            var pensionDetailsData = this._formatPensionDetailsTableData(this.model.get('data'));
            this._populateTableData('pensiondetailstable', pensionDetailsData);
        },

        _populateTableData: function (tableName, tableData) {
            var table = this.children.pensiondetailssection.children[tableName];
            table.setRows('rowName', tableData);
            table.renderComponentView();
        },

        _formatPensionDetailsTableData: function (data) {
            var maxAmountRowData = this._getMaxAmountRowData(data),
                formattedData;

            formattedData = [{
                'name': 'Commencement date',
                'value': format(data.commencementDate, 'date')
            }, {
                'name': 'Commencement value',
                'value': format(data.commencementValue, 'dollar', true)
            }, {
                'name': 'Account balance (as at ' + format(data.accountBalanceDate, 'date') + ')',
                'value': format(data.accountBalance, 'dollar', true)
            }, {
                'name': 'Minimum amount (current FY)',
                'value': format(data.minAmount, 'dollar', true)
            }];

            if (!_.isUndefined(maxAmountRowData)) {
                formattedData.push(maxAmountRowData);
            }

            return formattedData;
        },

        _getMaxAmountRowData: function (data) {
            if (data.pensionType === 'TTR') {
                return {
                    'name': 'Maximum amount (current FY)',
                    'value': format(data.maxAmount, 'dollar', true)
                };
            }
            return undefined;
        }

    });
});
