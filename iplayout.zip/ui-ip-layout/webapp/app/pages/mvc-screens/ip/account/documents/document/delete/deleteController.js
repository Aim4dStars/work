defineMvcController({
    name: 'delete',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['rootController', 'underscore']
}, function (config, ModalController, rootController, _) {
    'use strict';

    return ModalController.extend({
        config: config,
        deleteUrlTemplate: '../api/v1_0/documents/<%=documentId%>/delete',

        delete: function () {
            this.loadSpinner();
            var params = {};
            params.url = this.getUrl({
                documentId: this.model.get('key').documentId
            }, this.deleteUrlTemplate);
            params.success = _.bind(function (data) {
                if (data && data.data && data.data.success) {
                    this.parentController.deleteDocument(this.model.get('key').documentId);
                    this.closeModal();
                    this.parentController.showSuccessMessage('deletesuccess');
                } else {
                    this.parentController.showErrorMessage('', this);
                    this.unloadSpinner();
                }
            }, this);
            params.error = _.bind(function (qXHR, textStatus, errorThrown) {
                this.parentController.showErrorMessage(errorThrown, this);
                this.unloadSpinner();
            }, this);
            this.ajaxPost(params);
        },

        loadSpinner: function () {
            this.viewChildren.delete.loading(true);
            this.viewChildren.cancel.disable();
        },

        unloadSpinner: function () {
            this.viewChildren.delete.loading(false);
            this.viewChildren.cancel.enable();
        }
    });

});
