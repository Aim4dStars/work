defineMvcController({
    name: 'editoneoffwithdrawal',
    hashName: 'editoneoffwithdrawal',
    parentPath: 'mvc-screens/ip/account/accessingsuper',
    viewHtml: true,
    modelJs: true,
    viewJs: true,
    screens: ['confirmwithdrawal'],
    mvcComponents: ['inputautocomplete'],
    viewComponents: ['forminputselect', 'forminputtext', 'button', 'messagealert'],
    dependencies: ['rootController', 'underscore', 'app/pages/mvc-screens/ip/account/accessingsuper/accessingsuperServices', 'jquery', 'app/framework/services/dateService', 'app/framework/helpers/format'],
    extend: 'MvcController',
}, function (config, MvcController, rootController, _, accessingsuperServices, $, dateService, format) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        availableCashUriTemplate: '../api/portfolio/v3_0/<%=a%>/available-cash',
        viewEvents: {
            'submit form': 'confirmWithdrawal'
        },
        autoHideSpinner: false,

        preRender: function () {
            this.model.set({
                'accountId': rootController.getUrlParams().a,
                'startdate': dateService.firstBusinessDay(),
                'taxableComponent': '0.00%',
                'cashAvailable': '0.00',
                'maxAmount': 0,
                'showGenericError': false
            });
            this.model.on('change:accountselector', _.bind(this._accountSelectorChanged, this));
            this.model.on('change:amount change:description', this.hasAttributesChanged, this);
        },

        hasAttributesChanged: function () {
            var currentData = this._getPopulatedData(),
                previousData = this.model.get('previouslyPopulatedData');
            rootController.confirmNavigation(!_.isEqual(currentData, previousData));
        },

        postRender: function () {
            this.checkForErrorMessages();
            this.model.unset('previouslyPopulatedData');
            $.when(accessingsuperServices._fetchAccountData(this), accessingsuperServices._fetchPaymentAccounts(this), this._fetchAvailableCashData())
                .done(_.bind(function () {
                    this.view.showSpinner();
                    this._setAvailableBalance();
                    this.children.accountselector.renderMenuData(this.model.get('paymentAccounts'));
                    this._prepopulateSavedWithdrawalDetails(accessingsuperServices.getSelectedRowData(this, 'selectedwithdrawalData'));
                    accessingsuperServices.unsetRowData(this, 'selectedwithdrawalData');
                    this._previouslyPopulatedData();
                }, this))
                .fail(_.bind(function () {
                    this.model.set('showGenericError', true);
                }, this))
                .always(_.bind(function () {
                    this.view.hideSpinner();
                }, this));
        },

        //Amount currently available to withdraw is the lesser of the current cash balance or amount of unrestricted funds.
        _setAvailableBalance: function () {
            var cashAvailable = Number(this.model.get('cashAvailable')),
                unrestrictedNonPreservedAmount = Number(this.model.get('unrestrictedNonPreservedAmount')),
                balance = cashAvailable < unrestrictedNonPreservedAmount ? cashAvailable : unrestrictedNonPreservedAmount;
            this.model.set('cashAvailable', format.formatMoney(balance, 2));
            this.model.set('maxAmount', balance); // use this for checking available amount
        },

        // data.recieptNumber contains the receiptNumber it is not a typo error
        _prepopulateSavedWithdrawalDetails: function (data) {
            if (!_.isUndefined(data)) {
                this.model.set({
                    'amount': data.netAmount,
                    'description': data.description,
                    'paymentAccounts': this._setAccountSelector(data),
                    'receiptNumber': data.recieptNumber,
                    'transactionSeqNo': data.transSeqNo,
                    'stordPosId': data.stordPosId
                });
            }
        },

        _getPopulatedData: function () {
            var populatedData = {
                'amount': this.model.get('amount'),
                'description': this.model.get('description'),
                'paymentAccounts': this.model.get('accountselector')
            };
            return populatedData;
        },

        _previouslyPopulatedData: function () {
            this.model.set('previouslyPopulatedData', this._getPopulatedData());
            rootController.confirmNavigation(false);
        },

        checkForErrorMessages: function () {
            var errors = this.parentController.model.get('dataValidationErrors');
            if (!_.isEmpty(errors)) {
                var confirmWithdrawalErrors = accessingsuperServices.mapErrors(errors);
                accessingsuperServices._displayMessageAlert(this.viewChildren.errormessage, _.pluck(confirmWithdrawalErrors, 'message'));
            }
            this.parentController.model.unset('dataValidationErrors');
        },

        _fetchAvailableCashData: function () {
            return accessingsuperServices.fetchAvailableCashData(this)
                .done(_.bind(function (data) {
                    this.model.set('cashAvailable', data.availableCash);
                }, this));
        },

        _accountSelectorChanged: function () {
            if (this.model.get('accountselector')) {
                var toAccount = _.extend({}, this.model.get('accountselector'));
                this.model.set('fromAccount', toAccount.fromAccount);
                delete toAccount.groupsConfiguration;
                delete toAccount.fromAccount;
                this.model.set('toAccount', toAccount);
            }
            this.hasAttributesChanged();
        },

        confirmWithdrawal: function (event) {
            event.preventDefault();
            this.viewChildren.errormessage.hide();
            var validationResult = this.validateAndSubmitForm(event);
            if (validationResult) {
                rootController.confirmNavigation(false);
                this.view.showSpinner();
                var withdrawal = accessingsuperServices.buildLumpSumWithdrawal(this);
                this.checkIsSavedWithdrawalPresent(withdrawal);
                accessingsuperServices.confirmWithdrawal(this, withdrawal)
                    .done(_.bind(this._processConfirmationResponse, this))
                    .fail(_.bind(function () {
                        this.model.set('showGenericError', true);
                    }, this))
                    .always(_.bind(function () {
                        this.view.hideSpinner();
                    }, this));
            }
        },

        saveWithdrawal: function (saveType, event) {
            var isFieldsValid = this.validateAndSubmitForm(event, this.view.$el.find('form')),
                data;
            /* building request for saving one-off or lumpsump withdrawals */
            if (isFieldsValid) {
                rootController.confirmNavigation(false);
                this.view.showSpinner();
                data = accessingsuperServices.buildLumpSumWithdrawal(this);
                data.paymentAction = this.parentController.model.get('saveTypeAction');
                accessingsuperServices.buildSaveWithdrawal(data,
                    this.model.get('receiptNumber'),
                    this.model.get('transactionSeqNo'),
                    this.model.get('stordPosId'),
                    data.paymentAction);
                accessingsuperServices.saveWithdrawal(this, data)
                    .done(_.bind(function (data) {
                        if (_.isUndefined(data) || !_.isEmpty(data.errors)) {
                            this.model.set('showGenericError', true);
                        } else {
                            this.parentController.model.set('showSuccessMessage', 'saveoneoffwithdrawalsuccessmessage');
                            accessingsuperServices._navigateToWithdrawingSuperDetails(this);
                            this.parentController.children.withdrawingsuper.showSuccessMessage();
                        }
                    }, this))
                    .fail(_.bind(function () {
                        this.model.set('showGenericError', true);
                        rootController.confirmNavigation(true);
                    }, this))
                    .always(_.bind(function () {
                        this.view.hideSpinner();
                    }, this));
            }

        },

        checkIsSavedWithdrawalPresent: function (withdrawal) {
            var saveTypeAction = this.parentController.model.get('saveTypeAction');
            if (!_.isUndefined(withdrawal) && _.isEqual(saveTypeAction, 'modifyoneoff')) {
                withdrawal.receiptNumber = this.model.get('receiptNumber');
                withdrawal.transSeqNo = this.model.get('transactionSeqNo');
                withdrawal.transactionId = this.model.get('stordPosId');
                withdrawal.paymentAction = 'submitoneoff';
            }
        },

        getCmsEntry: function (index, substitutions) {
            return rootController.getCmsEntry(index, substitutions);
        },



        _setAccountSelector: function (paymentTypeDetails) {
            var account = _.find(this.model.get('paymentAccounts'), function (account) {
                var accountBsbAsInt = parseInt(account.code, 10);
                if (this.compareBsbAndAccount(accountBsbAsInt, paymentTypeDetails, account)) {
                    return true;
                } else if (this.compareLinkedAccountAndBsb(accountBsbAsInt, paymentTypeDetails, account)) {
                    return true;
                }
            }, this);
            if (account) {
                account.groupsConfiguration = {
                    'view_value': account.accountName + ' - ' + account.code + ' ' + account.accountId
                };
                this.model.set('accountselector', account);
            }
        },

        compareBsbAndAccount: function (accountBsbAsInt, paymentTypeDetails, account) {
            var compareBsb = _.isEqual(accountBsbAsInt, parseInt(paymentTypeDetails.payeeBsb, 10));
            var compareAccount = _.isEqual(parseInt(account.accountId, 10), parseInt(paymentTypeDetails.payeeAccount, 10));

            return compareBsb && compareAccount;
        },

        compareLinkedAccountAndBsb: function (accountBsbAsInt, paymentTypeDetails, account) {
            var linkedAccounts = paymentTypeDetails.linkedAccounts && paymentTypeDetails.linkedAccounts[0];
            if (!_.isUndefined(linkedAccounts)) {
                var compareBsb = _.isEqual(accountBsbAsInt, parseInt(paymentTypeDetails.linkedAccounts[0].bsb, 10));
                var compareLinkedAccount = _.isEqual(parseInt(account.accountId, 10), parseInt(paymentTypeDetails.linkedAccounts[0].accountNumber, 10));

                return compareBsb && compareLinkedAccount;
            } else {
                return false;
            }
        },

        _processConfirmationResponse: function (withdrawal) {
            if (_.isUndefined(this.viewChildren.confirmwithdrawal)) {
                return;
            }
            var confirmWithdrawal = withdrawal;
            // Override transaction ID with original - not sure why confirmation call returns some other transaction ID
            confirmWithdrawal.transactionId = this.model.get("transactionId");
            this.model.set('confirmWithdrawal', confirmWithdrawal);
            if (confirmWithdrawal.errors && confirmWithdrawal.errors.length > 0) {
                var confirmWithdrawalErrors = accessingsuperServices.mapErrors(confirmWithdrawal.errors);
                accessingsuperServices._displayMessageAlert(this.viewChildren.errormessage, _.pluck(confirmWithdrawalErrors, 'message'));
            } else {
                this.children.confirmwithdrawal.openModal(confirmWithdrawal);
            }
        }
    });
});
