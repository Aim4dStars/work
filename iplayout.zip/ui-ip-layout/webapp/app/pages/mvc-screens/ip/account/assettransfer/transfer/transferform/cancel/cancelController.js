defineMvcController({
    name: 'cancel',
    parentPath: 'mvc-screens/ip/account/assettransfer/transfer/transferform',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    hashName: 'cancel',
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: [],
}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config,

        submit: function () {
            this.parentController.goBack();
            this.closeModal();
        },

    });
});
