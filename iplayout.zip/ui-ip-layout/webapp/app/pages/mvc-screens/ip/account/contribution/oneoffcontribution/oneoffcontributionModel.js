define([
    'app/pages/mvc-screens/ip/account/movemoney/depositsv2/details/detailsModel'
], function (SuperModel) {
    'use strict';

    return SuperModel.extend({});

});
