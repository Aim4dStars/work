define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        events: {
            'click a': 'clearSearch'
        },

        showClearOption: function () {
            this.$el.find('.btn-clear-field').removeClass('hidden');
        },

        hideClearOption: function () {
            this.$el.find('.btn-clear-field').addClass('hidden');
        },

        clearSearch: function () {
            this.controller.clearSearch();
        }
    });
});
