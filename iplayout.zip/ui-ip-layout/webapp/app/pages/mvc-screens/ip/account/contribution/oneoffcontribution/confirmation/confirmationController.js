defineMvcController({
    name: 'confirmation',
    parentPath: 'mvc-screens/ip/account/contribution/oneoffcontribution',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-screens/ip/account/movemoney/depositsv2/details/confirmation/confirmationController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    viewComponents: ['messagedisclaimer', 'transferstatus'],
    dependencies: ['app/framework/router', 'rootController', 'app/framework/services/Permissions']
}, function (config, Super, router, rootController, Permissions) {
    'use strict';

    return Super.extend({
        config: config,

        onSubmitSuccess: function (response) {
            var type;
            rootController.confirmNavigation(false);
            var pensionView = Permissions.ruleMatched('account.super.pension.view', rootController.getUrlParams().a);

            if (pensionView) {
                type = "rollovercontribution";
            } else {
                type = "contribution";
            }
            this.parentController.showReceipt(response, type, 'submit');
        }
    });
});
