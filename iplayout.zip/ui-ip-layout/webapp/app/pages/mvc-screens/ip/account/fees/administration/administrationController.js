defineMvcController({
    name: 'administration',
    parentPath: 'mvc-screens/ip/account/fees',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['expandcollapseall'],
    mvcComponents: ['tablev3', 'section'],
    hashName: 'administration',
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore', 'app/pages/mvc-screens/ip/account/fees/_mixins/feesSectionMixin']
}, function (config, MvcController, rootController, _, feesSectionMixin) {
    'use strict';

    var adminController = MvcController.extend({
        config: config,
        hasPermission: 'account.report.view',
        requiredParams: ['a'],
        showHamburgerMenu: true,
        autoHideSpinner: false,
        preRender: function () {
            var promise = this.parentController.getData();
            promise.done(_.bind(function () {
                this.view.showSpinner();
                var data = this.parentController.model.get('adminData');
                this.model.set('ajaxerrormessage', null);
                if (!_.isEmpty(data)) {
                    if (!_.isEmpty(data.fees)) {
                        this.formatPercenatageData(data);
                        this.formatSlidingData(data);
                    }
                    this.isNoFeesApplied(data);
                    this.model.set('data', data);
                    this.parentController._hideErrorMessage();
                    this.removeChildren();
                    this.view.removeComponents(this.view.el);
                    this.view.render();
                    this.populateSections(data);
                    if (_.isObject(this.viewChildren.expandcollapseall)) {
                        this.viewChildren.expandcollapseall.update();
                    }
                }
                this.view.hideSpinner();
            }, this));
            promise.error(_.bind(function () {
                this.parentController._showErrorMessage();
                this.parentController.view.hideContent();
                this.view.hideSpinner();
            }, this));
        },

        isNoFeesApplied: function (data) {
            data.noFees = (!data.isAdminFees && !data.isSmsfFees && !data.investmentMgmtFees.managementData && !data.isTrusteeFees && !data.wrapAdvantageRebate && !data.advanceManagedFundRebate);
        },

        formatPercenatageData: function (data) {
            var tempListAssets = [];
            _.each(data.fees[0].feesComponent, function (component) {
                if (component.type === 'PercentageFee') {
                    var values = ['Listed securities', 'Managed funds', 'Managed portfolios', 'Term deposits', 'Cash'];
                    _.each(values, function (label) {
                        this.reOrderListAssets(component, label, tempListAssets);
                    }, this);
                    component.listAssets = tempListAssets;
                }
            }, this);
        },

        reOrderListAssets: function (component, label, tempListAssets) {
            for (var i = 0; i < component.listAssets.length; i++) {
                if (component.listAssets[i].isTailored && this.percentNullCheck(component.listAssets[i])) {
                    component.listAssets[i].assetClasses = this.reOrderAssetClasses(component.listAssets[i].assetClasses);
                    tempListAssets.push(component.listAssets[i]);
                    component.listAssets = _.without(component.listAssets, component.listAssets[i]);
                }
                if (i < component.listAssets.length) {
                    for (var j = 0; j < component.listAssets[i].assetClasses.length; j++) {
                        if (label === component.listAssets[i].assetClasses[j] && this.percentNullCheck(component.listAssets[i])) {
                            tempListAssets.push(component.listAssets[i]);
                            break;
                        }
                    }
                }
            }
        },

        reOrderAssetClasses: function (assetClasses) {
            var values = ['Listed securities', 'Managed funds', 'Managed portfolios', 'Term deposits', 'Cash'];
            var tempAssetClasses = [];
            _.each(values, function (label) {
                for (var i = 0; i < assetClasses.length; i++) {
                    if (assetClasses[i] === label) {
                        tempAssetClasses.push(label);
                    }
                }
            }, this);
            return tempAssetClasses;
        },

        percentNullCheck: function (val) {
            return val.tariffFactor > 0 || val.minFees > 0 || val.maxFees > 0;
        },



        formatSlidingData: function (data) {
            var clubbedSlidingScale = {};
            clubbedSlidingScale.feesComponent = [];
            _.each(data.fees[0].feesComponent, function (component) {
                if (component.type === 'SlidingScaleFee') {
                    clubbedSlidingScale.feesComponent.push(component);
                    clubbedSlidingScale.type = 'SlidingScaleFee';
                } else if (component.type === 'DollarFee') {
                    data.dollarComponent = component;
                } else if (component.type === 'PercentageFee' && component.listAssets !== null && component.listAssets.length > 0) {
                    data.percentageComponent = component;
                } else if (component.type === 'GlobalFee') {
                    data.globalComponent = component;
                }
            });
            if (!_.isEmpty(clubbedSlidingScale.feesComponent)) {
                data.slidingScaleComponent = clubbedSlidingScale;
            }
            data.isAdminFees = !(!data.percentageComponent && !data.slidingScaleComponent && !data.globalComponent && !data.dollarComponent);
        },

        formatPercentageAdminData: function (data) {
            var percentageData = [];
            var row;
            _.each(data.assetClasses, function (component) {
                row = {};
                row.type = component;
                row.percentage = data.tariffFactor;
                percentageData.push(row);
            }, this);
            return percentageData;
        },


        populateSections: function (data) {
            _.each(data.fees, _.bind(function (fee) {
                if (fee.type === 'Administration fee' && _.isObject(this.children['feetypeadmin'])) {
                    this.populateSection(this.children['feetypeadmin'], fee);
                }
            }, this));
            this._populateInvestmentManagementSection(this.children['feetypemgmt'], data.investmentMgmtFees);
            if (data.trusteeFee) {
                this._populateTrusteeSection(this.children['feetypetrustee'], this._mergeFees(data.trusteeFee));
            }
        },

        _populateInvestmentManagementSection: function (section, fees) {
            if (_.isObject(section)) {
                section.removeChildren();
                section.view.removeComponents(section.view.el);
                section.view.render();
                section.children.managementfee.setRows({
                    rowName: 'managementData'
                }, fees.managementData);
                section.children.managementfee.populateAndRenderData();
            }
        },

        _populateTrusteeSection: function (section, fees) {
            if (_.isObject(section)) {
                this.populateSection(section, fees);
            }
        }

    });
    _.extend(adminController.prototype, feesSectionMixin);
    return adminController;
});
