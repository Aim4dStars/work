define(['app/pages/mvc-screens/ip/tracking/corporateaction/election/buyback/selectedbuybackoptions/selectedbuybackoption/selectedbuybackoptionModel'],
    function (SelectedbuybackoptionModel) {
        'use strict';

        return SelectedbuybackoptionModel.extend({});
    });
