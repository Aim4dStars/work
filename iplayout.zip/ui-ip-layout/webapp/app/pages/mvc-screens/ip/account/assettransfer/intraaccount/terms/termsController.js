defineMvcController({
    name: 'terms',
    parentPath: 'mvc-screens/ip/account/assettransfer/intraaccount',
    viewHtml: true,
    viewJs: true,
    hashName: 'terms',
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal'
}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config,
    });
});
