define([
    'MvcView',
    'underscore'
], function (MvcView, _) {
    'use strict';

    return MvcView.extend({
        colorise: function (selector, value) {
            var element = this.$el.find(selector);
            element.removeClass('red');
            if (_.isFinite(value) && value < 0) {
                element.addClass('red');
            }
        },
    });
});
