defineMvcController({
    name: 'pensionpayments',
    parentPath: 'mvc-screens/ip/account/details/pensioncommencement',
    viewHtml: true,
    viewComponents: ['definitionlist', 'icon'],
    extend: 'MvcController',
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config
    });
});
