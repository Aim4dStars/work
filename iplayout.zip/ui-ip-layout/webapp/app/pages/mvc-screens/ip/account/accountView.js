define([
    'MvcView', 'app/framework/services/optionsService', 'underscore'
], function (MvcView, optionsService, _) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            summary: 'account',
            headerMenu: {
                menuHeading: 'Actions for this account:',
                items: [{
                    label: 'Place an order',
                    url: '#ng/account/investmentorders/ordercapture',
                    bindHrefParam: 'a',
                    permission: [{
                        rule: 'account.trade.create',
                        tree: 'a'
                    }, {
                        rule: '!account.super.pension.commencement.view',
                        tree: 'a'
                    }]
                }, {
                    label: 'Make a payment',
                    url: '#ng/account/movemoney/payments',
                    bindHrefParam: 'a',
                    permission: [{
                        rule: 'account.payment.transaction.view',
                        tree: 'a'
                    }, {
                        rule: '!account.super.pension.view',
                        tree: 'a'
                    }]
                }, {
                    label: 'Make a deposit',
                    url: '#ng/account/movemoney/deposits',
                    bindHrefParam: 'a',
                    permission: {
                        rule: 'account.deposit.transaction.view',
                        tree: 'a'
                    }
                }, {
                    label: 'Make a contribution',
                    url: '#ng/account/contribution/contributionstatus',
                    bindHrefParam: 'a',
                    permission: {
                        rule: 'account.super.contributions.menu.view',
                        tree: 'a'
                    }
                }, {
                    label: 'Rollover funds in',
                    url: '#/app/adviser/account/<=a=>/contribution/rollovers',
                    bindHrefParam: 'a',
                    permission: {
                        rule: 'account.super.rollovers.menu.view',
                        tree: 'a'
                    }
                }, {
                    label: 'Manage rollovers and contributions',
                    url: '#/app/adviser/account/<=a=>/contribution/rollover-contribution',
                    bindHrefParam: 'a',
                    permission: [{
                        rule: 'account.super.pension.view',
                        tree: 'a'
                    }, {
                        rule: 'account.super.pension.commencement.view',
                        tree: 'a'
                    }]
                }, {
                    label: 'Manage pension payments',
                    url: '#ng/account/pensionpayments',
                    bindHrefParam: 'a',
                    permission: {
                        rule: 'account.super.pension.view',
                        tree: 'a'
                    }
                }, {
                    label: 'Manage beneficiaries',
                    url: '#/app/adviser/account/<=a=>/details/beneficiary',
                    bindHrefParam: 'a',
                    permission: [{
                        rule: 'account.super.beneficiaries.view',
                        tree: 'a'
                    }, {
                        rule: 'account.super.pension.commencement.view',
                        tree: 'a'
                    }]
                }, {
                    label: 'Commence pension',
                    url: '#ng/account/details/pensioncommencement',
                    bindHrefParam: 'a',
                    permission: {
                        rule: 'account.super.pension.commencement.view',
                        tree: 'a'
                    }
                }, {
                    label: 'Apply for an annuity',
                    url: '#/app/adviser/account/<=a=>/policies/active',
                    bindHrefParam: 'a',
                    permission: {
                        rule: 'account.application.annuities.apply',
                        tree: 'a'
                    }
                }]
            },
            hamburger: {
                menuHeading: 'Account',
                menuItems: [{
                    children: [{
                        label: 'Overview',
                        url: '#ng/account/overview',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Account details',
                        url: '#/app/adviser/account/<=a=>/details/account-details',
                        pattern: '(ng\/account\/details)|(app\/adviser\/account\/[^\/]+\/details)',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }]
                }, {
                    children: [{
                        label: 'Portfolio views',
                        url: '#ng/account/portfolio',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Investment income',
                        url: '#ng/account/income',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Capital gains',
                        url: '#ng/account/cgt',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'option.capitalgains',
                            tree: 'a'
                        }
                    }, {
                        label: 'Transactions',
                        url: '#ng/account/transactions',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Insurance',
                        url: '#/app/adviser/account/<=a=>/insurance',
                        pattern: 'app\/adviser\/account\/[^\/]+\/insurance',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.super.insurance.view',
                            tree: 'a'
                        }
                    }]
                }, {
                    children: [{
                        label: 'Investment orders',
                        url: '#ng/account/investmentorders',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'account.investmentorders.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Corporate actions',
                        url: '#/app/adviser/account/<=a=>/corporate-actions/voluntary',
                        bindHrefParam: 'a',
                        permission: [{
                            rule: 'account.asim.view',
                            tree: 'a'
                        }, {
                            rule: 'option.noncashassets',
                            tree: 'a'
                        }]
                    }, {
                        label: 'Payments & deposits',
                        url: '#ng/account/movemoney',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'account.movemoney.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Scheduled transactions',
                        url: '#ng/account/scheduledtransaction',
                        bindHrefParam: 'a,c',
                        permission: {
                            rule: 'account.transaction.scheduled.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Rollovers & contributions',
                        url: '#/app/adviser/account/<=a=>/contribution/rollover-contribution',
                        pattern: '(ng\/account\/contribution)|(app\/adviser\/account\/[^\/]+\/contribution)',
                        bindHrefParam: 'a',
                        permission: [{
                            rule: 'account.super.contribution.view',
                            tree: 'a'
                        }, {
                            rule: 'account.super.pension.view',
                            tree: 'a'
                        }, {
                            rule: '!account.super.pension.commenced.view',
                            tree: 'a'
                        }]
                    }, {
                        label: 'Rollovers & contributions',
                        url: '#/app/adviser/account/<=a=>/contribution/rollover-history',
                        pattern: '(ng\/account\/contribution)|(app\/adviser\/account\/[^\/]+\/contribution)',
                        bindHrefParam: 'a',
                        permission: [{
                            rule: 'account.super.contribution.view',
                            tree: 'a'
                        }, {
                            rule: 'account.super.pension.commenced.view',
                            tree: 'a'
                        }]
                    }, {
                        label: 'Rollovers & contributions',
                        url: '#ng/account/contribution',
                        pattern: '(ng\/account\/contribution)|(app\/adviser\/account\/[^\/]+\/contribution)',
                        bindHrefParam: 'a',
                        permission: [{
                            rule: 'account.super.contribution.view',
                            tree: 'a'
                        }, {
                            rule: '!account.super.pension.view',
                            tree: 'a'
                        }]
                    }, {
                        label: 'Pension payments',
                        url: '#ng/account/pensionpayments',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.super.pension.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Accessing super',
                        url: '#ng/account/accessingsuper',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.super.accessing.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Cash management',
                        url: '#ng/account/preferences',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'option.cashmanagement.supported',
                            tree: 'a'
                        }
                    }, {
                        label: 'Asset transfers',
                        url: '#ng/account/assettransfer',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.transfer.external.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Intra account transfers',
                        url: '#ng/account/assettransfer',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.transfer.internal.menu.view',
                            tree: 'a'
                        }
                    }]
                }, {
                    children: [{
                        label: 'Reports',
                        url: '#/app/adviser/account/<=a=>/reports',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Document library',
                        url: '#ng/account/documents',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.document.view',
                            tree: 'a'
                        }
                    }, {
                        label: 'Fees',
                        url: '#ng/account/fees',
                        bindHrefParam: 'a',
                        permission: {
                            rule: 'account.hamburger.menu.view',
                            tree: 'a'
                        }
                    }]
                }]
            }
        },

        preRender: function () {
            var scheduledTransactionLabel = optionsService.getOption('scheduledtransaction.menu.description', 'a');
            if (_.isUndefined(scheduledTransactionLabel)) {
                scheduledTransactionLabel = 'Scheduled transactions';
            }
            _.each(this.rootTemplate.hamburger.menuItems, function (itemList) {
                _.each(itemList.children, function (item) {
                    if (item.url === '#ng/account/scheduledtransaction') {
                        item.label = scheduledTransactionLabel;
                    }
                }, this);
            }, this);
        }
    });
});
