defineMvcController({
    name: 'realisedsecurity',
    parentPath: 'mvc-screens/ip/account/cgt/realised',
    viewHtml: true,
    modelJs: false,
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['inputdate'],
    hashName: 'realisedsecurity',
    extend: 'app/pages/mvc-screens/ip/account/cgt/cgtBaseViewByController',
}, function (config, CgtViewByBaseController) {
    'use strict';

    return CgtViewByBaseController.extend({
        config: config,
        urlTemplate: '../api/v1_0/accounts/<%=a%>/realised-cgtBySecurity',
        taxColumns: [5, 7, 8],
        showQuantity: true,
        detailSort: 'ascendingSecurityName',
        repeatingAssetProperty: 'parentInvCode',
        totalColspan: 4,
        title: 'realised'
    });

});
