defineMvcController({
    name: 'account',
    parentPath: 'mvc-screens/ip',
    viewHtml: true,
    viewJs: true,
    hashName: 'account',
    viewComponents: ['messagealert'],
    screens: ['overview', 'fees', 'portfolio', 'cgt', 'contribution', 'income', 'details', 'status', 'transactions', 'scheduledtransaction', 'investmentorders', 'movemoney', 'statements', 'documents', 'assettransfer', 'pensionpayments', 'corporateaction', 'preferences', 'accessingsuper'],
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore', 'jquery', 'app/framework/helpers/timezone', 'app/pages/mvc-screens/ip/services/accountService', 'app/framework/services/Permissions']
}, function (config, MvcController, rootController, _, $, timezone, accountService, Permissions) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        accountOptionsParam: 'a',
        accountPromise: null,

        postRender: function () {
            this.fetchAccountDetails();
        },

        fetchAccountDetails: function () {
            this.accountPromise = $.Deferred();

            accountService.getAccount(this)
                .done(_.bind(function (accountRaw) {
                    var account = this.processAccountData(accountRaw);

                    if (Permissions.ruleMatched('recent.accounts.view', '')) {
                        rootController.addAccountDetailsToRecentlyAccessed({
                            accountId: accountRaw.key && accountRaw.key.accountId,
                            accountName: accountRaw.accountName,
                            accountNumber: accountRaw.accountNumber,
                            accountType: accountRaw.accountType,
                            productName: accountRaw.product && accountRaw.product.productName
                        });
                    }

                    this.model.set('account', account);
                    this.accountPromise.resolve(account);
                    this.viewChildren.ajaxerror.hide();
                    this.parentController.enableSpinner();
                }, this))
                .fail(_.bind(function () {
                    this.accountPromise.reject();
                    this.parentController.disableSpinner();
                    this.viewChildren.ajaxerror.show();
                }, this));

            return this.accountPromise;
        },

        getAccountPromise: function () {
            if (_.isNull(this.accountPromise)) {
                return this.fetchAccountDetails();
            }

            if (this.accountPromise.state() === "rejected") {
                return this.fetchAccountDetails();
            }

            return this.accountPromise;
        },

        processAccountData: function (account) {
            var openDate = timezone.convertTimezone(new Date(account.accountStartDate), 'AEDST');
            var migrationDetails = _.clone(account.migrationDetails);

            openDate = openDate.date;
            var closureDate;
            if (!_.isEmpty(account.closureDate)) {
                closureDate = timezone.convertTimezone(new Date(account.closureDate), 'AEDST');
            }
            closureDate = !_.isEmpty(closureDate) ? closureDate.date : closureDate;

            if (!_.isUndefined(migrationDetails)) {
                if (!_.isEmpty(migrationDetails.migrationDate)) {
                    migrationDetails.migrationDate = timezone.convertTimezone(new Date(migrationDetails.migrationDate), 'AEDST').date;
                }
            }

            var allowReinvestments = account.reinvestmentsAllowed;

            return {
                migrationDetails: migrationDetails,
                openDate: openDate,
                closureDate: closureDate,
                allowReinvestments: allowReinvestments,
                accountName: account.accountName,
                accountNumber: account.accountNumber,
                taxLiability: account.taxLiability,
                adminFeeRate: account.adminFeeRate,
                hasMinCash: account.hasMinCash,
                minCashAmount: account.minCashAmount,
                superAccountSubType: account.superAccountSubType,
                owners: account.owners,
                accounttype: account.accountType,
                hasIhin: account.hasIhin,
                linkedAccounts: account.linkedAccounts
            };
        }
    });
});
