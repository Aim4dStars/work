defineMvcController({
    name: 'dollarfee',
    parentPath: 'mvc-screens/ip/account/fees/manage/details/advicefee',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['forminputtext', 'forminputcheckbox', 'fieldset'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            var data = this.parentController.model.get('data');
            if (data && data.feesComponent) {
                var feesComponent = data.feesComponent;
                for (var j in feesComponent) {
                    if (feesComponent[j].type === 'DollarFee') {
                        this.model.set('amount', feesComponent[j].amount);
                        this.model.set('cpiindex', feesComponent[j].cpiindex);
                    }
                }
            }
        },

        deleteChildCell: function () {
            this.parentController.deleteChildCell(this.name);
        },

        getValues: function () {
            var valid = false;
            if (this.validateAndSubmitForm(this.view.getSubmitEvent())) {
                valid = true;
            }
            return {
                valid: valid,
                value: {
                    cpiindex: this.model.get('cpiindex'),
                    amount: this.model.get('amount'),
                    type: 'DollarFee',
                    label: 'Dollar fee component'
                }
            };
        }

    });

});
