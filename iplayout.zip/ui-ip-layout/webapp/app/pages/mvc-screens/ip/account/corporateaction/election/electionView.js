define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/electionView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/_election.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (ElectionView, _electionTemplate, componentXml, Handlebars) {
    'use strict';

    return ElectionView.extend({

        preRender: function () {
            Handlebars.registerPartial('election', componentXml.encode(_electionTemplate));
        }
    });

});
