defineMvcController({
    name: 'participationreport',
    parentPath: 'mvc-screens/ip/account/corporateaction',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    viewComponents: ['button', 'icon'],
    mvcComponents: ['tablev3'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/participationreport/participationreportController',
}, function (config, ParticipationReportController) {
    'use strict';

    return ParticipationReportController.extend({
        config: config
    });

});
