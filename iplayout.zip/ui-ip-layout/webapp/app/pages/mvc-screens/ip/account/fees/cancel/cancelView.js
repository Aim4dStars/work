define([
    'app/pages/mvc-templates/modal/modalView'
], function (ModalView) {
    'use strict';

    return ModalView.extend({
        //*Important* Merge `events` with ModalView events. If you are using events!
        //E.g.
        // events: _.extend({
        //'click .my-button': 'onButtonClick'
        //}, ModalView.prototype.events),

    });

});
