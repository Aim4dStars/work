defineMvcController({
    name: 'editdetails',
    parentPath: 'mvc-screens/ip/account/details',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['forminputradios', 'button', 'messagealert', 'termsandconditions'],
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['underscore', 'rootController', 'app/framework/services/Permissions']
}, function (config, ModalController, _, rootController, Permissions) {
    'use strict';

    return ModalController.extend({
        config: config,
        updateUrlTemplate: '../api/v1_0/accounts/<%=a%>/update',
        viewEvents: {
            'submit form': 'submit'
        },

        postRender: function () {
            //to toggle update button
            this.model.on('change:consent', this.toggleUpdate, this);

            var paramName = this.model.get('editParam');
            if (paramName === 'primaryContactPerson') {
                this.model.set('modalTitle', 'primary contact');
                var clients = this.model.get('primaryContactPerson');
                for (var i in clients) {
                    if (clients[i].primaryContactPerson) {
                        this.model.set('editableData', clients[i].key.clientId);
                        break;
                    }
                }
            } else if (paramName === 'capitalGainTax') {
                this.model.set('modalTitle', 'account tax preference');
                this.model.set('editableData', this.model.get('capitalGainTax.CGTLMethodId'));
            }
            this.viewChildren.update.disable();

            //hide the errors
            this._hideErrorMessage();
        },

        toggleUpdate: function () {
            var ruleMatched = Permissions.ruleMatched('emulating', '');
            if (!ruleMatched) {
                if (this.model.get('consent')) {
                    this.viewChildren.update.enable();
                } else {
                    this.viewChildren.update.disable();
                }
            }
        },

        submit: function (event) {
            if (this.validateAndSubmitForm(event)) {
                if (!this.viewChildren.update.isLoading()) {
                    this.updateDetails();
                }
            }
        },

        updateDetails: function () {
            this.viewChildren.termsandconditions.disable();
            var data = {};
            var paramName = this.model.get('editParam');

            if (paramName === 'primaryContactPerson') {
                var primaryContact = {
                    key: this.model.get('editableData')
                };
                data = this._convertArrayToJson(primaryContact, 'primaryContact');
            } else {
                data = {
                    cGTLMethodId: this.model.get('editableData')
                };
            }
            this._sendUpdateRequest(data, paramName);
        },

        _sendUpdateRequest: function (data, paramName) {
            var childName = this.model.get('childName');
            var params = {};
            params.success = _.bind(function (data) {
                this.parentController.updateDetails(data.data, childName, paramName);
                this.view.unloadSpinner();
            }, this);

            params.error = _.bind(function (jqXHR, textStatus, errorThrown) {
                this._showErrorMessage(errorThrown);
                this.view.unloadSpinner();
            }, this);

            params.url = this.getUrl(rootController.getUrlParams(), this.updateUrlTemplate);
            params.data = data;
            params.data.modificationSeq = this.model.get('modificationSeq');
            this.view.loadSpinner();
            this.ajaxPost(params);
        },

        _showErrorMessage: function (errorThrown) {
            if (errorThrown === 'timeout') {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0369'));
            }
            if (this.viewChildren && this.viewChildren.ajaxerror) {
                this.viewChildren.ajaxerror.show();
            }
        },

        _hideErrorMessage: function () {
            if (this.viewChildren && this.viewChildren.ajaxerror) {
                this.viewChildren.ajaxerror.hide();
            }
        },

        _convertArrayToJson: function (list, name, obj) {
            if (!obj) {
                obj = {};
            }
            for (var i in list) {
                if (_.isObject(list[i])) {
                    this._convertArrayToJson(list[i], name + '[' + i + ']', obj);
                } else {
                    obj[(name + '.' + i)] = list[i];
                }
            }
            return obj;
        },


    });

});
