define([
    'underscore', 'jquery', 'rootController'
], function (_, $, rootController) {
    'use strict';

    return {
        url: {
            rolloverInURL: '../api/rollover/v1_0/account/<%=a%>/rollover-in',
            rolloverInSaveURL: '../api/rollover/v1_0/account/<%=a%>/save',
            loadRolloverURL: '../api/rollover/v1_0/account/<%=a%>/rollover-in/<%=rid%>',
            cancelRolloverURL: '../api/rollover/v1_0/account/<%=a%>/discard/<%=rid%>'
        },

        submitRolloverIn: function (controller, params) {
            var deferred = $.Deferred();

            controller.ajaxPost({
                url: controller.getUrl(rootController.getUrlParams(), this.url.rolloverInURL),
                data: {
                    'rollInData': JSON.stringify(params)
                },
                success: function (data) {
                    if (data) {
                        deferred.resolve(data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },

        saveRolloverIn: function (controller, params) {
            var deferred = $.Deferred();

            controller.ajaxPost({
                url: controller.getUrl(rootController.getUrlParams(), this.url.rolloverInSaveURL),
                data: {
                    'rollInData': JSON.stringify(params)
                },
                success: function (data) {
                    if (data) {
                        deferred.resolve(data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },

        getRolloverDetails: function (controller) {
            var deferred = $.Deferred();

            controller.ajaxGet({
                url: controller.getUrl(rootController.getUrlParams(), this.url.loadRolloverURL),
                success: function (data) {
                    if (data) {
                        deferred.resolve(data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },

        cancelRollover: function (controller, rid) {
            var deferred = $.Deferred();
            var urlParams = {
                a: rootController.getUrlParams()["a"],
                rid: rid
            };
            controller.ajaxGet({
                url: controller.getUrl(urlParams, this.url.cancelRolloverURL),
                success: function (data) {
                    if (data) {
                        deferred.resolve(data);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        }
    };
});
