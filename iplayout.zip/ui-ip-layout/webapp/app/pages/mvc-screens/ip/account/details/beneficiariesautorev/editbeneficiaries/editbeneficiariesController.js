defineMvcController({
    name: 'editbeneficiaries',
    parentPath: 'mvc-screens/ip/account/details/beneficiariesautorev',
    viewHtml: true,
    viewJs: true,
    hashName: 'editbeneficiaries',
    mvcComponents: ['section'],
    screens: ['beneficiarysection'],
    viewComponents: ['button', 'position', 'termsandconditions'],
    extend: 'MvcController',
    dependencies: ['rootController', 'jquery', 'underscore', 'app/framework/helpers/format', 'app/framework/router', 'app/framework/services/dateService', 'libs/panorama-bridge/require-panoramaBridge']
}, function (config, MvcController, rootController, $, _, formatHelper, router, dateService, panoramaBridge) {
    'use strict';

    return MvcController.extend({
        config: config,
        defaults: {
            maxBeneficiaryCount: 20
        },
        autoHideSpinner: false,
        AUTO_REVERSIONARY: 'nomn_auto_revsnry',
        viewBeneficiariesUrl: '#/app/adviser/account/<%=a%>/details/beneficiary',

        preRender: function () {
            rootController.model.on('change:urlParams', this.pageRefresh, this);
            this.model.set('viewBeneficiariesUrl', this.viewBeneficiariesUrl);
            this.initialRow = rootController.getUrlParams().row;
            this.fetchData();
        },

        pageRefresh: function () {
            this.model.set('agree', null);
            this.viewChildren.termsandconditionscheck.turnOffTooltip();
            this.initialRow = rootController.getUrlParams().row;
            this.fetchData();
        },

        postRender: function () {
            this._hideAllMessage();
            this.model.set('showSecondarytotalAllocationPercentage', true);
        },

        onDestroy: function () {
            rootController.model.off('change:urlParams', this.pageRefresh);
        },

        fetchData: function () {
            // display screen spinner if trigger via Url params change.
            if (this.view) {
                this.view.showSpinner();
            }
            this.model.unset('autoReversionaryActivationDate');
            $.when(this.parentController.fetchBeneficiaries(),
                this.parentController.fetchNominationTypes(),
                this.parentController.fetchRelationshipTypes(),
                this.parentController.fetchGender())
                .then(_.bind(function (beneficiaryData, nominationTypeData, relationshipTypeData, genderData) {
                        this.model.set('autoReversionaryActivationDate', beneficiaryData.autoReversionaryActivationDate);
                        this.children.beneficiarysection.hide();
                        this._prepareRelationshipTypes(relationshipTypeData);
                        var filteredGenderData = this._filterGenderData(genderData);
                        var filteredDependentRelationshipTypes = this._filterDependentRelationshipTypes(relationshipTypeData);
                        var beneficiaries = this._parseBeneficiaryData(beneficiaryData.beneficiaries, nominationTypeData);
                        var beneficiariesData = this._checkForAutoReversionary(beneficiaries, nominationTypeData);

                        this.model.set({
                            'beneficiaries': beneficiariesData,
                            'nominationTypes': nominationTypeData,
                            'relationshipTypes': relationshipTypeData,
                            'dependentRelationshipTypes': filteredDependentRelationshipTypes,
                            'genderData': filteredGenderData,
                        });
                        this.children.beneficiarysection.show();
                        this.children.beneficiarysection.renderBeneficiaries();
                        this._setAddBeneficiaryEnabled();
                        this.view.hideSpinner();
                    }, this),
                    _.bind(function () {
                        this._setAjaxErrorMessage();
                        this._showMessage('ajaxerror');
                        this.view.hideSpinner();
                    }, this));
        },

        _checkForAutoReversionary: function (beneficiaries, nominationTypeData) {
            var beneficiaryIndex;
            _.each(beneficiaries, function (beneficiary, index) {
                if (beneficiary.nominationType === this.AUTO_REVERSIONARY) {
                    beneficiary.isPrimaryAllocationAvailable = true;
                    beneficiaryIndex = index;
                    this.model.set('totalAutoReversionaryAllocationPercentage', formatHelper.formatMoney(100, 2, '%'));
                    this.view._setSectionHeadings('change');
                } else {
                    beneficiary.isPrimaryAllocationAvailable = false;
                }
                beneficiary.showEmptyStateMsg = false;
            }, this);
            this.model.set('showSecondarytotalAllocationPercentage', true);
            if (!_.isUndefined(beneficiaryIndex)) {
                if (beneficiaries.length === 1) {
                    beneficiaries[beneficiaryIndex].showEmptyStateMsg = true;
                    this.model.set('showSecondarytotalAllocationPercentage', false);
                }
                this.model.set('secondaryBeneficiaryNominationTypes', this._setSecondaryBeneficiaryNominationTypes(nominationTypeData));
                return this._reorderBeneficiariesList(beneficiaries, beneficiaryIndex);
            } else {
                if (!_.isEmpty(this.model.get('autoReversionaryActivationDate'))) {
                    this.model.set('secondaryBeneficiaryNominationTypes', this._setSecondaryBeneficiaryNominationTypes(nominationTypeData));
                } else {
                    this.model.set('secondaryBeneficiaryNominationTypes', nominationTypeData);
                }
                this.view._setSectionHeadings();
            }
            return beneficiaries;
        },

        _setSecondaryBeneficiaryNominationTypes: function (nominationTypes) {
            var secondaryBeneficiaryNominationTypes = _.filter(nominationTypes, function (num) {
                return num.label !== "Auto reversionary";
            }, this);
            return secondaryBeneficiaryNominationTypes;
        },

        _prepareRelationshipTypes: function (relationshipTypes) {
            _.each(relationshipTypes, function (relationshipType) {
                relationshipType.label = this.toSentenceCase(relationshipType.label);
            }, this);
        },

        toSentenceCase: function (normalStr) {
            if ((normalStr === null) || (normalStr === '')) {
                return normalStr;
            }

            return normalStr.charAt(0).toUpperCase() + normalStr.substr(1).toLowerCase();
        },

        _filterGenderData: function (genderData) {
            var genderMap = _.object(_.pluck(genderData, 'intlId'), genderData);
            return [genderMap['male'],
                genderMap['female']];
        },

        _filterDependentRelationshipTypes: function (relationshipTypeData) {
            return _.filter(relationshipTypeData, function (relationshipType) {
                return relationshipType.dependent === true;
            });
        },

        _reorderBeneficiariesList: function (beneficiaries, rowIndex) {
            var autoReversionaryBeneficiary = beneficiaries[rowIndex];
            beneficiaries.splice(rowIndex, 1);
            beneficiaries.unshift(autoReversionaryBeneficiary);
            return beneficiaries;
        },

        _parseBeneficiaryData: function (beneficiaryData) {
            if (!beneficiaryData || !beneficiaryData.length) {
                var minimalBeneficiaryData = {
                    expanded: true,
                    firstName: "",
                    allocationPercent: ""
                };
                return [minimalBeneficiaryData];
            }

            _.each(beneficiaryData, function (beneficiary, index) {
                beneficiary.expanded = (index === Number(this.initialRow));
            }, this);

            return beneficiaryData;
        },

        updateAllocationTotal: function (value) {
            if (!_.isNaN(value)) {
                this.model.set('totalAllocationPercent', value);
                this.model.set('totalAllocationPercentFormatted', formatHelper.formatMoney(value, 2, '%'));
                this.view.colorAllocationTotal(value);
            }
        },

        addBeneficiary: function ($button) {
            $button.blur();
            this.model.set('showSecondarytotalAllocationPercentage', true);

            var beneficiaries = this.children.beneficiarysection.getAllSectionModelData();
            this.children.beneficiarysection.hide();
            _.each(beneficiaries, function (beneficiary) {
                beneficiary.expanded = false;
            });
            var lastBeneficiary = beneficiaries[beneficiaries.length - 1];
            var lastBeneficiaryNominationType = lastBeneficiary ? beneficiaries[beneficiaries.length - 1].nominationType : '';
            if (lastBeneficiaryNominationType === this.AUTO_REVERSIONARY) {
                lastBeneficiaryNominationType = '';
            }
            var minimalBeneficiaryData = {
                expanded: true,
                firstName: '',
                allocationPercent: '',
                nominationType: lastBeneficiaryNominationType
            };
            if (_.isArray(beneficiaries)) {
                beneficiaries.push(minimalBeneficiaryData);
            } else {
                beneficiaries = [minimalBeneficiaryData];
            }

            this.model.set('beneficiaries', beneficiaries);

            this.children.beneficiarysection.show();
            this.children.beneficiarysection.model.set('beneficiaries', beneficiaries);
            this.children.beneficiarysection.renderBeneficiaries();
            this._setAddBeneficiaryEnabled();


            var sections = this.children.beneficiarysection.getAllSections();

            // don't validate the new added section.
            sections.pop();

            _.each(sections, function (section) {
                var validate = section.validateFormAsync(section.view.$el, 'blur');
                $.when(validate).then(function (isValid) {
                    section.view.collapse();
                    section.model.set('showInvalidIcon', !isValid);
                }, this);
            }, this);
            this.view._hideSecondaryNominationEmptyStateMsg();
            this.view.updateExpandCollapseSections();
            this.enableConfirmNavigation();
        },

        save: function () {
            var sections = this.children.beneficiarysection.getAllSections();
            _.each(sections, function (section) {
                var validate = section.validateForm(section.view.$el, 'blur');
                $.when(validate).then(function (isValid) {
                    section.model.set('showInvalidIcon', !isValid);
                }, this);
                if (section.view.isExpanded()) {
                    section.view.collapse();
                }
            }, this);


            var isAllBeneficiariesValid = _.find(sections, function (section) {
                if (section.model.get('showInvalidIcon')) {
                    return true;
                }
            });

            if (_.isUndefined(isAllBeneficiariesValid) || !isAllBeneficiariesValid.model.get('showInvalidIcon')) {
                var isPrimaryAllocationOnlyAvailable;
                if (sections.length) {
                    isPrimaryAllocationOnlyAvailable = this.children.beneficiarysection._isAutoReversionary(sections[0].model.get('nominationType')) && sections.length === 1;
                }
                if (this._toggleConsent() || isPrimaryAllocationOnlyAvailable || sections.length === 0) {
                    if (this.model.get('agree')) {
                        this.model.set('showValidationError', false);
                        this._hideMessage('showvalidationerror');
                        var beneficiaries = this.children.beneficiarysection.getAllSectionModelData();
                        var data = this._getbeneficiaryTrxnDto(beneficiaries);
                        var url = this.parentController.beneficiariesUrl;
                        this._postData(this._modifyAllocationPercent(data, isPrimaryAllocationOnlyAvailable), url);
                    } else {
                        this.viewChildren.termsandconditionscheck.turnintoTooltip();
                    }
                }
            } else {
                this.model.set('showValidationError', true);
                this._showMessage('showvalidationerror');
            }
        },

        _toggleConsent: function () {
            var isTotalAllocation100 = Number(this.model.get('totalAllocationPercent')) === 100;
            var beneficiaries = this.children.beneficiarysection.getAllSectionModelData();
            if (isTotalAllocation100 || (this._isAutoReversionary() && beneficiaries.length === 1)) {
                this._hideMessage('allocationpercenterror');
                return true;
            } else {
                if (this._isAutoReversionary()) {
                    this.model.set('allocationPercentErrorMsg', rootController.getCmsEntry('Err.IP-0799'));
                } else {
                    this.model.set('allocationPercentErrorMsg', rootController.getCmsEntry('Err.IP-0784'));
                }
                this._showMessage('allocationpercenterror');
                this.model.set('showValidationError', false);
                this._hideMessage('showvalidationerror');
                return false;
            }
        },

        disableConfirmNavigation: function () {
            rootController.confirmNavigation(false);
        },

        enableConfirmNavigation: function () {
            rootController.confirmNavigation(true);
        },

        _getbeneficiaryTrxnDto: function (beneficiariesList) {
            var beneficiaries = [];
            _.each(beneficiariesList, function (data) {
                var beneficiary = {};
                beneficiary.nominationType = data.nominationType;
                beneficiary.allocationPercent = data.allocationPercent;
                beneficiary.relationshipType = data.relationshipType;
                beneficiary.firstName = data.firstName || '';
                beneficiary.lastName = data.lastName || '';
                beneficiary.dateOfBirth = this._formatDateOfBirth(data.dateOfBirth);
                beneficiary.gender = data.gender || '';
                beneficiary.phoneNumber = data.phoneNumber || '';
                beneficiary.email = data.email || '';
                beneficiaries.push(beneficiary);
            }, this);
            var beneficiaryTrxnDto = {
                'beneficiaries': beneficiaries
            };
            return beneficiaryTrxnDto;
        },

        _postData: function (data, url) {
            this.view.showSpinner();
            var deferred = $.Deferred();
            var params = {
                contentType: 'application/json',
                url: this.getUrl(rootController.getUrlParams(), url),
                data: JSON.stringify(data),
                success: _.bind(function (data) {
                    if (data.data.transactionStatus === 'saved') {
                        this.disableConfirmNavigation();
                        this.parentController.model.set('isBeneficiariesSaved', true);
                        this.navigateToViewBeneficiaries();
                    } else {
                        this._showMessage('genericerror');
                        this.view.hideSpinner();
                    }
                }, this),
                error: _.bind(function (data) {
                    //check for 400 explicit
                    if (data.status !== 400) {
                        rootController.model.set('ajax.error', true);
                        this.parentController.parentController.parentController.parentController.toggleAjaxError();
                    }

                    this.view.hideSpinner();
                }, this)
            };
            this.model.set('ajaxerrormessage', null);
            this._hideAllMessage();
            this.parentController.parentController.parentController.parentController.clearAjaxError();
            this.ajaxPost(params);
            return deferred.promise();
        },

        _modifyAllocationPercent: function (data, isPrimaryAllocationOnlyAvailable) {
            if (!isPrimaryAllocationOnlyAvailable) {
                _.each(data.beneficiaries, function (beneficiary) {
                    if (beneficiary.nominationType === this.AUTO_REVERSIONARY) {
                        beneficiary.allocationPercent = 0;
                    }
                }, this);
            }
            return data;
        },
        _setAjaxErrorMessage: function (errorThrown) {
            if (errorThrown === 'timeout') {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0344'));
            }
        },

        _formatDateOfBirth: function (date) {
            var formattedDate;
            if (!_.isUndefined(date) && !_.isNull(date)) {
                formattedDate = dateService.formatDate(date, 'dd mmm yyyy');
                return _.isUndefined(formattedDate) ? date : formattedDate;
            } else {
                return "";
            }
        },

        navigateToViewBeneficiaries: function () {
            var url = this.getUrl(rootController.getUrlParams(), this.viewBeneficiariesUrl) + '?success=true';
            panoramaBridge.notifyHashChange(url, true);
        },

        _setAddBeneficiaryEnabled: function () {
            var isMaxBeneficiariesAdded = this._isMaxBeneficiariesAdded();
            if (isMaxBeneficiariesAdded) {
                this.viewChildren.addbeneficiary.disable();
            } else {
                this.viewChildren.addbeneficiary.enable();
            }
        },

        _isMaxBeneficiariesAdded: function () {
            var beneficiaries = this.children.beneficiarysection.getAllSectionModelData();
            if (beneficiaries && beneficiaries.length >= this.defaults.maxBeneficiaryCount) {
                return true;
            }
            return false;
        },

        _isAutoReversionary: function () {
            var beneficiaries = this.children.beneficiarysection.getAllSectionModelData();
            if (beneficiaries && beneficiaries.length) {
                var autoReversionaryBeneficiaries = _.filter(beneficiaries, function (beneficiary) {
                    return beneficiary.isAutoReversionary;
                });
                return autoReversionaryBeneficiaries.length > 0;
            }
            return false;
        },



        _showMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].hide();
            }
        },

        _hideAllMessage: function () {
            _.each(['ajaxerror', 'genericerror'], function (message) {
                this._hideMessage(message);
            }, this);
        }
    });
});
