define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({

    });
});
