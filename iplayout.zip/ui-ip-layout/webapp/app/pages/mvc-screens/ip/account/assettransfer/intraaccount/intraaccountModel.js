define(['MvcModel', 'underscore', 'jquery',
    'app/pages/mvc-screens/ip/account/assettransfer/util/tradableassetsService',
    'app/pages/mvc-screens/ip/account/assettransfer/util/valuationService',
    'app/pages/mvc-screens/ip/account/assettransfer/util/utils'],
    function (MvcModel, _, $, tradableassetsService, valuationService, util) {
        'use strict';

        return MvcModel.extend({
            validation: {
                sourceportfolio: {
                    blur: {
                        required: false
                    },
                    submit: {
                        required: true
                    }
                },
                destinationportfolio: {
                    blur: {
                        required: false
                    },
                    submit: {
                        required: true
                    }
                },
                percentage: {
                    type: 'percent',
                    blur: {
                        required: false,
                        minValue: 0,
                        customFormat: 'customPercentageValidation'
                    }
                },
                dollarsall: {
                    priority: ['required', 'customFormat', 'minValue', 'customMaxValue'],
                    type: 'dollar',
                    blur: {
                        required: false,
                        minValue: 0,
                        customMaxValue: 'getDollarsAllMaxValue'
                    }
                },
            },

            getDollarsAllMaxValue: function (value) {
                var selectedHolding = this.get('selectedHolding');
                selectedHolding = util.convertToNumber(selectedHolding);
                return value <= selectedHolding;
            },

            structureInvestments: function (investments) {
                return _.map(investments, function (asset) {
                    var categoryName = valuationService.getCategoryName(asset);
                    return {
                        investmentAsset: asset,
                        categoryName: categoryName,
                        assetId: asset.assetId
                    };
                }, this);
            },

            getAssetSelectorData: function () {
                var sourceContainer = this.get('sourceContainer');
                var destinationContainer = this.get('destinationContainer');
                var heldMPPortfolios = this.get('allHeldManagedPortfolios');
                var heldTPPortfolios = this.get('allHeldTailoredPortfolios');
                var assetselectorObj = this.getAssetSelectorDTO();

                if (sourceContainer === 'portfolioContainer') {
                    var sourceHeldPortfolio = heldMPPortfolios;
                    var transferSource = this.get('sourceportfolio');
                    if (tradableassetsService.isTailoredPortfolio(transferSource)) {
                        sourceHeldPortfolio = heldTPPortfolios;
                    }
                    assetselectorObj.sourceContainerId = valuationService.getContainerId(transferSource, sourceHeldPortfolio);
                    assetselectorObj.source.assetCode = transferSource.assetCode;
                    assetselectorObj.source.assetName = transferSource.name;
                }
                if (destinationContainer === 'portfolioContainer') {
                    var destHeldPortfolio = heldMPPortfolios;
                    var transferDestination = this.get('destinationportfolio');
                    transferDestination.assetId = transferDestination.asset.assetId;
                    if (tradableassetsService.isTailoredPortfolio(transferDestination.asset)) {
                        destHeldPortfolio = heldTPPortfolios;
                    }
                    assetselectorObj.targetContainerId = valuationService.getContainerId(transferDestination, destHeldPortfolio);
                    if (_.isNull(assetselectorObj.targetContainerId)) {
                        assetselectorObj.targetContainerId = undefined;
                        assetselectorObj.targetAssetId = transferDestination.assetId;
                    } else {
                        assetselectorObj.targetAssetId = undefined;
                    }
                    assetselectorObj.dest.assetCode = transferDestination.asset.assetCode;
                    assetselectorObj.dest.assetName = transferDestination.assetName;
                }
                return assetselectorObj;
            },

            getAssetSelectorDTO: function () {
                var excludedAssets = [];
                var directContainerId = null;

                var cashAsset = this.get('cashAsset');
                if (!_.isUndefined(cashAsset) && cashAsset.investments.length > 0) {
                    directContainerId = cashAsset.investments[0].subAccountId;
                }

                excludedAssets = this.get('excludedAssets');

                return {
                    "targetAssetId": null,
                    "targetContainerId": directContainerId,
                    "sourceContainerId": directContainerId,
                    "transferPreferences": excludedAssets,
                    "incomePreference": this.get('incomepreference'),
                    "isFullClose": this.get('closeportfolio') === "true",
                    "selectedHolding": this.get('selectedHolding'),
                    "source": {},
                    "dest": {}
                };
            },

            getDataForServer: function (submitType, errorResponse) {
                var transferData = $.extend(true, {}, this.get('transferData'));
                transferData.transferAssets = _.map(transferData.transferAssets, function (asset) {
                    return {
                        asset: {
                            assetId: asset.asset.assetId,
                            "type": "Asset"
                        },
                        quantity: asset.quantity,
                        isCashTransfer: asset.isCashTransfer,
                    };
                });
                var data = {
                    "targetAssetId": transferData.targetAssetId,
                    "targetContainerId": transferData.targetContainerId,
                    "sourceContainerId": transferData.sourceContainerId,
                    "transferPreferences": transferData.transferPreferences,
                    "incomePreference": transferData.incomePreference,
                    "isFullClose": transferData.isFullClose,
                    "transferAssets": transferData.transferAssets,
                    "transferType": "Internal transfer",
                    "sourceAccountKey": {
                        "accountId": this.get('accountId')
                    },
                    "targetAccountKey": {
                        "accountId": this.get('accountId')
                    },
                    "action": submitType,
                    "orderType": "Intra account transfer"
                };
                if (errorResponse) {
                    data.warnings = errorResponse;
                }

                return data;
            }

        });
    });
