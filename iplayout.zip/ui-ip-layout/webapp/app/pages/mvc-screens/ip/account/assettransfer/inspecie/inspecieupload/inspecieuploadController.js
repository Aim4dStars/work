defineMvcController({
    name: 'inspecieupload',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'inspecieupload',
    hashDefault: true,
    extend: 'app/pages/mvc-screens/ip/account/assettransfer/transfer/transferController',
    viewComponents: ['trainstop', 'inputradios', 'forminputautocomplete', 'button', 'tooltip', 'inputselect', 'messagealert'],
    screens: ['mvc-screens/ip/account/investmentorders/ordercapture/modelpreferences', 'uploadstatus', 'uploadfile', 'terms'],
    mvcComponents: ['inputautocomplete'],
    dependencies: ['rootController',
                    'app/framework/services/Permissions',
                    'jquery',
                    'underscore',
                    'app/framework/router',
                    'app/pages/mvc-screens/ip/account/assettransfer/util/tradableinvestmentoptionsService',
                    'app/pages/mvc-screens/ip/services/accountService',
                    'app/framework/helpers/format',
                    'app/pages/mvc-screens/ip/account/investmentorders/ordercapture/ordercapturePreferences',
                    'app/pages/mvc-screens/ip/account/assettransfer/intraaccount/modelPreferencesHelper',
                    'app/pages/mvc-screens/ip/account/assettransfer/util/tradableassetsService']
}, function (config, Super, rootController, Permission, $, _, router, investmentoptionsService, accountService, format, ordercapturePreferences, modelPreferencesHelper, tradableassetsService) {
    'use strict';

    var inspecieuploadController = Super.extend({
        config: config,
        autoHideSpinner: false,
        hasPermission: 'account.inspecie.transfer.submit',

        viewEvents: {
            'click .view-errors': 'openErrorModal'
        },

        preRender: function () {
            this.model.on({
                'change:sourceFilter': this.onSourceFilterChange,
                'change:listedSecurityAssetSource change:managedFundAssetSource change:otherAssetSource': this.onAssetSourceChange,
                'change:transferInto': this.onTransferIntoChange,
                'change:showClientHoldingsOnly': this.updateManagedPortfolios,
                'change:showTailoredClientHoldingsOnly': this.updateTailoredPortfolios,
                'change:managedportfolios': this.onManagedPortfolioChange,
                'change:tailoredportfolios': this.onTailoredPortfolioChange,
                'change:cbo': this.onCBOChange,
                'change:incomepreference': this.showCashTooltip,
            }, this);

            var assettransferHelpUrl = this.getAssetTransferSupportUrl();
            this.model.set('assettransferHelpUrl', assettransferHelpUrl);

            this.model.set('accountId', rootController.getUrlParams().a);
        },

        postRender: function () {
            var assettransferHelpUrl = this.getAssetTransferSupportUrl();
            this.model.set({
                'assettransferHelpUrl': assettransferHelpUrl,
                'managedportfolios': null,
                'tailoredportfolios': null,
                'showTransferInto': true
            });

            this.onSourceFilterChange();
            this.onAssetSourceChange();
            this.onTransferIntoChange();

            $.when(investmentoptionsService.getInvestmentOptions(this), tradableassetsService.getTradableAssets(this, tradableassetsService.assetTypeFilter.portfolios),
                this.fetchPortfolios(), this.fetchAccountData(), this.populateChessSponsors())
                .done(_.bind(function (investmentOptions, tradablePortfolios) {
                    this.model.set('investmentOptions', investmentOptions);

                    var availablePortfolios = _.map(tradablePortfolios, function (tradablePortfolio) {
                        return tradablePortfolio.asset;
                    });
                    this.model.set('availableAssets', availablePortfolios);
                    this.populate();

                    this.populateIncomePreferenceOption();
                    this.updateTransferAssetsTo();
                    this.model.on('change', function () {
                        rootController.confirmNavigation(true);
                    }, this);
                }, this));

            this.children.lssponsorselector.model.validation.lssponsorselector = $.extend(true, {}, this.model.validation.sponsorselector);
            this.children.othersponsorselector.model.validation.othersponsorselector = $.extend(true, {}, this.model.validation.sponsorselector);
            var emulating = Permission.ruleMatched('emulating', '');
            if (emulating) {
                this.viewChildren.uploadbutton.disable();
            }
        },

        fetchAccountData: function () {
            return accountService.getAccount(this)
                .done(_.bind(function (account) {
                    this.model.set('accountName', account.accountName);
                    this.model.set('accountNumber', account.accountNumber);
                }, this));
        },

        updateTransferAssetsTo: function () {
            var tailoredPortfolios = this.model.get('tailoredPortfolios');
            if (_.isEmpty(tailoredPortfolios)) {
                this.viewChildren.transferinto.setOptions(this.view.transferIntoOptions);
            }
        },

        populateChessSponsors: function () {
            var params = {
                url: '../api/v1_0/chess/chessSponsor',
                success: _.bind(function (data) {
                    var chessSponsors = data.data.chessSponsorDataDtoList;
                    chessSponsors = this.sortSponsors(chessSponsors);
                    this.children.sponsorselector.renderMenuData(chessSponsors);
                    this.children.lssponsorselector.renderMenuData(chessSponsors);
                    this.children.othersponsorselector.renderMenuData(chessSponsors);
                    this.model.set('chessSponsors', chessSponsors);
                }, this)
            };
            return this.ajaxGet(params);
        },

        showCashTooltip: function () {
            var incomePreference = this.model.get('incomepreference');
            if (incomePreference !== 'transfer') {
                return;
            }

            var transferInto = this.model.get('transferInto');
            if (transferInto === 'tailoredPortfolio') {
                this.viewChildren.transfertpcashtooltip.showTooltip();
            } else {
                this.viewChildren.transfercashtooltip.showTooltip();
            }
        },

        onSourceFilterChange: function () {
            var sourceFilter = this.model.get('sourceFilter');

            this.viewChildren.lsassetsource.hide();
            this.viewChildren.lsassetsource.disable();
            this.viewChildren.mfassetsource.hide();
            this.viewChildren.mfassetsource.disable();
            this.viewChildren.otherassetsource.hide();
            this.viewChildren.otherassetsource.disable();
            this.resetAssetSource();

            if (sourceFilter === 'listedSecurities') {
                this.viewChildren.lsassetsource.show();
                this.viewChildren.lsassetsource.enable();
            } else if (sourceFilter === 'managedFunds') {
                this.viewChildren.mfassetsource.show();
                this.viewChildren.mfassetsource.enable();
            } else if (sourceFilter === 'listedSecuritiesAndManagedFunds') {
                this.viewChildren.otherassetsource.show();
                this.viewChildren.otherassetsource.enable();
            }

            this.view.showAssetSource(sourceFilter);
        },

        resetAssetSource: function () {
            this.model.unset('listedSecurityAssetSource');
            this.model.unset('managedFundAssetSource');
            this.model.unset('otherAssetSource');
            this.view.resetAssetSourceView();
        },

        onAssetSourceChange: function () {
            var assetSource = this.model.getAssetSource();
            var sourceFilter = this.model.get('sourceFilter');

            if (assetSource === 'listedSecurityChessSponsored') {
                this.viewChildren.sponsorselector.show();
                this.viewChildren.sponsorselector.enable();
                this.children.sponsorselector.view.clearListOptions();
            } else {
                this.viewChildren.sponsorselector.hide();
                this.viewChildren.sponsorselector.disable();
            }

            if (assetSource === 'assetsFromOtherPlatform' && sourceFilter === 'listedSecurities') {
                this.viewChildren.lssponsorselector.show();
                this.viewChildren.lssponsorselector.enable();
                this.children.lssponsorselector.view.clearListOptions();
            } else {
                this.viewChildren.lssponsorselector.hide();
                this.viewChildren.lssponsorselector.disable();
            }

            if (assetSource === 'assetsFromOtherPlatform' && sourceFilter === 'listedSecuritiesAndManagedFunds') {
                this.viewChildren.othersponsorselector.show();
                this.viewChildren.othersponsorselector.enable();
                this.children.othersponsorselector.view.clearListOptions();
            } else {
                this.viewChildren.othersponsorselector.hide();
                this.viewChildren.othersponsorselector.disable();
            }

            if (assetSource === 'assetsFromBTOrAsgard') {
                this.viewChildren.assettransfermessage.show();
                this.model.set('showTransferInto', false);
                this.model.set('showUpload', false);
                this.view.hidePrimaryBoxArrow();
            } else {
                this.viewChildren.assettransfermessage.hide();
                this.model.set('showTransferInto', true);
                this.model.set('showUpload', true);
                this.view.showPrimaryBoxArrow();
            }

            this.showHideUploadButton();
        },

        onTransferIntoChange: function () {
            var transferInto = this.model.get('transferInto');
            if (transferInto === 'managedPortfolio') {
                this.model.set('showManagedPortfolioSelector', true);
                this.children.managedportfolios.enable();
            } else {
                this.model.set('showManagedPortfolioSelector', false);
                this.model.set('managedPortfolio', null);
                this.children.managedportfolios.disable();
                this.children.managedportfolios.view.clearListOptions();
            }

            if (transferInto === 'tailoredPortfolio') {
                this.model.set('showTailoredPortfolioSelector', true);
                this.children.tailoredportfolios.enable();
            } else {
                this.model.set('showTailoredPortfolioSelector', false);
                this.model.set('tailoredPortfolio', null);
                this.children.tailoredportfolios.disable();
                this.children.tailoredportfolios.view.clearListOptions();
            }

            this.showHideUploadButton();
        },

        sortSponsors: function (sponsors) {
            return _.sortBy(sponsors, function (sponsor) {
                return sponsor.sponsorname.toLowerCase();
            });
        },


        onManagedPortfolioChange: function () {
            var managedPortfolio = this.model.get('managedportfolios');
            this.model.set('excludedAssets', []);
            var hasPermission = Permission.ruleMatched('modelportfolio.preference.edit', rootController.getUrlParams().a);
            var hasIncomePermission = Permission.ruleMatched('modelportfolio.incomepreference.view', rootController.getUrlParams().a);

            if (_.isObject(managedPortfolio) && managedPortfolio.status === "Suspended") {
                this.viewChildren.suspendedassetmessage.show();
                this.viewChildren.uploadbutton.disable();

                this.viewChildren.existingmpmessage.hide();
                this.viewChildren.newmpmessage.hide();

                this.model.set('showPreferences', false);
                this.model.set('showIncomePreference', false);
                return;
            }

            this.viewChildren.suspendedassetmessage.hide();

            var emulating = Permission.ruleMatched('emulating', '');
            if (emulating) {
                this.viewChildren.uploadbutton.disable();
            } else {
                this.viewChildren.uploadbutton.enable();
            }

            if (!_.isEmpty(managedPortfolio) && hasIncomePermission) {
                this.model.set('showIncomePreference', true);
                this.setIncomePreference(managedPortfolio);
            } else {
                this.model.set('showIncomePreference', false);
            }

            if (!_.isEmpty(managedPortfolio) && hasPermission) {
                this.model.set('showPreferences', true);
                this.getPreferences(managedPortfolio);
            } else {
                this.model.set('showPreferences', false);
            }

            if (_.isObject(managedPortfolio)) {
                if (managedPortfolio.balance > 0) {
                    this.viewChildren.existingmpmessage.show();
                    this.viewChildren.newmpmessage.hide();
                } else {
                    this.viewChildren.existingmpmessage.hide();
                    this.showExistingPortfolioMessage('newmpmessage', managedPortfolio);
                }
            } else {
                this.viewChildren.existingmpmessage.hide();
                this.viewChildren.newmpmessage.hide();
            }
        },

        setIncomePreference: function (portfolio) {
            var incomePreference = 'reinvest';
            if (portfolio.balance > 0) {
                incomePreference = portfolio.incomePreference;
                if (_.isString(incomePreference)) {
                    incomePreference = incomePreference.toLowerCase();
                }
            }
            this.model.set('incomepreference', incomePreference);
            this.showCashTooltip();
        },

        populateIncomePreferenceOption: function () {
            var cashInvestment = this.model.get('heldCash');
            var cashName = "";
            if (_.size(cashInvestment) > 0) {
                cashName = cashInvestment[0].name;
            }
            var options = [{
                label: 'Transfer to ' + cashName,
                value: 'transfer'
            }, {
                label: 'Reinvest into model',
                value: 'reinvest'
            }];
            this.model.set('cashName', cashName);
            this.viewChildren.incomepreference.setOptions(options);
            this.viewChildren.tailoredincomepreference.setOptions(options);
        },

        showExistingPortfolioMessage: function (childName, portfolio) {
            var investmentOptions = this.model.get('investmentOptions');
            var minInitalAmount = investmentoptionsService.getMinInitialAmount(investmentOptions, portfolio.assetCode);
            minInitalAmount = format.formatMoney(minInitalAmount, 0, '$');
            var message = rootController.getCmsEntry('Err.IP-0650', [minInitalAmount]);

            this.viewChildren[childName].viewData['html'] = message;
            this.viewChildren[childName].render();
            this.viewChildren[childName].show();
        },

        onTailoredPortfolioChange: function () {
            var tailoredPortfolio = this.model.get('tailoredportfolios');
            this.model.set('excludedAssets', []);
            var hasPermission = Permission.ruleMatched('modelportfolio.tailored.preference.edit', rootController.getUrlParams().a);
            var hasIncomePermission = Permission.ruleMatched('modelportfolio.tailored.incomepreference.view', rootController.getUrlParams().a);

            if (_.isObject(tailoredPortfolio) && tailoredPortfolio.status === "Suspended") {
                this.viewChildren.suspendedassetmessage.show();
                this.viewChildren.uploadbutton.disable();

                this.viewChildren.existingmpmessage.hide();
                this.viewChildren.newmpmessage.hide();

                this.model.set('showPreferences', false);
                this.model.set('showIncomePreference', false);
                return;
            }

            this.viewChildren.suspendedassetmessage.hide();

            var emulating = Permission.ruleMatched('emulating', '');
            if (emulating) {
                this.viewChildren.uploadbutton.disable();
            } else {
                this.viewChildren.uploadbutton.enable();
            }

            if (!_.isEmpty(tailoredPortfolio) && hasIncomePermission) {
                this.model.set('showIncomePreference', true);
                this.setIncomePreference(tailoredPortfolio);
            } else {
                this.model.set('showIncomePreference', false);
            }


            if (!_.isEmpty(tailoredPortfolio) && hasPermission) {
                this.model.set('showPreferences', true);
                this.getPreferences(tailoredPortfolio);
            } else {
                this.model.set('showPreferences', false);
            }

            if (_.isObject(tailoredPortfolio)) {
                if (tailoredPortfolio.balance > 0) {
                    this.viewChildren.existingtpmessage.show();
                    this.viewChildren.newtpmessage.hide();
                } else {
                    this.showExistingPortfolioMessage('newtpmessage', tailoredPortfolio);
                    this.viewChildren.existingtpmessage.hide();
                }
            } else {
                this.viewChildren.existingtpmessage.hide();
                this.viewChildren.newtpmessage.hide();
            }
        },

        setTailoredPortfolioPreferences: function (target) {
            var tailoredPortfolio = this.model.get('tailoredportfolios');
            var excludedAssets = this.model.get('excludedAssets');
            if (tailoredPortfolio.balance > 0 && _.isEmpty(excludedAssets)) {
                excludedAssets = undefined;
            }
            this.children.modelpreferences.openModal({
                asset: tailoredPortfolio,
                excludedAssets: excludedAssets,
                applyCallback: _.bind(function (excludedAssets) {
                    this.model.set('excludedAssets', excludedAssets);
                }, this)
            }, {
                $restoreFocusToEl: target
            });
        },

        onCBOChange: function () {
            var cbo = this.model.get('cbo');
            if (cbo === 'yes') {
                this.model.set({
                    showCGTTemplateLink: false,
                    showTemplateLink: true,
                    showUploadErrorMessage: false
                });
            } else if (cbo === 'no') {
                this.model.set({
                    showCGTTemplateLink: true,
                    showTemplateLink: false,
                    showUploadErrorMessage: false
                });
            } else {
                this.model.set({
                    showCGTTemplateLink: false,
                    showTemplateLink: false,
                    showUploadErrorMessage: false
                });
            }

            this.showHideUploadButton();
        },

        showHideUploadButton: function () {
            var cbo = this.model.get('cbo');
            var isCBO = cbo === 'yes';
            var assetSource = this.model.getAssetSource();
            var isManualSource = assetSource !== 'assetsFromBTOrAsgard';
            if (isCBO && isManualSource) {
                this.viewChildren.manualbutton.show();
            } else {
                this.viewChildren.manualbutton.hide();
            }
        },

        uploadAssetDetails: function () {
            var $form = this.view.getForm();
            if (this.validateForm($form, 'submit')) {
                this.model.unset('file', {
                    silent: true
                });
                this.children.uploadfile.uploadAssetDetails();
            }
        },

        getTransferInto: function () {
            return {
                'transferInto': this.model.get('transferInto'),
                'managedportfolios': this.model.get('managedportfolios'),
                'tailoredportfolios': this.model.get('tailoredportfolios')
            };
        },

        getTransferData: function () {
            var transferData = {
                isCBO: this.model.get('cbo') === 'yes',
                sourceAccountKey: {
                    accountId: this.model.get('accountId')
                },
                targetAccountKey: {
                    accountId: this.model.get('accountId')
                }
            };

            var excludedAssets = this.model.get('excludedAssets');
            transferData['transferPreferences'] = _.map(excludedAssets, function (asset) {
                return {
                    issuerKey: asset.issuerId,
                    preference: asset.preference,
                    action: asset.action
                };
            });

            transferData.incomePreference = this.model.get('incomepreference');

            transferData = _.extend(transferData, this.getTargetIdData());

            var assetSource = this.model.getAssetSource();
            if (assetSource === 'listedSecurityChessSponsored') {
                transferData['transferType'] = 'Listed Securities Broker Sponsored';
            } else if (assetSource === 'listedSecuritiesIssuerSponsored') {
                transferData['transferType'] = 'Listed Securities Issuer Sponsored';
            } else if (assetSource === 'managedFunds') {
                transferData['transferType'] = 'Managed Funds';
            } else if (assetSource === 'assetsFromBTOrAsgard') {
                transferData['transferType'] = 'Listed Securities Other Platform or Custodian';
            } else if (assetSource === 'assetsFromOtherPlatform') {
                transferData['transferType'] = 'Assets from other platform or Custodian';
            }

            return transferData;
        },

        getSponsorSelector: function () {
            return this.model.getSponsorSelector();
        },

        getTargetIdData: function () {
            var transferData = {};
            var transferInto = this.model.get('transferInto');
            if (transferInto === 'directHolding') {
                transferData['targetContainerId'] = this.getContainerId();

            } else if (transferInto === 'managedPortfolio') {
                var managedPortfolio = this.model.get('managedportfolios');
                if (managedPortfolio.balance > 0) {
                    transferData['targetContainerId'] = managedPortfolio.subAccountId;
                } else {
                    transferData['targetAssetId'] = managedPortfolio.assetId;
                }
            } else if (transferInto === 'tailoredPortfolio') {
                var tailoredPortfolio = this.model.get('tailoredportfolios');
                if (tailoredPortfolio.balance > 0) {
                    transferData['targetContainerId'] = tailoredPortfolio.subAccountId;
                } else {
                    transferData['targetAssetId'] = tailoredPortfolio.assetId;
                }
            }
            return transferData;
        },

        showUploadStatus: function () {
            this.children.uploadstatus.openModal();
        },

        hideUploadStatus: function () {
            this.children.uploadstatus.closeModal();
        },

        setUploadSuccess: function (successData) {
            this.children.uploadstatus.setSuccess(successData);
        },

        setUploadFailure: function (errors) {
            this.model.unset('errors');
            this.model.set({
                'showUploadErrorMessage': true,
                'errorlength': errors.length,
                'errors': errors
            });
            this.children.uploadstatus.setErrors(errors);
        },

        setUploadInProgress: function () {
            this.children.uploadstatus.setInProgress();
        },

        getAssetSource: function () {
            return this.model.getAssetSource();
        },

        submit: function () {
            this.children.uploadfile.submit();
        },

        setFileUploading: function (flag) {
            this.children.uploadfile.setFileUploading(flag);
        },

        submitCallback: function (data) {
            this.parentController.model.set({
                transferId: data.data.key.transferId,
                transferType: data.data.transferType,
                cbo: this.model.get('cbo')
            });
            router.appRouter.navigate('#ng/account/assettransfer/inspecie/providedocuments' + rootController.getUrlParamString(), {
                trigger: true,
                replace: true
            });
        },

        openErrorModal: function (ev) {
            ev.preventDefault();
            var errors = this.model.get('errors');
            this.children.uploadstatus.openModal({
                'showError': true,
                'errors': errors
            });
            this.children.uploadstatus.setErrors(errors);
        },

        openSuccessModal: function () {
            this.children.uploadstatus.openModal();
            this.children.uploadstatus.setSuccess(this.parentController.model.get('successData'));
        },

        _filterPortfolios: function (portfolios) {
            portfolios = _.filter(portfolios, function (portfolio) {
                var isNull = _.isNull(portfolio.status);
                var isOpen = portfolio.status === "Open";
                var isSuspended = portfolio.status === "Suspended";
                var isEmpty = _.isEmpty(portfolio.status);
                return isNull || isOpen || isEmpty || isSuspended;
            });
            return portfolios;
        },

        openTermsAndConditions: function () {
            this.children.terms.openModal({});
        },

        manualEntry: function () {
            var $form = this.view.getForm();
            if (this.validateForm($form, 'submit')) {
                var targetData = this.getTargetIdData();
                var assetSource = this.model.getAssetSourceForManualEntry();
                var sponsorSelector = this.model.getSponsorSelector();

                this.parentController.model.set('transferFormData', {
                    assetSource: assetSource,
                    cbo: this.model.get('cbo'),
                    accountName: this.model.get('accountName'),
                    accountNumber: this.model.get('accountNumber'),
                    managedPortfolio: this.model.get('managedportfolios'),
                    tailoredPortfolio: this.model.get('tailoredportfolios'),
                    sponsorSelector: sponsorSelector,
                    containerId: targetData.targetContainerId,
                    incomepreference: this.model.get('incomepreference'),
                    destAssetId: targetData.targetAssetId,
                    excludedAssets: this.model.get('excludedAssets'),
                    sourceFilter: this.model.get('sourceFilter')
                });

                rootController.confirmNavigation(false);
                router.appRouter.navigate('#ng/account/assettransfer/inspecie/transfer' + rootController.getUrlParamString(), {
                    trigger: true,
                    replace: true
                });
            }
        }
    });
    _.extend(inspecieuploadController.prototype, ordercapturePreferences, modelPreferencesHelper);
    return inspecieuploadController;

});
