defineMvcController({
    name: 'submitsavedwithdrawal',
    parentPath: 'mvc-screens/ip/account/accessingsuper/withdrawingsuper',
    viewHtml: true,
    viewJs: true,
    mvcComponents: [],
    viewComponents: ['termsandconditions', 'button', 'transferstatus', 'messagealert', 'messagedisclaimer'],
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['rootController', 'app/framework/router', 'underscore', 'app/pages/mvc-screens/ip/account/accessingsuper/accessingsuperServices', 'app/pages/mvc-screens/ip/services/accountService'],
    extend: 'app/pages/mvc-templates/modal/modalController'
}, function (config, ModalController, rootController, router, _, accessingsuperServices, accountService) {
    'use strict';

    return ModalController.extend({
        config: config,
        withdrawingSuperUriTemplate: '#ng/account/accessingsuper/withdrawingsuper?a=<%=a%>',

        preRender: function () {
            var data = this.model.get('withdrawal');
            this.model.set(data);
            this.model.set('showGenericError', false);
        },

        submitWithdrawal: function () {
            this.model.set('showGenericError', false);
            if (!_.isUndefined(this.viewChildren.termsandconditions) && _.isEmpty(this.model.get('termsandconditions'))) {
                this.viewChildren.termsandconditions.turnintoTooltip();
                return;
            }
            this.viewChildren.submitwithdrawal.loading(true);
            var withdrawal = this.model.get('withdrawal');
            accessingsuperServices.submitWithdrawal(this, withdrawal)
                .done(_.bind(function (data) {
                    this.viewChildren.submitwithdrawal.loading(false);
                    if (_.isUndefined(data)) {
                        this._showSubmissionErrors(withdrawal, undefined);
                        this.closeModal();
                    } else if (!_.isEmpty(data.errors)) {
                        this._showSubmissionErrors(withdrawal, accessingsuperServices.mapErrors(data.errors));
                        this.closeModal();
                    } else {
                        accountService.getAccount(this, true).always(_.bind(function () {
                            this.parentController.showSuccessfulSavedMessage('oneoffwithdrawalsuccessmessage', true);
                            this.closeModal();
                        }, this));
                    }
                }, this))
                .fail(_.bind(function () {
                    this.model.set('showGenericError', true);
                    this.viewChildren.submitwithdrawal.loading(false);
                }, this));
        },

        _showSubmissionErrors: function (withdrawal, errors) {
            var nonRecoverableError = _.find(errors, function (error) {
                return error.nonRecoverable === true;
            });

            // always navigate to edit payment so that re-navigating to view payments also works
            // (by toggling the path under the same /withdrawingsuper URI)
            accessingsuperServices.navigateToEditScreen(this, withdrawal.paymentAction, errors, withdrawal);

            // always go to View payments screen if there is a non-recoverable error
            if (!_.isUndefined(nonRecoverableError)) {
                this.parentController.parentController.setNonRecoverableErrorType('oneoffWithdrawal');
                this._navigateToWithdrawingSuperDetails();
            }
        },

        _navigateToWithdrawingSuperDetails: function () {
            var uri = this.getUrl(rootController.getUrlParams(), this.withdrawingSuperUriTemplate);
            router.appRouter.navigate(uri, {
                trigger: true,
                // use replace=true as the previous navigation was a 'temporary' edit payment URI
                replace: true
            });
        },

    });
});
