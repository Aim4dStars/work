define([
    'MvcModel',
    'underscore',
    'app/framework/services/dateService',
    'app/framework/services/Permissions'
], function (MvcModel, _, dateService, Permissions) {
    'use strict';

    return MvcModel.extend({
        START_FY: 1999,
        filterMap: {
            'formdocumentType': 'Document type',
            'formfinancialYear': 'Financial year',
            'formaudit': 'Flagged for audit',
            'formstatus': 'Private document',
            'formuploadedRole': 'Uploaded by',
            'formstartUploadedDate': 'Date uploaded',
            'formendUploadedDate': 'Date uploaded'
        },

        uploadedBys: [
            {
                label: 'Any',
                value: 'any'
            },
            {
                label: 'Accountant',
                value: 'Accountant',
            },
            {
                label: 'Adviser',
                value: 'Adviser',
            },
            {
                label: 'Investor',
                value: 'Investor',
            },
            {
                label: 'Panorama',
                value: 'Panorama',
            }
        ],

        uploadedBysChallenger: [
            {
                label: 'Any',
                value: 'any'
            },
            {
                label: 'Challenger',
                value: 'Challenger',
            },
            {
                label: 'Adviser or investor',
                value: 'AdviserOrInvestor',
            }
        ],

        documentTypes: [
            {
                label: 'Advice documentation',
                value: 'ADVICE',
                permission: {
                    rule: '!documents.accountant.view'
                }
            },
            {
                label: 'Correspondence',
                value: 'CORRO'
            },
            {
                label: 'Investments',
                value: 'INV'
            },
            {
                label: 'Notification',
                value: 'NOTIFICATION',
                hideOnUpload: true,
                hideMenuActionItems: true
            },
            {
                label: 'SMSF',
                value: 'SMSF',
                permission: {
                    rule: 'account.smsf.view',
                    tree: 'a'
                }
            },
            {
                label: 'Statements',
                value: 'STM',
                hideOnUpload: true,
                hideMenuActionItems: true
            },
            {
                label: 'Tax returns',
                value: 'TAX',
                permission: {
                    rule: '!account.type.super',
                    tree: 'a'
                }
            },
            {
                label: 'Tax',
                value: 'TAXSUPER',
                permission: {
                    rule: 'account.type.super',
                    tree: 'a'
                }
            },
            {
                label: 'Other',
                value: 'OTHER'
            },
            {
                label: 'Approval',
                value: 'APPROVAL',
                hideOnFilter: true,
                hideOnUpload: true,
                hideMenuActionItems: true
            }
        ],

        documentTypesChallenger: [
            {
                label: 'Any',
                value: 'any'
            },
            {
                label: 'Application form',
                value: 'CAPPFM'
            },
            {
                label: 'Welcome pack',
                value: 'CWELPK'
            },
            {
                label: 'Annuity adjustment confirmation',
                value: 'CANADJ'
            },
            {
                label: 'Withdrawal confirmation',
                value: 'CREDEM'
            },
            {
                label: 'Maturity closure confirmation',
                value: 'CMATCL'
            },
            {
                label: 'Maturity notice',
                value: 'CMATNT'
            },
            {
                label: 'Policy extension confirmation',
                value: 'CPOLEX'
            },
            {
                label: 'Annual & PAYG statement',
                value: 'CSTMNT'
            },
            {
                label: 'Withdrawal request form',
                value: 'CWITHD'
            },
            {
                label: 'Annual indexation confirmation',
                value: 'CINDEX'
            },
            {
                label: 'Centrelink schedule',
                value: 'CCENTR'
            },
            {
                label: 'Change of account details confirmation',
                value: 'CCHGDL'
            },
            {
                label: 'Important information',
                value: 'CCORRO'
            },
            {
                label: 'Continuity certificate letter',
                value: 'CCONTC'
            },
            {
                label: 'Deceased estate requirements',
                value: 'CDECSD'
            },
            {
                label: 'Policy reversion confirmation',
                value: 'CREVER'
            },
            {
                label: 'Rollover fund letter',
                value: 'CROLLO'
            }
        ],

        documentTypesAdviserOrInvestor: [
            {
                label: 'Any',
                value: 'any'
            },
            {
                label: 'Moving a maturing annuity to Panorama',
                value: 'COFFON'
            },
            {
                label: 'Application - paper form',
                value: 'CPAPER'
            },
            {
                label: 'Application - supporting document',
                value: 'CAPPFL'
            },
            {
                label: 'Beneficiary change',
                value: 'CBENEC'
            },
            {
                label: 'TFN declaration',
                value: 'CTFNDE'
            },
            {
                label: 'Cooling off request',
                value: 'CCOOLF'
            },
            {
                label: 'Maturity instruction',
                value: 'CMATIN'
            },
            {
                label: 'Withdrawal request',
                value: 'CWITHR'
            },
            {
                label: 'Supporting document',
                value: 'CSUPPO'
            },
            {
                label: 'Annuity update request',
                value: 'CANNUP'
            }
        ],

        documentSubTypesINV: [
            {
                label: 'Sub-type (optional)',
                value: 'any'
            },
            {
                label: 'Asset transfers',
                value: 'Asset Transfers'
            },
            {
                label: 'Corporate actions',
                value: 'Corporate Actions'
            },
            {
                label: 'Transaction confirmations',
                value: 'Transaction Confirmations'
            }
        ],

        documentSubTypesSMSF: [
            {
                label: 'Sub-type (optional)',
                value: 'any'
            },
            {
                label: 'Company',
                value: 'Company'
            },
            {
                label: 'Fund administration',
                value: 'SMSF Fund Administration'
            },
            {
                label: 'Fund establishment',
                value: 'SMSF Fund Establishment'
            },
            {
                label: 'General',
                value: 'SMSF General'
            }
        ],

        documentSubTypes2SMSFFundAdministration: [
            {
                label: 'Sub-type (optional)',
                value: 'any'
            },
            {
                label: 'Contributions',
                value: 'CONTRIBS'
            },
            {
                label: 'Pensions',
                value: 'PENSIONS'
            },
            {
                label: 'Income',
                value: 'INCOME'
            },
            {
                label: 'Expenses',
                value: 'EXPENSES'
            },
            {
                label: 'Assets',
                value: 'ASSETS'
            },
            {
                label: 'Liabilities',
                value: 'LIABS'
            },
            {
                label: 'Financial statements and tax documents',
                value: 'FNSTMTAX'
            },
            {
                label: 'Master documents',
                value: 'MSTDOCS'
            },
            {
                label: 'General',
                value: 'GENERAL'
            }
        ],

        documentSources: ['panoramaui', 'serviceui'],

        initialize: function () {
            this.setFinancialYear();
        },

        formatData: function (documentList) {
            _.each(documentList, function (document) {
                //financialYear
                if (!document.financialYear) {
                    document.financialYear = '-';
                }

                // For annuity, group the document type by uploadRole.
                this.setDocumentLabel('documentTypesChallenger', document.documentType, 'documentTypeLabel', document);
                this.setDocumentLabel('documentTypesAdviserOrInvestor', document.documentType, 'documentTypeLabel', document);

                //documentType
                var isLabelSet = this.setDocumentLabel('documentTypes', document.documentType, 'documentTypeLabel', document);
                if (isLabelSet && document.documentSubType) {
                    //documentSubType
                    isLabelSet = this.setDocumentLabel('documentSubTypes' + document.documentType, document.documentSubType, 'documentSubTypeLabel', document);
                    if (isLabelSet && document.documentSubType2) {
                        //documentSubType2Label
                        this.setDocumentLabel('documentSubTypes2' + document.documentSubType.replace(/\s/g, ''), document.documentSubType2, 'documentSubType2Label', document);
                    }
                }
                this._setHideMenuActionItems(document);
            }, this);
        },

        setDocumentLabel: function (list, value, attribute, document) {
            var matching = _.findWhere(this[list], {
                value: value
            });
            if (matching) {
                document[attribute] = matching.label;
                document.hideMenuActionItems = matching.hideMenuActionItems;
                return true;
            }
        },

        /**
         * Menu action items like upload new version, edit doc info and delete is disabled for system generated docs
         * @param document
         * @private
         */
        _setHideMenuActionItems: function (document) {
            if (document.documentType.toLowerCase() === 'taxsuper') {
                if (_.isString(document.sourceId)) {
                    document.hideMenuActionItems = this.documentSources.indexOf(document.sourceId.toLowerCase()) === -1;
                } else {
                    document.hideMenuActionItems = true;
                }
            }
        },

        getFlags: function (documentList) {
            var flagObject = {};
            _.each(documentList, function (doucument) {
                var docId = doucument.key.documentId;
                var auditFlag = 'audit_' + docId.toLowerCase();
                var selectFlag = 'select_' + docId.toLowerCase();
                flagObject[auditFlag] = doucument.audit;
                flagObject[selectFlag] = null;
            }, this);
            return flagObject;
        },

        getFilterLegend: function (tableOptionsAttributes) {
            var filterList = [];
            _.each(tableOptionsAttributes.filters, function (val, key) {
                if (val !== 'any' && val && this.filterMap[key] && filterList.indexOf(this.filterMap[key]) === -1) {
                    filterList.push(this.filterMap[key]);
                }
            }, this);
            return filterList.length;
        },

        getFilters: function (tableOptionsAttributes) {
            var filterList = [];
            _.each(tableOptionsAttributes.filters, function (val, key) {
                if (val === 'AdviserOrInvestor' && key === 'formuploadedRole') {
                    filterList.push(this._getObject('uploadedRole', 'Challenger', 'string', '~='));
                    filterList.push(this._getObject('uploadedRole', 'Admin', 'string', '~='));
                } else if (val !== 'any' && val) {
                    filterList.push(this._createFilters(key, val));
                }
            }, this);
            return filterList;
        },

        _createFilters: function (key, value) {
            var property = key.substring('form'.length);
            var filterObject = this._getObject(property, value);
            switch (property.toLowerCase()) {
            case 'startuploadeddate':
                filterObject.prop = 'uploadedDate';
                filterObject.type = 'date';
                filterObject.op = '~<';
                break;
            case 'enduploadeddate':
                filterObject = this._getObject('uploadedDate', new Date(value).addDays(1), 'date', '<');
                break;
            case 'audit':
                filterObject.type = 'boolean';
                filterObject.op = '=';
                break;
            default:
                filterObject.type = 'string';
                filterObject.op = '=';
            }
            return filterObject;
        },

        getDocument: function (documents, documentId) {
            return _.find(documents, function (docObject) {
                return docObject.key.documentId === documentId;
            });
        },

        _getObject: function (prop, val, type, op) {
            return {
                prop: prop,
                val: val,
                type: type,
                op: op
            };
        },

        setFinancialYear: function () {
            var financialYears = [];
            //Displaying financial year starting from 1999, current and plus one financial year
            var currentFinancialYear = dateService.today().startOfFinancialYear().getFullYear();
            var startYear = this.START_FY;
            var endYear = currentFinancialYear + 1;
            while (endYear >= startYear) {
                financialYears.push({
                    label: endYear + '/' + (endYear + 1),
                    value: endYear + '/' + (endYear + 1)
                });
                endYear--;
            }
            this.set('financialYears', financialYears);
        },

        filterDocumentType: function (accountId) {
            this.documentTypes = _.filter(this.documentTypes, function (documentType) {
                var filter = true;
                if (documentType.permission) {
                    filter = Permissions.ruleMatched(documentType.permission.rule, documentType.permission.tree ? accountId : '');
                }
                return filter;
            });
        }
    });
});
