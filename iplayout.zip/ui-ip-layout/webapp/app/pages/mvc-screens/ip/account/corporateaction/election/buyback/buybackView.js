define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/baseelectionform/baseelectionformView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/buyback/_buyback.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (SuperView, _buybackTemplate, componentXml, Handlebars) {
    'use strict';

    return SuperView.extend({
        preRender: function () {
            Handlebars.registerPartial('buyback', componentXml.encode(_buybackTemplate));
        }
    });

});
