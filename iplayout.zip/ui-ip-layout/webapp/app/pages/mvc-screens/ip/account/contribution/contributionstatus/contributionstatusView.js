define([
    'app/pages/mvc-screens/ip/account/movemoney/depositsv2/details/detailsView'
], function (SuperView) {
    'use strict';

    return SuperView.extend({
        rootTemplate: {
            headerPanel: 'Rollovers & contributions'
        }
    });

});
