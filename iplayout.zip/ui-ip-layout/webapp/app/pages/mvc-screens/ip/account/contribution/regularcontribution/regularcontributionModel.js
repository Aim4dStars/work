define([
    'app/pages/mvc-screens/ip/account/movemoney/depositsv2/details/detailsModel',
    'app/framework/helpers/timezone',
    'moment',
    'app/framework/services/dateService',
], function (SuperModel, timezone, moment, dateService) {
    'use strict';

    return SuperModel.extend({
        getMinPaymentDate: function () {
            var now = timezone.convertTimezone(dateService.now(), 'AEDST');
            var minPaymentDate = moment(now.date).add(1, 'days');

            var weekday = minPaymentDate.weekday();
            if (weekday === 0) {
                minPaymentDate.add(1, 'days');
            } else if (weekday === 6) {
                minPaymentDate.add(2, 'days');
            }

            minPaymentDate.startOf('day');
            return minPaymentDate.toDate();
        }
    });

});
