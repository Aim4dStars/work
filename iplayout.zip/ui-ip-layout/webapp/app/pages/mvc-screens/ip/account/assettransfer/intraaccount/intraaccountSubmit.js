define([
    'underscore', 'jquery', 'rootController', 'app/framework/router', 'app/framework/helpers/format',
    'app/pages/mvc-screens/ip/account/assettransfer/util/inspecietransferService',
    'app/pages/mvc-screens/ip/account/assettransfer/util/tradableinvestmentoptionsService',
    'app/framework/services/analyticsService',
], function (_, $, rootController, router, format, inspecietransferService, investmentoptionsService, analyticsService) {
    'use strict';

    return {
        SCREEN_STATE: {
            PREVIEW: 'preview',
            SUBMIT: 'submit'
        },
        warningsArray: [],
        errorResponse: null,

        showDestinationErrorMessage: function () {
            this.model.set('showPreferences', false);
            this.viewChildren.portfolioerrordestination.show();
            this.viewChildren.errorpreviewdestination.show();
            this.destinationPortfolioError = true;
        },

        hideDestinationErrorMessage: function () {
            this.viewChildren.portfolioerrordestination.hide();
            this.viewChildren.errorpreviewdestination.hide();
            this.viewChildren.portfoliowarning.hide();
        },

        showMinAmountWarningMessage: function (portfolio, isTP) {
            var cmsMessge = rootController.getCmsEntry('Err.IP-0543');
            if (isTP) {
                cmsMessge = rootController.getCmsEntry('Err.IP-0597');
            }
            if (_.isUndefined(portfolio.availableBalance) || portfolio.availableBalance <= 0) {
                var investmentOptions = this.model.get('investmentOptions');
                var minInitalAmount = investmentoptionsService.getMinInitialAmount(investmentOptions, portfolio.asset.assetCode);
                minInitalAmount = format.formatMoney(minInitalAmount, 0, '$');
                cmsMessge = rootController.getCmsEntry('Err.IP-0650', [minInitalAmount]);
            }
            this.renderMessage('portfoliowarning', 'message', cmsMessge);
        },

        renderMessage: function (chilName, dataName, data) {
            this.viewChildren[chilName].viewData[dataName] = data;
            this.viewChildren[chilName].render();
            this.viewChildren[chilName].show();
        },

        screenStateChanged: function () {
            var screenState = this.model.get('screenState');
            this.viewChildren.previewemptystate.hide();
            if (screenState === this.SCREEN_STATE.PREVIEW) {
                this.viewChildren.previewsuccess.hide();
                this.viewChildren.submitbtn.hide();
                this.viewChildren.previewbtn.show();
                this.viewChildren.termsandconditions.hide();
            } else {
                analyticsService.send({
                    "pageName": "ng:account:assettransfer:intraaccount:preview",
                    "pageType": "selfservice",
                    "formName": "intraaccount transfer"
                });
                this.viewChildren.previewsuccess.show();
                this.viewChildren.submitbtn.show();
                this.viewChildren.previewbtn.hide();
                this.viewChildren.termsandconditions.show();
            }
        },

        previewTransfer: function () {
            this.viewChildren.previewemptystate.hide();
            this.viewChildren.previewerror.hide();
            this.viewChildren.previewwarning.hide();
            var valid = this.isValid();
            if (!valid) {
                this.children.destinationportfolio.model.validationResult = {};
                this.children.sourceportfolio.model.validationResult = {};
                return;
            }
            var transferData = this.getTransferData();
            if (!(_.isArray(transferData.transferAssets) && transferData.transferAssets.length > 0)) {
                this.showEmptyStateError();
                return;
            }
            this.view.showSpinner();
            this.model.unset('transferData');
            this.model.set('transferData', transferData);
            var requestData = this.model.getDataForServer("validate");
            inspecietransferService.submitTransferRequest(this, requestData)
                .done(_.bind(function (data) {
                    this.processVettingResponse(data.data);
                    this.view.hideSpinner();
                }, this))
                .fail(_.bind(function (data) {
                    this.processVettingResponse(data.data);
                    this.view.hideSpinner();
                }, this));
        },

        processVettingResponse: function (data) {
            var closePortfolio = this.model.get('closeportfolio');
            var screenState = this.SCREEN_STATE.PREVIEW;
            if (data.warnings.length > 0) {
                var isError = _.find(data.warnings, function (error) {
                    return error.errorType === 'error';
                });
                if (!isError) {
                    screenState = this.SCREEN_STATE.SUBMIT;
                }
            } else {
                screenState = this.SCREEN_STATE.SUBMIT;
            }
            this.handleVetting(data);
            this.isClosePortfolioChanging = true;
            this.children.assetlist.showVettingResponse(data);
            if (closePortfolio) {
                this.children.assetlist.toggleAllAssetQuantity(false);
            }
            this.isClosePortfolioChanging = false;
            this.model.set('screenState', screenState);
            this.view.scrollToAssetList();
        },

        handleVetting: function (data) {
            this.errorResponse = data.warnings;
            this.warningsArray = [];
            if (data.warnings.length > 0) {
                var warnings = _.filter(data.warnings, function (error) {
                    return error.errorType === 'warning' && _.isNull(error.domain);
                });
                var errors = _.filter(data.warnings, function (error) {
                    return error.errorType === 'error' && _.isNull(error.domain);
                });

                var hasWarnings = _.find(data.warnings, function (error) {
                    return error.errorType === 'warning';
                });

                var hasErrors = _.find(data.warnings, function (error) {
                    return error.errorType === 'error';
                });

                if (warnings.length > 0 || hasWarnings) {
                    this.warningsArray = warnings;
                    this.renderMessage('previewwarning', 'warnings', warnings);
                }
                if (errors.length > 0 || hasErrors) {
                    this.renderMessage('previewerror', 'errors', errors);
                }
            }
        },

        showEmptyStateError: function () {
            var assetlistData = this.children.assetlist.model.get('assetlistData');
            var showCashTable = this.model.get('showCashTable');
            var message = "There are no assets to transfer below";
            if (_.isArray(assetlistData) && (assetlistData.length !== 0 || showCashTable)) {
                message = "You have not entered any transfer quantities below";
            }
            this.renderMessage('previewemptystate', 'message', message);
            this.view.scrollToAssetList();
        },

        isValid: function () {
            var assetSelectorIsValid = this.assetSelectorIsValid();
            var assetlistIsValid = this.children.assetlist.isValid();
            if (assetSelectorIsValid && !assetlistIsValid) {
                this.view.scrollToAssetList();
            }
            return assetSelectorIsValid && assetlistIsValid;
        },

        assetSelectorIsValid: function () {
            if (this.destinationPortfolioError) {
                this.view.scrollToAssetSelector();
                return;
            }
            var sourceContainer = this.model.get('sourceContainer');
            var destinationContainer = this.model.get('destinationContainer');
            if (sourceContainer === 'directContainer') {
                this.model.validation['sourceportfolio'].submit.required = false;
            } else {
                this.model.validation['sourceportfolio'].submit.required = true;
            }
            if (destinationContainer === 'directContainer') {
                this.model.validation['destinationportfolio'].submit.required = false;
            } else {
                this.model.validation['destinationportfolio'].submit.required = true;
            }
            var $form = this.view.getForm();
            var valid = this.validateAndSubmitForm(null, $form);
            return valid;
        },

        submitTransfer: function () {
            if (!this.model.get('termsandconditions')) {
                this.viewChildren.termsandconditions.turnintoTooltip();
                return;
            }
            rootController.confirmNavigation(false);
            this.view.showSpinner();
            var data = this.model.getDataForServer("submit", this.errorResponse);
            inspecietransferService.submitTransferRequest(this, data)
                .done(_.bind(function (data) {
                    this.view.hideSpinner();
                    data = this.getReceiptData(data);
                    rootController.model.unset('transferreceiptData');
                    rootController.model.set('transferreceiptData', data);
                    router.appRouter.navigate('#ng/account/assettransfer/transferreceipt' + rootController.getUrlParamString(), {
                        trigger: true,
                        replace: true
                    });
                }, this))
                .fail(_.bind(function (data) {
                    this.model.unset('termsandconditions');
                    this.processVettingResponse(data.data);
                    this.view.hideSpinner();
                }, this));
        },

        getTransferData: function () {
            var assetlistData = this.children.assetlist.getAssetData();
            var assetselectorData = this.model.getAssetSelectorData();
            return _.extend(assetlistData, assetselectorData);
        },

        getReceiptData: function (data) {
            var transferData = this.model.get('transferData');
            transferData.key = {
                transferId: data.data.key.transferId
            };
            transferData.showIncomePreference = this.model.get('showIncomePreference');
            transferData.incomePreferenceLabel = this.getIncomePreferenceValue();
            transferData.cashAssetName = this.model.get('cashName');
            transferData.showPreferences = this.model.get('showPreferences');
            transferData.preferenceLabel = this.getPreferenceValue();
            var assetlistData = this.children.assetlist.getAssetData();
            transferData.transferAssets = assetlistData.transferAssets;
            transferData.warnings = this.warningsArray;
            return transferData;
        },

        getIncomePreferenceValue: function () {
            var incomePreference = this.model.get('incomepreference');
            var cashName = this.model.get('cashName');
            if (incomePreference === 'transfer') {
                return 'Transfer to ' + cashName;
            } else if (incomePreference === 'reinvest') {
                return 'Reinvest into model';
            } else {
                return incomePreference;
            }
        },

        confirmClearData: function () {
            this.children.cancel.openModal();
        },

        goBack: function () {
            var sourceContainer = this.model.get('defaultContainer');
            this.model.set('sourceContainer', sourceContainer);
            this.sourceContainerChanged();
            if (sourceContainer === 'portfolioContainer') {
                this.model.set('destinationContainer', 'portfolioContainer');
            }
        }
    };
});
