defineMvcController({
    name: 'details',
    parentPath: 'mvc-screens/ip/account/fees/chargeoneoff',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['forminputtext', 'button', 'messagealert', 'tooltip', 'snapshot'],
    dependencies: ['underscore', 'rootController', 'app/framework/helpers/format'],
    screens: ['cancel'],
    hashName: 'details',
    hashDefault: true,
    extend: 'MvcController'
}, function (config, MvcController, _, rootController, format) {
    'use strict';

    return MvcController.extend({
        config: config,
        urlTemplate: '../api/v1_0/fees/accounts/<%=a%>/advicefees/validation',
        urlAdviseFees: '../api/v1_0/fees/accounts/<%=a%>/advicefees',

        viewEvents: {
            'submit form': 'validateDataAndSubmitForm'
        },

        _fetchAvlCash: function () {
            var params = {
                url: this.getUrl(rootController.getUrlParams(), this.urlAdviseFees),
                data: {},
                success: _.bind(function (data) {
                    this.model.set("data.availableCash", format.formatMoney(data.data.availableCash, 2, '$'));
                    this.model.set("data.yearlyFees", format.formatMoney(data.data.yearlyFees, 2, '$'));
                }, this),
                error: _.bind(function () {
                    this.view.showSnapShotErrorMessage();
                    log('Error in fetching available cash and yearly fees');
                }, this),
            };

            this.ajaxGet(params);
        },

        preRender: function () {
            rootController.confirmNavigation(true);
        },

        postRender: function () {
            this._fetchAvlCash();
            this.view.hideError();
            this.model.set('accountId', rootController.getUrlParams().a);
            this.parentController.model.bindAttributeToOtherModel({
                'feesAmount': 'feesAmount',
                'description': 'description',
                'accountId': 'accountId'
            }, this.model);
            this.parentController.formFail(this.name);

        },

        validateDataAndSubmitForm: function (event) {
            var validationResult = this.validateAndSubmitForm(event);
            if (validationResult && !this.viewChildren.next.isLoading()) {
                this.view.loadSpinner();
                this.ajaxPost({
                    url: this.getUrl(rootController.getUrlParams(), this.urlTemplate),
                    data: {
                        'feesAmount': this.model.get('feesAmount'),
                        'description': this.model.get('description') ? this.model.get('description') : ''
                    },
                    success: _.bind(function (data) {
                        if (this.parentController && this.parentController.parentController) {
                            this.parentController.parentController._hideErrorMessage();
                        }
                        if (data.data && !this.parentController.isError(data.data.warnings)) {
                            this.model.set('feesAmount', data.data.feesAmount);
                            this.model.set('description', data.data.description);
                            rootController.confirmNavigation(false);
                            this.parentController.formSuccess(this.name);
                        } else if (data.data && data.data.warnings) {
                            this.parentController.checkError(data);
                        }
                        this.view.unloadSpinner();
                    }, this),
                    error: _.bind(function (jqXHR, textStatus, errorThrown) {
                        if (this.parentController && this.parentController.parentController) {
                            this.parentController.parentController._setErrorMessage(errorThrown);
                            this.parentController.parentController._showErrorMessage();
                            this.parentController.view.hideError();
                        }
                        this.view.unloadSpinner();
                    }, this),
                });
            }
        },

        isError: function (errorList) {
            var result = false;
            if (errorList) {
                for (var el in errorList) {
                    if (errorList[el].errorType === 'error') {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        },

        openModal: function () {
            if (this.children && this.children.cancel) {
                rootController.confirmNavigation(false);
                this.children.cancel.openModal();
            }
        }
    });
});
