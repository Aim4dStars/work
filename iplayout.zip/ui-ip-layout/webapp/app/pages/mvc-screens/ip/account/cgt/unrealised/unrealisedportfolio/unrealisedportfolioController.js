defineMvcController({
    name: 'unrealisedportfolio',
    parentPath: 'mvc-screens/ip/account/cgt/unrealised',
    viewHtml: true,
    modelJs: false,
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['inputdate', 'tooltip'],
    hashName: 'unrealisedportfolio',
    hashDefault: true,
    extend: 'app/pages/mvc-screens/ip/account/cgt/cgtBaseViewByController',
    dependencies: []
}, function (config, CgtViewByBaseController) {
    'use strict';

    return CgtViewByBaseController.extend({
        config: config,
        urlTemplate: '../api/v1_0/accounts/<%=a%>/unrealised-cgt',
        taxColumns: [6, 8, 9],
        detailSort: 'ascendingSecurityName',
        repeatingAssetProperty: 'securityCode',
        totalColspan: 5,
        title: 'unrealised'
    });
});
