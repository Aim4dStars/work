define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/corporateactionView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/_corporateaction.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (CorporateActionView, _corporateactionTemplate, componentXml, Handlebars) {
    'use strict';

    return CorporateActionView.extend({
        preRender: function () {
            Handlebars.registerPartial('corporateaction-child', componentXml.encode(_corporateactionTemplate));
        }
    });
});
