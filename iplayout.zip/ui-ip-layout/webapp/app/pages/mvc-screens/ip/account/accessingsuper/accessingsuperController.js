defineMvcController({
    name: 'accessingsuper',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    screens: ['withdrawingsuper', 'editoneoffwithdrawal'],
    hashName: 'accessingsuper',
    extend: 'MvcController',
    dependencies: []
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],

        setSaveAction: function (saveTypeAction) {
            this.model.set('saveTypeAction', saveTypeAction);
        },

        unsetSaveAction: function () {
            this.model.unset('saveTypeAction');
        },

        setNonRecoverableErrorType: function (screenType) {
            this.model.set('nonRecoverableErrorType', screenType);
        },

        unsetNonRecoverableErrorType: function () {
            this.model.unset('nonRecoverableErrorType');
        },

        getNonRecoverableErrorType: function () {
            return this.model.get('nonRecoverableErrorType');
        }

    });
});
