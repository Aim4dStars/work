defineMvcController({
    name: 'financialyear',
    parentPath: 'mvc-screens/ip/account/contribution/personaltax/viewdeduction',
    viewHtml: true,
    viewComponents: ['inputselect'],
    extend: 'MvcController',
    dependencies: ['jquery', 'underscore', 'rootController']
}, function (config, MvcController, $, _, rootController) {
    'use strict';

    /*****
     * This screen provides a financial year drop down.
     *
     * Dependency: parentController.parentController.model is updated on change of the financialYear
     *                  financialYear         = "2015-07-01"
     *                  financialYearPeriod   = "FY 2015/2016"
     *                  isLatestFinancialYear = (boolean) true if selected financialyear is the most recent
     */
    return MvcController.extend({
        config: config,
        financialYearUrl: '../api/v1_0/accounts/<%=a%>/availablefinancialyears',

        postRender: function () {
            this._fetchFinancialYearData();
        },

        _fetchFinancialYearData: function () {
            var url = this.getUrl(rootController.getUrlParams(), this.financialYearUrl);
            $.when(this.fetchData(url, 'data.resultList'))
                .then(_.bind(function (financialYearData) {
                    var options = _.map(financialYearData, function (fy) {
                        return {
                            label: 'FY ' + fy.displayText,
                            value: fy.startDate
                        };
                    });

                    this.model.set('options', options);
                    this.model.set('financialYear', _.isObject(options) && options.length && options[0].value);
                    this.setOptions(options);

                    this.parentController.parentController.search();
                }, this));
        },

        setOptions: function (options) {
            this.viewChildren.financialyear.setOptions(options);
        },

        onDestroy: function () {
            this.model.off('change:financialYear');
        },



        /// Utility functions. Probably belong on a mixin.
        fetchData: function (url, path) {
            var deferred = $.Deferred();
            var params = {
                url: this.getUrl(rootController.getUrlParams(), url),
                success: _.bind(function (data) {
                    data = this.getDataFromObject(data, path || '');
                    deferred.resolve(data);
                }, this),
                error: _.bind(function (data) {
                    deferred.reject(data);
                }, this)
            };
            this.ajaxGet(params);
            return deferred;
        },

        getDataFromObject: function (data, path) {
            if (data && _.isObject(data) && path) {
                var parts = path.split('.');
                while (data && parts.length) {
                    var part = parts.shift();
                    data = data[part];
                }
            }
            return data;
        },
    });
});
