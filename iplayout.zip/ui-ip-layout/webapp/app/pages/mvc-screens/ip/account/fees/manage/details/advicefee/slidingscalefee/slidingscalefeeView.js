define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({

        events: {
            'click button': 'deleteRow',
            'blur input[name*=upperBound]': 'addRow',
            'change input[type=checkbox]': 'validateCheckbox',
            'blur [data-component-name*=percent]  input': 'hidePercentageError'
        },

        showPercentageError: function () {
            this.$el.find('.error-percentage').show();
        },

        hidePercentageError: function () {
            this.$el.find('.error-percentage').hide();
        },

        showCheckboxError: function () {
            this.$el.find('.error-checkbox').show();
        },

        hideCheckboxError: function () {
            this.$el.find('.error-checkbox').hide();
        },

        addRow: function (event) {
            this.controller.addRow(event);
        },

        deleteRow: function (event) {
            this.controller.deleteRow(event);
        },

        validateCheckbox: function (event) {
            this.controller.validateCheckbox(event);
        },

        getSubmitEvent: function () {
            return {
                'currentTarget': this.$el.find('.slidingscale-form')
            };
        }

    });
});
