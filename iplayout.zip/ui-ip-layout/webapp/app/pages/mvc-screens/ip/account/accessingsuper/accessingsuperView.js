define([
    'MvcView',
    'text!app/pages/mvc-screens/ip/account/accessingsuper/_partials/_confirmoneoffwithdrawal.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (MvcView, _confirmwithdrawalTemplate, componentXml, Handlebars) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            headerPanel: 'Accessing super',
            menuTabs: [{
                label: 'Withdrawing super',
                url: '#ng/account/accessingsuper/withdrawingsuper',
                child: 'withdrawingsuper',
                bindHrefParam: 'a,e',
            }]
        },

        preRender: function () {
            Handlebars.registerPartial('confirm-withdrawal', componentXml.encode(_confirmwithdrawalTemplate));
        }
    });
});
