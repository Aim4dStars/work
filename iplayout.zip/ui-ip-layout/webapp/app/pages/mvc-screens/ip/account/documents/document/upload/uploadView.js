define([
    'app/pages/mvc-templates/modal/modalView'
], function (ModalView) {
    'use strict';

    return ModalView.extend({

        hideContent: function () {
            this.$el.find('.js-screen-content').hide();
        },

        showContent: function () {
            this.$el.find('.js-screen-content').show();
        },

        hideUploadButton: function () {
            if (this.controller.viewChildren.upload) {
                this.controller.viewChildren.upload.hide();
            }
        },

        showUploadButton: function () {
            if (this.controller.viewChildren.upload) {
                this.controller.viewChildren.upload.show();
            }
        },

        uploadNewDocument: function () {
            this.hideContent();
            this.showUploadButton();
        },

        clearError: function () {
            var $error = this.$el.find('.view-error .message p');
            $error.html('');
        },

        updateError: function (message) {
            var $error = this.$el.find('.view-error .message p');
            $error.append(message + "</br>");
        },

        updateDocumentInfo: function (documentName) {
            this.$el.find('.modal-body span[data-name="documentName"]').attr('title', documentName);
        }

    });

});
