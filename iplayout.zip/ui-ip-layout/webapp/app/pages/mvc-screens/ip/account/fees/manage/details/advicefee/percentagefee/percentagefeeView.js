define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        events: {
            'click .btn-delete': 'deleteChildCell',
            'blur [data-view-component=forminputtext]  input': 'hidePercentageError'
        },

        deleteChildCell: function () {
            this.controller.deleteChildCell();
        },

        showPercentageError: function () {
            this.$el.find('.error-percentage').removeClass('hidden');
        },

        hidePercentageError: function () {
            this.$el.find('.error-percentage').addClass('hidden');
        },

        getSubmitEvent: function () {
            return {
                'currentTarget': this.$el.find('.percentage-form')
            };
        }

    });
});
