defineMvcController({
    name: 'status',
    parentPath: 'mvc-screens/ip/account/assettransfer',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'status',
    hashDefault: true,
    extend: 'MvcController',
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['lastupdatedtime', 'button', 'menuaction'],
    screens: ['mvc-screens/ip/account/assettransfer/inspecie/inspecieupload/uploadstatus', 'mvc-screens/ip/account/assettransfer/inspecie/inspecieupload/uploadfile'],
    dependencies: ['rootController', 'underscore', 'jquery', 'app/framework/services/dateService', 'app/framework/router', 'app/framework/services/analyticsService', 'app/framework/services/Permissions']
}, function (config, MvcController, rootController, _, $, dateService, router, analyticsService, Permissions) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.transfer.status.view',
        targetId: 'a',
        requiredParams: ['a'],
        assetTransfersUrl: '../api/inspecietransfer/v3_0/accounts/<%=a%>/inspecie-transfers',
        autoHideSpinner: false,
        errorList: {},

        viewEvents: {
            'click .view-errors': 'openErrorModal'
        },

        postRender: function () {
            var canViewSummaryBar = Permissions.ruleMatched('account.summary.bar.view', rootController.getUrlParams().a);
            if (!canViewSummaryBar) {
                this.view.hideSpinner();
                return;
            }
            this.errorList = {};
            this.fetchAssetTransfers();
            this.model.on('change:transferStatus change:transferType', _.bind(this.populate, this));

            analyticsService.send({
                "pageName": "ng:account:assettransfer:status"
            });
        },

        fetchAssetTransfers: function () {
            this.view.showSpinner();
            var url = this.getUrl(rootController.getUrlParams(), this.assetTransfersUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    var assetTransfers = data.data.resultList;
                    assetTransfers = this.model.processTransfers(assetTransfers);
                    this.model.set('assetTransfers', assetTransfers);
                    this.populate();
                }, this)
            };

            return this.ajaxGet(params);
        },

        populate: function () {
            var assetTransfers = this.model.get('assetTransfers');
            var totalAssetTransfers = assetTransfers.length;

            assetTransfers = this.model.filter(assetTransfers);
            assetTransfers = this.model.sort(assetTransfers);

            this.children.transfers.setRows({
                rowName: 'transfers',
                expand: 'transferItems'
            }, {
                transfers: assetTransfers
            });
            this.children.transfers.renderComponentView();

            var today = dateService.now();
            this.viewChildren.lastupdatedtime.setUpdatedTime(today);

            this.setPagination(assetTransfers.length, totalAssetTransfers);
            this.view.hideSpinner();
        },

        setPagination: function (showing, total) {
            var paginationLegend = {
                'end': showing,
                'total': total,
                'hasMore': false
            };
            this.children.tableoptions.setPaginationLegend(paginationLegend);
        },

        updateFilter: function () {
            var transferStatus = this.children.tableoptions.model.get('transferStatus');
            var transferType = this.children.tableoptions.model.get('transferType');
            this.model.set({
                'transferStatus': transferStatus,
                'transferType': transferType
            });
        },

        upload: function (transferId) {
            var urlParams = rootController.getUrlParams();
            var accountId = urlParams['a'];

            var url = '#ng/account/assettransfer/individualstatus?a=' + accountId + '&t=' + transferId;
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },

        downloadPrintHolding: function (transferId) {
            var urlParams = rootController.getUrlParams();
            var accountId = urlParams['a'];
            this.view.closeMenuAction();
            var url = "../reportpdf/inspecieTransferReportV2?account-id=" + accountId + "&transferId=" + transferId;
            window.open(url);
        },

        downloadCGTTemplate: function () {
            var url = "/content/dam/secure/others/BT_Panorama_AssetDetails_and_CGTcostbase.xlsx";
            window.open(url);
        },

        uploadAssetDetails: function (transferId) {
            this.children.uploadfile.uploadAssetDetails();
            this.transferId = transferId;
        },

        showUploadStatus: function () {
            this.children.uploadstatus.openModal({
                showCGTMessage: true,
                transferId: this.transferId
            });
        },

        hideUploadStatus: function () {
            this.children.uploadstatus.closeModal();
        },

        setFileUploading: function (flag) {
            this.children.uploadfile.setFileUploading(flag);
        },

        setUploadSuccess: function (successData) {
            this.view.hideErrorMessage(this.transferId);
            this.children.uploadstatus.setSuccess(successData);
        },

        setUploadFailure: function (errors) {
            rootController.confirmNavigation(true);
            this.errorList[this.transferId] = errors;
            this.view.showErrorMessage(this.transferId, errors.length);
            if (this.view.isRowClosed(this.transferId)) {
                var $row = this.view.getTargetRow(this.transferId);
                this.children.transfers.view.expandRow($row);
            }
            this.children.uploadstatus.setErrors(errors);
        },

        setUploadInProgress: function () {
            this.children.uploadstatus.setInProgress();
        },

        getAssetSource: function () {
            var source = '';
            var transferData = this.getTransferById();
            if (!_.isUndefined(transferData)) {
                source = transferData.transferType;
            }
            return source;
        },

        getTransferData: function () {
            return {
                transferId: this.transferId
            };
        },

        submit: function () {
            this.children.uploadfile.submit();
        },

        submitCallback: function () {
            this.refresh();
        },

        refresh: function () {
            $.when(this.fetchAssetTransfers())
                .done(_.bind(function () {
                    _.each(this.errorList, function (errors, transferId) {
                        this.view.showErrorMessage(transferId, errors.length);
                        var $row = this.view.getTargetRow(transferId);
                        this.children.transfers.view.expandRow($row);
                    }, this);
                    this.view.showSuccessMessage(this.transferId);
                    if (this.view.isRowClosed(this.transferId)) {
                        var $row = this.view.getTargetRow(this.transferId);
                        this.children.transfers.view.expandRow($row);
                    }
                }, this));

        },

        getTransferInto: function () {
            var transferData = this.getTransferById();
            var newTransferData = {};
            if (_.isNull(transferData.dest.assetCode)) {
                newTransferData.transferInto = 'Listed securities';
                if (transferData.transferType === 'MANAGED_FUND') {
                    newTransferData.transferInto = 'Managed funds';
                }
            } else {
                newTransferData.transferInto = 'tailoredPortfolio';
                newTransferData.tailoredportfolios = transferData.dest;
                if (transferData.dest.assetType === 'MANAGED_PORTFOLIO') {
                    newTransferData.transferInto = 'managedPortfolio';
                    newTransferData.managedportfolios = transferData.dest;
                }
            }
            return newTransferData;
        },

        getTransferById: function () {
            var assettransfers = this.model.get('assetTransfers');
            var transferData = _.find(assettransfers, function (_asset) {
                return _asset.key.transferId === this.transferId;
            }, this);

            return transferData;
        },

        openErrorModal: function (event) {
            event.preventDefault();
            var transferId = this.view.getTransferId(event);
            var errors = this.errorList[transferId];
            this.children.uploadstatus.openModal({
                showCGTMessage: true,
                transferId: this.transferId,
                showError: true,
                errors: errors
            });
            this.children.uploadstatus.setErrors(errors);
        }
    });
});
