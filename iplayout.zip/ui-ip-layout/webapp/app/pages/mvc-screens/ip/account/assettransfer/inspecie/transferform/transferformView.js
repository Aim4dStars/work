define(['MvcView', 'jquery', 'underscore'],
    function (MvcView, $, _) {
        'use strict';

        return MvcView.extend({
            rootTemplate: {
                headerPanel: 'Asset transfers',
                headerDownload: {
                    items: []
                },
                menuTabs: []
            },
            postRender: function () {
                this.$el.find('.showTermsAndConditionsHyperlink').on('click', _.bind(this.showTerms, this));
            },
            setUIErrors: function (messages) {
                var $uiErrorMessageContainer = this.$el.find('.view-uierror .message');

                $uiErrorMessageContainer.find('p').not(':eq(0)').remove();
                _.each(messages, function (message) {
                    $uiErrorMessageContainer.append('<p>' + message + '</p>');
                });
            },
            setUIWarnings: function (messages) {
                var $uiWarningMessageContainer = this.$el.find('.view-uiwarning .message');

                $uiWarningMessageContainer.find('p').not(':eq(0)').remove();
                _.each(messages, function (message) {
                    $uiWarningMessageContainer.append('<p>' + message + '</p>');
                });
            },
            showTerms: function (e) {
                //Prevent the showTerms link from triggering the checkbox on click
                e.preventDefault();
                e.stopPropagation();

                //show the terms and conditions modal
                this.controller.children.terms.openModal();
            },
            hideManagedPortfolio: function () {
                this.$el.find('.snapshot-container .snapshot:eq(3) .data-wrapper').hide();
            },

            hideManagedPortfolioTooltip: function () {
                this.$el.find('.managedPortfolioNewTooltip').hide();
            },

            showManagedPortfolioTooltip: function () {
                this.$el.find('.managedPortfolioNewTooltip').show();
            },
            getTransferFormContainer: function () {
                return this.$el.find('.transferFormContainer');
            }
        });
    });
