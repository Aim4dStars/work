defineMvcController({
    name: 'changenominationtype',
    parentPath: 'mvc-screens/ip/account/details/beneficiariesautorev/editbeneficiaries/beneficiarysection',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['spinner', 'button', 'messagealert'],
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config,

        changeToPrimaryBeneficiaries: function () {
            this.view.showLoading();
            var rowIndex = Number(this.model.get('rowIndex'));
            this.parentController.proceedChangeToPrimaryNomination(rowIndex);
            this.closeModal();
        },

        cancel: function () {
            var rowIndex = Number(this.model.get('rowIndex'));
            this.parentController.cancelChangeOfNominationType(rowIndex);
            this.closeModal();
        },
    });

});
