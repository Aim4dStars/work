defineMvcController({
    name: 'documents',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    screens: ['document'],
    hashName: 'documents',
    extend: 'MvcController',
    dependencies: ['app/framework/services/optionsService']
}, function (config, MvcController, optionsService) {
    'use strict';

    return MvcController.extend({
        config: config,
        hasPermission: 'account.document.view',
        targetId: 'a',
        requiredParams: ['a'],
        preRender: function () {
            this.model.set('isChallengerScheme', false);
            this.model.set('isDefaultScheme', true);
            if (optionsService.getOption('adviser.documents.filter.scheme', 'a') === 'challenger') {
                this.model.set('isChallengerScheme', true);
                this.model.set('isDefaultScheme', false);
            }
        }
    });
});
