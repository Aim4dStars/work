define([
    'MvcModel',
    'underscore'
], function (MvcModel, _) {
    'use strict';

    return MvcModel.extend({
        validation: {
            'disclaimer': {
                blur: {
                    required: true
                }
            }
        },

        colateFees: function (fees, contributionFees) {
            var data = {
                fees: []
            };
            _.each(fees, _.bind(function (fee) {
                var modelFee = _.extend({}, fee);
                if (fee.type === 'Portfolio management fee' && fee.feesComponent.length > 0) {
                    data.pmf = this._colatePmf(modelFee);
                } else if (fee.type !== 'Portfolio management fee' && fee.type !== 'Contribution fee') {
                    data.fees.push(this._colateAdviceFee(modelFee));
                }
            }, this));
            if (contributionFees.oneoffFees.length > 0 || contributionFees.regularFees.length > 0) {
                data.contributionFees = contributionFees;
            }
            this.set('data', data);
        },

        _colateAdviceFee: function (adviceFee) {
            _.each(adviceFee.feesComponent, function (component) {
                var name = adviceFee.type + component.type;
                name = name.replace(/ /g, '');
                name = name.toLowerCase();
                component.name = name;
            });
            return adviceFee;
        },

        _colatePmf: function (portfolioFee) {
            var percentFees = [];
            var slidingFees = [];
            _.each(portfolioFee.feesComponent, function (component) {
                if (component.type === 'PercentageFee') {
                    percentFees.push(component);
                } else if (component.type === 'SlidingScaleFee') {
                    slidingFees.push(component);
                }
            });
            return {
                slidingScaleComponent: slidingFees,
                percentageComponent: percentFees
            };
        }
    });
});
