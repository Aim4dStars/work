defineMvcController({
    name: 'financialyear',
    parentPath: 'mvc-screens/ip/account/contribution/history',
    viewHtml: true,
    viewComponents: ['inputselect'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            this.model.on('change:financialYear', this.updateParentFinancialYear.bind(this));
        },

        updateParentFinancialYear: function () {
            this.parentController.model.set('financialYear', this.model.get('financialYear'));
        },

        setOptions: function (options) {
            this.viewChildren.financialyear.setOptions(options);
        },

        onDestroy: function () {
            this.model.off('change:financialYear');
        }
    });
});
