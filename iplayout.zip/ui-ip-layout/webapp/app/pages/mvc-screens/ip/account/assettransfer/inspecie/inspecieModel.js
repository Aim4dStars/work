define(['MvcModel'],
    function (MvcModel) {
        'use strict';

        return MvcModel.extend({

        });
    });
