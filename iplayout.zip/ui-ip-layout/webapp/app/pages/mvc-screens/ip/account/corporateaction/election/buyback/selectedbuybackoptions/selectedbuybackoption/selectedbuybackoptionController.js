defineMvcController({
    name: 'selectedbuybackoption',
    parentPath: 'mvc-screens/ip/account/corporateaction/election/buyback/selectedbuybackoptions',
    viewHtml: true,
    modelJs: true,
    viewJs: true,
    viewComponents: ['inputselect'],
    screens: [],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/buyback/selectedbuybackoptions/selectedbuybackoption/selectedbuybackoptionController'
}, function (config, SelectedbuybackoptionController) {
    'use strict';

    return SelectedbuybackoptionController.extend({
        config: config
    });
});
