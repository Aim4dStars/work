defineMvcController({
    name: 'oneoffwithdrawal',
    parentPath: 'mvc-screens/ip/account/accessingsuper/withdrawingsuper',
    viewHtml: true,
    viewJs: true,
    mvcComponents: ['tablev3', 'tableoptions'],
    viewComponents: ['menuaction', 'button'],
    dependencies: ['app/pages/mvc-screens/ip/account/accessingsuper/accessingsuperServices', 'jquery', 'underscore', 'rootController', 'app/framework/router'],
    extend: 'MvcController'
}, function (config, MvcController, accessingsuperServices, $, _, rootController, router) {
    'use strict';

    return MvcController.extend({
        config: config,
        editOneOffWithdrawalUriTemplate: '#ng/account/accessingsuper/editoneoffwithdrawal?a=',
        hideDescriptionColumn: [3],

        postRender: function () {
            this.parentController.extendModelProperties(this);
            this.populateOneOffWithdrawal();
        },

        populateOneOffWithdrawal: function () {
            this.view.toggleSpinner(true);
            var savedWithdrawals = this.parentController.model.get('savedWithdrawals');
            if (!_.isUndefined(savedWithdrawals)) {
                var filteredOneOffWithdrawals = this._sortOneOffWithdrawals(accessingsuperServices.filterOneOffWithdrawals(savedWithdrawals));
                this.renderOneOffWithdrawalTable(filteredOneOffWithdrawals, 'oneoffwithdrawaltable');
                this.view.toggleSpinner(false);
            }
        },

        _sortOneOffWithdrawals: function (withdrawals) {
            return _.sortBy(withdrawals, 'recieptNumber').reverse();
        },


        renderOneOffWithdrawalTable: function (filteredOneOffWithdrawals, tableName) {
            this.children[tableName].setRows({}, filteredOneOffWithdrawals);
            this.children[tableName].renderComponentView();
        },

        navigateToEditOneOffWithdrawal: function () {
            var url = this.editOneOffWithdrawalUriTemplate + rootController.getUrlParams().a;
            this.parentController.parentController.setSaveAction('saveoneoff');
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },

        submitSavedWithdrawal: function (rowIndex, saveTypeAction) {
            this.view.showSpinner();
            var data = this.children.oneoffwithdrawaltable.model.get('rows')[rowIndex];
            accessingsuperServices.reviewSavedWithdrawal(this, data, saveTypeAction);
        },

        editDetails: function (rowIndex) {
            var url,
                data = this.children.oneoffwithdrawaltable.model.get('rows')[rowIndex];
            accessingsuperServices.setSelectedRowData(this, data, 'modifyoneoff');
            url = this.editOneOffWithdrawalUriTemplate + rootController.getUrlParams().a;
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },

        cancelSavedWithdrawal: function (rowIndex) {
            var data = this.children.oneoffwithdrawaltable.model.get('rows')[rowIndex];
            this.parentController.children.cancelsavedwithdrawal.openModal({
                transSeqNo: data.transSeqNo,
                stordPosId: data.stordPosId,
                receiptNumber: data.recieptNumber,
                withdrawalType: data.orderType,
                paymentType: 'OneOffWithdrawals',
                paymentAction: 'canceloneoff'
            });
        }
    });

});
