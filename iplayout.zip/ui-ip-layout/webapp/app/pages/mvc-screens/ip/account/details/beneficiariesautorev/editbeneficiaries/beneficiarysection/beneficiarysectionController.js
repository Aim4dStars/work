defineMvcController({
    name: 'beneficiarysection',
    parentPath: 'mvc-screens/ip/account/details/beneficiariesautorev/editbeneficiaries',
    hashName: 'beneficiarysection',
    viewHtml: true,
    mvcComponents: ['section'],
    screens: ['delete', 'autoreversionary', 'changenominationtype'],
    viewComponents: ['forminputtext', 'expandcollapseall', 'forminputradios', 'button', 'forminputselect', 'tooltip', 'forminputdate', 'position'],
    extend: 'MvcController',
    dependencies: ['jquery', 'underscore', 'app/framework/helpers/format', 'app/framework/mvc/MvcModelValidationTypes']
}, function (config, MvcController, $, _, formatHelper, MvcModelValidationTypes) {
    'use strict';

    return MvcController.extend({
        config: config,

        LEGAL_PERSON_REPRESENTATIVE_INTLID: 'lpr',

        sectionToggled: function (sectionName) {
            var expandcollapseall = this.viewChildren.expandcollapseall;
            if (expandcollapseall) {
                expandcollapseall.update(sectionName);
            }
            this._clearInvalidIndicator(sectionName);
        },

        postRender: function () {
            this.sectionToggled();
        },

        _clearInvalidIndicator: function (sectionName) {
            var beneficiaryChild = this.children[sectionName];
            if (beneficiaryChild) {
                beneficiaryChild.model.set('showInvalidIcon', false);
            }
        },

        renderBeneficiaries: function () {
            var beneficiaryData = this.getParentControllerData('beneficiaries');
            var expandcollapseall = this.viewChildren.expandcollapseall;
            if (expandcollapseall) {
                if (beneficiaryData.length) {
                    expandcollapseall.show();
                } else {
                    expandcollapseall.hide();
                }
            }
            _.each(beneficiaryData, function (beneficiary, index) {
                var beneficiaryChild = this.children['beneficiary' + index];

                this._applySectionModelValidation(beneficiaryChild.model);

                beneficiary.index = index;
                beneficiary.isDependentRelationship = this._isDependentRelationship(beneficiary.relationshipType);
                beneficiary.isAutoReversionary = this._isAutoReversionary(beneficiary.nominationType);
                beneficiaryChild.model.on('change:firstName change:lastName change:relationshipType', this._updateBeneficiaryDisplayName, this);
                beneficiaryChild.model.on('change:allocationPercent', this._updateAllocationPercentWithSymbol, this);
                beneficiaryChild.model.set(beneficiary);
                beneficiaryChild.model.original = beneficiary;
                beneficiaryChild.model.on('change:nominationType', this._checkForAutoReversionary, this);
                beneficiaryChild.model.on('change:relationshipType', this._checkForLegalRepresentative, this);
                beneficiaryChild.model.on('change', this.showConfirmationWhenSectionModelDirty, this);

                if (beneficiary.isAutoReversionary) {
                    beneficiaryChild.viewChildren.allocationpercent.disable();
                }

                if (beneficiary.expanded) {
                    beneficiaryChild.view.toggleSection({});
                }
            }, this);
        },

        _updateBeneficiaryDisplayName: function (sectionModel) {
            var displayName = "";
            if (sectionModel.get('relationshipType') === this.LEGAL_PERSON_REPRESENTATIVE_INTLID) {
                displayName = this._getRelationshipName(sectionModel);
            } else {
                displayName = this._getFullName(sectionModel);
            }
            sectionModel.set('displayName', displayName);
        },

        _getRelationshipName: function (sectionModel) {
            var relationshipIntlId = sectionModel.get('relationshipType');
            var relationshipOptions = this.parentController.model.get('relationshipTypes');
            var found = _.find(relationshipOptions, function (option) {
                return option.intlId === relationshipIntlId;
            });
            if (found) {
                return found.label;
            }
        },

        _getFullName: function (sectionModel) {
            var firstName = sectionModel.get('firstName');
            var lastName = sectionModel.get('lastName');
            var index = Number(sectionModel.get('index')) + 1;
            return _.compact([firstName, lastName]).join(' ') || 'Beneficiary ' + index;
        },

        _updateAllocationPercentWithSymbol: function (sectionModel, newValue) {
            var checkerrormessage = this.parentController.model.get('allocationPercentError');
            if (checkerrormessage) {
                this.parentController._hideMessage('allocationpercenterror');
            }
            sectionModel.set('allocationPercentWithSymbol', formatHelper.formatMoney(newValue, 2, '%'));
            this.updateParentAllocationTotal();
        },

        _isAutoReversionary: function (intlId) {
            var nominationTypes = this.getParentControllerData('nominationTypes');
            var found = _.findWhere(nominationTypes, {
                intlId: intlId
            });
            if (found && found.soleNominationOnly) {

                return true;
            }
            return false;
        },

        clearDependentBeneficiaryAttributes: function (sectionModel) {
            sectionModel.unset('firstName');
            sectionModel.unset('lastName');
            sectionModel.unset('email');
            sectionModel.unset('phoneNumber');
            sectionModel.unset('gender');
            sectionModel.unset('dateOfBirth');
        },

        _checkForAutoReversionary: function (sectionModel, intlId) {
            if (!this.model.get('cancelChangeOfNominationType') || _.isUndefined(this.model.get('cancelChangeOfNominationType'))) {
                var beneficiaries = this.getAllSectionModelData();
                var previousNominationType = sectionModel.previous('nominationType');
                sectionModel.set('previousNominationType', previousNominationType);
                if (this._isAutoReversionary(previousNominationType)) {
                    if (beneficiaries.length > 1) {
                        this.changeToPrimaryBeneficiaries(sectionModel, beneficiaries, previousNominationType);
                    } else {
                        this.proceedChangeToPrimaryNomination(sectionModel.get('index'));
                    }
                } else {
                    if (this._isAutoReversionary(intlId) || this._isAutoReversionary(previousNominationType)) {
                        if (beneficiaries.length > 1) {
                            var rowIndex = sectionModel.get('index');
                            previousNominationType = sectionModel.previous('nominationType');
                            var namesOfBeneficiariesToBeRemoved = this._filterNamesOfBeneficiaries(rowIndex, beneficiaries);
                            this.showAutoReversionaryModal(rowIndex, namesOfBeneficiariesToBeRemoved);
                        } else {
                            this.proceedAutoReversionary(0);
                        }
                    } else {
                        sectionModel.controller.viewChildren.allocationpercent.enable();
                        sectionModel.controller.view.$el.find('[data-component-name="allocation"]').removeClass('disabled');
                        sectionModel.set('isAutoReversionary', false);
                        this.parentController._setAddBeneficiaryEnabled();
                    }
                }
            }

        },

        changeToPrimaryBeneficiaries: function (sectionModel, beneficiaries) {
            var rowIndex = sectionModel.get('index');
            var namesOfBeneficiariesToBeRemoved = this._filterNamesOfBeneficiaries(rowIndex, beneficiaries);
            this.showChangeToPrimaryNominationModal(rowIndex, namesOfBeneficiariesToBeRemoved);
        },

        showChangeToPrimaryNominationModal: function (rowIndex, namesOfBeneficiariesToBeRemoved) {
            this.children.changenominationtype.openModal({
                rowIndex: rowIndex,
                namesOfBeneficiariesToBeRemoved: namesOfBeneficiariesToBeRemoved,
            });
        },

        proceedChangeToPrimaryNomination: function (rowIndex) {
            var beneficiaryChild = this.children['beneficiary' + rowIndex];
            if (beneficiaryChild) {
                beneficiaryChild.model.set('allocationPercent', 0);
                beneficiaryChild.viewChildren.allocation.enable();
                beneficiaryChild.model.set('isAutoReversionary', false);
                beneficiaryChild.model.set('isPrimaryAllocationAvailable', false);
            }
            var beneficiaries = this.getAllSectionModelData();
            this.refreshSectionData(beneficiaries);
        },


        _isDependentRelationship: function (intlId) {
            var allRelationshipTypes = this.getParentControllerData('relationshipTypes');
            var selectedRelationshipType = _.find(allRelationshipTypes, function (relationshipType) {
                return relationshipType.intlId === intlId;
            });
            if (!selectedRelationshipType || selectedRelationshipType.dependent) {
                return true;
            }
            return false;
        },

        _checkForLegalRepresentative: function (sectionModel, intlId) {
            var isDependentRelationship = this._isDependentRelationship(intlId);
            sectionModel.set('isDependentRelationship', isDependentRelationship);
            if (!isDependentRelationship) {
                this.clearDependentBeneficiaryAttributes(sectionModel);
            }
        },

        proceedAutoReversionary: function (rowIndex) {
            var beneficiaryChild = this.children['beneficiary' + rowIndex];
            if (beneficiaryChild) {
                beneficiaryChild.model.set('allocationPercent', 100);
                beneficiaryChild.viewChildren.allocation.disable();
                beneficiaryChild.model.set('isAutoReversionary', true);

                // auto reversionary cannot be Legal person representative.
                if (beneficiaryChild.model.get('isDependentRelationship') === false) {
                    beneficiaryChild.model.set('relationshipType', '');
                }
            }
            var beneficiaries = this.getAllSectionModelData();
            this.refreshSectionData(beneficiaries);
        },

        cancelChangeOfNominationType: function (index) {
            var beneficiaryChild = this.children['beneficiary' + index];
            if (beneficiaryChild) {
                this.model.set('cancelChangeOfNominationType', true);
                beneficiaryChild.model.set('nominationType', beneficiaryChild.model.get('previousNominationType'));
                this.model.set('cancelChangeOfNominationType', false);
            }
        },

        updateParentAllocationTotal: function () {
            var sections = this.getAllSections();
            var allocationPercents = _.map(sections, function (section) {
                if (!section.model.get('isAutoReversionary')) {
                    return section.model.get('allocationPercent');
                } else {
                    return 0;
                }
            }, this);
            var totalAllocationPercent = _.reduce(allocationPercents, function (total, value) {
                return total + Number(value);
            }, 0);
            this.parentController.updateAllocationTotal(!_.isNaN(totalAllocationPercent) ? formatHelper.formatMoney(totalAllocationPercent, 2) : totalAllocationPercent);
        },

        getParentControllerData: function (key) {
            return this.parentController.model.get(key);
        },

        setParentControllerData: function (key, val) {
            return this.parentController.model.set(key, val);
        },

        unsetParentControllerData: function (key) {
            return this.parentController.model.unset(key);
        },

        getAllSections: function () {
            var keys = _.keys(this.children);
            var beneficiaryKeys = _.filter(keys, function (key) {
                return key.indexOf('beneficiary') === 0;
            });
            return _.map(beneficiaryKeys, function (key) {
                return this.children[key];
            }, this);
        },

        getAllSectionModelData: function () {
            var sections = this.getAllSections();
            return _.map(sections, function (section) {
                var data = _.clone(section.model.attributes);
                delete data.parent;
                return data;
            }, this);
        },

        showAutoReversionaryModal: function (rowIndex, namesOfBeneficiariesToBeRemoved) {
            this.children.autoreversionary.openModal({
                rowIndex: rowIndex,
                namesOfBeneficiariesToBeRemoved: namesOfBeneficiariesToBeRemoved,
            });
        },

        showDeleteModal: function ($el, event) {
            this.stopEventPropogating(event);
            var section = $el.closest('div[data-mvc-component="section"]');
            var dataIndex = section.attr('data-index');
            var showAutoReversionaryDeletePopup = this.children["beneficiary" + dataIndex].model.get('isAutoReversionary') && this.getAllSectionModelData().length > 1;
            this.children.delete.openModal({
                rowIndex: dataIndex,
                showAutoReversionaryDeletePopup: showAutoReversionaryDeletePopup
            });
        },

        stopEventPropogating: function (event) {
            if (event && event.preventDefault) {
                event.preventDefault();
                event.stopPropagation();
            }
        },

        clearAndRenderView: function () {
            this.removeChildren();
            this.removeViewChildren();
            this.view.render();
        },

        showConfirmationWhenSectionModelDirty: function () {
            var sections = this.getAllSections();
            var hasAnythingReallyChanged = false;
            var keysToTriggerDirty = ['nominationType', 'allocationPercent', 'relationshipType', 'firstName', 'lastName', 'dateOfBirth', 'gender', 'phoneNumber', 'email'];
            _.each(sections, function (section) {
                var changedKeys = _.keys(section.model.changed);
                var keysToCheck = _.intersection(changedKeys, keysToTriggerDirty);
                _.each(keysToCheck, function (key) {
                    var original = section.model.original[key];
                    var changed = section.model.changed[key];

                    if (!_.isNaN(Number(original)) && !_.isNaN(Number(changed))) {
                        // compare "40.00" to 40
                        if (Number(original) !== Number(changed)) {
                            hasAnythingReallyChanged = true;
                        }
                    } else if (original !== changed && !(_.isEmpty(original) && _.isEmpty(changed))) {
                        hasAnythingReallyChanged = true;
                    }
                });
            });

            if (hasAnythingReallyChanged) {
                this.parentController.enableConfirmNavigation();
            } else {
                this.parentController.disableConfirmNavigation();
            }
        },

        removeRow: function (rowIndex) {
            var beneficiaries = this.getAllSectionModelData();
            beneficiaries.splice(rowIndex, 1);
            this.refreshSectionData(beneficiaries);
        },

        refreshSectionData: function (beneficiariesData) {
            var beneficiaries = this.parentController._checkForAutoReversionary(beneficiariesData, this.getParentControllerData('nominationTypes'));
            this.unsetParentControllerData('beneficiaries');
            this.setParentControllerData('beneficiaries', beneficiaries);
            this.clearAndRenderView();
            this.renderBeneficiaries();
            this.parentController._setAddBeneficiaryEnabled();
            this.showConfirmationWhenSectionModelDirty();
            this.updateParentAllocationTotal();
            this.parentController._hideMessage('allocationpercenterror');
        },

        onDestroy: function () {
            var sections = this.getAllSections();
            _.each(sections, function (section) {
                if (section.model) {
                    section.model.off('change:firstName');
                    section.model.off('change:lastName');
                    section.model.off('change:relationshipType');
                    section.model.off('change:allocationPercent');
                }
            }, this);
        },

        _applySectionModelValidation: function (model) {
            var requiredValidation = function () {
                return {
                    blur: {
                        required: true
                    },
                    submit: {
                        required: true
                    }
                };
            };
            var phoneValidation = _.clone(MvcModelValidationTypes.validationTypes.telephone);
            phoneValidation.blur.required = false;
            var emailValidation = _.clone(MvcModelValidationTypes.validationTypes.email);
            emailValidation.blur.required = false;

            _.extend(model.validation, {
                nominationType: requiredValidation(),
                relationshipType: requiredValidation(),
                firstName: requiredValidation(),
                lastName: requiredValidation(),
                gender: requiredValidation(),
                phoneNumber: phoneValidation,
                email: emailValidation,
                dateOfBirth: {
                    type: 'date',
                    blur: {
                        required: true,
                        customMaxValue: function (value) {
                            var today = new Date(),
                                parseDate = $.parseDate(value);
                            return _.isDate(parseDate) ? (parseDate <= today) : true;
                        },
                        customDuplicateInvestors: 'isNotDuplicated'
                    },
                    convertForSummary: function (value) {
                        if (value) {
                            var dateString = this.validationTypes.date.convertForView($.parseDate(value));
                            if (dateString) {
                                return dateString;
                            }
                        }
                        return value;
                    },
                    convertForModel: function (value) {
                        if (value) {
                            value = value.trim();
                        }
                        var parseDate = $.parseDate(value);
                        if (parseDate && _.isDate(parseDate)) {
                            return formatHelper.formatDate(parseDate);
                        }
                        return value;
                    },
                    convertForView: function (value) {
                        return this.validationTypes.date.convertForView($.parseDate(value));
                    }
                },
            });
        },

        _filterNamesOfBeneficiaries: function (excludeIndex, beneficiaries) {
            return _.compact(_.map(beneficiaries, function (beneficiary) {
                if (beneficiary.index !== excludeIndex) {
                    return beneficiary.displayName;
                }
            }, this));
        },
    });
});
