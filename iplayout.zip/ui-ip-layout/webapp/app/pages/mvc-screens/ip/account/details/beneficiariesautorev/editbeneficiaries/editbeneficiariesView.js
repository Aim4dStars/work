define([
    'MvcView',
    'underscore'
], function (MvcView, _) {
    'use strict';

    return MvcView.extend({
        scrollIntoView: false,
        TOTAL_ALLOCATION_PERCENTAGE_HEADING: 'Total secondary allocation',
        NOMINATE_ANOTHER_BENEFICIARY_HEADING: 'Nominate secondary beneficiary',

        rootTemplate: {
            menuTabs: false
        },

        colorAllocationTotal: function (value) {
            var el = this.$el.find('.js-totalAllocationPercent');
            el.removeClass('red');
            if (Number(value) !== 100 && Number(value) !== 0) {
                el.addClass('red');
            }
        },

        updateExpandCollapseSections: function () {
            this.$el.find('.accordion-item.table-grid-layout:not(.expanded) .icon-arrow-down').removeClass('icon-arrow-down').addClass('icon-arrow-right');
            this.$el.find('.accordion-item.table-grid-layout.expanded .icon-arrow-right').removeClass('icon-arrow-right').addClass('icon-arrow-down');
        },

        _hideSecondaryNominationEmptyStateMsg: function () {
            var viewChildren = this.controller.children.beneficiarysection.viewChildren.secondarynominationemptystate;
            if (!_.isUndefined(viewChildren)) {
                viewChildren.hide();
            }
        },

        _setSectionHeadings: function (value) {
            var totalAllocationPercentageElement = this.$el.find('.js-totalAllocationPercent-label');
            var nominateAnotherBeneficiaryElement = this.$el.find('.js-addbeneficiary  .label-content');
            var totalAllocationPercentageHeading = this.TOTAL_ALLOCATION_PERCENTAGE_HEADING;
            var nominateAnotherBeneficiaryHeading = this.NOMINATE_ANOTHER_BENEFICIARY_HEADING;
            if (value === 'change') {
                totalAllocationPercentageElement.html(totalAllocationPercentageHeading);
                nominateAnotherBeneficiaryElement.html(nominateAnotherBeneficiaryHeading);
            } else {
                totalAllocationPercentageElement.html(totalAllocationPercentageHeading.replace('secondary', ''));
                nominateAnotherBeneficiaryElement.html(nominateAnotherBeneficiaryHeading.replace('secondary', 'another'));
            }
        }

    });
});
