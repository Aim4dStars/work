define([
    'app/pages/mvc-templates/modal/modalView'
], function (ModalView) {
    'use strict';

    return ModalView.extend({

    });

});
