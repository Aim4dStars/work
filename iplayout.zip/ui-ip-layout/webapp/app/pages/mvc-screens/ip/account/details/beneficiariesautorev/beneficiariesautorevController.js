defineMvcController({
    name: 'beneficiariesautorev',
    parentPath: 'mvc-screens/ip/account/details',
    viewHtml: true,
    viewJs: true,
    hashName: 'beneficiariesautorev',
    viewComponents: ['button', 'messagedisclaimer'],
    mvcComponents: ['tablev3'],
    screens: ['editbeneficiaries', 'viewbeneficiaries'],
    extend: 'MvcController',
    dependencies: ['rootController', 'jquery', 'underscore'],
}, function (config, MvcController, rootController, $, _) {
    'use strict';

    return MvcController.extend({
        config: config,
        nominationTypesUrl: '../api/v1_0/accounts/<%=a%>/super/nominationtypes?filter_for_account=<%=isfilterRequired%>',
        relationshipsUrl: '../api/v1_0/accounts/<%=a%>/super/relationshiptypes',
        beneficiariesUrl: '../api/v1_0/accounts/<%=a%>/super/beneficiaries',
        // TODO: Properly escape the following parameters.
        genderUrl: '../api/v1_0/static?criteria=[{prop:"gender",op:"=",val:"gender",type:"string"}]',
        AUTO_REVERSIONARY: 'auto reversionary',

        fetchNominationTypes: function () {
            var url = this.getUrl({
                'a': rootController.getUrlParams().a,
                'isfilterRequired': true
            }, this.nominationTypesUrl);
            return this._fetchData(url, 'data.resultList');
        },

        fetchRelationshipTypes: function () {
            return this._fetchData(this.relationshipsUrl, 'data.resultList');
        },

        fetchGender: function () {
            return this._fetchData(this.genderUrl, 'data.resultMap.gender');
        },

        fetchBeneficiaries: function () {
            return this._fetchData(this.beneficiariesUrl, 'data');
        },

        _fetchData: function (url, dataPath) {
            var deferred = $.Deferred();
            var params = {
                url: this.getUrl(rootController.getUrlParams(), url),
                success: _.bind(function (data) {
                    data = this._getDataFromObject(data, dataPath);
                    deferred.resolve(data);
                }, this)
            };
            this.ajaxGet(params);
            return deferred.promise();
        },



        _getDataFromObject: function (data, dataPath) {
            if (data && _.isObject(data) && dataPath) {
                var parts = dataPath.split('.');
                while (parts.length) {
                    var part = parts.shift();
                    data = data[part];
                }
            }
            return data;
        },

        _formatBeneficiaryData: function (beneficiaries) {
            var beneficiariesDetails = [];
            var secondaryNominations = [];
            this.model.set('isprimaryNominationAvailable', false);
            _.each(beneficiaries, function (beneficiary) {
                if (beneficiary.nominationTypeLabel.toLowerCase() === this.AUTO_REVERSIONARY) {
                    beneficiariesDetails.primaryNomination = [beneficiary];
                    beneficiariesDetails.primaryNomination.totalAllocationPercent = beneficiary.allocationPercent;
                    this.model.set('isprimaryNominationAvailable', true);
                } else {
                    secondaryNominations.push(beneficiary);
                }
            }, this);
            if (this.model.get('isprimaryNominationAvailable')) {
                secondaryNominations.totalAllocationPercent = _.reduce(secondaryNominations, function (memo, num) {
                    return memo + Number(num.allocationPercent);
                }, 0);
                beneficiariesDetails.secondaryNominations = secondaryNominations;
            } else {
                beneficiariesDetails.nominations = beneficiaries;
            }
            return beneficiariesDetails;
        }

    });
});
