define([
    'MvcView',
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            headerPanel: 'Asset transfers',
            headerDownload: {
                items: []
            },
            menuTabs: []
        }
    });
});
