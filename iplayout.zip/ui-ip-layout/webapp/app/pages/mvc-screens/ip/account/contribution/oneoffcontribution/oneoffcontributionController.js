defineMvcController({
    name: 'oneoffcontribution',
    parentPath: 'mvc-screens/ip/account/contribution',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'oneoffcontribution',
    extend: 'app/pages/mvc-screens/ip/account/contribution/regularcontribution/regularcontributionController',
    screens: ['confirmation'],
    viewComponents: ['forminputselect', 'forminputtext', 'forminputdate', 'button', 'forminputcheckbox', 'messagealert'],
    mvcComponents: ['inputautocomplete'],
    dependencies: []
}, function (config, Super) {
    'use strict';

    return Super.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        hasPermission: 'account.super.contribution.view',

        onRepeatDepositChanged: function () {},

        getDataForSubmission: function () {
            var data = Super.prototype.getDataForSubmission.call(this);
            data['contributionType'] = this.model.get('contributionType');
            data['isRecurring'] = false;
            return data;
        },

        showReceipt: function (response, type, action) {
            var payeeList = this.model.get('payeelist');
            response.toPayeeDto = this.parentController._getToPayeeDto(payeeList);
            this.parentController.model.set({
                submitResponse: response,
                type: type,
                action: action
            });
            this.parentController.children.contributionreceipt.show({
                updateLocationHash: true,
                preserveQueryStringParams: true
            });
        },

        showSavedContribution: function (response) {
            this.showReceipt(response, 'contributionstatus', 'save');
        }
    });
});
