define([
    'underscore', 'jquery', 'rootController'
], function (_, $, rootController) {
    'use strict';

    return {
        url: {
            tradableInvestmentOptionsServiceUrl: '../api/trading/v1_0/accounts/<%=a%>/tradableinvestmentoptions?query=++&asset_type=Tailored+portfolio,Managed+portfolio'
        },

        getInvestmentOptions: function (controller, params) {
            var deferred = $.Deferred();

            controller.ajaxGet({
                url: controller.getUrl(rootController.getUrlParams(), this.url.tradableInvestmentOptionsServiceUrl),
                data: params,
                success: function (data) {
                    if (data.data) {
                        deferred.resolve(data.data.resultList);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },

        getMinInitialAmount: function (investmentOptions, assetCode) {
            var selectedPortfolio = _.find(investmentOptions, function (portfolioInvestment) {
                return portfolioInvestment.asset.assetCode === assetCode;
            });
            var minAmount = 0;

            if (!_.isUndefined(selectedPortfolio)) {
                minAmount = selectedPortfolio.minAmount;
            }

            return minAmount;
        }
    };
});
