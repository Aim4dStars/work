defineMvcController({
    name: 'viewdeduction',
    parentPath: 'mvc-screens/ip/account/contribution/personaltax',
    viewHtml: true,
    viewJs: true,
    hashDefault: true,
    screens: ['financialyear'],
    hashName: 'viewdeduction',
    extend: 'MvcController',
    viewComponents: ['button', 'tooltip', 'snapshot', 'menuaction', 'messagedisclaimer', 'messagealert'],
    mvcComponents: ['search', 'tablev3'],
    dependencies: ['underscore', 'jquery', 'rootController', 'app/framework/handlebars/format', 'app/framework/helpers/format', 'app/pages/mvc-screens/ip/services/accountService', 'app/framework/router']
}, function (config, MvcController, _, $, rootController, format, formatHelper, accountService, router) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        autoHideSpinner: false,
        isoDateFormat: 'YYYY-MM-dd',
        hasPermission: 'account.super.personaltaxdeductionnotice.view',
        taxdeductionUrl: '../api/superpersonaltaxdeduction/v1_0/accounts/<%=a%>/notices?date=<%=sc%>',
        contCapsUrl: '../api/v1_0/accounts/<%=a%>/super/contributioncaps?date=<%=sc%>',
        contHistoryUrl: '../api/v1_0/accounts/<%=a%>/super/contributionhistory?date=<%=sc%>',


        preRender: function () {
            this.model.on('change:isPriorLastFY change:hasPensionCommenced', _.bind(this._showMessageAlert, this));
            this.model.on('change:isPriorLastFY change:hasPensionCommenced change:amountAvailableBeforeReachingCap', _.bind(this._showProvideNewNoticeLink, this));
        },

        postRender: function () {
            this._hideMessage('ajaxerror');
            accountService.getAccount(this)
                .done(_.bind(function (account) {
                    if (_.isObject(account) && _.isObject(account.pensionDetails)) {
                        this.model.set('hasPensionCommenced', !_.isEmpty(account.pensionDetails.commencementDate) || account.pensionDetails.commencementPending);
                    }
                    this.model.set('migrationdetails', _.isObject(account) && _.isObject(account.migrationDetails));
                }, this));
            this.view.colorise('.amountBeforeCap', this.model.get('contributionCap'));
        },

        _showOneTimeSuccessMessage: function () {
            this.viewChildren.onetimesuccessmessage.hide();
            if (this.parentController.model.get('noticeSubmitted') === true) {
                this.model.set('documentLibraryUrl', this._getDocumentLibraryUrl(this._formatDate(new Date(), this.isoDateFormat)));
                this.viewChildren.onetimesuccessmessage.show();
                this.parentController.model.unset('noticeSubmitted');
                this.parentController.model.unset('docId');
            }
        },

        _showMessageAlert: function () {
            this.viewChildren.pensioncommencedmessage.hide();
            this.viewChildren.precommencementpriorlastfymessage.hide();
            this.viewChildren.precommencementcurrentorlastfymessage.hide();
            if (this.model.get('hasPensionCommenced')) {
                this.viewChildren.pensioncommencedmessage.show();
            } else {
                if (this.model.get('isPriorLastFY')) {
                    this.viewChildren.precommencementpriorlastfymessage.show();
                } else {
                    this.viewChildren.precommencementcurrentorlastfymessage.show();
                }
            }
        },

        _showProvideNewNoticeLink: function () {
            if (this.model.get('hasPensionCommenced') ||
                this.model.get('isPriorLastFY') ||
                this.model.get('amountAvailableForNewNotices') <= 0
            ) {
                this.model.set('showProvideNewNoticeLink', false);
            } else {
                this.model.set('showProvideNewNoticeLink', true);
            }
        },

        search: function () {
            var search = this.children.financialyear.children.financialyear;
            var financialYear = search.model.get('financialYear');
            var options = search.model.get('options');
            var found = _.find(options, function (fy) {
                return fy.value === financialYear;
            }, this);
            var financialYearPeriod = found && found.label;
            this._hideMessage('ajaxerror');
            this.model.set({
                financialYear: financialYear,
                financialYearPeriod: financialYearPeriod,
                isPriorLastFY: _.isArray(options) && options.indexOf(found) > 1
            });

            this._fetchScreenData();

            var params = this.getUrlParams();
            this.model.set('contributionHistoryUrl', "#ng/account/contribution/history?a=" + params.a + (params.sc ? '&sc=' + params.sc : ''));
        },

        _fetchScreenData: function () {
            this.view.showSpinner();
            $.when(
                this.fetchData(this.taxdeductionUrl, 'data'),
                this.fetchData(this.contCapsUrl, 'data.resultList.0.contributionCaps'),
                this.fetchData(this.contHistoryUrl, 'data')
            )
                .then(
                    _.bind(function (taxData, contCapsData, contHistoryData) {

                        // hide onetime message when changing years.
                        this._showOneTimeSuccessMessage();

                        var historyTotal = this._getHistoryTotal(contHistoryData);
                        var capsAmount = this._getCapsAmount(contCapsData);
                        var amountAvailableBeforeReachingCap = this._getAmountAvailableBeforeReachingCap(capsAmount, historyTotal, contHistoryData.maxAmount);
                        var totalNotifiedTaxDeductionAmount = _.isObject(contHistoryData) && _.isObject(contHistoryData.contributionSummary) ? contHistoryData.contributionSummary.totalNotifiedTaxDeductionAmount : null;

                        this.model.set('totalContributions', this._formatDollar(totalNotifiedTaxDeductionAmount));
                        this.model.set('totalNotifiedAmount', this._formatDollar(taxData.totalNotifiedAmount));
                        this.model.set('amountAvailableForNewNotices', contHistoryData.maxAmount);
                        this.model.set('amountAvailableBeforeReachingCap', this._formatDollar(amountAvailableBeforeReachingCap));
                        this.model.set('noticesCaptured', _.isObject(taxData) && _.isObject(taxData.notices) && taxData.notices.length);

                        this.view.colorise('.amountBeforeCap', amountAvailableBeforeReachingCap);
                        this.renderViewDeductionTable(taxData);
                        this.view.hideSpinner();
                    }, this),
                    _.bind(function (taxDataError, contCapsDataError, contHistoryDataError) {
                        this._showAjaxErrorMessage(taxDataError || contCapsDataError || contHistoryDataError);
                        this.view.hideSpinner();
                    }, this)
            );
        },

        _getHistoryTotal: function (contHistoryData) {
            if (!(_.isObject(contHistoryData) && _.isObject(contHistoryData.contributionSummary) && _.isObject(contHistoryData.contributionSummary.contributionSummaryClassifications))) {
                return null;
            }
            var historyTotal;
            var historylist = contHistoryData.contributionSummary.contributionSummaryClassifications;
            for (var i = 0; i < historylist.length; i++) {
                if (historylist[i].contributionClassification === "conc") {
                    historyTotal = historylist[i].total;
                }
            }
            return historyTotal;
        },

        _getCapsAmount: function (contCapsData) {
            var capsAmount;
            for (var i = 0; i < contCapsData.length; i++) {
                if (contCapsData[i].contributionClassification === "conc") {
                    capsAmount = contCapsData[i].amount;
                }
            }
            return capsAmount;
        },

        downloadLatestNotice: function () {
            var url = this._getDocumentLibraryUrl();
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },
        _getDocumentLibraryUrl: function (noticeDate) {
            if (!noticeDate) {
                var rows = this.children.viewdeductiontable.model.get('rows');
                var latestNoticeDate = _.first(_.pluck(rows, 'noticeDate'));
                noticeDate = this._formatDate(latestNoticeDate, this.isoDateFormat);
            }

            var urlParams = rootController.getUrlParams();
            return '#ng/account/documents?a=' + urlParams.a + '&type=TAXSUPER&sd=' + noticeDate + '&ed=' + noticeDate;
        },

        _formatDate: function (date, format) {
            return formatHelper.formatDate(date, {
                convertTimezone: true,
                format: format || 'dd MMM YYYY',
                type: 'date'
            });
        },

        _getAmountAvailableBeforeReachingCap: function (capsAmount, historyTotal, maxAmountAvailable) {
            var concessionalAmountRemaining = _.isNumber(capsAmount) ? capsAmount - historyTotal : capsAmount;
            return Math.min(concessionalAmountRemaining, maxAmountAvailable);
        },

        _formatDollar: function (value) {
            return format(value ? value : 0, 'dollar', true);
        },

        _unformatDollar: function (value) {
            return value ? Number(String(value).replace(/[\$\,]/gi, '')) : value;
        },

        renderViewDeductionTable: function (taxData) {
            if (taxData) {
                _.each(taxData.notices, function (row) {

                    if (_.isEmpty(row.pastNotices)) {
                        row.expandable = false;
                    }

                    if (this.model.get('hasPensionCommenced') || this.model.get('isPriorLastFY')) {
                        row.showReduceMenuAction = false;
                    } else {
                        row.showReduceMenuAction = _.isEmpty(row.pastNotices) || row.pastNotices.length === 0 || row.noticeAmount > 0;
                    }
                }, this);
            }

            this.children.viewdeductiontable.setRows({
                rowName: 'notices',
                expand: 'pastNotices'
            }, taxData);
            this.children.viewdeductiontable.renderComponentView();
            this.children.viewdeductiontable.model.set('financialYearPeriod', this.model.get('financialYearPeriod'));
            this.children.viewdeductiontable.model.set('totalNotifiedAmount', this.model.get('totalNotifiedAmount'));
        },

        showNewNoticeOfIntent: function () {
            // new so no docId or other details.
            this.showNoticeOfIntent();
        },

        showNoticeOfIntent: function (docId, originalAmount, unalterableNoticeAmount, originalDocId) {
            this.parentController.model.set('data', {
                docId: docId,
                originalDocId: originalDocId,
                originalAmount: originalAmount,
                unalterableNoticeAmount: this._unformatDollar(unalterableNoticeAmount),
                totalContributions: this._unformatDollar(this.model.get('totalContributions')),
                totalNotifiedAmount: this._unformatDollar(this.model.get('totalNotifiedAmount')),
                amountAvailableForNewNotices: this.model.get('amountAvailableForNewNotices'),
                amountAvailableBeforeReachingCap: this._unformatDollar(this.model.get('amountAvailableBeforeReachingCap')),
                financialYearPeriod: this.model.get('financialYearPeriod'),
                financialYear: this.model.get('financialYear')
            });

            var urlParams = rootController.getUrlParams();
            var url = '#ng/account/contribution/personaltax/deductionnotice?a=' + urlParams.a;
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        },

        getUrlParams: function () {
            return {
                'a': rootController.getUrlParams().a,
                'sc': this.model.get('financialYear')
            };
        },

        fetchData: function (url, path) {
            var deferred = $.Deferred();
            var params = {
                url: this.getUrl(this.getUrlParams(), url),
                success: _.bind(function (data) {
                    data = this.getDataFromObject(data, path || '');
                    deferred.resolve(data);
                }, this),
                error: _.bind(function (jqXHR, textStatus, errorThrown) {
                    deferred.reject(errorThrown);
                }, this)
            };
            this.ajaxGet(params);
            return deferred;
        },

        _showAjaxErrorMessage: function (errorThrown) {
            if (errorThrown === 'timeout') {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0344'));
            }
            this._showMessage('ajaxerror');
        },

        _showMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].hide();
            }
        },

        getDataFromObject: function (data, path) {
            if (data && _.isObject(data) && path) {
                var parts = path.split('.');
                while (data && parts.length) {
                    var part = parts.shift();
                    data = data[part];
                }
            }
            return data;
        },
    });
});
