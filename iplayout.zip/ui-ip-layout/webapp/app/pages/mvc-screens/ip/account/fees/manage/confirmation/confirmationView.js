define([
    'MvcView',
    'rootController'
], function (MvcView, rootController) {
    'use strict';

    return MvcView.extend({

        rootTemplate: {
            headerPanel: 'Fees'
        },

        hideError: function () {
            this.controller.viewChildren.messagealert.hide();
        },
        checkError: function (data) {
            this.clearError();
            var hasErrIP0241;
            var hasErrIP0092;
            var hasErrIP0090;
            var hasErrIP0344;
            for (var i = 0; i < data.data.warnings.length; i++) {
                if (data.data.warnings[i]['errorType'] !== 'error') {
                    continue;
                }
                var code;
                //conversion of error id to cms code
                switch (data.data.warnings[i]['message']) {
                case 'btfg$fee_cap_tariff_offset':
                    if (!hasErrIP0241) {
                        code = 'Err.IP-0241';
                        this.showError(rootController.getCmsEntry(code));
                        hasErrIP0241 = true;
                    }
                    break;
                case 'btfg$fee_cap_tariff_factor':
                    if (!hasErrIP0092) {
                        code = 'Err.IP-0092';
                        this.showError(rootController.getCmsEntry(code));
                        hasErrIP0092 = true;
                    }
                    break;
                case 'btfg$fee_cap_tariff_bnd_factor':
                    if (!hasErrIP0090) {
                        code = 'Err.IP-0090';
                        this.showError(rootController.getCmsEntry(code));
                        hasErrIP0090 = true;
                    }
                    break;
                default:
                    if (!hasErrIP0344) {
                        code = 'Err.IP-0344';
                        this.showError(rootController.getCmsEntry(code));
                        hasErrIP0344 = true;
                    }
                }
            }
        },

        clearError: function () {
            this.controller.viewChildren.messagealert.show();
            var $error = this.$el.find('.view-messagealert .message p');
            $error.html('');
        },

        showError: function (message) {
            var $error = this.$el.find('.view-messagealert .message p');
            $error.append(message + "</br>");
        },

        loadSpinner: function () {
            this.controller.viewChildren.next.loading(true);
            this.controller.viewChildren.cancel.disable();
        },

        unloadSpinner: function () {
            if (this.controller.viewChildren && this.controller.viewChildren.next) {
                this.controller.viewChildren.next.loading(false);
                this.controller.viewChildren.cancel.enable();
            }
        }

    });

});
