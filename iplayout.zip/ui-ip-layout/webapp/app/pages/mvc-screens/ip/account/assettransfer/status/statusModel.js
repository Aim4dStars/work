define(['MvcModel',
        'underscore',
    ],
    function (MvcModel, _) {
        'use strict';

        var TRANSFER_TYPES = {
            'LS_BROKER_SPONSORED': 'LS_BROKER_SPONSORED',
            'LS_ISSUER_SPONSORED': 'LS_ISSUER_SPONSORED',
            'MANAGED_FUND': 'MANAGED_FUND',
            'LS_OTHER': 'LS_OTHER'
        };

        var TRANSFER_STATUS = {
            'CANCELLED': 'CANCELLED',
            'COMPLETE': 'COMPLETED',
            'IN_PROGRESS': 'IN_PROGRESS',
            'WAITING_CGT_COST_BASE': 'WAITING_CGT_COST_BASE',
            'WAITING_DOCUMENTS': 'WAITING_SUPPORT_DOC',
            'PROCESSING_CGT_COST_BASE': 'PROCESSING_CGT_COST_BASE',
            'REVERSED': 'REVERSED'
        };

        return MvcModel.extend({
            processTransfers: function (transfers) {
                transfers = _.map(transfers, function (transfer) {
                    var waitingForCgt = transfer.transferStatus === TRANSFER_STATUS.WAITING_CGT_COST_BASE || transfer.transferStatus === TRANSFER_STATUS.PROCESSING_CGT_COST_BASE;
                    var waitingForDocuments = transfer.transferStatus === TRANSFER_STATUS.WAITING_DOCUMENTS;
                    transfer.transferDate = new Date(transfer.transferDate);
                    transfer.showMenuAction = transfer.initiatedOnline && (waitingForCgt || waitingForDocuments);
                    _.each(transfer.transferItems, function (transferItem) {
                        transferItem.sponsorDetails = transfer.sponsorDetails;
                        transferItem.parentStatus = transfer.transferStatus;
                    });
                    return transfer;
                });
                return transfers;
            },

            filter: function (assetTransfers) {
                assetTransfers = this.filterByAssetStatus(assetTransfers);
                assetTransfers = this.filterByAssetType(assetTransfers);
                return assetTransfers;
            },

            sort: function (assetTransfers) {
                assetTransfers = _.sortBy(assetTransfers, function (assetTransfer) {
                    return -(assetTransfer.transferDate.getTime());
                });
                return assetTransfers;
            },

            filterByAssetStatus: function (assetTransfers) {
                var transferStatus = this.get('transferStatus');
                if (transferStatus === 'cancelled') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferStatus === TRANSFER_STATUS.CANCELLED;
                    });
                } else if (transferStatus === 'complete') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferStatus === TRANSFER_STATUS.COMPLETE;
                    });
                } else if (transferStatus === 'inprogress') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferStatus === TRANSFER_STATUS.IN_PROGRESS;
                    });
                } else if (transferStatus === 'waiting') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        var waitingForCgt = assetTransfer.transferStatus === TRANSFER_STATUS.WAITING_CGT_COST_BASE;
                        var waitingForDocuments = assetTransfer.transferStatus === TRANSFER_STATUS.WAITING_DOCUMENTS;
                        var processingCgt = assetTransfer.transferStatus === TRANSFER_STATUS.PROCESSING_CGT_COST_BASE;
                        return waitingForCgt || waitingForDocuments || processingCgt;
                    });
                }

                return assetTransfers;
            },

            filterByAssetType: function (assetTransfers) {
                var transferType = this.get('transferType');
                if (transferType === 'broker') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferType === TRANSFER_TYPES.LS_BROKER_SPONSORED;
                    });
                } else if (transferType === 'issuer') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferType === TRANSFER_TYPES.LS_ISSUER_SPONSORED;
                    });
                } else if (transferType === 'managedfunds') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferType === TRANSFER_TYPES.MANAGED_FUND;
                    });
                } else if (transferType === 'custodian') {
                    assetTransfers = _.filter(assetTransfers, function (assetTransfer) {
                        return assetTransfer.transferType === TRANSFER_TYPES.LS_OTHER;
                    });
                }

                return assetTransfers;
            },
        });
    });
