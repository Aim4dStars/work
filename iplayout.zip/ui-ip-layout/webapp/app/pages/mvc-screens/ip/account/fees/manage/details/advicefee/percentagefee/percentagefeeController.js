defineMvcController({
    name: 'percentagefee',
    parentPath: 'mvc-screens/ip/account/fees/manage/details/advicefee',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    viewComponents: ['button', 'forminputtext', 'forminputcheckbox'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            var data = this.parentController.model.get('data');
            if (data && data.feesComponent) {
                var feesComponent = data.feesComponent;
                for (var j in feesComponent) {
                    if (feesComponent[j].type === 'PercentageFee') {
                        this.model.set('managedportfolios', feesComponent[j].managedPortfolio === 0 ? '0.00' : feesComponent[j].managedPortfolio);
                        this.model.set('listedsecurities', feesComponent[j].share === 0 ? '0.00' : feesComponent[j].share);
                        this.model.set('managedfunds', feesComponent[j].managedFund === 0 ? '0.00' : feesComponent[j].managedFund);
                        this.model.set('termdeposits', feesComponent[j].termDeposit === 0 ? '0.00' : feesComponent[j].termDeposit);
                        this.model.set('cash', feesComponent[j].cash === 0 ? '0.00' : feesComponent[j].cash);
                    }
                }
            }
            this.model._updatePercentageValidation('listedsecurities');
            this.model._updatePercentageValidation('managedfunds');
            this.model._updatePercentageValidation('managedportfolios');
            this.model._updatePercentageValidation('termdeposits');
            this.model._updatePercentageValidation('cash');
        },

        deleteChildCell: function () {
            this.parentController.deleteChildCell(this.name);
        },

        getValues: function () {
            var valid = false;
            if (this.validateAndSubmitForm(this.view.getSubmitEvent()) && this.model.validateFeesComponent()) {
                valid = true;
            }
            return {
                valid: valid,
                value: {
                    managedPortfolio: this.model.get('managedportfolios') !== '' ? this.model.get('managedportfolios') : 0,
                    share: this.model.get('listedsecurities') !== '' ? this.model.get('listedsecurities') : 0,
                    managedFund: this.model.get('managedfunds') !== '' ? this.model.get('managedfunds') : 0,
                    termDeposit: this.model.get('termdeposits') !== '' ? this.model.get('termdeposits') : 0,
                    cash: this.model.get('cash') !== '' ? this.model.get('cash') : 0,
                    type: 'PercentageFee',
                    label: "Percentage fee component"
                }
            };
        },

        hidePercentageError: function () {
            this.view.hidePercentageError();
        },

        showPercentageError: function () {
            this.view.showPercentageError();
        }

    });
});
