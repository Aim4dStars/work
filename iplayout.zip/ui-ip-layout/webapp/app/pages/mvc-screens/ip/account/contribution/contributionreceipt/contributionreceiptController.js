defineMvcController({
    name: 'contributionreceipt',
    parentPath: 'mvc-screens/ip/account/contribution',
    viewHtml: true,
    viewJs: false,
    screens: [],
    hashName: 'contributionreceipt',
    viewComponents: ['transferstatus'],
    dependencies: ['rootController', 'app/framework/router', 'underscore'],
    extend: 'MvcController'
}, function (config, MvcController, rootController, router, _) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            var data = this.parentController.model.get('submitResponse');
            this.parentController.model.set('submitResponse.frequency', _.isNull(data.frequency) ? 'Once' : data.frequency);
            if (_.isUndefined(data)) {
                this.parentController.show({
                    updateLocationHash: true,
                    preserveQueryStringParams: true
                });
            }
        },

        navigateToContributionForm: function () {
            var submitResponse = this.parentController.model.get('submitResponse');
            var toEditSavedContribution = this.parentController.getDataSubmissionFromReceipt(submitResponse);
            this.parentController.model.set('toEditSavedContribution', toEditSavedContribution);
            var frequency = submitResponse.frequency;
            var urlParams = rootController.getUrlParams();
            var regularFormUrl = "#ng/account/contribution/regularcontribution?a=" + urlParams.a;
            var oneoffFormUrl = "#ng/account/contribution/oneoffcontribution?a=" + urlParams.a;
            var url = _.isEqual(frequency, 'Once') ? oneoffFormUrl : regularFormUrl;
            router.appRouter.navigate(url, {
                trigger: true,
                replace: false
            });
        }
    });
});
