define([
    'MvcView',
    'app/framework/services/spinnerService',
], function (MvcView, spinnerService) {
    'use strict';

    return MvcView.extend({
        spinner: spinnerService.createSpinner('medium', {
            position: 'relative'
        }),

        toggleSpinner: function (bool) {
            this.spinner(bool, this.$el.find('.mvc-oneoffwithdrawal'), this.$el.find('.mvc-oneoffwithdrawal table'));
        }

    });
});
