defineMvcController({
    name: 'individualstatus',
    hashName: 'individualstatus',
    parentPath: 'mvc-screens/ip/account/assettransfer',
    screens: ['mvc-screens/ip/account/assettransfer/inspecie/providedocuments'],
    viewHtml: true,
    modelJs: false,
    viewJs: true,
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore']
}, function (config, MvcController, rootController, _) {
    'use strict';

    return MvcController.extend({
        config: config,
        assetTransferUrl: '../api/inspecietransfer/v2_0/accounts/<%=a%>/inspecie-transfer/<%=t%>',
        autoHideSpinner: false,

        preRender: function () {
            var params = rootController.getUrlParams();
            var transferId = params['t'];
            this.model.set("accountId", params['a']);
            this.fetchAssetTransfer(transferId);
        },

        fetchAssetTransfer: function () {
            var url = this.getUrl(rootController.getUrlParams(), this.assetTransferUrl);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    this.populateUploadDocuments(data.data);
                }, this)
            };

            return this.ajaxGet(params);
        },

        populateUploadDocuments: function (data) {
            this.model.set("transferData", data);
            this.model.set("transferId", data.key.transferId);
            this.model.set("showSupportingDoc", true);
            this.model.set("showCGTCostBase", false);
            this.removeChildren();
            this.removeViewChildren();
            this.view.render();
            var childName = 'providedocuments';
            this.children[childName].removeChildren();
            this.children[childName].removeViewChildren();
            this.children[childName].setUploadDocumentsData(data.transferType, data.isCBO, false);
            this.children[childName].setSupportingDocumentLinks();
            this.children[childName].view.render();
            this.view.hideSpinner();
        },

        openAssetTransferSupport: function () {
            var assettransferHelpUrl = this.parentController.getAssetTransferSupportUrl();
            window.open(assettransferHelpUrl, 'Asset Transfer');
        }
    });
});
