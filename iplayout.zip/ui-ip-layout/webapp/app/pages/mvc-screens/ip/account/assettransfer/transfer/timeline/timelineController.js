defineMvcController({
    name: 'timeline',
    parentPath: 'mvc-screens/ip/account/assettransfer/transfer',
    viewHtml: true,
    viewJs: true,
    extend: 'MvcController',
    viewComponents: ['icon'],
    dependencies: []
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        postRender: function () {
            var pageState = this.parentController.model.get('pageState');
            this.model.set('screenState', pageState);
            this.model.on('change:screenState', this.changeStepByScreenState, this);
            this.view.hideBackButton();
        },

        goBack: function () {
            this.parentController.children.transferform.children.cancel.openModal();
        },

        changeStepByScreenState: function () {
            var timelineStep = this.model.get('screenState');
            this.changeTimelineStepsView(timelineStep);
        },

        changeTimelineStepsView: function (timelineStep) {
            this.parentController.removeDocumentsState();
            switch (timelineStep) {
            case 'wizard':
                this.view.hideBackButton();
                this.view.showParentTimeLine();
                this.view.resetToInitialState();
                break;
            case 'table':
                this.view.showChildTimeLine();
                this.view.showBackButton();
                this.view.completedTransferTypeStep();
                break;
            case 'submit':
                this.view.completedAssetHoldingStep();
                break;
            case 'addDocuments':
                this.parentController.addDocumentsState();
                this.view.hideBackButton();
                this.view.hideParentTimeLine();
                this.view.hideChildTimeLine();
                break;
            }
        }
    });
});
