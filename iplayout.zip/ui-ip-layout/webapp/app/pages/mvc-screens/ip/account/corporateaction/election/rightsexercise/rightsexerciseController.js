defineMvcController({
    name: 'rightsexercise',
    parentPath: 'mvc-screens/ip/account/corporateaction/election',
    viewHtml: true,
    modelJs: true,
    viewJs: true,
    mvcComponents: ['tableoptions', 'tablev3', 'menuactioninput'],
    viewComponents: ['inputselect', 'forminputtext'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/rightsexercise/rightsexerciseController'
}, function (config, RightsExerciseController) {
    'use strict';

    return RightsExerciseController.extend({
        config: config
    });
});
