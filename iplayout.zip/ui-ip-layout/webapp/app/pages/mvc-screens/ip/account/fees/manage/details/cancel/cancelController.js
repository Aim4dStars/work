defineMvcController({
    name: 'cancel',
    parentPath: 'mvc-screens/ip/account/fees/manage/details',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal'
}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config,

        cancelForm: function () {
            this.closeModal();
            window.history.go(-1);
        }
    });
});
