define([
    'MvcView',
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            menuTabs: [{
                label: 'Account details',
                url: '#/app/adviser/account/<=a=>/details/account-details',
                child: 'accountdetails',
                bindHrefParam: 'a'
            }, {
                label: 'Additional services',
                url: '#/app/adviser/account/<=a=>/details/additional-services',
                child: 'additionalservices',
                bindHrefParam: 'a',
                permission: {
                    rule: '!account.type.super',
                    tree: 'a'
                }
            }, {
                label: 'Tax & preservation components',
                url: '#/app/adviser/account/<=a=>/details/tax-and-preservation',
                child: 'taxandpreservation',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.taxpreservation.view',
                    tree: 'a'
                }
            }, {
                label: 'Beneficiaries',
                url: '#/app/adviser/account/<=a=>/details/beneficiary',
                child: 'beneficiariesautorev',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.beneficiaries.view',
                    tree: 'a'
                }
            }, {
                label: 'Commence pension',
                url: '#ng/account/details/pensioncommencement',
                child: 'pensioncommencement',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.pension.commencement.view',
                    tree: 'a'
                }
            }]
        }
    });
});
