define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/rightsexercise/rightsexerciseView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/rightsexercise/_rightsexercise.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (RightsExerciseView, _rightsexerciseTemplate, componentXml, Handlebars) {
    'use strict';

    return RightsExerciseView.extend({
        formSelector: '.rightsexercise-form',

        preRender: function () {
            Handlebars.registerPartial('rightsexercise', componentXml.encode(_rightsexerciseTemplate));
        }
    });

});
