defineMvcController({
    name: 'confirmwithdrawal',
    parentPath: 'mvc-screens/ip/account/accessingsuper/editoneoffwithdrawal',
    viewHtml: true,
    viewJs: true,
    mvcComponents: [],
    viewComponents: [],
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['underscore', 'app/pages/mvc-screens/ip/account/accessingsuper/accessingsuperServices', 'app/pages/mvc-screens/ip/services/accountService'],
    extend: 'app/pages/mvc-templates/modal/modalController'
}, function (config, ModalController, _, accessingsuperServices, accountService) {
    'use strict';

    return ModalController.extend({
        config: config,

        submitWithdrawal: function () {
            if (!_.isUndefined(this.viewChildren.termsandconditions) && _.isEmpty(this.model.get('termsandconditions'))) {
                this.viewChildren.termsandconditions.turnintoTooltip();
                return;
            }
            this.viewChildren.submitwithdrawal.loading(true);
            var withdrawal = this.parentController.model.get('confirmWithdrawal');
            this.parentController.checkIsSavedWithdrawalPresent(withdrawal);
            accessingsuperServices.submitWithdrawal(this, withdrawal)
                .done(_.bind(function (data) {
                    this.viewChildren.submitwithdrawal.loading(false);
                    if (_.isUndefined(data) || !_.isEmpty(data.errors)) {
                        var errors = accessingsuperServices.mapErrors(data.errors);
                        this._showSubmissionErrors(errors);
                    } else {
                        accountService.getAccount(this, true).always(_.bind(function () {
                            this.closeModal();
                            accessingsuperServices._navigateToWithdrawingSuperDetails(this);
                            this.parentController.parentController.children.withdrawingsuper.showSuccessfulSavedMessage('oneoffwithdrawalsuccessmessage', true);
                        }, this));
                    }
                }, this))
                .fail(_.bind(function () {
                    this.parentController.model.set('showGenericError', true);
                    this.viewChildren.submitwithdrawal.loading(false);
                    this.closeModal();
                }, this));
        },

        _showSubmissionErrors: function (errors) {
            var nonRecoverableError = _.find(errors, function (error) {
                return error.nonRecoverable === true;
            });

            // always go to View payments screen if there is a non-recoverable error
            if (!_.isUndefined(nonRecoverableError)) {
                this.parentController.parentController.setNonRecoverableErrorType('oneoffWithdrawal');
                accessingsuperServices._navigateToWithdrawingSuperDetails(this);
            } else {
                accessingsuperServices._displayMessageAlert(this.parentController.viewChildren.errormessage, _.pluck(errors, 'message'));
                this.closeModal();
                this.view.hideSpinner();
            }
        }

    });
});
