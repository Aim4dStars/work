define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/mandatoryreport/mandatoryreportView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/mandatoryreport/_mandatoryreport.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (MandatoryReportView, _mandatoryreportTemplate, componentXml, Handlebars) {
    'use strict';

    return MandatoryReportView.extend({

        preRender: function () {
            Handlebars.registerPartial('mandatoryreport', componentXml.encode(_mandatoryreportTemplate));
        }
    });

});
