defineMvcController({
    name: 'details',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    modelJs: false,
    hashName: 'details',
    screens: ['accountdetails', 'pensioncommencement', 'beneficiariesautorev'],
    extend: 'MvcController',
    dependencies: []
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,
    });
});
