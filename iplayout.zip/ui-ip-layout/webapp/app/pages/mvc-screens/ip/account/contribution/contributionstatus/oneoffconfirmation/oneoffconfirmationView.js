define([
    'app/pages/mvc-screens/ip/account/movemoney/deposits/details/confirmation/confirmationView'
], function (SuperView) {
    'use strict';

    return SuperView.extend({});

});
