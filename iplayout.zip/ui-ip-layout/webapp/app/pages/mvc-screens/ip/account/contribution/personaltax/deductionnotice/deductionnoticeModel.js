define([
    'MvcModel'
], function (MvcModel) {
    'use strict';

    return MvcModel.extend({

        amountMinValue: function (amount) {
            var unalterableNoticeAmount = this.get('unalterableNoticeAmount');
            var docId = this.get('docId');
            if (docId) {
                // for vary notice, allow zero value;
                return (unalterableNoticeAmount || 0) <= amount;
            }
            return 0 < amount;
        },
        amountMaxValue: function (amount) {
            var amountAvailableForNewNotices = this.get('amountAvailableForNewNotices');
            var originalAmount = this.get('originalAmount');
            if (originalAmount) {
                return originalAmount > amount;
            }
            return amountAvailableForNewNotices >= amount;
        },
        validation: {
            amount: {
                blur: {
                    required: true,
                    customMinValue: 'amountMinValue',
                    customMaxValue: 'amountMaxValue'
                }
            }
        }
    });
});
