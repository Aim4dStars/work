defineMvcController({
    name: 'uploaddocuments',
    parentPath: 'mvc-screens/ip/account/assettransfer/transfer',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['inputtext'],
    screens: ['upload'],
    extend: 'MvcController',
    dependencies: ['app/framework/router', 'underscore', 'rootController', 'app/framework/services/Permissions']
}, function (config, MvcController, router, _, rootController, Permissions) {
    'use strict';

    return MvcController.extend({
        config: config,

        viewEvents: {
            'click .errorhref': 'openErrorModal'
        },

        preRender: function () {
            this.model.set('accountId', rootController.getUrlParams().a);
            var formsPageHelpUrl = this.getFormsPageHelpUrl();
            this.model.set('formsPageHelpUrl', formsPageHelpUrl);
        },

        postRender: function () {
            var params = rootController.getUrlParams();
            var transferId = params['t'];

            if (_.isUndefined(transferId)) {
                this.parentController.view.hidePMMessage();
                var cbo = true;
                var transferType = this.parentController.model.get('transferType');
                if (this.parentController.model.get('cbo') === 'no') {
                    cbo = false;
                }
                this.setUploadDocumentsData(transferType, cbo, true);
                rootController.confirmNavigation(false);
                this.setSupportingDocumentLinks();

                this.view.setScrollIntoView({
                    element: this.view.$el.find('.mvc-uploaddocuments')
                });
            }

            this.model.on('change:modelupload', _.bind(this._fileSelected, this));

        },

        setUploadDocumentsData: function (transferType, cbo, newTransfer) {
            var showSupportingDocumentBox = true;
            var showCGTCostBaseBox = !cbo;
            if (!newTransfer && !this.parentController.model.get('showSupportingDoc')) {
                showSupportingDocumentBox = false;
            }
            if (!newTransfer && !this.parentController.model.get('showCGTCostBase')) {
                showCGTCostBaseBox = false;
            }
            this.model.set({
                "transferType": transferType,
                "cbo": cbo,
                "newTransfer": newTransfer,
                "showSupportingDocumentBox": showSupportingDocumentBox,
                "showCGTCostBaseBox": showCGTCostBaseBox
            });
        },

        getFormsPageHelpUrl: function () {
            if (Permissions.ruleMatched('feature.global.aemEnabled')) {
                var path = '/content/secure/help-and-support/bt/en/' + rootController.getStaticPageRole() + '/home/welcome/forms.html';
                return rootController.getCmsHost() + path;
            } else {
                return '/ng/public/content/helpandsupport/static-templates/' + rootController.getStaticPageRole() + '/forms.html';
            }
        },

        setSupportingDocumentLinks: function () {
            var transferType = this.model.get("transferType");
            if (!_.isUndefined(transferType)) {
                transferType = transferType.toLowerCase();
            }
            this.resetDocumentLinks();
            var cbo = this.model.get("cbo");
            if (cbo) {
                this.setCBOLinks(transferType);
            } else {
                this.setNCBOLinks(transferType);
            }
        },

        setCBOLinks: function (transferType) {
            if (transferType === 'listed securities broker sponsored') {
                this.model.set("showASTF", true);
                this.model.set("showHoldingBS", true);
            } else if (transferType === 'listed securities issuer sponsored') {
                this.model.set("showASTF", true);
                this.model.set("showHoldingIS", true);
                this.model.set("showID", true);
            } else if (transferType === 'listed securities other platform or custodian') {
                this.model.set("showPVReport", true);
                this.model.set("showANDLS", true);
            } else if (transferType === 'managed funds') {
                this.model.set("showASTFMF", true);
                this.model.set("showHoldingMF", true);
                this.model.set("showANDMF", true);
            }
        },

        setNCBOLinks: function (transferType) {
            if (transferType === 'listed securities broker sponsored') {
                this.model.set("showASTFncbo", true);
                this.model.set("showHoldingBS", true);
            } else if (transferType === 'listed securities issuer sponsored') {
                this.model.set("showHoldingIS", true);
                this.model.set("showASTFncbo", true);
            } else if (transferType === 'listed securities other platform or custodian') {
                this.model.set("showLPOACustodian", true);
                this.model.set("showPVReport", true);
                this.model.set("showANDLS", true);
            } else if (transferType === 'managed funds') {
                this.model.set("showHoldingMF", true);
                this.model.set("showANDMF", true);
            }
        },

        resetDocumentLinks: function () {
            this.model.set({
                "showASTF": false,
                "showHoldingBS": false,
                "showHoldingIS": false,
                "showHoldingMF": false,
                "showID": false,
                "showPVReport": false,
                "showANDLS": false,
                "showANDMF": false,
                "showASTFncbo": false,
                "showLPOACustodian": false
            });
        },

        chooseFile: function () {
            if (window.FormData) {
                this.model.unset('modelupload', {
                    silent: true
                });
                this.view.clickModelUpload();
            } else {
                this.uploadTaxParcel();
            }
        },

        uploadTaxParcel: function () {
            var files = this.view.getModelUpload().get(0).files;
            var uploadFile = null;
            var uploadFileSize = null;
            var uploadFileName = null;
            if (_.isObject(files) && files.length !== 0) {
                uploadFile = files[0];
                uploadFileSize = uploadFile.size + "KB";
                uploadFileName = uploadFile.name;
            }
            this.children.upload.openModal({
                'uploadFileName': uploadFileName,
                'uploadFileSize': uploadFileSize,
                'modal': 'upload',
                'transferId': this.parentController.model.get('transferId')
            });

            rootController.confirmNavigation(true);
        },

        _fileSelected: function () {
            this.uploadTaxParcel();
        },

        showSuccessMessage: function () {
            rootController.confirmNavigation(false);
            this.view.showSuccessMessage();
        },

        openErrorModal: function () {
            this.children.upload.openModal({
                'modal': 'error',
                'errors': this.model.get('errors')
            });
            return false;
        },

        openFormsPage: function () {
            var formsPageHelpUrl = this.model.get('formsPageHelpUrl');
            window.open(formsPageHelpUrl, 'Forms');
        },

        gotoCreateTransfer: function () {
            var params = rootController.getUrlParams();
            var transferId = params['t'];
            var accountId = this.model.get('accountId');
            if (_.isUndefined(transferId)) {
                this.parentController.back();
            } else {
                var url = "#ng/account/assettransfer/transfer?a=" + accountId;
                router.appRouter.navigate(url, {
                    trigger: true,
                    replace: false
                });
            }
        }
    });
});
