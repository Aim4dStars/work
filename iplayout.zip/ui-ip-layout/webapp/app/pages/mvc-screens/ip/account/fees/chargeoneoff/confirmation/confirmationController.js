defineMvcController({
    name: 'confirmation',
    parentPath: 'mvc-screens/ip/account/fees/chargeoneoff',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    viewComponents: ['forminputtext', 'button', 'messagedisclaimer'],
    screens: ['cancel'],
    hashName: 'confirmation',
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore']
}, function (config, MvcController, rootController, _) {
    'use strict';

    return MvcController.extend({
        config: config,

        viewEvents: {
            'submit form': 'submit'
        },

        preRender: function () {
            if (!this.parentController.isPreviousStepValid(this.name)) {
                this.parentController.showLastValidStep();
            } else {
                rootController.confirmNavigation(true);
                this.parentController.model.bindAttributeToOtherModel({
                    'feesAmount': 'feesAmount',
                    'description': 'description',
                    'accountId': 'accountId'
                }, this.model);
                this.model.set('absFeesAmount', this.parentController.absFeeAmount(this.model.get('feesAmount')));
                this.parentController.formFail(this.name);
            }
        },

        postRender: function () {
            this.view.hideError();
            this.parentController.omnitureEventTrigger(this, "start");
        },

        submit: function (event) {
            var validationResult = this.validateAndSubmitForm(event);
            if (validationResult) {
                if (!this.viewChildren.next.isLoading()) {
                    rootController.confirmNavigation(false);
                    this.parentController.formSuccess(this.name);
                }
            } else {
                if (!this.model.get('disclaimer')) {
                    this.viewChildren.termsandconditions.turnintoTooltip();
                    this.parentController.formFail(this.name);
                }
            }
        },

        openModal: function () {
            if (this.children && this.children.cancel) {
                rootController.confirmNavigation(false);
                this.children.cancel.openModal();
            }
        },

        generatePdf: function () {
            rootController.confirmNavigation(false);
            var description = _.isNull(this.model.get('description')) || _.isEmpty(this.model.get('description')) ? '-' : this.model.get('description');
            var url = '../reportpdf/oneOffFeesAdviceAuthorisationForm?feesAmount=' + this.model.get('feesAmount') + '&description=' + description + '&account-id=' + rootController.getUrlParams().a;
            window.open(url);
            rootController.confirmNavigation(true);
        }

    });

});
