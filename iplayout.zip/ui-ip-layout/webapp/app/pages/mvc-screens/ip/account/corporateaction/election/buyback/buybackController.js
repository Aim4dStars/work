defineMvcController({
    name: 'buyback',
    parentPath: 'mvc-screens/ip/account/corporateaction/election',
    viewHtml: true,
    modelJs: false,
    viewJs: true,
    viewComponents: ['inputselect'],
    screens: ['selectedbuybackoptions'],
    extend: 'app/pages/mvc-screens/ip/tracking/corporateaction/election/baseelectionform/baseelectionformController',
}, function (config, BaseElectionFormController) {
    'use strict';

    return BaseElectionFormController.extend({
        config: config
    });
});
