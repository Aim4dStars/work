defineMvcController({
    name: 'personaltax',
    parentPath: 'mvc-screens/ip/account/contribution',
    viewHtml: true,
    hashName: 'personaltax',
    extend: 'MvcController',
    screens: ['deductionnotice', 'viewdeduction'],
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

    });
});
