defineMvcController({
    name: 'editdetails',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    viewComponents: ['inputcheckbox', 'button', 'forminputselect', 'messagealert'],
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['underscore', 'rootController', 'jquery', 'app/framework/services/Permissions']
}, function (config, ModalController, _, rootController, $, Permissions) {
    'use strict';

    return ModalController.extend({
        config: config,

        postRender: function () {
            this.setFYs();
        },

        setFYs: function () {
            var financialYears = _.clone(this.parentController.model.get('financialYears'));
            if (financialYears) {
                financialYears.unshift({
                    label: 'Select',
                    value: 'any'
                });
                this.viewChildren.financialyear.setOptions(financialYears);
            }
        },

        submit: function () {
            this.loadSpinner();
            var updateDocInfo = {
                'financialYear': this.model.get('financialYear') !== 'any' ? this.model.get('financialYear') : '',
                'status': this.model.get('status') === this.parentController.DOCUMENT_STATUS.DRAFT ? this.parentController.DOCUMENT_STATUS.DRAFT : this.parentController.DOCUMENT_STATUS.FINAL
            };

            if (Permissions.ruleMatched('account.document.audit.edit', rootController.getUrlParams().a)) {
                updateDocInfo.audit = this.model.get('audit') ? true : false;
            }

            $.when(this.parentController.updateProperties(this.model.get('key').documentId, updateDocInfo))
                .done(_.bind(function () {
                    this.closeModal();
                    this.parentController.fetchDocuments();
                }, this))
                .fail(_.bind(function (errorThrown) {
                    this.unloadSpinner();
                    this.parentController.showErrorMessage(errorThrown, this);
                }, this));
        },

        loadSpinner: function () {
            this.viewChildren.save.loading(true);
            this.viewChildren.cancel.disable();
        },

        unloadSpinner: function () {
            this.viewChildren.save.loading(false);
            this.viewChildren.cancel.enable();
        }

    });

});
