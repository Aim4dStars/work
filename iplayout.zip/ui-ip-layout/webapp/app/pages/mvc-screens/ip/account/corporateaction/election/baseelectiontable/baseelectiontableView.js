define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/baseelectiontable/baseelectiontableView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/baseelectiontable/_baseelectiontable.html',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/baseelectiontable/_baseelectiontablerow.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (BaseElectiontableView, baseElectionTableTemplate, baseElectionTableRowTemplate, componentXml, Handlebars) {
    'use strict';

    return BaseElectiontableView.extend({
        preRender: function () {
            Handlebars.registerPartial('baseelectiontable', componentXml.encode(baseElectionTableTemplate));
            Handlebars.registerPartial('baseelectiontable-row', componentXml.encode(baseElectionTableRowTemplate));
        }
    });

});
