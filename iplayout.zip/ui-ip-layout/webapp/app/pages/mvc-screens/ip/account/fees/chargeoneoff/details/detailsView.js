define([
    'app/pages/mvc-screens/ip/account/fees/chargeoneoff/chargeoneoffView'
], function (chargeoneoffView) {
    'use strict';

    return chargeoneoffView.extend({
        rootTemplate: {
            /*headerPanel: 'Charge one-off advice fee',*/
            headerPanel: 'Fees'
        },

        loadSpinner: function () {
            this.controller.viewChildren.next.loading(true);
            this.controller.viewChildren.cancel.disable();
        },

        unloadSpinner: function () {
            if (this.controller.viewChildren && this.controller.viewChildren.next) {
                this.controller.viewChildren.next.loading(false);
                this.controller.viewChildren.cancel.enable();
            }
        },

        showSnapShotErrorMessage: function () {
            this.$el.find('.js-snapshot').html("<span>Unable to load</span>");
        },
    });

});
