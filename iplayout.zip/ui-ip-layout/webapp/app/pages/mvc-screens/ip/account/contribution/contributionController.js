defineMvcController({
    name: 'contribution',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    hashName: 'contribution',
    screens: ['history', 'contributionstatus', 'oneoffcontribution', 'regularcontribution', 'personaltax', 'contributionreceipt'],
    dependencies: ['app/pages/mvc-screens/ip/services/accountService', 'rootController',
    'jquery', 'underscore'],
    extend: 'MvcController'
}, function (config, MvcController, accountService, rootController, $, _) {
    'use strict';

    return MvcController.extend({
        config: config,
        targetId: 'a',
        requiredParams: ['a'],
        hasPermission: 'account.super.contribution.view',
        statusSortingOrder: ['NOT_SUBMITTED', 'PENDING', 'SUBMITTED'],

        preRender: function () {
            var params = rootController.getUrlParams();
            this.model.set("accountId", params['a']);
        },

        showLinkedAccountValidation: function () {
            this.children.regularcontribution.showLinkedAccountValidation();
        },

        showOneOffLinkedAccountValidation: function () {
            this.children.oneoffcontribution.showLinkedAccountValidation();
        },

        showGraceMessage: function () {
            this.viewChildren.gracemessage.hide();
        },

        hideGraceMessage: function () {
            this.viewChildren.gracemessage.hide();
        },

        postRender: function () {
            if (!_.isUndefined(this.children.contributionreceipt)) {
                this.children.contributionreceipt.hide();
            }
            this.getAccountDetails();
            this.hideGraceMessage();
        },

        getAccountDetails: function () {
            $.when(accountService.getAccount(this)).done(_.bind(function (accountDetails) {
                this.model.set('accountDetails', accountDetails);
            }, this));
        },

        _getToPayeeDto: function (payeeList) {
            return {
                moneyAccountId: payeeList.moneyAccountId,
                moneyAccountName: payeeList.moneyAccountName,
                moneyAccountBsb: payeeList.moneyAccountBsb ? payeeList.moneyAccountBsb.replace('-', '') : ''
            };
        },

        getDataSubmissionFromReceipt: function (submitResponse) {
            return {
                contributionType: submitResponse.depositType,
                fromPayDto: submitResponse.fromPayDto,
                frequency: submitResponse.frequency,
                amount: submitResponse.amount,
                startDate: submitResponse.transactionDate,
                endRepeatNumber: submitResponse.endRepeatNumber,
                endDate: submitResponse.repeatEndDate
            };
        }
    });

});
