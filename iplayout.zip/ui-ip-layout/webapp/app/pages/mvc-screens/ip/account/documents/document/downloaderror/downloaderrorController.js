defineMvcController({
    name: 'downloaderror',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
}, function (config, ModalController) {
    'use strict';

    return ModalController.extend({
        config: config,

    });

});
