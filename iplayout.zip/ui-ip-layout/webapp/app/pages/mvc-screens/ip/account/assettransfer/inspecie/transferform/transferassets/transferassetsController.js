defineMvcController({
    name: 'transferassets',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie/transferform',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    viewComponents: ['snapshot', 'inputtext', 'termsandconditions', 'messagedisclaimer', 'tooltip', 'forminputautocomplete'],
    mvcComponents: ['tablev3', 'inputautocomplete'],
    extend: 'MvcController',
    dependencies: ['app/framework/services/Permissions', 'rootController', 'jquery', 'underscore']
}, function (config, MvcController, Permissions, rootController, $, _) {
    'use strict';

    var NUM_ROWS = 5;

    return MvcController.extend({
        config: config,

        dataTypes: {
            listedSecurityChessSponsored: ['asxcode', 'quantity', 'hin', 'sponsorname'],
            listedSecuritiesIssuerSponsored: ['asxcode', 'quantity', 'srn'],
            managedFunds: ['apircode', 'mfquantity', 'account', 'custodian'],
            listedsecuritycustodian: ['asxcode', 'quantity', 'hinaccount', 'sponsorname']
        },

        requiredFields: {
            listedSecurityChessSponsored: ['asxcode', 'quantity'],
            listedSecuritiesIssuerSponsored: ['asxcode', 'quantity'],
            managedFunds: ['apircode', 'mfquantity'],
            listedsecuritycustodian: ['asxcode', 'quantity']
        },

        replicatedFields: ['hinaccount', 'hin', 'account', 'custodian'],

        postRender: function () {
            this.model.set({
                numAssets: 0
            });
            this.initializeAssets();
            this.renderAssetTable();
        },

        initializeAssets: function () {
            this.model.set('assets', []);
            _.times(NUM_ROWS, this.createAsset, this);
        },

        createAsset: function () {
            var numAssets = this.model.get('numAssets');
            var newAsset = {
                id: ++numAssets
            };
            this.model.set('numAssets', numAssets);
            var assets = this.model.get('assets');
            assets.push(newAsset);
            this.initAssetValidation(newAsset);
        },

        initAssetValidation: function (asset) {
            var assetSource = this.model.get('assetSource');

            var dataTypes = this.dataTypes[assetSource];
            _.each(dataTypes, function (attribute) {
                // Replicated fields all get the same bound value
                if (_.contains(this.replicatedFields, attribute)) {
                    return;
                }

                var attributeName = attribute + '_' + asset.id;
                this.model.validation[attributeName] = this.model.validation[attribute];
                this.model.on('change:' + attributeName, this.dataChanged, this);
            }, this);
        },

        renderAssetTable: function () {
            if (!this.children.assets) {
                return;
            }

            this.children.assets.setRows({}, this.model.get('assets'));
            this.children.assets.renderComponentView();

            this.updateDeleteRowButtons();
            this.view.updateDynamicDisabledFields();
        },

        updateDeleteRowButtons: function () {
            var assets = this.model.get('assets');
            if (_.isArray(assets) && assets.length <= 1) {
                this.applyToButtons(function (viewChild) {
                    viewChild.disable();
                });
            }
        },

        applyToButtons: function (func) {
            _.each(this.children.assets.viewChildren, function (viewChild, viewChildName) {
                if (viewChildName.indexOf('button') !== -1) {
                    func.call(this, viewChild);
                }
            });
        },

        deleteAsset: function (id) {
            id = parseInt(id, 10);
            var assets = this.model.get('assets');
            assets = _.filter(assets, function (asset) {
                return asset.id !== id;
            });
            this.model.unset('assets');
            this.model.set('assets', assets);
            this.model.set('numAssets', assets.length);

            var assetSource = this.model.get('assetSource');
            _.each(this.dataTypes[assetSource], function (attribute) {
                this.model.unset(attribute + '_' + id);
            }, this);

            this.refreshAssetTable();
        },

        addAsset: function () {
            this.createAsset();
            this.refreshAssetTable();
        },

        refreshAssetTable: function () {
            this.renderAssetTable();
            this.view._setBindings();
        },

        removeNonFilledRows: function () {
            var assetSource = this.model.get('assetSource');
            var dataTypes = this.dataTypes[assetSource];

            _.each(this.model.get('assets'), function (asset) {
                var hasEntries = _.any(dataTypes, function (attribute) {
                    var attributeName = attribute + '_' + asset.id;
                    var attributeValue = this.model.get(attributeName);
                    return !_.isUndefined(attributeValue) && attributeValue !== '';
                }, this);

                if (!hasEntries) {
                    this.deleteAsset(asset.id);
                }
            }, this);

            if (this.model.get('numAssets') === 0) {
                this.model.set('assets', []);
                this.addAsset();
            }
        },

        clearData: function () {
            var assetSource = this.model.get('assetSource');
            var dataTypes = this.dataTypes[assetSource];

            _.each(this.model.get('assets'), function (asset) {
                _.each(dataTypes, function (attribute) {
                    var attributeName = attribute + '_' + asset.id;
                    this.model.unset(attributeName);
                }, this);
            }, this);
        },

        dataChanged: function () {
            this.parentController.dataChanged();
        },

        resetRowList: function () {
            this.clearData();
            this.removeNonFilledRows();
            this.initializeAssets();
            this.refreshAssetTable();
            _.each(this.replicatedFields, function (fieldName) {
                this.model.set(fieldName, undefined);
            }, this);
        },

        getForm: function () {
            return this.view.getForm();
        },

        showAssetCodeError: function (key) {
            this.view.showAssetCodeError(key);
            this.model.on("change:" + key, _.bind(this.view.hideAssetCodeError, this, key));
        },

        hideAssetCodeError: function (key) {
            this.view.hideAssetCodeError(key);
        },

        getSponsorDetailsDto: function () {
            var sponsorDetailsObj = {
                'accNumber': this.model.get('account'),
                'custodian': this.model.get('custodian'),
                'hin': _.isString(this.model.get('hin')) ? this.model.get('hin').toUpperCase() : undefined,
                'pid': _.isObject(this.parentController.model.get('sponsorSelector')) ? this.parentController.model.get('sponsorSelector').sponsorpid : undefined,
                'srn': this.model.get('srn')
            };
            return sponsorDetailsObj;
        },

        getTransferAssets: function (sponsorDetails) {
            var transferAssets = [];
            var assetSource = this.model.get('assetSource');
            var clientListIds = this.model.get('assets');
            var assetFields = this.dataTypes[assetSource];

            _.each(clientListIds, function (rowIndex) {
                var matchRecord = {
                    asset: {
                        "type": "Asset"
                    },
                    sponsorDetails: _.extend({}, sponsorDetails, true),
                    taxParcels: []
                };
                _.each(assetFields, function (fieldAttribute) {
                    var modelVal = this.model.get(fieldAttribute + '_' + rowIndex.id);

                    if (fieldAttribute === 'asxcode' || fieldAttribute === 'apircode') {
                        var asxObj = this.matchASXCodeToAsset(modelVal);
                        if (_.isNull(asxObj) && this.parentController.isAssetCodeValidationRequired()) {
                            asxObj = this.matchASXCodeToAsset(modelVal, true);
                        }
                        if (!_.isNull(asxObj)) {
                            matchRecord.asset['assetId'] = asxObj.assetId;
                        } else {
                            matchRecord.asset['assetCode'] = modelVal;
                        }
                    }
                    if (fieldAttribute === 'quantity' || fieldAttribute === 'mfquantity') {
                        matchRecord.quantity = modelVal;
                    }
                    if (fieldAttribute === 'srn') {
                        matchRecord.sponsorDetails['srn'] = modelVal;
                    }

                }, this);
                transferAssets.push(matchRecord);

            }, this);

            return transferAssets;
        },

        matchASXCodeToAsset: function (asxCode, checkforUniversalAAL) {
            if (_.isUndefined(asxCode)) {
                return null;
            }

            var availableAssets = this.parentController.availableAssets;
            if (checkforUniversalAAL) {
                availableAssets = this.parentController.model.get('universalAAL');
            }
            var filteredCodeMatches = _.filter(availableAssets, function (obj) {
                return (_.isUndefined(obj.assetCode) || _.isNull(obj.assetCode)) ? false : obj.assetCode.toUpperCase() === asxCode.toUpperCase();
            }, this);

            return (filteredCodeMatches.length > 0) ? filteredCodeMatches[0] : null;
        },

    });
});
