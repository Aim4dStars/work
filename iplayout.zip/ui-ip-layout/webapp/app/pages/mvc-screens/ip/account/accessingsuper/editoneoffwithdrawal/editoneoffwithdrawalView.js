define([
    'MvcView',
    'underscore'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            menuTabs: false,
        }
    });
});
