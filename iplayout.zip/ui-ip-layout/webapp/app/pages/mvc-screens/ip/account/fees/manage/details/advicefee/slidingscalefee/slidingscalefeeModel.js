define([
    'MvcModel',
    'underscore',
    'app/framework/helpers/format'
], function (MvcModel, _, format) {
    'use strict';

    return MvcModel.extend({

        updateValidation: function (index) {
            this._updatePercentageValidation(index);
            this._updateUpperBoundValidation(index);
        },

        _updatePercentageValidation: function (i) {
            this.validation[this.get('name') + 'percentage' + i] = _.extend({}, this.validationTypes.percent);
            this.validation[this.get('name') + 'percentage' + i].blur = _.omit(this.validation[this.get('name') + 'percentage' + i].blur, 'customFormat');
            this.validation[this.get('name') + 'percentage' + i].blur.required = false;
            this.validation[this.get('name') + 'percentage' + i].blur.minValue = 0;
        },

        _updateUpperBoundValidation: function (i) {
            this.validation[this.get('name') + 'upperBound' + i] = {
                blur: {},
                change: {}
            };
            this.validation[this.get('name') + 'upperBound' + i].change = _.extend({}, this.validationTypes.dollar.change);
            this.validation[this.get('name') + 'upperBound' + i].convertForModel = function (value) {
                var regex = /^[$ ]*[+-]?[$ ]*[0-9,]*[$ ]*$/;
                return (!regex.test(value.toString())) ? value : this.validationTypes.dollar.convertForModel.call(this, value);
            };
            this.validation[this.get('name') + 'upperBound' + i].blur.required = true;
            this.validation[this.get('name') + 'upperBound' + i].blur.minValue = 0.01;
            this.validation[this.get('name') + 'upperBound' + i].change.customFormat = function (value) {
                var regex = /^[$ ]*[+-]?[$ ]*[0-9,]*[$ ]*$/;
                return regex.test(value.toString());
            };
            this.validation[this.get('name') + 'upperBound' + i].convertForView = function (value) {
                return _.isNumber(value) ? format.formatWholeValues(value) : value;
            };
        },

        validateForm: function (listedSecurities, managedFunds, managedPortfolios, termDeposits, cash) {
            var areCheckboxesValid = this._validateCheckboxes(listedSecurities, managedFunds, managedPortfolios, termDeposits, cash);
            var areTiersValid = this._validateTiers();
            return (areCheckboxesValid && areTiersValid);

        },

        _validateCheckboxes: function (listedSecurities, managedFunds, managedPortfolios, termDeposits, cash) {
            if (listedSecurities || managedFunds || managedPortfolios || termDeposits || cash) {
                this.controller.hideCheckboxError();
                return true;
            } else {
                this.controller.showCheckboxError();
                return false;
            }
        },

        _validateTiers: function () {
            var data = this.get('data');
            if (data) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].percentage > 0) {
                        this.controller.hidePercentageError();
                        return true;
                    }
                }
                this.controller.showPercentageError();
                return false;
            }
            return true;
        },

        setTierValidation: function () {
            var data = this.get('data');
            for (var i = data.length - 1; i > 0; i--) {
                this.validation[this.get('name') + 'upperBound' + i].blur.minValue = parseFloat(data[i].lowerBound) + 0.01;
                if (i === data.length - 1) {
                    this.validation[this.get('name') + 'upperBound' + i].blur.required = false;
                } else {
                    this.validation[this.get('name') + 'upperBound' + i].blur.required = true;
                }
            }
        },

        formatValue: function (value) {
            return format.formatWholeValues(value);
        }

    });
});
