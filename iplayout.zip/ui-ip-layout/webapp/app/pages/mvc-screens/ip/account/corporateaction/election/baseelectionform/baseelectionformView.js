define([
    'app/pages/mvc-screens/ip/tracking/corporateaction/election/baseelectionform/baseelectionformView'
], function (BaseElectionFormView) {
    'use strict';

    return BaseElectionFormView.extend({});
});
