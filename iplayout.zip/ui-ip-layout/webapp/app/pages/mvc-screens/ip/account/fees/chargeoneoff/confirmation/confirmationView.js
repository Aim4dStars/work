define([
    'app/pages/mvc-screens/ip/account/fees/chargeoneoff/chargeoneoffView'
], function (chargeoneoffView) {
    'use strict';

    return chargeoneoffView.extend({

        rootTemplate: {
            headerPanel: 'Fees'
        },

        postRender: function () {
            // TODO: To be removed when download functionality is defined globally
            this.$el.find('a[title=Download]').attr('download', 'authorization.pdf');
        },

        loadSpinner: function () {
            this.controller.viewChildren.next.loading(true);
            this.controller.viewChildren.cancel.disable();
        },

        unloadSpinner: function () {
            if (this.controller.viewChildren && this.controller.viewChildren.next) {
                this.controller.viewChildren.next.loading(false);
                this.controller.viewChildren.cancel.enable();
            }
        }

    });

});
