define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({
        rootTemplate: {
            headerPanel: 'Rollovers & contributions',
            menuTabs: [{
                label: 'Rollover history',
                url: '#/app/adviser/account/<=a=>/contribution/rollover-history',
                child: 'rolloverhistory',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.pension.commenced.view',
                    tree: 'a'
                }
            }, {
                label: 'Rollovers & contributions',
                url: '#/app/adviser/account/<=a=>/contribution/rollover-contribution',
                child: 'rollovercontribution',
                bindHrefParam: 'a',
                permission: [{
                    rule: 'account.super.pension.view',
                    tree: 'a'
                }, {
                    rule: 'account.super.pension.commencement.view',
                    tree: 'a'
                }]
            }, {
                label: 'Contributions',
                url: '#ng/account/contribution/contributionstatus',
                child: 'contributionstatus',
                bindHrefParam: 'a,c',
                permission: {
                    rule: 'account.super.contributions.menu.view',
                    tree: 'a'
                }
            }, {
                label: 'Contribution history',
                url: '#ng/account/contribution/history',
                child: 'history',
                bindHrefParam: 'a,c',
                permission: {
                    rule: 'account.super.contribution.view',
                    tree: 'a'
                }
            }, {
                label: 'Deduction notices',
                url: '#ng/account/contribution/personaltax',
                child: 'personaltax',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.personaltaxdeductionnotice.view',
                    tree: 'a'
                }
            }, {
                label: 'Rollovers',
                url: '#/app/adviser/account/<=a=>/contribution/rollovers',
                child: 'rollovers',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.rollovers.menu.view',
                    tree: 'a'
                }
            }, {
                label: 'Linked bank accounts',
                url: '#/app/adviser/account/<=a=>/contribution/linked-bank-accounts',
                child: 'linkedbankaccounts',
                bindHrefParam: 'a',
                permission: {
                    rule: 'account.super.accum.linkedbankaccounts.view',
                    tree: 'a'
                }
            }]
        }
    });
});
