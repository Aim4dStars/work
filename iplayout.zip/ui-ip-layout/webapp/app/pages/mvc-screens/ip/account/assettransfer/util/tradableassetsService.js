define([
    'underscore', 'jquery', 'rootController', 'app/framework/services/Permissions'
], function (_, $, rootController, Permissions) {
    'use strict';

    return {

        url: {
            tradableAssetsServiceUrl: '../api/trading/v1_0/accounts/<%=a%>/tradableassets?query=++&asset_type=',
            transferAssetsServiceUrl: '../api/trading/v1_0/accounts/<%=a%>/transferassets?query=++&asset_type='
        },

        assetTypeFilter: {
            all: 'all',
            portfolios: 'Managed+portfolio,Tailored+portfolio',
            shares: 'Listed+security',
            funds: 'Managed+fund',
            sharesAndFunds: 'Listed+security,Managed+fund'
        },

        ASSET_TYPE: {
            'TAILORED_PORTFOLIO': 'Tailored portfolio',
            'MANAGED_PORTFOLIO': 'Managed portfolio'
        },

        STATUS: {
            'SUSPENDED': 'Suspended',
            'CLOSED': 'Closed',
            'CLOSED_TO_NEW': 'Closed to New Investors'
        },

        getTradableAssets: function (controller, assetTypeFilter) {
            var deferred = $.Deferred();

            if (_.isUndefined(assetTypeFilter)) {
                assetTypeFilter = assetTypeFilter.all;
            }

            var serviceCallUrl = controller.getUrl(rootController.getUrlParams(), this.url.transferAssetsServiceUrl + assetTypeFilter);

            if (!Permissions.ruleMatched('feature.global.aalv3')) {
                serviceCallUrl = controller.getUrl(rootController.getUrlParams(), this.url.tradableAssetsServiceUrl + assetTypeFilter);
            }

            controller.ajaxGet({
                url: serviceCallUrl,
                success: function (data) {
                    if (data.data) {
                        deferred.resolve(data.data.resultList);
                    } else {
                        deferred.reject();
                    }
                },
                error: function () {
                    deferred.reject();
                }
            });

            return deferred.promise();
        },

        isSuspended: function (asset) {
            return asset.status === this.STATUS.SUSPENDED;
        },

        filterManagedPortfolio: function (tradableAssets) {
            return _.filter(tradableAssets, function (asset) {
                return asset.asset.assetType === this.ASSET_TYPE.MANAGED_PORTFOLIO;
            }, this);
        },

        filterTailoredPortfolio: function (tradableAssets) {
            return _.filter(tradableAssets, function (asset) {
                return asset.asset.assetType === this.ASSET_TYPE.TAILORED_PORTFOLIO;
            }, this);
        },

        removePortfolio: function (selectedPortfolio, portfolioList) {
            return _.filter(portfolioList, function (portfolio) {
                return portfolio.asset.assetId !== selectedPortfolio.assetId;
            }, this);
        },

        isManagedPortfolio: function (asset) {
            return asset.assetType === this.ASSET_TYPE.MANAGED_PORTFOLIO;
        },

        isTailoredPortfolio: function (asset) {
            return asset.assetType === this.ASSET_TYPE.TAILORED_PORTFOLIO;
        },

        addDataToPortfolio: function (portfolios, allHeldPortfolios) {
            _.each(portfolios, function (portfolio) {
                portfolio.assetId = portfolio.asset.assetId;
                portfolio.assetName = portfolio.asset.assetName;

                var heldPortfolio = _.find(allHeldPortfolios, function (asset) {
                    return asset.assetId === portfolio.assetId;
                });

                if (heldPortfolio) {
                    var preference = heldPortfolio.incomePreference;
                    portfolio.pendingClosure = heldPortfolio.pendingClosure;
                    portfolio.availableBalance = heldPortfolio.availableBalance;
                    portfolio.incomePreference = _.isString(preference) ? preference.toLowerCase() : preference;
                }
            }, this);

            portfolios = _.sortBy(portfolios, function (portfolio) {
                return portfolio.assetName;
            });

            return portfolios;
        },

        filterByStatus: function (portfolios) {
            return _.filter(portfolios, function (portfolio) {
                var isClosed = portfolio.asset.status === this.STATUS.CLOSED;
                var isClosedtoNew = portfolio.asset.status === this.STATUS.CLOSED_TO_NEW;
                return !(portfolio.pendingClosure || isClosed || isClosedtoNew);
            }, this);
        }
    };
});
