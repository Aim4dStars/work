defineMvcController({
    name: 'oneoffconfirmation',
    parentPath: 'mvc-screens/ip/account/contribution/contributionstatus',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-screens/ip/account/contribution/oneoffcontribution/confirmation/confirmationController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    viewComponents: ['messagedisclaimer', 'transferstatus'],
    dependencies: []
}, function (config, Super) {
    'use strict';

    return Super.extend({
        config: config,

        onBeforeCloseModal: function () {
            this.parentController.unsetModelValue();
            return true;
        }
    });
});
