define([
    'MvcView', 'jquery', 'underscore'
], function (MvcView, $, _) {
    'use strict';

    return MvcView.extend({
        postRender: function () {
            this.$fileInput = this.$el.find('input[type="file"]');
            this.$fileInput.on('change', _.bind(this.fileUploaded, this));
        },

        fileUploaded: function (event) {
            event.preventDefault();
            this.controller.onFileSelected();
        },

        triggerFileUpload: function () {
            this.$el.find('input[name="file"]').click();
        },

        resetFileUpload: function () {
            var $file = this.$el.find('input[name=file]');
            $file.replaceWith($file.clone(true));
        },

        getFiles: function () {
            var $file = this.$el.find('input[name=file]');
            var files = $.extend({}, $file.get(0).files);
            this.resetFileUpload();
            return files;
        },
    });
});
