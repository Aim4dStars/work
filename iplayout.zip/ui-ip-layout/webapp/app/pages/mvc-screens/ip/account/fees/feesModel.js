define([
    'MvcModel',
    'underscore'
], function (MvcModel, _) {
    'use strict';

    return MvcModel.extend({
        getScheduleData: function (data) {
            var feesData = data;
            var scheduleData = {};
            var fees = [];
            var index = 0;
            if (feesData.fees) {
                for (var i = 0; i < feesData.fees.length; i++) {
                    if (feesData.fees[i].type === "Ongoing advice fee" || feesData.fees[i].type === "Licensee advice fee") {
                        fees[index] = feesData.fees[i];
                        index++;
                    }
                }
                scheduleData.fees = fees;
            }
            return scheduleData;
        },
        getAdminData: function (feesData) {
            var adminData = {};
            var fees = [];
            var index = 0;
            var smsfAmount = 0;
            adminData.isSmsfFees = false;
            adminData.isAdminFees = false;
            adminData.isTrusteeFees = false;
            if (feesData.fees) {
                for (var i = 0; i < feesData.fees.length; i++) {
                    if (feesData.fees[i].type === "Administration fee") {
                        adminData.isAdminFees = true;
                        adminData.specialDiscount = feesData.fees[i].specialDiscount;
                        fees[index] = (feesData.fees[i]);
                        index++;
                    } else if (feesData.fees[i].type === "SMSF Administration fee" && !_.isEmpty(feesData.fees[i].feesComponent)) {
                        _.each(feesData.fees[i].feesComponent, function (feeComponent) {
                            if (!_.isNull(feeComponent.amount) && !_.isNaN(feeComponent.amount)) {
                                smsfAmount += feeComponent.amount;
                                adminData.isSmsfFees = true;
                            }
                        });
                    } else if (feesData.fees[i].type === "Trustee fee" && !_.isEmpty(feesData.fees[i].feesComponent)) {
                        adminData.isTrusteeFees = true;
                        adminData.trusteeFee = feesData.fees[i];
                    } else if (feesData.fees[i].type === "Wrap advantage rebate" && !_.isEmpty(feesData.fees[i].feesComponent)) {
                        adminData.wrapAdvantageRebate = feesData.fees[i];
                        adminData.wrapAdvantageFee = feesData.fees[i].feesComponent[0].rate;
                    } else if (feesData.fees[i].type === "Advance managed fund rebate" && !_.isEmpty(feesData.fees[i].feesComponent)) {
                        adminData.advanceManagedFundRebate = feesData.fees[i];
                        adminData.advanceManagedFundFee = feesData.fees[i].feesComponent[0].rate;
                    }
                }
                adminData.fees = fees;
                adminData.investmentMgmtFees = feesData.investmentMgmtFees;
                smsfAmount = Math.ceil(smsfAmount * 100) / 100;
                adminData.smsfAmount = smsfAmount;
            }
            return adminData;
        },

        getContributionFees: function (data) {
            var contributionFees = {};
            var oneoffFees = [];
            var regularFees = [];
            for (var i = 0; i < data.fees.length; i++) {
                if (data.fees[i].type === "Contribution fee") {
                    _.each(data.fees[i].feesComponent, function (fee) {
                        if (fee.name.toLowerCase().indexOf("employer") > -1) {
                            fee.contributionType = 'Employer';
                        } else if (fee.name.toLowerCase().indexOf("personal") > -1) {
                            fee.contributionType = 'Personal';
                        } else if (fee.name.toLowerCase().indexOf("spouse") > -1) {
                            fee.contributionType = 'Spouse';
                        } else if (fee.name.toLowerCase().indexOf("deposit") > -1) {
                            fee.contributionType = 'Deposit';
                        }
                        if (fee.name.toLowerCase().indexOf("oneoff") > -1 || fee.name.toLowerCase().indexOf("employer") > -1) {
                            oneoffFees.push(fee);
                        } else if (fee.name.toLowerCase().indexOf("regular") > -1) {
                            regularFees.push(fee);
                        }
                    });
                }
            }
            contributionFees.oneoffFees = _.sortBy(oneoffFees, function (fee) {
                return fee.contributionType;
            });
            contributionFees.regularFees = _.sortBy(regularFees, function (fee) {
                return fee.contributionType;
            });
            contributionFees.type = 'Contribution fee';
            return contributionFees;
        }
    });
});
