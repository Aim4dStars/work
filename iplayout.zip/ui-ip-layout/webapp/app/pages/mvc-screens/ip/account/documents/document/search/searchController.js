defineMvcController({
    name: 'search',
    parentPath: 'mvc-screens/ip/account/documents/document',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['inputtext'],
    extend: 'MvcController',
    dependencies: ['underscore']
}, function (config, MvcController, _) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            this.model.on('change:documentName', this._showClearOption, this);
        },

        _showClearOption: function () {
            var documentName = this.model.get('documentName');
            if (_.isString(documentName) && documentName.length > 0) {
                this.view.showClearOption();
            } else {
                this.view.hideClearOption();
            }
        },

        clearSearch: function () {
            this.model.unset('documentName');
        }
    });

});
