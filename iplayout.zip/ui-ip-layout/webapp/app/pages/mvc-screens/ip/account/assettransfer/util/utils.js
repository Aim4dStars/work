define([
    'underscore'
], function (_) {
    'use strict';

    return {
        convertToNumber: function (amount) {
            if (_.isString(amount)) {
                amount = amount.replace("$", "");
                amount = amount.replace(",", "");
                amount = parseFloat(amount);
                if (_.isNumber(amount)) {
                    return amount;
                }
            }
            return amount;
        }

    };
});
