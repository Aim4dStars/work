/*
 * The purpose of this model is to run validation on the saved contribution before calling confirmation service
 * If the validation fails navidate the screen to contribution form screen
 */

define([
    'app/pages/mvc-screens/ip/account/contribution/regularcontribution/regularcontributionModel',
    'app/framework/helpers/timezone',
    'app/framework/services/dateService',
    'app/framework/helpers/format',
    'underscore',
    'moment'
], function (SuperModel, timezone, dateService, format, _, moment) {
    'use strict';

    var MAX_AGE_FOR_SPOUSE_CONTRIBUTION = 70;

    return SuperModel.extend({
        validation: {
            age: {
                submit: {
                    customAgeCheck: 'customAgeCheck'
                }
            },
            payer: {
                submit: {
                    customLinkedAccountCheck: 'customLinkedAccountCheck'
                }
            },
            depositDate: {
                submit: {
                    customMinValue: 'checkMinPaymentDate',
                    customTimeValidation: 'afterCOBToday',
                    customCheckweekendValidation: 'validateIsWeekday'
                }
            }
        },

        customAgeCheck: function (value) {
            var contributionType = this.get('contributionType');
            return _.isEqual(contributionType.toLowerCase(), 'spouse') ? value <= MAX_AGE_FOR_SPOUSE_CONTRIBUTION : true;
        },

        customLinkedAccountCheck: function (value) {
            return !_.isNull(value);
        },

        checkMinPaymentDate: function (value) {
            var type = this.get('type');
            if (_.isEqual(type, 'regular')) {
                return this.minRegularPaymentDate(value);
            } else if (_.isEqual(type, 'oneoff')) {
                return this.minOneOffPaymentDate(value);
            }
        },

        minRegularPaymentDate: function (value) {
            var now = timezone.convertTimezone(dateService.now(), 'AEDST');
            var minPaymentDate = moment(now.date).add(1, 'days');
            var paymentDate = new Date(format.formatDate(value, 'date'));
            minPaymentDate = this.calculateDateForWeekEnd(minPaymentDate);
            return paymentDate >= minPaymentDate.toDate();
        },

        minOneOffPaymentDate: function (value) {
            var now = timezone.convertTimezone(dateService.now(), 'AEDST');
            var minPaymentDate = moment(now.date);
            var paymentDate = new Date(format.formatDate(value, 'date'));
            var hour = minPaymentDate.hour();
            if (hour >= 17) {
                minPaymentDate.add(1, 'days');
            }
            minPaymentDate = this.calculateDateForWeekEnd(minPaymentDate);
            return paymentDate >= minPaymentDate.toDate();
        },

        calculateDateForWeekEnd: function (minPaymentDate) {
            var weekday = minPaymentDate.weekday();
            if (weekday === 0) {
                minPaymentDate.add(1, 'days');
            } else if (weekday === 6) {
                minPaymentDate.add(2, 'days');
            }
            minPaymentDate.startOf('day');
            return minPaymentDate;
        }
    });
});
