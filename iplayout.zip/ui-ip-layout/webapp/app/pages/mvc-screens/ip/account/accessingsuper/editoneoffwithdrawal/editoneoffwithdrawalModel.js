define([
    'MvcModel',
    'underscore'
], function (MvcModel, _) {
    'use strict';

    return MvcModel.extend({
        validation: {
            'accountselector': {
                blur: {
                    required: true
                },
                submit: {
                    required: true
                }
            },
            'amount': {
                priority: ['required', 'customValidation', 'minValue'],
                type: 'dollar',
                blur: {
                    required: true,
                    customValidation: function (amount) {
                        return this.availableAmountValidation(amount);
                    },
                    minValue: 0.01,
                    maxValue: 200000
                },
                submit: {
                    required: true,
                    customValidation: function (amount) {
                        return this.availableAmountValidation(amount);
                    },
                    minValue: 0.01,
                    maxValue: 200000
                },
                trigger: {
                    blur: [
                        {
                            name: 'accountselector'
                        }
                    ]
                }
            },
            'description': {
                type: 'alphaNumericSpace'
            },
        },

        availableAmountValidation: function (amount) {
            var availableAmount = this.get('maxAmount');
            if (_.isFinite(amount)) { // check we have a number, excluding NaN. If not, other validations handle those cases.
                return amount <= availableAmount;
            }
            return true;
        }

    });
});
