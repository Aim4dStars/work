define([
    'MvcView',
    'text!app/pages/mvc-screens/ip/account/assettransfer/transfer/timeline/_subtimeline.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (MvcView, subtimelineTemplate, componentXml, Handlebars) {
    'use strict';

    return MvcView.extend({
        preRender: function () {
            this._registerPartials();
        },
        _registerPartials: function () {
            Handlebars.registerPartial('sub-timeline-asset-transfer', componentXml.encode(subtimelineTemplate));
        },

        showParentTimeLine: function () {
            this.hideChildTimeLine();
            this.$el.find('.parent-timeline').show().css('display', 'block');
        },

        showChildTimeLine: function () {
            this.hideParentTimeLine();
            this.$el.find('.child-timeline').show();
        },

        hideChildTimeLine: function () {
            this.$el.find('.child-timeline').hide();
        },

        hideInnerChildTimeline: function () {
            this.$el.find('.inner-child-timeline').hide();
        },

        hideParentTimeLine: function () {
            this.$el.find('.parent-timeline').hide();
        },

        hideBackButton: function () {
            this.$el.find('.page-tabs').hide();
        },

        showBackButton: function () {
            this.$el.find('.page-tabs').show();
        },

        resetToInitialState: function () {
            var $transferType = this.$el.find('.child-step .step-transfer-type');
            var $assetHolding = this.$el.find('.step-asset-holdings');
            $transferType.find('.icon-container .value').addClass('step-text-color').show();
            $transferType.find('.icon-container .icon-checkbox').hide();
            $transferType.next().find('.icon-container').removeClass('inverted step-complete-color').addClass('inactive');
            $transferType.parent().find('.icon-container').first().addClass('step-complete-color');
            $transferType.find('.child-step-description-1').children().removeClass('step-inactive-text-color').addClass('step-text-complete-color');
            $assetHolding.removeClass('step-active').addClass('step-deactive');
            $assetHolding.next().removeClass('step-active').addClass('step-deactive');
            $assetHolding.find('.icon-container .icon-checkbox').hide();
            $assetHolding.find('.icon-container .value').show();
            $assetHolding.find('.icon-container .value').removeClass('step-text-color').addClass('step-inactive-text-color');
            $assetHolding.find('.child-step-description-2').children().removeClass('step-text-complete-color').addClass('step-inactive-text-color');
            $assetHolding.next().find('.child-step-description-3').children().removeClass('step-text-complete-color').addClass('step-inactive-text-color');
            $assetHolding.next().find('.icon-container').removeClass('inverted step-complete-color').addClass('inactive');
            $assetHolding.next().find('.icon-container .value').removeClass('step-text-color');
        },

        completedTransferTypeStep: function () {
            var $transferType = this.$el.find('.step-transfer-type');
            var $assetHolding = this.$el.find('.step-asset-holdings');
            $transferType.removeClass('step-deactive').addClass('step-active');
            $transferType.find('.icon-container').removeClass('step-complete-color');
            $transferType.find('.icon-container .icon').removeClass('step-text-color');
            $transferType.next().find('.icon-container').removeClass('inactive').addClass('inverted step-complete-color');
            $transferType.next().find('.icon-container .icon').removeClass('step-inactive-text-color').addClass('step-text-color');
            $transferType.find('.child-step-description-1').children().removeClass('step-text-complete-color').addClass('step-inactive-text-color');
            $transferType.next().find('.child-step-description-2').children().removeClass('step-inactive-text-color').addClass('step-text-complete-color');
            $transferType.find('.icon-container .value').hide();
            $transferType.find('.icon-container .icon-checkbox').show();
            $assetHolding.removeClass('step-active').addClass('step-deactive');
            $assetHolding.find('.icon-container .value').show();
            $assetHolding.find('.icon-container .icon-checkbox').hide();
            $assetHolding.next().find('.icon-container').removeClass('inverted step-complete-color').addClass('inactive');
            $assetHolding.next().find('.icon-container .icon').removeClass('step-text-color').addClass('step-inactive-text-color');
            $assetHolding.next().find('.child-step-description-3').children().removeClass('step-text-complete-color').addClass('step-inactive-text-color');
        },

        completedAssetHoldingStep: function () {
            var $assetHolding = this.$el.find('.step-asset-holdings');
            $assetHolding.removeClass('step-deactive').addClass('step-active');
            $assetHolding.find('.icon-container').removeClass('step-complete-color');
            $assetHolding.find('.icon-container .icon').removeClass('step-text-color');
            $assetHolding.next().find('.icon-container').removeClass('inactive').addClass('inverted step-complete-color');
            $assetHolding.next().find('.icon-container .icon').removeClass('step-inactive-text-color').addClass('step-text-color');
            $assetHolding.find('.child-step-description-2').children().removeClass('step-text-complete-color').addClass('step-inactive-text-color');
            $assetHolding.next().find('.child-step-description-3').children().removeClass('step-inactive-text-color').addClass('step-text-complete-color');
            $assetHolding.find('.icon-container .value').hide();
            $assetHolding.find('.icon-container .icon-checkbox').show().css('display', '');
        },

        completedTransferFormStep: function () {
            var $createTransfer = this.$el.find('.parent-step-1');
            $createTransfer.removeClass('step-deactive').addClass('step-active');
            $createTransfer.find('.icon-container').removeClass('step-complete-color');
            $createTransfer.find('.icon-container .value').hide();
            $createTransfer.find('.icon-container .icon-checkbox').show().css('display', '');
            $createTransfer.next().find('.icon-container').removeClass('inactive').addClass('inverted step-complete-color');
            $createTransfer.next().find('.icon-container .value').addClass('step-text-color');
            $createTransfer.find('.parent-step-description-1').children().first().removeClass('step-text-complete-color').addClass('step-inactive-text-color');
            $createTransfer.next().find('.parent-step-description-2').children().removeClass('step-inactive-text-color').addClass('step-text-complete-color');
        }
    });
});
