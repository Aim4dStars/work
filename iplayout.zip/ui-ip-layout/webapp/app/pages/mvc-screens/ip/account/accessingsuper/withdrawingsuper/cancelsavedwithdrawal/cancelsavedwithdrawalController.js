defineMvcController({
    name: 'cancelsavedwithdrawal',
    parentPath: 'mvc-screens/ip/account/accessingsuper/withdrawingsuper',
    viewHtml: true,
    viewJs: true,
    extend: 'app/pages/mvc-templates/modal/modalController',
    wrapperHtml: 'app/pages/mvc-templates/modal/modal',
    dependencies: ['underscore', 'app/pages/mvc-screens/ip/account/accessingsuper/accessingsuperServices', 'jquery']
}, function (config, ModalController, _, accessingsuperServices, $) {
    'use strict';
    return ModalController.extend({
        config: config,

        postRender: function () {
            this._hideMessage('ajaxerror');
        },

        cancelForm: function () {
            this.closeModal();
        },

        cancelSavedWithdrawal: function () {
            this.view.showSpinner();
            var withdrawal = {
                transSeqNo: this.model.get('transSeqNo'),
                stordPosId: this.model.get('stordPosId'),
                receiptNumber: this.model.get('receiptNumber'),
                withdrawalType: this.model.get('withdrawalType'),
                paymentAction: this.model.get('paymentAction')
            };
            $.when(accessingsuperServices.cancelSavedWithdrawal(this, withdrawal))
                .done(_.bind(function (data) {
                    if (_.isUndefined(data) || !_.isEmpty(data.errors)) {
                        this._showMessage('ajaxerror');
                    } else {
                        this.closeModal();
                        this.parentController.showSuccessfulSavedMessage('cancelsavedoneoffwithdrawalmessage', true);
                    }
                }, this))
                .fail(_.bind(function () {
                    this._showMessage('ajaxerror');
                    this.view.hideSpinner();
                }, this));
        },

        _showMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].show();
            }
        },

        _hideMessage: function (messageType) {
            if (this.viewChildren && this.viewChildren[messageType]) {
                this.viewChildren[messageType].hide();
            }
        }
    });
});
