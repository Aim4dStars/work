defineMvcController({
    name: 'providedocuments',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie',
    viewHtml: true,
    viewJs: true,
    viewComponents: ['inputtext'],
    screens: [],
    hashName: 'providedocuments',
    extend: 'MvcController',
    dependencies: ['app/framework/router', 'underscore', 'rootController', 'app/framework/services/analyticsService']
}, function (config, MvcController, router, _, rootController, analyticsService) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            this.model.set('accountId', rootController.getUrlParams().a);
        },

        postRender: function () {
            var params = rootController.getUrlParams();
            var transferId = params['t'];

            if (_.isUndefined(transferId)) {
                var cbo = true;
                var transferType = this.parentController.model.get('transferType');
                transferId = this.parentController.model.get('transferId');
                this.model.set('transferId', transferId);
                if (this.parentController.model.get('cbo') === 'no') {
                    cbo = false;
                }
                this.setUploadDocumentsData(transferType, cbo, true);
                rootController.confirmNavigation(false);
                this.setSupportingDocumentLinks();

                this.view.setScrollIntoView({
                    element: this.view.$el.find('.mvc-uploaddocuments')
                });
            }

            if (this.parentController.name === 'inspecie') {
                analyticsService.send({
                    "pageName": "ng:account:assettransfer:inspecie:providedocuments",
                    "pageType": "selfservice",
                    "formName": "inspecie transfer",
                    "pageStep": "complete"
                });
            }
        },

        setUploadDocumentsData: function (transferType, cbo, newTransfer) {
            var showSupportingDocumentBox = true;
            if (!newTransfer && !this.parentController.model.get('showSupportingDoc')) {
                showSupportingDocumentBox = false;
            }
            this.model.set({
                "transferType": transferType,
                "cbo": cbo,
                "newTransfer": newTransfer,
                "showSupportingDocumentBox": showSupportingDocumentBox
            });
        },

        setSupportingDocumentLinks: function () {
            var transferType = this.model.get("transferType");
            if (!_.isUndefined(transferType)) {
                transferType = transferType.toLowerCase();
            }
            this.resetDocumentLinks();
            var cbo = this.model.get("cbo");
            if (cbo) {
                this.setCBOLinks(transferType);
            } else {
                this.setNCBOLinks(transferType);
            }
        },

        setCBOLinks: function (transferType) {
            if (transferType === 'listed securities broker sponsored') {
                this.model.set("showASTF", true);
                this.model.set("showHoldingBS", true);
            } else if (transferType === 'listed securities issuer sponsored') {
                this.model.set("showASTF", true);
                this.model.set("showHoldingIS", true);
                this.model.set("showID", true);
            } else if (transferType === 'assets from other platform or custodian') {
                this.model.set("showPVReport", true);
                this.model.set("showANDLS", true);
            } else if (transferType === 'managed funds') {
                this.model.set("showASTFMF", true);
                this.model.set("showHoldingMF", true);
                this.model.set("showANDMF", true);
            }
        },

        setNCBOLinks: function (transferType) {
            if (transferType === 'listed securities broker sponsored') {
                this.model.set("showASTFncbo", true);
                this.model.set("showHoldingBS", true);
            } else if (transferType === 'listed securities issuer sponsored') {
                this.model.set("showHoldingIS", true);
                this.model.set("showASTFncbo", true);
            } else if (transferType === 'assets from other platform or custodian') {
                this.model.set("showLPOACustodian", true);
                this.model.set("showPVReport", true);
                this.model.set("showANDLS", true);
            } else if (transferType === 'managed funds') {
                this.model.set("showHoldingMF", true);
                this.model.set("showANDMF", true);
            }
        },

        resetDocumentLinks: function () {
            this.model.set({
                "showASTF": false,
                "showHoldingBS": false,
                "showHoldingIS": false,
                "showHoldingMF": false,
                "showID": false,
                "showPVReport": false,
                "showANDLS": false,
                "showANDMF": false,
                "showASTFncbo": false,
                "showLPOACustodian": false
            });
        }
    });
});
