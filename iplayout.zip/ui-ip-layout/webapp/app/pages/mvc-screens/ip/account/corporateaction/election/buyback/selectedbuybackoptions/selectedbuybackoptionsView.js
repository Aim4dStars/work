define([
    'MvcView',
    'text!app/pages/mvc-screens/ip/tracking/corporateactiontemplates/corporateaction/election/buyback/selectedbuybackoptions/_selectedbuybackoptions.html',
    'app/framework/services/componentXml',
    'handlebars'
], function (MvcView, _selectedbuybackoptionsTemplate, componentXml, Handlebars) {
    'use strict';

    return MvcView.extend({

        preRender: function () {
            Handlebars.registerPartial('selectedbuybackoptions', componentXml.encode(_selectedbuybackoptionsTemplate));
        },

        toggleSelectedOptionsListContainer: function (doShow) {
            var $elem = this.$el.find('.selectedOptionsListContainer');
            if (doShow) {
                $elem.show();
            } else {
                $elem.hide();
            }
        }
    });

});
