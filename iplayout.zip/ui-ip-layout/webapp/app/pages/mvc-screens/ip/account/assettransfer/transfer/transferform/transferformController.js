defineMvcController({
    name: 'transferform',
    parentPath: 'mvc-screens/ip/account/assettransfer/transfer',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'transfer',
    hashDefault: false,
    viewComponents: ['snapshot', 'inputtext', 'termsandconditions', 'messagedisclaimer', 'tooltip', 'forminputautocomplete'],
    mvcComponents: ['tablev3', 'inputautocomplete'],
    screens: ['terms', 'cancel'],
    extend: 'MvcController',
    dependencies: ['app/framework/services/Permissions', 'rootController', 'jquery', 'underscore']
}, function (config, MvcController, Permissions, rootController, $, _) {
    'use strict';

    return MvcController.extend({
        config: config,
        isAssetCodeValid: true,
        vettingUrl: '/ng/secure/api/inspecietransfer/v2_0/accounts/<%=a%>/inspecie-transfer',
        availableAssetsServiceUrl: '../api/v1_0/accounts/<%=a%>/available-assets',
        doHideWarnings: false,
        PENDING_CONTAINER_STATUS_CODE: 'btfg$mdf_mp_cont_status',
        universalAssetListURL: '../api/v1_0/assets',

        assets: [],
        initialRows: 5,
        dataTypes: {
            brokersponsored: ['asxcode', 'quantity', 'hin', 'chess', 'sponsorname'],
            issuersponsored: ['asxcode', 'quantity', 'srn'],
            managedfunds: ['apircode', 'mfquantity', 'account', 'custodian'],
            listedsecuritycustodian: ['asxcode', 'quantity', 'hinaccount', 'chess', 'sponsorname']
        },
        requiredFields: {
            brokersponsored: ['asxcode', 'quantity'],
            issuersponsored: ['asxcode', 'quantity'],
            managedfunds: ['apircode', 'mfquantity'],
            listedsecuritycustodian: ['asxcode', 'quantity']
        },
        assetTypeValues: {
            brokerSponsored: 'brokersponsored',
            issuerSponsored: 'issuersponsored',
            managedFunds: 'managedfunds',
            listedSecurityCustodian: 'listedsecuritycustodian'
        },
        transferTypes: {
            brokersponsored: 'Listed Securities Broker Sponsored',
            issuersponsored: 'Listed Securities Issuer Sponsored',
            managedfunds: 'Managed Funds',
            listedsecuritycustodian: 'Listed Securities Other Platform or Custodian'
        },
        sponsorAttributeMapping: {
            'account': 'accNumber',
            'hinaccount': 'hin',
            'custodian': 'custodian',
            'hin': 'hin',
            'pid': 'pid',
            'chess': 'pid',
            'srn': 'srn'
        },

        viewEvents: {
            'submit form': 'submitForm',
            'focus input': 'dataBlurred',
            'blur input': 'dataBlurred'
        },

        goBack: function () {
            this.parentController.back();
        },

        postRender: function () {
            this.model.unset('parent');

            var assetType = this.model.get('assetType');
            this.setAssetTypeHeader(assetType);

            var cbo = this.model.get('cbo');
            var cbolabel = cbo === 'yes' ? 'Yes' : 'No';
            this.model.set('cbolabel', cbolabel);

            var managedPortfolio = this.model.get('managedPortfolio');
            var tailoredPortfolio = this.model.get('tailoredPortfolio');
            if (!managedPortfolio && !tailoredPortfolio) {
                this.view.hideManagedPortfolio();
            } else if (!tailoredPortfolio) {
                this.model.set('portfolioCode', managedPortfolio.assetCode);
            } else {
                this.model.set('portfolioCode', tailoredPortfolio.assetCode);
            }

            this.clearData();

            var isIssuerSponsor = assetType === this.assetTypeValues.issuerSponsored;
            this.view.toggleAddButtonContainer(isIssuerSponsor);

            // Adjust the initial number of rows
            if (isIssuerSponsor) {
                this.initialRows = 1;
            } else {
                this.initialRows = 5;
            }
            var usedInitRows = this.initialRows;

            this.assets = _.range(usedInitRows);
            this.assetId = usedInitRows;
            this.assets = _.map(this.assets, function (assetId) {
                return {
                    id: assetId
                };
            });
            _.each(this.assets, function (asset) {
                this.initAssetValidation(asset);
            }, this);

            this.renderAssetTable();

            this.viewChildren.submit.hide();
            this.viewChildren.termsandconditions.hide();
            this.view.updateDynamicDisabledFields();
        },

        setAssetTypeHeader: function (assetType) {
            var assetTypeName = '';
            switch (assetType) {
            case this.assetTypeValues.brokerSponsored:
                assetTypeName = 'Listed securities - broker sponsored';
                break;
            case this.assetTypeValues.issuerSponsored:
                assetTypeName = 'Listed securities - issuer sponsored';
                break;
            case this.assetTypeValues.managedFunds:
                assetTypeName = 'Managed funds';
                break;
            case this.assetTypeValues.listedSecurityCustodian:
                assetTypeName = 'Listed Securities on other platform or custodian';
                break;
            }

            this.model.set('assetTypeHeader', assetTypeName);
        },

        initAssetValidation: function (asset) {
            var assetType = this.model.get('assetType');
            _.each(this.dataTypes[assetType], function (attribute) {
                var attributeName = attribute + '_' + asset.id;
                this.model.validation[attributeName] = this.model.validation[attribute];
                this.model.on('change:' + attributeName, _.bind(this.dataChanged, this));
            }, this);
        },

        renderAssetTable: function () {
            if (!this.children.assets) {
                return;
            }

            this.assets[0].id = 0;

            var rowData = {
                rows: this.assets
            };
            this.model.set('chessId', 'render');
            this.children.assets.setRows({
                rowName: 'rows'
            }, rowData);

            delete this.children.assets.children.sponsorselector;
            this.children.assets.renderComponentView();

            this.populateSponsorSelector();

            var assetType = this.model.get('assetType');
            var isIssuerSponsor = assetType === this.assetTypeValues.issuerSponsored;

            // If isIssuerSponsor, hide the button entirely
            if (isIssuerSponsor) {
                _.each(this.children.assets.viewChildren, function (viewChild, viewChildName) {
                    if (viewChildName.indexOf('button') !== -1) {
                        viewChild.hide();
                    }
                });
            }
            // If only one row is left, disable the viewChild
            else if (this.assets.length <= 1) {
                _.each(this.children.assets.viewChildren, function (viewChild, viewChildName) {
                    if (viewChildName.indexOf('button') !== -1) {
                        viewChild.disable();
                    } else {
                        viewChild.enable();
                    }
                });
            }
        },

        deleteAsset: function (id) {
            id = parseInt(id, 10);
            this.assets = _.filter(this.assets, function (asset) {
                return asset.id !== id;
            });
            var assetType = this.model.get('assetType');
            _.each(this.dataTypes[assetType], function (attribute) {
                this.model.unset(attribute + '_' + id);
            }, this);
            if (id === 0) {
                _.each(this.dataTypes[assetType], function (attribute) {
                    var attributeVal = this.model.get(attribute + '_' + this.assets[0].id);
                    if (!_.isUndefined(attributeVal)) {
                        this.model.set(attribute + '_0', attributeVal);
                    }
                    this.model.unset(attribute + '_' + this.assets[0].id);
                }, this);
            }
            this.refreshAssetTable();
            this.view.updateDynamicDisabledFields();
        },

        addAsset: function () {
            var newAsset = {
                id: ++this.assetId
            };
            this.assets.push(newAsset);
            this.initAssetValidation(newAsset);

            this.refreshAssetTable();
            this.view.updateDynamicDisabledFields();

            this.updateAllReplicateFields();
        },

        refreshAssetTable: function () {
            this.renderAssetTable();
            this.view._setBindings();
        },

        isAssetCodeValidationRequired: function () {
            var managedPortfolio = this.model.get('managedPortfolio');
            var tailoredPortfolio = this.model.get('tailoredPortfolio');
            if (!_.isEmpty(managedPortfolio) || !_.isEmpty(tailoredPortfolio)) {
                return true;
            }
            return false;
        },

        getAsxCodes: function () {
            var asxCodeObj = [];
            var asxCodes = _.filter(this.model.attributes, function (value, key) {
                if (key.indexOf('asxcode') !== -1 && value !== "") {
                    asxCodeObj.push({
                        "key": key,
                        "value": value
                    });
                    return value;
                }
            });
            this.model.set('assetCodeObj', asxCodeObj);
            return asxCodes;
        },

        getApirCodes: function () {
            var apirCodeObj = [];
            var apirCodes = _.filter(this.model.attributes, function (value, key) {
                if (key.indexOf('apircode') !== -1 && value !== "") {
                    apirCodeObj.push({
                        "key": key,
                        "value": value
                    });
                    return value;
                }
            });
            this.model.set('assetCodeObj', apirCodeObj);
            return apirCodes;
        },

        validateAssetCode: function () {
            this.isAssetCodeValid = true;
            var assetCodes = null;
            if (this.model.get('assetType') === 'managedfunds') {
                assetCodes = this.getApirCodes();
            } else {
                assetCodes = this.getAsxCodes();
            }
            var url = this.universalAssetListURL + "?asset-codes=" + JSON.stringify(assetCodes);
            var params = {
                url: url,
                success: _.bind(function (data) {
                    var assetList = data.data.resultList;
                    this.model.set("universalAAL", assetList);
                    _.each(this.model.get("assetCodeObj"), function (code) {
                        var newAsset = _.find(assetList, function (asset) {
                            return code.value === asset.assetCode;
                        });
                        if (_.isUndefined(newAsset)) {
                            this.view.showAssetCodeError(code.key);
                            this.model.on("change:" + code.key, _.bind(this.view.hideAssetCodeError, this, code.key));
                            this.isAssetCodeValid = false;
                        }
                    }, this);
                }, this)
            };
            this.view.showSpinner();
            return this.ajaxGet(params);
        },

        submitForm: function (event) {
            this.removeNonFilledRows();
            if (this.validateAndSubmitForm(event)) {
                if (this.isAssetCodeValidationRequired()) {
                    $.when(this.validateAssetCode()).done(_.bind(function () {
                        if (this.isAssetCodeValid) {
                            this.submitTranserDetails();
                        } else {
                            this.view.hideSpinner();
                        }
                    }, this));
                } else {
                    this.submitTranserDetails();
                }
            }
        },
        submitTranserDetails: function () {
            var transferData = this.getTransferData();
            var url = this.getUrl(rootController.getUrlParams(), this.vettingUrl);
            var params = {
                url: url,
                data: {
                    'x-ro-validate-only': true,
                    'transferDetails': JSON.stringify(transferData)
                },
                success: _.bind(function (data) {
                    var hasErrors = this.handleVettingError(data);
                    this.handleVettingWarning(data);
                    this.parentController.model.set('transferType', transferData.transferType);
                    if (!hasErrors) {
                        this.handleVettingResponse(data);
                    }
                    this.view.hideSpinner();
                }, this),
                error: _.bind(function (data) {
                    this.handleVettingError(data);
                    this.handleVettingWarning(data);
                    this.view.hideSpinner();
                }, this)
            };
            this.view.showSpinner();

            return this.ajaxPost(params);
        },
        handleVettingError: function (data) {
            var hasErrors = false;
            if (!_.isUndefined(data.data)) {
                var uiErrors = data.data.warnings;

                // Filter to errors
                uiErrors = _.filter(uiErrors, function (response) {
                    return response['errorType'] === 'error';
                });

                uiErrors = _.map(uiErrors, function (error) {
                    return error.message;
                });
                if (!_.isEmpty(uiErrors)) {
                    this.view.setUIErrors(uiErrors);

                    this.viewChildren.uierror.show();
                    this.view.setScrollIntoView({
                        element: this.viewChildren.uierror.$el
                    });
                    hasErrors = true;
                } else {
                    this.viewChildren.uierror.hide();
                }
            }
            return hasErrors;
        },
        handleVettingWarning: function (data) {

            if (!_.isUndefined(data.data) && !this.doHideWarnings) {
                var uiWarnings = data.data.warnings;

                // Filter to warnings
                uiWarnings = _.filter(uiWarnings, function (response) {
                    return response['errorType'] === 'warning';
                });

                // Do not show the pending container status warning
                uiWarnings = _.filter(uiWarnings, function (warn) {
                    return warn['errorId'] !== this.PENDING_CONTAINER_STATUS_CODE;
                }, this);

                uiWarnings = _.map(uiWarnings, function (warning) {
                    return warning.message;
                });

                if (!_.isEmpty(uiWarnings)) {
                    this.view.setUIWarnings(uiWarnings);

                    this.viewChildren.uiwarning.show();
                    this.view.setScrollIntoView({
                        element: this.viewChildren.uiwarning.$el
                    });
                } else {
                    this.viewChildren.uiwarning.hide();
                }
            }
        },

        handleVettingResponse: function (data) {

            // Store the state warning message
            this.model.set('submitwarnings', _.map(data.data.warnings, function (warn) {
                return {
                    "errorId": warn.errorId,
                    "domain": warn.domain,
                    "reason": warn.reason,
                    "message": warn.message,
                    "errorType": warn.errorType
                };
            }));
            this.parentController.children.timeline.model.set('screenState', 'submit');
            this.viewChildren.submit.show();
            this.viewChildren.termsandconditions.show();
            this.viewChildren.preview.hide();
        },

        removeNonFilledRows: function () {
            var assetType = this.model.get('assetType');
            var fields = this.requiredFields[assetType];
            var indexesToKeep = [];

            _.each(this.model.attributes, function (obj, attr) {
                _.each(fields, function (field) {
                    var isRequiredField = attr.indexOf(field) === 0;
                    if (isRequiredField) {
                        var index = attr.split('_')[1];
                        if (obj.toString().length > 0) {
                            indexesToKeep = _.union(indexesToKeep, [index]);
                        }
                    }
                }, this);
            });

            var isMF = assetType === this.assetTypeValues.managedFunds;
            var pidIndexList = this.view.getAllClientRowsForIndexinglds(isMF);
            _.each(pidIndexList, function (pidAttr, index) {
                if (index !== 0 && !_.contains(indexesToKeep, pidAttr)) {
                    this.deleteAsset(pidAttr);
                }
            }, this);
        },

        getTaxparcelDto: function (obj) {
            return {
                'assetId': obj.assetId,
                'taxRelvDate': obj.taxRelvDate,
                'taxVisibDate': obj.taxVisibDate,
                'quantity': obj.quantity,
                'currency': obj.currency,
                'importCostBase': obj.importCostBase,
                'importReduCostBase': obj.importReduCostBase,
                'importIdxCostBase': obj.importIdxCostBase,
            };
        },

        matchASXCodeToAsset: function (asxCode, checkforUniversalAAL) {
            if (_.isUndefined(asxCode)) {
                return null;
            }

            var availableAssets = this.parentController.model.get('availableAssets');
            if (checkforUniversalAAL) {
                availableAssets = this.model.get('universalAAL');
            }
            var filteredCodeMatches = _.filter(availableAssets, function (obj) {
                return (_.isUndefined(obj.assetCode) || _.isNull(obj.assetCode)) ? false : obj.assetCode.toUpperCase() === asxCode.toUpperCase();
            }, this);

            return (filteredCodeMatches.length > 0) ? filteredCodeMatches[0] : null;
        },

        getSponsorDetailsDto: function () {

            var assetType = this.model.get('assetType');
            var isMF = assetType === this.assetTypeValues.managedFunds;
            var pidIndexList = this.view.getAllClientRowsForIndexinglds(isMF);
            var firstClientIndex = pidIndexList[0];

            // Initialize structure
            var sponsorDetailsObj = {
                'accNumber': null,
                'custodian': null,
                'hin': null,
                'pid': null,
                'srn': null
            };

            // Only populate if there are valid values
            if (!_.isUndefined(firstClientIndex)) {
                var assetFields = this.dataTypes[assetType];
                _.each(assetFields, function (attribute) {
                    var mappedAttr = this.sponsorAttributeMapping[attribute];
                    if (!_.isUndefined(mappedAttr)) {
                        sponsorDetailsObj[mappedAttr] = this.model.get(attribute + '_' + firstClientIndex);
                    }
                }, this);
            }

            return sponsorDetailsObj;
        },

        getSettlementRecords: function () {

            var settlementRecords = [];

            var assetType = this.model.get('assetType');
            var isMF = assetType === this.assetTypeValues.managedFunds;
            var clientListIds = this.view.getAllClientRowsForIndexinglds(isMF);
            var assetFields = this.dataTypes[assetType];

            // Iterate over the entered rows
            _.each(clientListIds, function (rowIndex) {

                // Iterate over the fields for a row
                var matchRecord = {};
                _.each(assetFields, function (fieldAttribute) {
                    var modelVal = this.model.get(fieldAttribute + '_' + rowIndex);

                    if (fieldAttribute === 'asxcode' || fieldAttribute === 'apircode') {
                        var asxObj = this.matchASXCodeToAsset(modelVal);
                        if (_.isNull(asxObj) && this.isAssetCodeValidationRequired()) {
                            asxObj = this.matchASXCodeToAsset(modelVal, true);
                        }
                        if (!_.isNull(asxObj)) {
                            matchRecord['assetId'] = asxObj.assetId;
                        } else {
                            matchRecord['assetCode'] = modelVal;
                        }
                    }

                    if (fieldAttribute === 'quantity' || fieldAttribute === 'mfquantity') {
                        matchRecord.quantity = modelVal;
                    }

                    matchRecord.type = 'SettlementRecordDtoImpl';

                }, this);
                settlementRecords.push(matchRecord);

            }, this);

            return settlementRecords;
        },

        getTransferData: function () {

            var assetType = this.model.get('assetType');
            var isCBO = this.model.get('cbo') === 'yes';

            var transferData = {
                'transferType': this.transferTypes[assetType],
                'sponsorDetails': this.getSponsorDetailsDto(),
                'settlementRecords': this.getSettlementRecords(),
                'taxParcels': null,
                'destContainerId': this.model.get('containerId'),
                'key': {},
                'isCBO': isCBO
            };
            if (!_.isUndefined(this.model.get('destAssetId'))) {
                transferData['destAssetId'] = this.model.get('destAssetId');
            }

            return transferData;
        },

        submitOrder: function () {
            if (!this.model.get('termsandconditions')) {
                this.viewChildren.termsandconditions.turnintoTooltip();
                return;
            }

            var transferData = this.getTransferData();
            transferData['warnings'] = this.model.get('submitwarnings');
            transferData['action'] = 'submit';

            var url = this.getUrl(rootController.getUrlParams(), this.vettingUrl);
            var params = {
                url: url,
                data: {
                    'transferDetails': JSON.stringify(transferData)
                },
                success: _.bind(function (data) {
                    this.parentController.model.set('transferId', data.data.key.transferId);
                    this.parentController.children.timeline.model.set('screenState', 'addDocuments');
                    this.parentController.showUploadDocuments();
                    this.view.hideSpinner();
                }, this)
            };
            this.view.showSpinner();

            return this.ajaxPost(params);
        },

        confirmClearData: function () {
            this.children.cancel.openModal();
        },

        resetRowList: function () {
            this.clearData();
            this.removeNonFilledRows();
            for (var i = 1; i < this.initialRows; i++) {
                this.addAsset();
            }
        },

        clearData: function () {
            var assetType = this.model.get('assetType');
            _.each(this.dataTypes[assetType], function (attribute) {
                _.each(this.model.attributes, function (val, key) {
                    if (key.indexOf(attribute) === 0 && key.indexOf('_') !== -1) {
                        this.model.set(key, '', {
                            'silent': true
                        });
                    }
                }, this);
            }, this);

            this.resetPreviewSubmitState();
            this.removeSelectedSponsor();
            this.refreshAssetTable();
            this.view.updateDynamicDisabledFields();
        },

        updateAllReplicateFields: function () {
            this.updateReplicateFields('hinaccount');
            this.updateReplicateFields('chess');
            this.updateReplicateFields('hin');
            this.updateReplicateFields('account');
            this.updateReplicateFields('custodian');
            this.updateReplicateFields('sponsorname');
        },

        autoCapitalizeAllFields: function () {
            this.autoCapitalizeFields('hinaccount');
            this.autoCapitalizeFields('asxcode');
            this.autoCapitalizeFields('chess');
            this.autoCapitalizeFields('hin');
            this.autoCapitalizeFields('srn');
            this.autoCapitalizeFields('account');
            this.autoCapitalizeFields('apircode');
        },

        dataChanged: function () {
            this.resetPreviewSubmitState();
            this.parentController.children.timeline.model.set('screenState', 'table');
        },

        dataBlurred: function () {
            this.updateAllReplicateFields();
            this.autoCapitalizeAllFields();
        },

        resetPreviewSubmitState: function () {
            this.model.set('termsandconditions', false);
            this.viewChildren.submit.hide();
            this.viewChildren.termsandconditions.hide();
            this.viewChildren.preview.show();
        },

        autoCapitalizeFields: function (filterAttr) {
            var pidList = _.map(this.model.attributes, function (attr, key) {
                return (key.indexOf(filterAttr + '_') !== -1) ? key : null;
            }, this);
            pidList = _.filter(pidList, function (pid) {
                return !_.isNull(pid);
            });

            if (pidList.length > 0) {
                var assetType = this.model.get('assetType');
                var isMF = assetType === this.assetTypeValues.managedFunds;
                var pidIndexList = this.view.getAllClientRowsForIndexinglds(isMF);

                _.each(pidIndexList, function (pidAttr) {
                    var modelAttr = filterAttr + '_' + pidAttr;
                    var pidVal = this.model.get(modelAttr);
                    if (!_.isUndefined(pidVal)) {
                        var uppercase = pidVal.toUpperCase();
                        this.model.set(modelAttr, uppercase);
                    }
                }, this);
            }
        },

        updateReplicateFields: function (filterAttr) {
            var pidList = _.map(this.model.attributes, function (attr, key) {
                return (key.indexOf(filterAttr + '_') !== -1) ? key : null;
            }, this);
            pidList = _.filter(pidList, function (pid) {
                return !_.isNull(pid);
            });

            if (pidList.length > 0) {
                pidList.sort();
                var firstPid = pidList[0];
                var isValid = this.model.validateValue(this.model.get(firstPid), firstPid).valid;
                var firstPidVal = (isValid) ? this.model.get(firstPid) : '';
                var assetType = this.model.get('assetType');
                var isMF = assetType === this.assetTypeValues.managedFunds;
                var pidIndexList = this.view.getAllClientRowsForIndexinglds(isMF);

                _.each(pidIndexList, function (pidAttr, index) {
                    if (index !== 0) {
                        if (isValid) {
                            this.model.set(filterAttr + '_' + pidAttr, firstPidVal);
                        } else {
                            this.model.unset(filterAttr + '_' + pidAttr);
                        }
                    }
                }, this);
            }
        },

        updatePreviewSubmitButtonState: function () {
            var amendContainer = this.view.getTransferFormContainer();
            var isValid = this.validateForm(amendContainer, 'change');

            if (isValid) {
                this.viewChildren.preview.enable();
                this.viewChildren.submit.enable();
            } else {
                this.viewChildren.preview.disable();
                this.viewChildren.submit.disable();
            }
        },

        cancel: function () {
            this.model.set('termsandconditions', false);
            this.viewChildren.submit.hide();
            this.viewChildren.termsandconditions.hide();
            this.viewChildren.preview.show();
            this.clearData();
        },

        populateSponsorSelector: function () {
            if (!_.isUndefined(this.children.assets.children.sponsorselector)) {
                var sponsorselector = this.children.assets.children.sponsorselector;
                sponsorselector.renderMenuData(this._sortSponsors(this.parentController.model.get('chessSponsors')));
                if (this.model.get('sponsorname_0')) {
                    sponsorselector.model.set('sponsorselector', this.model.get('sponsorname_0'));
                    sponsorselector.view.showClearOption();
                }
                sponsorselector.model.on('change:sponsorselector', _.bind(this.selectSponsor, this));
                sponsorselector.model.validation['sponsorselector'] = this.model.validation['sponsorname'];
            }
        },

        _sortSponsors: function (sponsors) {
            if (!_.isUndefined(sponsors) && !_.isNull(sponsors) && _.isArray(sponsors)) {
                return _.sortBy(sponsors, function (obj) {
                    return obj.sponsorname.toLowerCase();
                });
            }

            return sponsors;
        },

        selectSponsor: function () {
            if (!_.isUndefined(this.children.assets.children.sponsorselector)) {
                var sponsorselector = this.children.assets.children.sponsorselector.model.get('sponsorselector');
                if (_.isObject(sponsorselector)) {
                    this.model.set('sponsorname_0', sponsorselector.sponsorname);
                    this.model.set('sponsorselector', sponsorselector.sponsorname);
                    this.model.set('chess_0', sponsorselector.sponsorpid);
                } else if (sponsorselector === "") {
                    this.model.set('sponsorname_0', "");
                    this.model.set('chess_0', "");
                }

                if (this.model.get('sponsorname_0') === "") {
                    this.model.set("sponsorselector", '');
                }
            }
        },

        removeSelectedSponsor: function () {
            this.model.unset('sponsorname_0');
            this.model.unset('chess_0');
        }

    });
});
