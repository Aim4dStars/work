defineMvcController({
    name: 'advicefee',
    parentPath: 'mvc-screens/ip/account/fees/manage/details',
    viewHtml: true,
    viewComponents: ['tooltip'],
    screens: ['dollarfee', 'percentagefee', 'slidingscalefee'],
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

        preRender: function () {
            this.model.set('name', this.name);
            this.disabledComponents = [];
        },

        postRender: function () {
            if (this.model.get('data.feesComponent')) {
                var feesComponent = this.model.get('data.feesComponent');
                for (var j in feesComponent) {
                    if (feesComponent[j].type === 'DollarFee') {
                        this._addToDisabled('dollarfee');
                    } else if (feesComponent[j].type === 'PercentageFee') {
                        this._addToDisabled('percentagefee');
                    } else if (feesComponent[j].type === 'SlidingScaleFee') {
                        this._addToDisabled('slidingscalefee');
                    }
                }
            }
            this._disableComponents();
        },

        getValues: function (type) {
            var data = {
                feesComponent: []
            };
            for (var child in this.children) {
                if (this.children[child].displayed) {
                    var feeComp = this.children[child].getValues();
                    if (!feeComp.valid) {
                        return false;
                    } else {
                        data.feesComponent.push(feeComp.value);
                    }
                }
            }
            data.type = type;
            return data;
        },

        addDollarComponent: function () {
            var newData = {
                cpiindex: false,
                amount: '',
                date: null,
                name: this.name + 'advicefeedollarfee',
                type: 'DollarFee',
                label: 'Dollar fee component'
            };
            this._addComponent('dollarfee', newData);
        },

        addPercentageComponent: function () {
            var newData = {
                name: this.name + 'advicefeepercentagefee',
                type: 'PercentageFee',
                label: 'Percentage fee component',
                managedPortfolio: '',
                termDeposit: '',
                cash: ''
            };

            this._addComponent('percentagefee', newData);
        },

        addSlidingscaleComponent: function () {
            var newData = {
                assetTypes: ['Cash', 'Term Deposit', 'Managed Portfolios'],
                slidingScaleFeeTier: [
                    {
                        lowerBound: 0,
                        upperBound: '',
                        percentage: '',
                        type: 'SlidingScaleFeeTier'
                    }, {
                        lowerBound: '',
                        upperBound: null,
                        percentage: '',
                        type: 'SlidingScaleFeeTier'
                    }
                ],
                minimumFee: null,
                maximumFee: null,
                label: 'Sliding scale fee component',
                type: 'SlidingScaleFee',
                name: this.name + 'advicefeeslidingscalefee'
            };

            this._addComponent('slidingscalefee', newData);
        },

        _addComponent: function (childName, newData) {
            var existingFeesComp = [];
            for (var child in this.children) {
                if (this.children && this.children[child] && this.children[child].displayed) {
                    var feeComp = this.children[child].getValues();
                    existingFeesComp.push(feeComp.value);
                }
            }
            if (childName === 'dollarfee') {
                //add it to the starting
                existingFeesComp.unshift(newData);
            } else {
                //add it to the end
                existingFeesComp.push(newData);
            }
            this.model.set('data.feesComponent', existingFeesComp);
            this._addToDisabled(childName);
            this.removeChildren();
            this.view.removeComponents(this.view.el);
            this.view.render();
        },

        deleteChildCell: function (childName) {
            if (this.disabledComponents.indexOf(childName) > -1) {
                var index = this.disabledComponents.indexOf(childName);
                this.disabledComponents.splice(index, 1);
            }
            var existingFeesComp = this.model.get('data.feesComponent');
            if (childName === 'dollarfee') {
                //delete the first element
                existingFeesComp.shift();
            } else {
                //remove the last element
                existingFeesComp.pop();
            }
            this.children[childName].hide();
            this._enableComponents(childName);
        },

        _disableComponents: function () {
            for (var component in this.disabledComponents) {
                if (this.disabledComponents[component]) {
                    if (this.disabledComponents[component] === 'dollarfee') {
                        this.viewChildren[this.name + 'dollarcomponent'].disable();
                    } else {
                        this.viewChildren[this.name + 'percentagecomponent'].disable();
                        this.viewChildren[this.name + 'slidingscalecomponent'].disable();
                    }
                }
            }
        },

        _addToDisabled: function (value) {
            if (this.disabledComponents.indexOf(value) === -1) {
                this.disabledComponents.push(value);
            }
        },

        _enableComponents: function (childName) {
            if (childName === 'dollarfee') {
                this.viewChildren[this.name + 'dollarcomponent'].enable();
            } else {
                this.viewChildren[this.name + 'percentagecomponent'].enable();
                this.viewChildren[this.name + 'slidingscalecomponent'].enable();
            }
        }

    });
});
