define([
    'MvcView',
    'handlebars'
], function (MvcView, Handlebars) {
    'use strict';

    return MvcView.extend({

        rootTemplate: {
            headerPanel: 'Fees'
        },
        preRender: function () {
            var percentLabel = false;

            Handlebars.registerHelper('ifPercentLabel', function (options) {
                if (percentLabel) {
                    return options.inverse(this);
                } else {
                    percentLabel = true;
                    return options.fn(this);
                }
            });

            Handlebars.registerHelper('percentLabelReset', function () {
                percentLabel = false;
            });
        }
    });
});
