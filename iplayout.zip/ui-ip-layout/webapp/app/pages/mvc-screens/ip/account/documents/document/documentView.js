define([
    'MvcView',
    'handlebars',
    'text!app/pages/mvc-screens/ip/account/documents/document/_partials/_documentbar.html'
], function (MvcView, Handlebars, documentBarTemplate) {
    'use strict';

    return MvcView.extend({


        preRender: function () {
            Handlebars.registerPartial('document-bar', documentBarTemplate);
        },

        hideUploadSearchBar: function () {
            this.$el.find('.js-upload-search-bar').hide();
        },

        _clearFileInput: function ($file) {
            $file.replaceWith($file.clone(true));
        },

        getFileInput: function () {
            var $file = this.$el.find('input[name=docupload]');
            this._clearFileInput($file);
            return $file[0].files[0];
        },

        clickFilePicker: function () {
            this.$el.find('input[name=docupload]').click();
        }

    });
});
