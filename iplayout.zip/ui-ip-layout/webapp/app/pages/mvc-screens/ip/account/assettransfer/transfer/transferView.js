define([
    'MvcView',
], function (MvcView) {
    'use strict';

    return MvcView.extend({

        showAssetType: function () {
            this.$el.find('.assettype').show();
        },
        hideAssetType: function () {
            this.$el.find('.assettype').hide();
        },
        showTransferInfo: function () {
            this.$el.find('.transferinfo').show();
        },
        hideTransferInfo: function () {
            this.$el.find('.transferinfo').hide();
        },
        showManagedPortfolio: function () {
            this.$el.find('.managedportfolio').show();
        },
        hideManagedPortfolio: function () {
            this.$el.find('.managedportfolio').hide();
        },
        showTailoredPortfolio: function () {
            this.$el.find('.tailoredportfolio').show();
        },
        hideTailoredPortfolio: function () {
            this.$el.find('.tailoredportfolio').hide();
        },
        showCBO: function () {
            this.$el.find('.cbo').show();
        },
        hideCBO: function () {
            this.$el.find('.cbo').hide();
        },
        showTable: function () {
            this.$el.find('.mvc-transferform').show();
            this.$el.find('.generate-transfer-form').hide();
        },
        hideTable: function () {
            this.$el.find('.mvc-transferform').hide();
            this.$el.find('.generate-transfer-form').show();
        },
        hideTransferForm: function () {
            this.$el.find('.mvc-transferform').hide();
        },
        hideUploadDocuments: function () {
            this.$el.find('.mvc-uploaddocuments').hide();
        },
        showPMMessage: function () {
            this.$el.find('.pmmessage').show();
        },
        hidePMMessage: function () {
            this.$el.find('.pmmessage').hide();
        },
        hideGenerateTransferForm: function () {
            this.$el.find('.generate-transfer-form').hide();
        },
        addDocumentsState: function () {
            this.$el.find('.header-container').addClass("add-documents-state");
        },
        removeDocumentsState: function () {
            this.$el.find('.header-container').removeClass("add-documents-state");
        }

    });
});
