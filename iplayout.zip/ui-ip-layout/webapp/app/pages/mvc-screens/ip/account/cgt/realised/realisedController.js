defineMvcController({
        name: 'realised',
        parentPath: 'mvc-screens/ip/account/cgt',
        viewHtml: true,
        modelJs: true,
        viewJs: true,
        viewComponents: ['search', 'forminputdaterange'],
        mvcComponents: ['tableoptions'],
        screens: ['realisedportfolio', 'realisedsecurity'],
        hashName: 'realised',
        extend: 'app/pages/mvc-screens/ip/account/cgt/cgtBaseController',
        dependencies: ['rootController', 'underscore']
    },
    function (config, CgtBaseController, rootController, _) {
        'use strict';

        return CgtBaseController.extend({
            config: config,
            viewByChildren: ['realisedportfolio', 'realisedsecurity'],
            defaultViewBy: 'realisedportfolio',
            defaultTotalColumns: [20, 7, 7, 7],
            showParcelsTotalColumns: [24, 5, 6, 6],
            showTaxDetailsTotalColumns: [24, 6, 6, 24],

            preRender: function () {
                this.model.initialize();
            },

            getFetchParams: function () {
                var startDate = this.model.get('startdate');
                var endDate = this.model.get('enddate');
                if (_.isUndefined(startDate) && _.isUndefined(endDate)) {
                    this.model.init();
                }
                var url = "start-date=" + encodeURIComponent(this.model.startDateString());
                url += "&end-date=" + encodeURIComponent(this.model.endDateString());
                return url;
            },

            buildPdfLink: function () {
                var url = '../reportpdf/realisedCapitalGainsTaxReportV2';

                url += '?account-id=' + rootController.getUrlParams().a;
                url += '&start-date=' + encodeURIComponent(this.model.startDateString());
                url += '&end-date=' + encodeURIComponent(this.model.endDateString());
                url += '&order-by=' + this.getOrderBy();

                window.open(url, '_report');
            },

            buildCsvLink: function () {

                var url = '../reportcsv/realisedCapitalGainsTaxCsvReport';
                url += '?account-id=' + rootController.getUrlParams().a;
                url += '&start-date=' + encodeURIComponent(this.model.startDateString());
                url += '&end-date=' + encodeURIComponent(this.model.endDateString());

                window.open(url, '_report');
            }

        });

    });
