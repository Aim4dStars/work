defineMvcController({
    name: 'transferform',
    parentPath: 'mvc-screens/ip/account/assettransfer/inspecie',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    hashName: 'transfer',
    viewComponents: ['snapshot', 'inputtext', 'termsandconditions', 'messagedisclaimer', 'tooltip', 'forminputautocomplete'],
    mvcComponents: ['tablev3', 'inputautocomplete'],
    screens: ['terms', 'cancel', 'transferassets'],
    extend: 'MvcController',
    dependencies: ['app/framework/services/Permissions', 'rootController', 'jquery', 'underscore', 'app/pages/mvc-screens/ip/account/assettransfer/inspecie/transferform/transferformSubmit', 'app/framework/router', 'app/pages/mvc-screens/ip/account/assettransfer/util/tradableassetsService']
}, function (config, MvcController, Permissions, rootController, $, _, transferformSubmit, router, tradableassetsService) {
    'use strict';

    var controller = MvcController.extend({
        config: config,
        showOnInit: false,
        isAssetCodeValid: true,
        doHideWarnings: false,
        autoHideSpinner: false,
        universalAssetListURL: '../api/v1_0/assets',
        assetTables: [],

        sponsorAttributeMapping: {
            'account': 'accNumber',
            'hinaccount': 'hin',
            'custodian': 'custodian',
            'hin': 'hin',
            'pid': 'pid',
            'srn': 'srn'
        },

        transferTypes: {
            listedSecurityChessSponsored: 'Listed Securities Broker Sponsored',
            listedSecuritiesIssuerSponsored: 'Listed Securities Issuer Sponsored',
            managedFunds: 'Managed Funds',
            listedsecuritycustodian: 'Listed Securities Other Platform or Custodian',
            assetsFromOtherPlatform: 'Assets from other platform or Custodian'
        },

        preRender: function () {
            var data = this.parentController.model.get('transferFormData');
            this.model.set(data);

            // Keep available assets out of the model because it's so large that it causes massive performance issues
            $.when(this.loadAssetsForManualEntry())
                .done(_.bind(function (tradableAssets) {
                    var availableAssets = _.map(tradableAssets, function (tradableAsset) {
                        return tradableAsset.asset;
                    });
                    this.availableAssets = availableAssets;
                    this.view.hideSpinner();
                }, this));
        },

        loadAssetsForManualEntry: function () {
            var sourceFilter = this.model.get('sourceFilter');
            var assetTypeFilter;

            if (sourceFilter === 'listedSecurities') {
                assetTypeFilter = tradableassetsService.assetTypeFilter.shares;
            } else if (sourceFilter === 'managedFunds') {
                assetTypeFilter = tradableassetsService.assetTypeFilter.funds;
            } else if (sourceFilter === 'listedSecuritiesAndManagedFunds') {
                assetTypeFilter = tradableassetsService.assetTypeFilter.sharesAndFunds;
            }

            return tradableassetsService.getTradableAssets(this, assetTypeFilter);
        },

        postRender: function () {
            this.model.set('accountId', rootController.getUrlParams().a);
            this.populateTitle();
            this.populateCBO();
            this.populateTarget();
            this.populateAllAssetTables();
            this.populateFooter();
            this.model.on('change', function () {
                rootController.confirmNavigation(true);
            }, this);
        },

        populateTitle: function () {
            var assetSource = this.model.get('assetSource');
            var assetSourceName;
            if (assetSource === 'listedSecurityChessSponsored') {
                assetSourceName = 'Listed securities – CHESS sponsored';
            } else if (assetSource === 'listedSecuritiesIssuerSponsored') {
                assetSourceName = "Listed securities – issuer sponsored";
            } else if (assetSource === 'managedFunds') {
                assetSourceName = "Managed funds – held with fund manager";
            } else if (assetSource === 'assetsFromOtherPlatform') {
                assetSourceName = "Investments held on other platform or custodian";
            }

            this.model.set('assetSourceName', assetSourceName);
        },

        populateCBO: function () {
            var cbo = this.model.get('cbo');
            var cbolabel = cbo === 'yes' ? 'Yes' : 'No';
            this.model.set('cbolabel', cbolabel);
        },

        populateTarget: function () {
            var managedPortfolio = this.model.get('managedPortfolio');
            var tailoredPortfolio = this.model.get('tailoredPortfolio');
            if (!managedPortfolio && !tailoredPortfolio) {
                this.view.hideManagedPortfolio();
            } else if (!tailoredPortfolio) {
                this.model.set('portfolioCode', managedPortfolio.assetCode);
            } else {
                this.model.set('portfolioCode', tailoredPortfolio.assetCode);
            }
        },

        populateAllAssetTables: function () {
            var children = _.keys(this.children);
            var assetTables = _.filter(children, function (child) {
                return child.indexOf('transferassets') === 0;
            });

            this.assetTables = assetTables;
            var assetSource = this.model.get('assetSource');
            if (assetSource === 'assetsFromOtherPlatform' && assetTables.length === 2) {
                this.populateAssetTable(this.children[assetTables[0]], 'listedSecurityChessSponsored');
                this.populateAssetTable(this.children[assetTables[1]], 'managedFunds');
            } else if (assetTables.length === 1) {
                this.populateAssetTable(this.children[assetTables[0]], assetSource);
            }
        },

        populateAssetTable: function (child, assetSource) {
            child.model.set({
                assetSource: assetSource,
                availableAssets: this.availableAssets,
                managedPortfolio: this.model.get('managedPortfolio'),
                tailoredPortfolio: this.model.get('tailoredPortfolio')
            });

            child.removeChildren();
            child.removeViewChildren();
            child.view.render();
        },

        populateFooter: function () {
            this.viewChildren.submit.hide();
            this.viewChildren.termsandconditions.hide();
        },

        resetData: function () {
            this.children.cancel.openModal({
                removeall: true
            });
        },

        resetRowList: function () {
            this.viewChildren.uierror.hide();
            this.viewChildren.uiwarning.hide();
            this.applyToTransferAssets(function (transferassets) {
                transferassets.resetRowList();
            });
        },

        clearData: function () {
            this.applyToTransferAssets(function (transferassets) {
                transferassets.clearData();
            });
        },

        applyToTransferAssets: function (func) {
            var children = _.keys(this.children);
            var assetTables = _.filter(children, function (child) {
                return child.indexOf('transferassets') === 0;
            });

            var assetSource = this.model.get('assetSource');
            if (assetSource === 'assetsFromOtherPlatform') {
                func(this.children[assetTables[0]]);
                func(this.children[assetTables[1]]);
            } else {
                func(this.children[assetTables[0]]);
            }
        },

        dataChanged: function () {
            this.resetPreviewSubmitState();
        },

        resetPreviewSubmitState: function () {
            this.model.set('termsandconditions', false);
            this.viewChildren.submit.hide();
            this.viewChildren.termsandconditions.hide();
            this.viewChildren.preview.show();
        },

        updatePreviewSubmitButtonState: function () {
            var amendContainer = this.view.getTransferFormContainer();
            var isValid = this.validateForm(amendContainer, 'change');

            if (isValid) {
                this.viewChildren.preview.enable();
                this.viewChildren.submit.enable();
            } else {
                this.viewChildren.preview.disable();
                this.viewChildren.submit.disable();
            }
        },

        onBackClicked: function () {
            this.children.cancel.openModal();
        },

        onCancelClicked: function () {
            this.children.cancel.openModal();
        },

        back: function () {
            rootController.confirmNavigation(false);
            router.appRouter.navigate('#ng/account/assettransfer/inspecie' + rootController.getUrlParamString(), {
                trigger: true,
                replace: true
            });
        },

        openAssetTransferSupport: function () {
            var assettransferHelpUrl = this.model.get('assettransferHelpUrl');
            window.open(assettransferHelpUrl, 'Asset Transfer');
        },

    });

    _.extend(controller.prototype, transferformSubmit);
    return controller;
});
