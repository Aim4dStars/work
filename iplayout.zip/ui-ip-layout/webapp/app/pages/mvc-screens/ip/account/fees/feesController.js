defineMvcController({
    name: 'fees',
    parentPath: 'mvc-screens/ip/account',
    viewHtml: true,
    viewJs: true,
    modelJs: true,
    screens: ['schedule', 'manage', 'chargeoneoff', 'taxinvoices', 'cancel', 'administration'],
    viewComponents: ['menutabs'],
    hashName: 'fees',
    extend: 'MvcController',
    dependencies: ['rootController', 'underscore', 'app/framework/helpers/format']
}, function (config, MvcController, rootController, _, format) {
    'use strict';

    return MvcController.extend({
        config: config,
        urlTemplate: '../api/v1_0/fees/accounts/<%=a%>',

        getData: function () {
            var urlParams = rootController.getUrlParams();
            if (urlParams) {
                this.model.set('accountId', urlParams.p);
            }

            if (this) {
                this._setErrorMessage();
            }
            var params = {};
            params.url = this.getUrl(rootController.getUrlParams(), this.urlTemplate);
            params.success = _.bind(function (data) {
                if (data && data.data) {
                    this.model.set('data', data.data);
                    var notNullData = this.removeNull(data.data);
                    var scheduleData = this.model.getScheduleData(notNullData);
                    if (!_.isNull(this.model.get('scheduleData'))) {
                        this.model.set('scheduleData', null);
                    }
                    this.model.set('scheduleData', scheduleData);
                    var adminData = this.model.getAdminData(notNullData);
                    adminData.investmentMgmtFees = this.formatManagementData(adminData.investmentMgmtFees);
                    if (!_.isNull(this.model.get('adminData'))) {
                        this.model.set('adminData', null);
                    }
                    this.model.set('adminData', adminData);

                    var contributionFees = this.getContributionFees(notNullData);
                    if (!_.isNull(this.model.get('contributionFees'))) {
                        this.model.set('contributionFees', null);
                    }
                    if (contributionFees.oneoffFees.length > 0 || contributionFees.regularFees.length > 0) {
                        this.model.set('contributionFees', contributionFees);
                    }
                }
            }, this);
            params.error = _.bind(function (jqXHR, textStatus, errorThrown) {
                if (this) {
                    this._setErrorMessage(errorThrown);
                }
            }, this);
            return this.ajaxGet(params);
        },

        getContributionFees: function (data) {
            return this.model.getContributionFees(data);
        },

        _setErrorMessage: function (errorThrown) {
            if (errorThrown === 'timeout') {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0368'));
            } else {
                this.model.set('ajaxerrormessage', rootController.getCmsEntry('Err.IP-0344'));
            }
        },

        _showErrorMessage: function () {
            if (this.viewChildren && this.viewChildren.ajaxerror) {
                this.viewChildren.ajaxerror.show();
            }
        },

        _hideErrorMessage: function () {
            if (this.viewChildren && this.viewChildren.ajaxerror) {
                this.viewChildren.ajaxerror.hide();
            }
        },

        formatPercentageData: function (data) {
            var values = ['Listed securities', 'Managed funds', 'Managed portfolios', 'Term deposits', 'Cash'];
            var percentageData = [];
            var row;
            _.each(values, function (label) {
                row = {};
                row.type = label;
                switch (label) {
                case 'Listed securities':
                    row.percentage = data.share;
                    break;
                case 'Managed funds':
                    row.percentage = data.managedFund;
                    break;
                case 'Managed portfolios':
                    row.percentage = data.managedPortfolio;
                    break;
                case 'Term deposits':
                    row.percentage = data.termDeposit;
                    break;
                default:
                    row.percentage = data.cash;
                }
                if (label === 'Managed funds' || label === 'Listed securities') {
                    percentageData.push(row);
                } else {
                    percentageData.push(row);
                }
            }, this);
            return percentageData;
        },

        formatPercentageAdminData: function (data) {
            var percentageData = [];
            var row;
            _.each(data.assetClasses, function (component) {
                row = {};
                row.type = component;
                row.percentage = data.tariffFactor;
                percentageData.push(row);
            }, this);
            return percentageData;
        },

        formatManagementData: function (data) {
            return this.dividePmfAndImfData(data);
        },

        dividePmfAndImfData: function (data) {
            var managementData = [],
                pmfData = {},
                clubbedData = {};
            var percentTotalData = this.getTotalPercentDataIforManagementFee(data);

            pmfData.percentageComponent = [];
            pmfData.slidingScaleComponent = [];
            var row, countObject = [];
            _.each(data, function (dataElement) {
                if (dataElement.feeType === 'INVESTMENT_MANAGEMENT_FEE' && !_.contains(countObject, dataElement.ipsId + "IM")) {

                    row = {};
                    row.investmentName = dataElement.investmentName;
                    row.apirCode = dataElement.apirCode;
                    row.percent = percentTotalData[dataElement.ipsId + "IM"];
                    managementData.push(row);
                    countObject.push(dataElement.ipsId + "IM");


                } else if (dataElement.feeType === 'PORTFOLIO_MANAGEMENT_FEE' && !_.contains(countObject, dataElement.ipsId + "PM")) {

                    if (!_.isNull(dataElement.percent)) {
                        row = {};
                        row.investmentName = dataElement.investmentName;
                        row.apirCode = dataElement.apirCode;
                        row.percent = percentTotalData[dataElement.ipsId + "PM"];
                        row.code = dataElement.code;
                        row.ipsId = dataElement.ipsId;
                        row.subaccountId = dataElement.subaccountId;
                        pmfData.percentageComponent.push(row);
                        countObject.push(dataElement.ipsId + "PM");
                    } else if (!_.isEmpty(dataElement.slidingScaleFeeTier) && !_.isEmpty(dataElement.slidingScaleFeeTier)) {
                        row = {};
                        row.investmentName = dataElement.investmentName;
                        row.apirCode = dataElement.apirCode;
                        row.code = dataElement.code;
                        row.ipsId = dataElement.ipsId;
                        row.subaccountId = dataElement.subaccountId;
                        row.percent = percentTotalData[dataElement.ipsId + "PM"];
                        row.slidingScaleFeeTier = this.formatSlidingScaleData(dataElement.slidingScaleFeeTier);
                        pmfData.slidingScaleComponent.push(row);
                    }

                }
            }, this);
            if (!_.isEmpty(pmfData.slidingScaleComponent) || !_.isEmpty(pmfData.percentageComponent)) {
                clubbedData.pmfData = pmfData;
            }
            if (!_.isEmpty(managementData)) {
                clubbedData.managementData = managementData;
            }
            return clubbedData;
        },
        getTotalPercentDataIforManagementFee: function (data) {
            var percentData = {};
            _.each(data, function (dataElement) {
                if (dataElement.feeType === 'INVESTMENT_MANAGEMENT_FEE') {
                    if (_.isNull(percentData[dataElement.ipsId + "IM"]) || _.isUndefined(percentData[dataElement.ipsId + "IM"])) {
                        percentData[dataElement.ipsId + "IM"] = dataElement.percent;
                    } else {
                        percentData[dataElement.ipsId + "IM"] = percentData[dataElement.ipsId + "IM"] + dataElement.percent;
                    }
                } else if (dataElement.feeType === 'PORTFOLIO_MANAGEMENT_FEE') {
                    if (_.isNull(percentData[dataElement.ipsId + "PM"]) || _.isUndefined(percentData[dataElement.ipsId + "PM"])) {
                        percentData[dataElement.ipsId + "PM"] = dataElement.percent;
                    } else {
                        percentData[dataElement.ipsId + "PM"] = percentData[dataElement.ipsId + "PM"] + dataElement.percent;
                    }
                }
            }, this);
            return percentData;
        },


        formatSlidingScaleData: function (data) {
            var slidingScaleData = [];
            var option = {};
            _.each(data, function (label) {
                option = {};
                option.tiers = ((label.lowerBound === 0 ? format.formatMoney(label.lowerBound, 0) : (label.upperBound ? 'Over ' + format.formatMoney(label.lowerBound, 0) : 'Balance over ' + format.formatMoney(label.lowerBound, 0))) + (label.upperBound ? ' - ' + format.formatMoney(label.upperBound, 0) : ''));
                option.from = (_.isNaN(parseFloat(label.lowerBound))) ? '' : parseFloat(label.lowerBound);
                option.to = (_.isNaN(parseFloat(label.upperBound))) ? '' : parseFloat(label.upperBound);
                option.percentage = (_.isNaN(parseFloat(label.percentage))) ? '' : label.percentage;
                slidingScaleData.push(option);
            }, this);
            if (slidingScaleData.length > 1 && slidingScaleData[slidingScaleData.length - 1] && slidingScaleData[slidingScaleData.length - 1].from === '') {
                slidingScaleData.splice(slidingScaleData.length - 1, 1);
            }
            return slidingScaleData;
        },

        removeNull: function (data) {
            var formatedData = {};
            formatedData.fees = data.fees;
            formatedData.investmentMgmtFees = data.investmentMgmtFees;
            var that = this;
            var i = 0;
            if (data.fees && !_.isUndefined(data.fees)) {
                _.each(data.fees, function (fee) {
                    var feesComponent = [];
                    if (!_.isUndefined(fee) && !_.isNull(fee)) {
                        if (!_.isUndefined(fee.feesComponent) && fee.feesComponent.length !== 0) {
                            _.each(fee.feesComponent, function (component) {
                                switch (component.type) {
                                case 'DollarFee':
                                    if (!_.isNull(component.amount) && component.amount !== 0) {
                                        feesComponent.push(component);
                                    }
                                    break;
                                case 'PercentageFee':
                                case 'FlatPercentageFee':
                                    if (that.ifNullCheck(component)) {
                                        feesComponent.push(component);
                                    }
                                    break;
                                case 'SlidingScaleFee':
                                    if (!_.isNull(component.slidingScaleFeeTier)) {
                                        if (that.allZerroCheck(component)) {
                                            feesComponent.push(component);
                                        }
                                    }
                                    break;
                                case 'GlobalFee':
                                    that.globalComponentNullCheck(component, feesComponent);
                                    break;
                                }
                            });
                            if (formatedData.fees[i]) {
                                formatedData.fees[i].feesComponent = feesComponent;
                            }
                        }
                    } else {
                        formatedData.fees.splice(i, 1);
                        if (i > 0) {
                            i--;
                        }
                    }
                    i++;
                });
            }
            return formatedData;
        },
        globalComponentNullCheck: function (component, feesComponent) {
            if ((component.share === false) && (component.managedFund === false) && (component.managedPortfolio === false) && (component.termDeposit === false) && (component.cash === false)) {
                return;
            } else {
                if ((component.minimumFee > 0) || (component.maximumFee > 0)) {
                    feesComponent.push(component);
                }
            }

        },
        allZerroCheck: function (obj) {
            var count = 0;
            _.each(obj.slidingScaleFeeTier, function (tier) {
                if (parseFloat(tier.percentage).toFixed(2) === "0.00") {
                    count++;
                }
            });
            if (count === obj.slidingScaleFeeTier.length) {
                if (obj.minimumFee > 0 || obj.maximumFee > 0) {
                    obj.slidingScaleFeeTier = null;
                    return true;
                } else {
                    return false;
                }
            } else {
                return true;
            }
        },

        _isNullOrZero: function (val) {
            return val === null || val === 0;
        },
        ifNullCheck: function (component) {
            if (component.name === "administrationfeepercentagefee" || component.name === "trusteefeepercentagefee") {
                if (!_.isNull(component.listAssets) && !_.isUndefined(component.listAssets)) {
                    return component.listAssets.length > 0 ? true : false;
                } else {
                    return false;
                }
            } else {
                var listNotNullOrZero = _.reject([component.share, component.managedFund, component.managedPortfolio, component.termDeposit, component.cash], this._isNullOrZero);
                return listNotNullOrZero.length > 0;
            }
        },
        formatData: function (feesData) {
            var data = feesData.fees;
            var feesComponent;
            var formattedData, dollarAvl, percentAvl, slidingAvl;
            if (data) {
                for (var i in data) {
                    if (data[i] && data[i].feesComponent) {
                        formattedData = [null, null, null];
                        dollarAvl = false;
                        percentAvl = false;
                        slidingAvl = false;
                        feesComponent = data[i].feesComponent;
                        for (var j in feesComponent) {
                            if (feesComponent[j].type === 'PercentageFee') {
                                formattedData[1] = feesComponent[j];
                                percentAvl = true;
                            } else if (feesComponent[j].type === 'SlidingScaleFee') {
                                formattedData[2] = feesComponent[j];
                                slidingAvl = true;
                            } else if (feesComponent[j].type === 'DollarFee') {
                                dollarAvl = true;
                                formattedData[0] = feesComponent[j];
                            }
                            if (feesComponent[j].spclDiscount) {
                                feesComponent[j].spclDiscount = format.formatMoney(feesComponent[j].spclDiscount, 2);
                            }
                        }
                        //If sliding scale component is not available then remove the last element
                        if (!slidingAvl) {
                            formattedData.pop();
                        }
                        //If percentage component is not available then shift sliding scale to the index 1
                        if (!percentAvl) {
                            if (slidingAvl) {
                                formattedData[1] = formattedData[2];
                            }
                            formattedData.pop();
                        }
                        //If dollar component is not available then remove the first element
                        if (!dollarAvl) {
                            formattedData.shift();
                        }
                        //At this point if the length is 2,
                        //then dollar is not avl and % or sliding is avl

                        data[i].feesComponent = formattedData;
                    }
                }
            }
        }
    });
});
