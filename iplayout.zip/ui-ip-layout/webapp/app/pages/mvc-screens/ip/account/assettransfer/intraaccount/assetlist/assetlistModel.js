define(['MvcModel', 'underscore', 'app/framework/helpers/format',
    'app/pages/mvc-screens/ip/account/assettransfer/util/valuationService'],
    function (MvcModel, _, format, valuationService) {
        'use strict';

        return MvcModel.extend({
            PENDING_EVENT_STATUS_CODE: 'btfg$ls_pend',
            EXCEED_QUANTITY_STATUS_CODE: 'btfg$xfer_qty_exceeded2',
            validation: {
                percentage: {
                    type: 'percent',
                    blur: {
                        required: false,
                        minValue: 0,
                        customFormat: 'customPercentageValidation'
                    }
                },
                units: {
                    priority: ['required', 'customFormat', 'minValue', 'maxValue'],
                    type: 'unit',
                    blur: {
                        required: false,
                        minValue: 0
                    }
                },
                dollars: {
                    priority: ['required', 'customFormat', 'minValue', 'maxValue'],
                    type: 'dollar',
                    blur: {
                        required: false,
                        minValue: 0
                    }
                },
                cashquantity: {
                    type: 'dollar',
                    blur: {
                        required: false,
                        minValue: 0
                    },
                    change: {
                        customMaxValue: 'cashMaxValue'
                    }
                }
            },

            customPercentageValidation: function () {
                return true;
            },

            removeExcessQuantityError: function (vettWarnings) {
                vettWarnings = _.filter(vettWarnings, function (errorObj) {
                    if (errorObj.errorId === this.EXCEED_QUANTITY_STATUS_CODE) {
                        var pendingEventError = _.find(vettWarnings, function (_error) {
                            return _error.domain === errorObj.domain && _error.errorId === this.PENDING_EVENT_STATUS_CODE;
                        }, this);
                        if (pendingEventError) {
                            return false;
                        }
                        return true;
                    }
                    return true;
                }, this);
                return vettWarnings;
            },

            sort: function (assetlistData, sortBy) {
                if (sortBy === 'groupByAssetType') {
                    assetlistData = _.sortBy(assetlistData, function (investment) {
                        return investment.categoryName;
                    });
                } else {
                    var cashAsset = valuationService.getCashAsset(assetlistData);
                    if (!_.isUndefined(cashAsset)) {
                        assetlistData = valuationService.removeCash(assetlistData);
                    }

                    if (sortBy === 'sortByAssetCode') {
                        assetlistData = _.sortBy(assetlistData, function (investment) {
                            return investment.investmentAsset.assetCode;
                        });
                    } else if (sortBy === 'sortByAssetName') {
                        assetlistData = _.sortBy(assetlistData, function (investment) {
                            return investment.investmentAsset.assetName.toUpperCase();
                        });
                    }
                    if (!_.isUndefined(cashAsset)) {
                        assetlistData.push(cashAsset);
                    }
                }
                return assetlistData;
            },

            convertQuantity: function (asset, oldOption, newOption, value) {
                if (!_.isUndefined(asset)) {
                    if (newOption === "percentage") {
                        value = this.convertToPercentage(asset, oldOption, value);
                    } else if (newOption === "dollars") {
                        value = this.convertToDollar(asset, oldOption, value);
                    } else if (newOption === "units") {
                        value = this.convertToUnits(asset, oldOption, value);
                    }
                }
                return value;
            },

            convertToPercentage: function (asset, oldOption, value) {
                if (oldOption === "dollars") {
                    value = (value * 100) / asset.investmentAsset.availableMarketValue;
                    return format.formatPercent(value / 100, 2);
                } else if (oldOption === "units") {
                    value = (value * 100) / asset.investmentAsset.availableQuantityHolding;
                    return format.formatPercent(value / 100, 2);
                }
            },

            convertToDollar: function (asset, oldOption, value) {
                if (oldOption === "percentage") {
                    value = (asset.investmentAsset.availableMarketValue * value) / 100;
                    return value.toFixed(2);
                } else if (oldOption === "units") {
                    value = (value * asset.investmentAsset.availableMarketValue) / asset.investmentAsset.availableQuantityHolding;
                    return value.toFixed(2);
                }
            },

            convertToUnits: function (asset, oldOption, value) {
                if (oldOption === "percentage") {
                    value = (asset.investmentAsset.availableQuantityHolding * value) / 100;
                    return Math.floor(value);
                } else if (oldOption === "dollars" && asset.investmentAsset.availableMarketValue !== 0) {
                    value = ((value * asset.investmentAsset.availableQuantityHolding).toFixed(6) / asset.investmentAsset.availableMarketValue).toFixed(6);
                    return Math.floor(value);
                }
            },

            removeVettErrors: function () {
                var assetlistData = this.get('assetlistData');
                _.each(assetlistData, function (asset) {
                    asset.vettErrors = [];
                    asset.vettWarnings = [];
                }, this);

                this.set('assetlistData', assetlistData);
            },

            getAssetObj: function (asset, transferAmount, quantityObj) {
                return {
                    asset: {
                        assetCode: asset.investmentAsset.assetCode,
                        assetName: asset.investmentAsset.assetName,
                        amount: transferAmount,
                        assetId: asset.assetId
                    },
                    isCashTransfer: false,
                    vettWarnings: asset.vettWarnings,
                    categoryName: asset.categoryName,
                    quantity: quantityObj.value
                };
            },

            getCashAsset: function (cashData, cashquantity) {
                return {
                    asset: {
                        assetName: cashData.name,
                        assetId: cashData.assetId
                    },
                    isCashTransfer: true,
                    quantity: cashquantity,
                };
            }

        });
    });
