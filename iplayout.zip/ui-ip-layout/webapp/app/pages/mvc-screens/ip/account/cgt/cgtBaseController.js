defineMvcController({
    name: 'cgtbase',
    viewHtml: false,
    modelJs: false,
    extend: 'MvcController',
    dependencies: ['rootController']
}, function (config, MvcController, rootController) {
    'use strict';

    return MvcController.extend({
        config: config,


        postRender: function () {
            // Preset the Tooltip messages for gain details
            var realisedGainMessageDetails = rootController.getCmsEntry('Help-IP-0149');
            var realisedGainMessageUsual = rootController.getCmsEntry('Help-IP-0150');
            var unrealisedGainMessageDetails = rootController.getCmsEntry('Help-IP-0151');
            var unrealisedGainMessageUsual = rootController.getCmsEntry('Help-IP-0152');
            this.model.set('realisedGainMessageDetails', realisedGainMessageDetails);
            this.model.set('realisedGainMessageUsual', realisedGainMessageUsual);
            this.model.set('unrealisedGainMessageDetails', unrealisedGainMessageDetails);
            this.model.set('unrealisedGainMessageUsual', unrealisedGainMessageUsual);

            this.model.on('change:viewBy', this.setViewBy, this);
            this.model.on('change:showParcels change:showTaxDetails change:sortBy', this.updateTable, this);
            this.model.set('viewBy', this.defaultViewBy);
        },

        setViewBy: function () {
            this.activeViewBy = this.model.get('viewBy');
            if (this.activeViewBy === this.viewByChildren[0]) {
                this.inactiveViewBy = this.viewByChildren[1];
            } else {
                this.inactiveViewBy = this.viewByChildren[0];
            }
            this.updateViewBy();
        },

        updateViewBy: function () {
            this.children[this.inactiveViewBy].hide();
            this.children[this.activeViewBy].show();
            this.children[this.activeViewBy].fetchData();
        },

        inputDateSearch: function (event) {
            var validationResult = this.validateAndSubmitForm(event);
            if (validationResult) {
                this.children[this.activeViewBy].fetchData();
            }
        },

        tableOptionsUpdated: function (data) {
            if (data.filters.showParcels) {
                this.children.tableoptions.viewChildren.showtaxdetails.enable();
            } else {
                this.children.tableoptions.model.set('showTaxDetails', null);
                this.children.tableoptions.disableFilters([this.children.tableoptions.viewChildren.showtaxdetails]);
            }

            this.model.set({
                'showParcels': data.filters.showParcels,
                'showTaxDetails': data.filters.showTaxDetails,
                'sortBy': data.sortBy,
                'viewBy': data.viewBy
            });
        },

        updateTable: function () {
            this.children[this.activeViewBy].populateScreen();
        },

        getFetchParams: function () {
            return "effective-date=" + encodeURIComponent(this.model.dateDetailsDateString());
        },

        getOrderBy: function () {

            var sortBy = this.model.get('sortBy');

            switch (sortBy) {
            case 'descendingGainLosses':
                return 'grossGain,desc';
            case 'ascendingGainLosses':
                return 'grossGain,asc';
            case 'descendingName':
                return 'assetName,desc';
            case 'ascendingName':
                return 'assetName,asc';
            default:
                return 'assetName,asc';
            }
        }
    });

});
