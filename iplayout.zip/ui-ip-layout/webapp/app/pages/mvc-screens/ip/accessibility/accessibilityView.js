define([
    'MvcView'
], function (MvcView) {
    'use strict';

    return MvcView.extend({

        rootTemplate: {
            headerPanel: 'Accessibility',
            fatFooter: false,
            headerMenu: false,
            summary: false
        }
    });
});
