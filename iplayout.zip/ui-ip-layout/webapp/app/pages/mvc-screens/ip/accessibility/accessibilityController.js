defineMvcController({
    name: 'accessibility',
    parentPath: 'mvc-screens/ip',
    viewHtml: true,
    viewJs: true,
    hashName: 'accessibility',
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config,

    });

});
