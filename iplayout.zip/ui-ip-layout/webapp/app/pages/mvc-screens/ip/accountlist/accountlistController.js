defineMvcController({
    name: 'accountlist',
    parentPath: 'mvc-screens/ip',
    viewHtml: true,
    hashName: 'accountlist',
    extend: 'MvcController'
}, function (config, MvcController) {
    'use strict';

    return MvcController.extend({
        config: config
    });

});
