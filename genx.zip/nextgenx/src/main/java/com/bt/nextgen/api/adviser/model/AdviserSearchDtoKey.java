package com.bt.nextgen.api.adviser.model;

public class AdviserSearchDtoKey
{
	private String search;

	public AdviserSearchDtoKey(String search)
	{
		this.search = search;
	}

	public String getSearch()
	{
		return search;
	}
}
