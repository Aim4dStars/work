/**
 * Package to hold the model used for the account api functions.
 *
 */
package com.bt.nextgen.api.account.v1.model;
