@Deprecated
package com.bt.nextgen.api.account.v2.model.allocation.sector;