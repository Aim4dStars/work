package com.bt.nextgen.api.account.v1.validation;

import com.bt.nextgen.core.api.validation.ErrorMapper;

/**
 * @deprecated Use V2
 */
@Deprecated
public interface BpayBillerDtoErrorMapper extends ErrorMapper {
}
