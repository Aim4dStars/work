package com.bt.nextgen.api.account.v3.validation;

import com.bt.nextgen.core.api.validation.ErrorMapper;

public interface BpayBillerDtoErrorMapper extends ErrorMapper {
}
