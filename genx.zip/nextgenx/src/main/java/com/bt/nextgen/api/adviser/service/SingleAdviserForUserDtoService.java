package com.bt.nextgen.api.adviser.service;

import com.bt.nextgen.api.adviser.model.SingleAdviserForUserDto;
import com.bt.nextgen.core.api.dto.FindOneDtoService;


public interface SingleAdviserForUserDtoService extends FindOneDtoService<SingleAdviserForUserDto> {
}
