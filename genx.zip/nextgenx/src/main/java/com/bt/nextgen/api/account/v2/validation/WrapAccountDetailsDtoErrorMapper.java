package com.bt.nextgen.api.account.v2.validation;

import com.bt.nextgen.core.api.validation.ErrorMapper;

@Deprecated
public interface WrapAccountDetailsDtoErrorMapper extends ErrorMapper
{

}
