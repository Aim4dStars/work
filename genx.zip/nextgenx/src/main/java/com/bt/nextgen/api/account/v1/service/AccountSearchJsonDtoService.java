/**
 *
 */
package com.bt.nextgen.api.account.v1.service;

import com.bt.nextgen.api.client.model.JsonItemDto;
import com.bt.nextgen.core.api.dto.SearchByCriteriaDtoService;

/**
 * @author L095519 created on 07.07.2017
 *
 */
public interface AccountSearchJsonDtoService extends SearchByCriteriaDtoService<JsonItemDto>{

}