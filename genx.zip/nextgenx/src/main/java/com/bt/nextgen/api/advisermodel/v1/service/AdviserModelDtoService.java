package com.bt.nextgen.api.advisermodel.v1.service;

import com.bt.nextgen.api.asset.model.AssetDto;
import com.bt.nextgen.core.api.dto.FindOneDtoService;

public interface AdviserModelDtoService extends FindOneDtoService<AssetDto> {

}
