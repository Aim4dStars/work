package com.bt.nextgen.api.account.v2.service;

import com.bt.nextgen.api.account.v2.model.AccountKey;
import com.bt.nextgen.api.account.v2.model.TermDepositAccountDto;
import com.bt.nextgen.core.api.dto.UpdateDtoService;

@Deprecated
public interface TermDepositAccountDtoService extends UpdateDtoService <AccountKey, TermDepositAccountDto>
{

}
